"""
tl_portfolio.py - tradelab v1: the money layer.

Takes the simulated trades (their fills, in time order) and runs them through one account:
  - each trade's TARGET size is set when its first buy happens, from the equity at the previous close:
        equal_slots  equity / slots                      (default: 15 slots = 3 new picks a day x 5 days)
        pct_equity   pct x equity
        fixed        a fixed rupee amount
        atr_risk     risk_pct x equity / (atr_mult x the stock's ATR14% on the signal day), capped
        expression   any rule over equity, cash, open_positions, signal_atr14_pct and the pick's attributes
    then capped by max_pct of equity and, optionally, a share of the stock's 20-session median turnover;
  - each entry leg buys its fraction of the target (integer shares by default); when cash cannot fund a leg it
    buys what cash allows, unless that is below min_order_frac of the leg (then the leg is skipped);
  - each exit sells its fraction of the shares held; costs from the strategy's cost model (in rupees);
  - optional limits: max_new_per_day, max_open (concurrent trades), allow_duplicates.
Exits are DECIDED at the trade level (with the planned legs); when cash trims or skips a leg, the shares actually
held follow those same exit decisions. The report counts how often that happened.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from tl_common import TLError
from tl_data import Market
import tl_rules as R

PORTFOLIO_DEFAULTS = {"capital": 1_000_000.0, "integer_shares": True, "min_order_frac": 0.25,
                      "max_new_per_day": None, "max_open": None, "allow_duplicates": True}
SIZING_DEFAULTS = {"rule": "equal_slots", "slots": 15, "max_pct": 0.25, "liquidity_cap": None, "min_notional": 0.0}
SIZING_KEYS = {"rule", "slots", "pct", "amount", "risk_pct", "atr_mult", "expression", "max_pct", "liquidity_cap",
               "min_notional"}


class Sizer:
    def __init__(self, sizing: dict, pick_attrs):
        s = dict(SIZING_DEFAULTS)
        bad = set(sizing) - SIZING_KEYS
        if bad:
            raise TLError(f"sizing: unknown keys {sorted(bad)} (allowed {sorted(SIZING_KEYS)})")
        s.update(sizing)
        self.s = s
        rule = s["rule"]
        if rule not in ("equal_slots", "pct_equity", "fixed", "atr_risk", "expression"):
            raise TLError(f"sizing: rule must be equal_slots | pct_equity | fixed | atr_risk | expression")
        need = {"equal_slots": ["slots"], "pct_equity": ["pct"], "fixed": ["amount"],
                "atr_risk": ["risk_pct", "atr_mult"], "expression": ["expression"]}[rule]
        for k in need:
            if s.get(k) is None:
                raise TLError(f"sizing: rule {rule} needs '{k}'")
        self.expr = None
        if rule == "expression":
            names = R.Names("daily", pick_attrs=list(pick_attrs) + ["equity", "cash", "open_positions",
                                                                    "signal_atr14_pct"], features=set())
            self.expr = R.Rule(s["expression"], names, "sizing.expression", "num")
            if self.expr.market or self.expr.state_used:
                raise TLError("sizing.expression may use equity, cash, open_positions, signal_atr14_pct and pick "
                              "attributes only")

    def target(self, equity: float, cash: float, n_open: int, pick: dict, atr_pct: float, turnover: float) -> float:
        s = self.s
        r = s["rule"]
        if r == "equal_slots":
            t = equity / float(s["slots"])
        elif r == "pct_equity":
            t = equity * float(s["pct"])
        elif r == "fixed":
            t = float(s["amount"])
        elif r == "atr_risk":
            t = equity * float(s["risk_pct"]) / (float(s["atr_mult"]) * atr_pct) if atr_pct > 0 else 0.0
        else:
            env = {"__builtins__": {}, **R.BASE_NS, "equity": equity, "cash": cash, "open_positions": float(n_open),
                   "signal_atr14_pct": atr_pct}
            for nm in self.expr.picks:
                if nm in env:                      # equity / cash / open_positions / signal_atr14_pct
                    continue
                try:
                    env[nm] = float(pick.get(nm, np.nan))
                except (TypeError, ValueError):
                    env[nm] = np.nan
            t = float(np.asarray(eval(self.expr.code, env), dtype=float))
        if not np.isfinite(t) or t <= 0:
            return 0.0
        if s.get("max_pct") is not None:
            t = min(t, float(s["max_pct"]) * equity)
        if s.get("liquidity_cap") is not None and np.isfinite(turnover) and turnover > 0:
            t = min(t, float(s["liquidity_cap"]) * turnover)
        if t < float(s.get("min_notional") or 0.0):
            return 0.0
        return t


@dataclass
class PortfolioResult:
    daily: pd.DataFrame
    trades: pd.DataFrame
    stats: dict


def run_portfolio(results: List, strat, market: Market, overrides: Optional[dict] = None) -> PortfolioResult:
    cfg = dict(PORTFOLIO_DEFAULTS)
    pc = dict(strat.portfolio or {})
    bad = set(pc) - set(PORTFOLIO_DEFAULTS)
    if bad:
        raise TLError(f"portfolio: unknown keys {sorted(bad)} (allowed {sorted(PORTFOLIO_DEFAULTS)})")
    cfg.update(pc)
    if overrides:
        cfg.update(overrides)
    sizer = Sizer(strat.sizing, strat.names.pick_attrs)
    cm = strat.costs
    capital = float(cfg["capital"])
    trades = [r for r in results if r.fills and any(f.side == "buy" for f in r.fills)]
    if not trades:
        empty = pd.DataFrame(columns=["date", "equity", "cash", "invested", "exposure", "n_open", "new_trades",
                                      "day_ret", "drawdown"])
        return PortfolioResult(empty, pd.DataFrame(), {"note": "no trade entered", "capital": capital})
    events = []
    for ti, r in enumerate(trades):
        for f in r.fills:
            events.append((np.datetime64(f.ts, "m"), 0 if f.side == "sell" else 1, int(r.pick.get("rank", 99)),
                           str(r.pick.get("engine", "")), ti, f))
    events.sort(key=lambda e: (e[0], e[1], e[2], e[3], e[4]))
    first_day = events[0][0].astype("datetime64[D]")
    last_day = events[-1][0].astype("datetime64[D]")
    cal = market.cal[(market.cal >= first_day) & (market.cal <= last_day)]
    if len(cal) == 0:
        raise TLError("portfolio: no calendar sessions between the first and the last fill")
    ev_day = np.array([e[0].astype("datetime64[D]") for e in events])
    cash = capital
    pos: Dict[int, dict] = {}            # trade index -> {sym, shares, basis, target, ...}
    state = [{"opened": False, "skip": "", "target": 0.0, "bought": 0.0, "sold": 0.0, "costs": 0.0,
              "legs_trimmed": 0, "legs_skipped": 0, "shares_max": 0.0} for _ in trades]
    last_px: Dict[str, float] = {}
    rows = []
    eq_prev = capital
    ei = 0
    held_syms: Dict[str, int] = {}
    for d in cal:
        # mark at the previous close happened at the end of the previous day (eq_prev)
        new_today = 0
        while ei < len(events) and ev_day[ei] <= d:
            _, sidex, rank, eng, ti, f = events[ei]
            ei += 1
            r = trades[ti]
            S = state[ti]
            sym = r.pick["symbol"]
            if f.side == "buy":
                if S["skip"]:
                    continue
                if not S["opened"]:
                    if cfg["max_new_per_day"] is not None and new_today >= int(cfg["max_new_per_day"]):
                        S["skip"] = "max_new_per_day"
                        continue
                    if cfg["max_open"] is not None and len(pos) >= int(cfg["max_open"]):
                        S["skip"] = "max_open"
                        continue
                    if not cfg["allow_duplicates"] and held_syms.get(sym, 0) > 0:
                        S["skip"] = "duplicate_symbol"
                        continue
                    atr_pct, turn = _signal_context(market, r.pick)
                    tgt = sizer.target(eq_prev, cash, len(pos), r.pick, atr_pct, turn)
                    if tgt <= 0:
                        S["skip"] = "size_zero"
                        continue
                    S["opened"], S["target"] = True, tgt
                    pos[ti] = {"sym": sym, "shares": 0.0, "basis": 0.0}
                    held_syms[sym] = held_syms.get(sym, 0) + 1
                    new_today += 1
                P = pos.get(ti)
                if P is None:
                    continue
                want = S["target"] * f.frac
                px = f.price
                shares = math.floor(want / px) if cfg["integer_shares"] else want / px
                cost = cm.buy(shares * px, rupees=True)
                if shares * px + cost > cash + 1e-9:
                    afford = max(0.0, cash) / (px * (1 + cm.buy(1.0, rupees=True)))
                    shares = math.floor(afford) if cfg["integer_shares"] else afford
                    if shares * px < float(cfg["min_order_frac"]) * want or shares <= 0:
                        S["legs_skipped"] += 1
                        continue
                    S["legs_trimmed"] += 1
                    cost = cm.buy(shares * px, rupees=True)
                if shares <= 0:
                    S["legs_skipped"] += 1
                    continue
                cash -= shares * px + cost
                P["shares"] += shares
                P["basis"] += shares * px
                S["bought"] += shares * px
                S["costs"] += cost
                S["shares_max"] = max(S["shares_max"], P["shares"])
                last_px[sym] = px
            else:
                P = pos.get(ti)
                if P is None or P["shares"] <= 0:
                    continue
                if f.frac >= 1.0 - 1e-12:
                    q = P["shares"]
                else:
                    q = math.floor(P["shares"] * f.frac + 0.5) if cfg["integer_shares"] else P["shares"] * f.frac
                    q = min(q, P["shares"])
                if q <= 0:
                    continue
                basis = P["basis"] * (q / P["shares"])
                proceeds = q * f.price
                cost = cm.sell(proceeds, basis, rupees=True)
                cash += proceeds - cost
                P["shares"] -= q
                P["basis"] -= basis
                S["sold"] += proceeds
                S["costs"] += cost
                last_px[sym] = f.price
                if P["shares"] <= 1e-9:
                    del pos[ti]
                    held_syms[sym] -= 1
        invested = 0.0
        for ti, P in pos.items():
            px = _close_on(market, P["sym"], d, last_px)
            invested += P["shares"] * px
        eq = cash + invested
        rows.append({"date": str(d), "equity": eq, "cash": cash, "invested": invested,
                     "exposure": invested / eq if eq > 0 else np.nan, "n_open": len(pos), "new_trades": new_today,
                     "day_ret": eq / eq_prev - 1 if eq_prev > 0 else np.nan})
        eq_prev = eq
    daily = pd.DataFrame(rows)
    peak = daily["equity"].cummax()
    daily["drawdown"] = daily["equity"] / peak - 1
    # per trade
    trows = []
    for ti, r in enumerate(trades):
        S = state[ti]
        open_value = 0.0
        if ti in pos:
            open_value = pos[ti]["shares"] * _close_on(market, pos[ti]["sym"], cal[-1], last_px)
        pnl = S["sold"] + open_value - S["bought"] - S["costs"] if S["opened"] else 0.0
        trows.append({"trade_id": r.pick.get("trade_id"), "engine": r.pick.get("engine"), "symbol": r.pick.get("symbol"),
                      "signal_day": r.pick.get("signal_day"), "rank": r.pick.get("rank"), "status": r.status,
                      "opened": S["opened"], "skip_reason": S["skip"], "target_rupees": S["target"],
                      "bought_rupees": S["bought"], "sold_rupees": S["sold"], "costs_rupees": S["costs"],
                      "open_value": open_value, "pnl_rupees": pnl,
                      "ret_on_target": pnl / S["target"] if S["target"] > 0 else np.nan,
                      "legs_trimmed": S["legs_trimmed"], "legs_skipped": S["legs_skipped"],
                      "still_open": ti in pos})
    T = pd.DataFrame(trows)
    stats = _stats(daily, capital, T)
    stats["config"] = {**cfg, "sizing": sizer.s, "costs": cm.describe()}
    return PortfolioResult(daily, T, stats)


def _signal_context(market: Market, pick: dict):
    ds = market.series(pick["symbol"])
    if ds is None:
        return np.nan, np.nan
    i = ds.idx(np.datetime64(pick["signal_day"], "D"))
    if i < 0:
        return np.nan, np.nan
    from tl_engine import _daily_context
    _daily_context(ds)
    atr = ds._atr14[i] / ds.c[i] if np.isfinite(ds._atr14[i]) else np.nan
    lo = max(0, i - 19)
    turn = float(np.nanmedian(ds.c[lo:i + 1] * ds.v[lo:i + 1])) if i - lo >= 19 else np.nan
    return float(atr), turn


def _close_on(market: Market, sym: str, d, last_px: Dict[str, float]) -> float:
    ds = market.series(sym)
    if ds is not None:
        j = ds.idx(d)
        if j >= 0:
            last_px[sym] = float(ds.c[j])
            return float(ds.c[j])
        k = int(np.searchsorted(ds.dates, np.datetime64(d, "D"), side="right")) - 1
        if k >= 0:
            return float(ds.c[k])
    return float(last_px.get(sym, np.nan))


def _stats(daily: pd.DataFrame, capital: float, T: pd.DataFrame) -> dict:
    if daily.empty:
        return {"capital": capital}
    eq = daily["equity"].to_numpy(float)
    rets = daily["day_ret"].to_numpy(float)
    d0, d1 = pd.Timestamp(daily["date"].iloc[0]), pd.Timestamp(daily["date"].iloc[-1])
    years = max((d1 - d0).days / 365.25, 1e-9)
    final = float(eq[-1])
    dd = daily["drawdown"].to_numpy(float)
    i_tr = int(np.argmin(dd))
    i_pk = int(np.argmax(eq[:i_tr + 1])) if i_tr > 0 else 0
    rec = np.flatnonzero(eq[i_tr:] >= eq[i_pk])
    sd = float(np.nanstd(rets, ddof=1)) if len(rets) > 2 else float("nan")
    reasons = T.loc[~T["opened"], "skip_reason"].value_counts().to_dict() if len(T) else {}
    return {"capital": capital, "start": str(d0.date()), "end": str(d1.date()), "sessions": int(len(daily)),
            "final_equity": final, "total_return": final / capital - 1,
            "cagr": (final / capital) ** (1 / years) - 1 if final > 0 else float("nan"),
            "max_drawdown": float(dd[i_tr]), "dd_peak": daily["date"].iloc[i_pk], "dd_trough": daily["date"].iloc[i_tr],
            "dd_recovered": daily["date"].iloc[i_tr + int(rec[0])] if len(rec) else None,
            "sharpe": float(np.nanmean(rets) / sd * np.sqrt(252)) if sd and sd > 0 else float("nan"),
            "avg_exposure": float(np.nanmean(daily["exposure"])), "trades_opened": int(T["opened"].sum()),
            "trades_skipped": reasons, "legs_trimmed_by_cash": int(T["legs_trimmed"].sum()),
            "legs_skipped_by_cash": int(T["legs_skipped"].sum()), "still_open": int(T["still_open"].sum()),
            "pnl_check": float(T["pnl_rupees"].sum() - (final - capital))}
