# tradelab v1 — every pick, trade by trade; a backtester and a trade simulator

tradelab sits **next to** `bigmove_deploy` (not inside it). It reads production data read-only — the cache, pick_meta's research run, `panel_oc`, the 3-minute bars, and stage E's lower-circuit rule — and writes only under `C:\QuantData\tradelab`. Nothing in production changes.

| command | what it gives you |
|---|---|
| `tl_check.py` | a 30-second preflight: what tradelab sees on your PC, and the plan reproduced on 300 random picks |
| `tl_export.py` | every pick D and ENS made (ranks 1–10, 2020–2026) with its outcomes, day by day for sessions 0–5 (P&L each day), the panel features at each close, a daily book, 3-minute bars on request |
| `tl_backtest.py` | any strategy (entries, exits, sizing) on the picks, compared with the plan on the same picks, with 95% intervals and a money view (equity, drawdown) |
| `tl_sim.py` | one trade (or a few) replayed bar by bar: a written story, every bar's values, and a chart |

## Install (once)

1. Copy the `tradelab` folder to `C:\Users\karanvsi\PyCharmMiscProject\tradelab` (beside `bigmove_deploy`, not inside it).
2. Open `cmd`:
   ```
   call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
   python tests\test_tradelab.py
   ```
   It must end with `VERIFIED (tradelab v1)` (about 3–6 minutes). The test uses synthetic data only.
3. Preflight on your real data (reads only, about 30 seconds):
   ```
   python tl_check.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
   ```
   It must end with `CHECK OK`. If it prints `CHECK FAILED`, send me the whole output.

`env_tradelab.bat` runs your `env_daily.bat` (sets `CACHE_DAILY_ROOT`), puts `tradelab`, then `bigmove_deploy\open_close`, then `bigmove_deploy` on `PYTHONPATH`, and sets `TRADELAB_OUT=C:\QuantData\tradelab`. Every command needs `--root %CACHE_DAILY_ROOT%` (no silent default path) and `--pm-run PM_20261017_001`.

## 1. Export every pick

```
python tl_export.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
```
Options: `--engines D ENS` · `--ranks 1-10` (default; `1-3` = the traded picks) · `--from 2020-01-01 --to 2026-09-30` · `--features all|none|D_rsi14,D_atr_pct` · `--features-csv` (the features file as CSV too — large) · `--bars3 D-20240425-2,ENS-20250102-1` or `--bars3 traded` (3-minute bars; `traded` ≈ 9,900 trades × 750 bars — big) · `--no-benchmark`.

**Safety stop.** The plan (buy the session-1 open, sell the session-5 close, a locked close sells at the first unlocked open within 20 sessions, 35 bp) is recomputed from the bars for every pick and must match pick_meta's recorded status and net to 1e-9 for at least 99.5% of each engine's picks, with the mean net within 0.01 bp. Otherwise the run writes only `STOPPED.txt` and `reconcile_mismatches.csv` — send me that CSV. MFE / MAE agreement with the record is reported on the same line (pick_meta's 5-session definition) but does not stop the run.

Files in `C:\QuantData\tradelab\export\TLX_YYYYMMDD_NNN\`:

| file | one row per | main columns |
|---|---|---|
| `trades` | pick | identity (trade_id, engine, rank, traded, overlaps, repeat_of), forecasts (prob_*, pred_*), the plan's outcome (entry, exit, exit_kind, locked_exit, net_bp, win), path outcomes (mfe, mae and their sessions, `touch_up3/5/10_session`, `touch_dn3/5/8_session`, `close_ret_s1..s5`, `open_ret_s2..s6`), alternatives (`open6_net_bp`, `hold10_net_bp`), the record and `matches_record`, buy-everything that day (`mkt_net_bp`) and `excess_bp` |
| `trade_days` | pick × session 0–5 (longer for a locked exit) | daily OHLCV, `ret_*_vs_entry`, `day_ret`, `gap`, `range_pct`, `clv`, `vol_ratio20`, `atr_ratio`, `rel_nifty_day`, `held_at_close`, `day_pnl_bp`, `cum_pnl_bp` (ends at net_bp), `mfe_sofar`, `mae_sofar`, `after_exit` |
| `trade_day_features` | pick × session 0–5 | every allowed panel feature at that session's close |
| `daily_book` | engine × session | positions open, new, exits, the book's day P&L (1/15 of capital per slot — a proxy) and its running total |
| `trade_bars_3m` | 3-minute bar (chosen trades) | OHLCV, VWAP, cumulative volume, return vs entry and vs the previous close, session high / low so far |

## 2. Backtest a strategy

```
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\scale_20_80_vwap.py
```
Options: `--compare auto` (default: the plan on the same picks and clock) or another strategy file · `--values rvol,clv,D_rsi14` (extra values recorded in the timelines) · `--engines`, `--ranks`, `--from`, `--to` (override the strategy's picks) · `--capital 1000000` · `--no-portfolio` · `--timeline D-20240425-2,...` (save those trades' bar timelines) · `--tag "what I am trying"` · `--declare "PASS if the paired lower bound > 0"` · `--list-names` (prints every value and function a rule can use; with `--root/--pm-run` it adds pick attributes and panel features).

The report leads with the verdict: the strategy's mean net per pick slot, the plan's on the **same** picks, and the paired difference with its 95% interval (circular blocks of 10 signal days, 2,000 resamples, seed 7) → BETTER / WORSE / NOT SHOWN. Then fills, exits, MFE/MAE, by year / engine / rank, and the money view (CAGR, worst drawdown with dates, Sharpe, exposure, skipped trades).

**Discipline.** Every backtest is logged in `C:\QuantData\tradelab\tradelab_ledger.jsonl` *before* it runs (with your `--declare` rule) and again with its result; the report says how many backtests and distinct strategies the ledger holds. With 20 variants on the same years, one will look BETTER by luck. A strategy found here is a hypothesis until a declared rule passes on the forward paper ledger.

## 3. Simulate single trades

```
python tl_sim.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --trade D-20240425-2 --strategy strategies\scale_20_80_vwap.py --strategy strategies\plan.py
python tl_sim.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --symbol RELIANCE --signal-day 2024-04-25
```
Add `--values rvol,clv,rel_nifty_day,D_rsi14,prob_big` to record any built-in value, pick attribute or panel feature on every bar of the timeline, even when the strategy does not trade on it.

Writes, per trade and strategy: `*_story.md` (every buy / sell with its reason, when each event first fired, a day-by-day table), `*_timeline.csv` (one row per bar: prices, VWAP, every value the rules use, each event, position, average entry, unrealised P&L, MFE/MAE so far, armed orders, fills) and `<trade>_chart.html` (open in a browser; hover a triangle for the reason). Same engine as the backtester — identical numbers.

**Features across a backtest's trades.** A backtest's `trade_days` and the export's `trade_day_features` share `trade_id` and `session`: join them to see every panel feature, day by day, next to the strategy's position and P&L.

## Writing strategies

A strategy is a Python file with a `STRATEGY` dict (or JSON). Start from a file in `strategies\`:

| file | idea |
|---|---|
| `plan.py`, `plan_intraday.py` | the paper test's plan (daily / on the 3-minute clock) |
| `open6.py` | sell at the 6th open |
| `scale_20_80_vwap.py` | 20% at the open, 80% when a 3-minute close crosses above VWAP (sessions 1–2, 09:30–14:30) |
| `orb_add_on.py` | 50% at the open, 50% on a buy stop at the 15-minute opening-range high |
| `dip_or_fallback.py` | limit 1% under the open until 11:00, else buy at 11:00 |
| `half_target_stop.py` | half at +5%, stop at −8%, rest at the 5th close |
| `trail_after_5pct.py` | trail 4% under the highest high once MFE ≥ 5%, hold up to 10 sessions |
| `filtered_rsi_entry.py` | skip picks with P(stuck) ≥ 10%; buy only if RSI(14) at the signal close < 70 (a panel feature) |
| `weak_close_exit.py` | sell after 14:30 in sessions 2–4 if under VWAP and down 3%+ (with a plugin) |

```python
STRATEGY = {
    "name": "my_idea",
    "mode": "intraday",               # "daily" = one bar a session; "intraday" = 3-minute bars (Oct 2021 on)
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": None, "to": None, "filter": "prob_trap < 0.10"},
    "max_sessions": 5,                # the trade ends at this session's close at the latest
    "warmup_sessions": 1,             # sessions before the signal day loaded for indicators (daily default 30)
    "events": {"reclaim": "crosses_above(close, vwap)"},          # named conditions, usable anywhere
    "entries": [
        {"name": "first", "size": 0.2, "at": "open", "session": 1},                       # official open
        {"name": "add", "size": 0.8, "when": "reclaim", "sessions": [1, 2], "time": ["09:30", "14:30"]},
        # fill: "next_open" (default) | "stop" / "limit" (with "level": "...") | "close" (needs same_bar_close_fills)
        # "cancel_if": "..." cancels a waiting leg for good
    ],
    "exits": [
        {"name": "stop", "type": "stop", "level": "avg_entry * 0.95"},           # sell stop (gap -> the open)
        {"name": "tgt", "type": "target", "level": "first_entry * 1.10", "size": 0.5},
        {"name": "trail", "type": "trail", "pct": 0.04, "activate": "upnl > 0.03"},  # or "atr": 2.0
        {"name": "weak", "type": "signal", "when": "close < vwap and upnl < -0.02", "sessions": [2, 4]},
        {"name": "time", "type": "time", "at": "close", "session": 5},           # "at": "open" for an open exit
    ],
    "intrabar": "worst",              # stop and target in one bar: worst | best | intraday (daily mode)
    "costs": {"model": "flat", "round_trip_bp": 35},   # or per_side (buy_bp, sell_bp) or zerodha (itemised)
    "slippage_bp": 0,                 # added against you on every fill
    "sizing": {"rule": "equal_slots", "slots": 15, "max_pct": 0.25},
    "portfolio": {"capital": 1000000, "integer_shares": True, "min_order_frac": 0.25,
                  "max_new_per_day": None, "max_open": None, "allow_duplicates": True},
    "decision_rule": {"metric": "diff_mean_bp", "pass_if": "lower > 0"},
    "plugins": ["example_plugin.py"],
}
```

**Timing rules (no look-ahead).** A rule checked at a bar's close acts at the next bar's open. Stop / limit / trail levels are computed at the previous bar's close (state-based levels such as `avg_entry * 0.95` are refreshed right after fills at a bar's open) — so inside a level, `low` means the low of the bar before, and `opening_range_high(5)` is blank until the session's 5th bar (give such orders a `time` window that starts after the range). `at: open/close` orders use the session's official open / close. A window (`sessions`, `time`) applies to the bar where the order fills. An entry filled inside a bar cannot exit inside that same bar. A level built on today's open is valid from the second bar on (`time` starting 09:18).

**Sizes.** Entry sizes are fractions of the trade's target size; P&L is measured on the full target, so an unfilled leg counts as cash. Legs may add up to more than 1.0 when they are alternatives — a buy is clipped so the position never exceeds the target. Exit sizes are fractions of the position held.

**Sizing rules** (`sizing.rule`): `equal_slots` (equity / slots), `pct_equity` (`pct`), `fixed` (`amount`), `atr_risk` (`risk_pct`, `atr_mult`: risk_pct × equity / (atr_mult × the stock's ATR14% on the signal day)), `expression` (any rule over `equity`, `cash`, `open_positions`, `signal_atr14_pct` and pick attributes, e.g. `"equity / 15 * min(1.5, 0.03 / signal_atr14_pct)"`). Caps: `max_pct` of equity, `liquidity_cap` (share of the 20-session median turnover), `min_notional`.

**What a rule can use** — run `python tl_backtest.py --list-names --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001`:
- bar: `open high low close volume typical hl_range body upper_wick lower_wick clv bar_ret`
- clock: `session` (0 = signal day, 1 = entry day) `bar_in_session minute hhmm is_first_bar is_last_bar weekday sessions_left`
- session: `vwap` (3-minute only) `session_open session_high session_low session_volume day_ret gap prev_close prev_open prev_high prev_low prev_volume dist_prev_high dist_prev_low entry_open signal_close ret_vs_entry_open`
- daily context: `atr14 atr14_pct vol_med20 rvol nifty nifty_day_ret rel_nifty_day nifty_ret5` (values known when the rule is checked)
- pick attributes (constant per trade): `rank score other_rank both_engines repeat engine_D s_atr14 prob_* pred_*`
- panel features by name (daily values; in intraday mode the previous session's)
- trade state: `pos in_pos avg_entry first_entry upnl upnl_first mfe_sofar mae_sofar peak_close bars_in_trade sessions_in_trade legs_filled exits_done realized filled_<leg>`
- functions: `shift prev sma/mean ema rsi std zscore highest lowest roc change rsum crosses_above crosses_below rising falling bars_since held_for count_true trade_max trade_min session_max session_min session_sum session_first prev_session opening_range_high opening_range_low` (look back over bars — market values only) and `abs min max log exp sqrt sign round clip where isnan nz`
- operators: `+ - * / ** % //`, comparisons (chains allowed), `and or not`, `x if cond else y`

Refused: `label_*` and forward-looking names (the firewall), `shift(x, -1)`, attributes, indexing, strings, lambdas, imports.

**Your own values and functions** — copy `plugins\example_plugin.py`:
```python
from tl_rules import variable, function

@variable("vol_surge", "bar volume / mean of the previous 20 bars")
def vol_surge(ctx):                       # ctx.open/high/low/close/volume, ctx.var("vwap"), ctx.daily, ...
    v = pd.Series(ctx.volume)
    return (v / v.shift(1).rolling(20, min_periods=20).mean()).to_numpy(float)
```
List it in the strategy (`"plugins": ["my_plugin.py"]`). tradelab recomputes every plugin value with the later bars removed and refuses the run if anything earlier changes.

## Limits (v1)

- 3-minute bars start Oct 2021: intraday strategies skip earlier picks (`no_intraday`); the plan comparison uses the same picks.
- Exits are decided on the planned position; if cash trims a leg in the money view, the shares held follow the same exit decisions (counted in the report).
- Not modelled: buys at an upper-circuit lock, partial fills, impact beyond the cost model. VWAP is computed from 3-minute bars (typical price × volume), close to — not identical with — the exchange VWAP.
- Results on 2020–2026 are the same history the engines were built and studied on: descriptive, not new evidence.
