"""Scale in: 20% at the session-1 open, the other 80% when a 3-minute close crosses above the session VWAP
(sessions 1-2, 09:30-14:30). If the cross never comes, only the 20% is held. Everything sells at the session-5
close (honest exits). Needs 3-minute bars, so only trades from Oct 2021 are simulated; the rest are reported
as 'no_intraday' and the plan comparison uses the same trades."""
STRATEGY = {
    "name": "scale_20_80_vwap",
    "mode": "intraday",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "events": {
        "vwap_reclaim": "crosses_above(close, vwap)",
    },
    "entries": [
        {"name": "open20", "size": 0.20, "at": "open", "session": 1},
        {"name": "vwap80", "size": 0.80, "when": "vwap_reclaim", "sessions": [1, 2], "time": ["09:30", "14:30"]},
    ],
    "exits": [
        {"name": "time", "type": "time", "at": "close", "session": 5},
    ],
}
