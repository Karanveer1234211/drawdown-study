"""The plain plan (the paper test's own rule): buy the open of session 1, sell the close of session 5.
A close locked at the lower circuit sells at the first unlocked open within 20 sessions (stage E's rule).
This strategy must reproduce pick_meta's recorded net for every pick - tradelab checks that on every export."""
STRATEGY = {
    "name": "plan",
    "description": "buy next open, sell the 5th close (honest exits), 35 bp round trip",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
    "costs": {"model": "flat", "round_trip_bp": 35},
}
