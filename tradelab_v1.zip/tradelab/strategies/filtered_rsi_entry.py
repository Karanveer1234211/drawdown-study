"""Daily bars, a pick filter and a feature-based entry: skip picks whose forecast P(stuck) is 10% or more, and
buy at the session-1 open only if the stock's RSI(14) at the signal-day close was below 70 (a panel feature,
read at the close it belongs to). Exit at the 5th close."""
STRATEGY = {
    "name": "filtered_rsi_entry",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "filter": "prob_trap < 0.10"},
    "max_sessions": 5,
    "entries": [
        {"name": "open_if_not_overbought", "size": 1.0, "when": "session == 0 and D_rsi14 < 70", "sessions": [1, 1]},
    ],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
}
