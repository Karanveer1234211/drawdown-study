"""
tl_export.py - tradelab v1: every pick the frozen engines made, with its outcomes, day by day.

    python tl_export.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
        [--engines D ENS] [--ranks 1-10] [--from 2020-01-01] [--to 2026-09-30]
        [--features all|none|D_rsi14,D_atr_pct] [--features-csv]
        [--bars3 none|traded|all|D-20240425-2,ENS-20250102-1] [--bars3-sessions 0-5]
        [--no-benchmark] [--out C:\\QuantData\\tradelab]

The trade for every pick is the paper test's plan: buy the session-1 open, sell the session-5 close, honest exits
(a close locked at the lower band sells at the first unlocked open within 20 sessions), 35 bp round trip.
SAFETY STOP: the plan recomputed from the bars must equal pick_meta's recorded status / net / mfe / mae
(within 1e-9) for >= 99.5% of each engine's picks, and each engine's mean net within 0.01 bp; otherwise the run
writes STOPPED.txt + reconcile_mismatches.csv and nothing else (exit 3).

Writes <out>\\export\\TLX_YYYYMMDD_NNN\\
  trades.csv / .parquet              one row per pick: identity, forecasts, overlaps, the plan's outcome, the path
                                     outcomes (MFE/MAE, touches of +3/+5/+10% and -3/-5/-8% with their sessions,
                                     close vs entry on each day), alternatives (6th-open exit, 10th-close hold),
                                     the recorded values and match flags, buy-everything that day and the excess
  trade_days.csv / .parquet          one row per pick per session 0..5 (longer for a locked exit): daily OHLCV,
                                     returns vs entry, day / gap / range / close location / volume ratio / ATR
                                     ratio / NIFTY-relative, position held, the day's P&L and the running P&L (bp)
  trade_day_features.parquet         one row per pick per session 0..5: every allowed panel feature at that close
                                     (.csv too with --features-csv; large)
  daily_book.csv / .parquet          per engine and session: positions open, new, exits, the book's day P&L
                                     (1/15 of capital a slot - a proxy) and its running total
  trade_bars_3m.csv / .parquet       3-minute bars of the chosen trades (only with --bars3)
  report.md, summary.json, outputs.sha256; a line in <out>\\tradelab_ledger.jsonl
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (BOOT, COST_RT_BP_DEFAULT, StopRun, TLError, VERSION, bootstrap_mean_by_day, fmt_bp,
                       ledger_append, new_run_dir, out_base, parse_ranks, provenance, require_root, say,
                       write_outputs_sha, write_table)
import tl_data as D
import tl_engine as E
from tl_run import Workspace, path_frame

TOOL = "tl_export v1"
RECON_TOL = 1e-9
RECON_SHARE = 0.995
RECON_MEAN_BP = 0.01
TOUCH_UP = (0.03, 0.05, 0.10)
TOUCH_DN = (0.03, 0.05, 0.08)

PLAN = {"name": "plan", "mode": "daily", "max_sessions": 5,
        "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
        "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
        "costs": {"model": "flat", "round_trip_bp": COST_RT_BP_DEFAULT}}
OPEN6 = {"name": "open6", "mode": "daily", "max_sessions": 6,
         "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
         "exits": [{"name": "time", "type": "time", "at": "open", "session": 6}],
         "costs": {"model": "flat", "round_trip_bp": COST_RT_BP_DEFAULT}}
HOLD10 = {"name": "hold10", "mode": "daily", "max_sessions": 10,
          "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
          "exits": [{"name": "time", "type": "time", "at": "close", "session": 10}],
          "costs": {"model": "flat", "round_trip_bp": COST_RT_BP_DEFAULT}}


def parse_args(argv):
    ap = argparse.ArgumentParser(description="tradelab export: every pick with its outcomes, day by day")
    ap.add_argument("--root", help="the cache root: %%CACHE_DAILY_ROOT%%")
    ap.add_argument("--pm-run", help="pick_meta research run, e.g. PM_20261017_001")
    ap.add_argument("--engines", nargs="+", default=["D", "ENS"])
    ap.add_argument("--ranks", default="1-10")
    ap.add_argument("--from", dest="d_from", default=None)
    ap.add_argument("--to", dest="d_to", default=None)
    ap.add_argument("--features", default="all", help="all | none | comma list of panel features")
    ap.add_argument("--features-csv", action="store_true", help="also write trade_day_features.csv (large)")
    ap.add_argument("--bars3", default="none", help="none | traded | all | comma list of trade ids")
    ap.add_argument("--bars3-sessions", default="0-5")
    ap.add_argument("--no-benchmark", action="store_true", help="skip buy-everything (reads every panel stock's bars)")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--out", default=None)
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--no-reconcile-stop", action="store_true",
                    help="write the files even when the plan does not reproduce the record (NOT recommended)")
    return ap.parse_args(argv)


def main(argv=None) -> int:
    a = parse_args(sys.argv[1:] if argv is None else argv)
    t0 = time.time()
    try:
        root = require_root(a.root)
        base = out_base(a.out, root)
        ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel)
        say(f"{TOOL} ({VERSION}) | root {root} | pick_meta run {a.pm_run}")
        T = ws.picks(a.engines, a.ranks, a.d_from, a.d_to)
        say(f"picks: {len(T):,} ({', '.join(f'{e} {int((T.engine == e).sum()):,}' for e in a.engines)}), "
            f"signal days {T.signal_day.min()} .. {T.signal_day.max()}, ranks {parse_ranks(a.ranks)}")
        pa = ws.pick_attrs(T)
        plan, open6, hold10 = (E.Strategy(dict(x), None, pa) for x in (PLAN, OPEN6, HOLD10))
        bars3_ids = _bars3_ids(a.bars3, T)
        s3 = tuple(int(x) for x in a.bars3_sessions.split("-")) if bars3_ids else None
        say("simulating the plan (and the 6th-open / 10th-close alternatives) on every pick ...")
        res, extra = ws.simulate([plan, open6, hold10], T, extra_3m_sessions=s3)
        run_dir = new_run_dir(base, "export", "TLX")
        rec = reconcile(T, res["plan"], ws.market)
        say(f"reconcile: {rec['line']}")
        if not rec["ok"] and not a.no_reconcile_stop:
            rec["mismatches"].to_csv(run_dir / "reconcile_mismatches.csv", index=False)
            (run_dir / "STOPPED.txt").write_text(
                f"{TOOL}: the plan recomputed from the bars does not reproduce pick_meta's record.\n{rec['line']}\n"
                f"Send Claude reconcile_mismatches.csv from this folder.\n", encoding="utf-8")
            ledger_append(base, {"tool": TOOL, "event": "export_stopped", "run": run_dir.name, "pm_run": a.pm_run,
                                 "reason": rec["line"]})
            say(f"STOPPED - see {run_dir / 'STOPPED.txt'}")
            return 3
        trades = build_trades(ws, T, res, rec)
        days = build_days(ws, T, res["plan"])
        feats_cols = _feature_list(ws, a.features)
        written = []
        if feats_cols:
            say(f"panel features: {len(feats_cols)} columns at each session's close ...")
            F = feature_table(ws, days, feats_cols)
            written += write_table(F, run_dir / "trade_day_features", csv=a.features_csv, parquet=True)
        bench = None
        if not a.no_benchmark:
            say("buy-everything: the plan on every panel stock each signal day ...")
            bench = benchmark(ws, sorted(T["signal_day"].unique()))
            trades = trades.merge(bench, on="signal_day", how="left")
            trades["excess_bp"] = trades["net_bp"] - trades["mkt_net_bp"]
        book = build_book(days, T)
        written += write_table(trades, run_dir / "trades")
        written += write_table(days, run_dir / "trade_days")
        written += write_table(book, run_dir / "daily_book")
        if bars3_ids:
            B3 = bars3_table(ws, T, extra["bars3"], bars3_ids, s3)
            written += write_table(B3, run_dir / "trade_bars_3m")
            say(f"3-minute bars: {len(B3):,} rows for {B3['trade_id'].nunique() if len(B3) else 0:,} trades")
        summ = summarize(T, trades, rec, extra["info"], ws, a, bench is not None, feats_cols, written, t0)
        (run_dir / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
        (run_dir / "report.md").write_text(report_md(summ, trades), encoding="utf-8")
        write_outputs_sha(run_dir)
        ledger_append(base, {"tool": TOOL, "event": "export", "run": run_dir.name, "pm_run": a.pm_run,
                             "picks": len(T), "engines": a.engines, "ranks": a.ranks,
                             "reconcile": rec["line"], "seconds": round(time.time() - t0, 1)})
        say(f"DONE {run_dir}  ({time.time() - t0:,.0f} s)")
        for e in a.engines:
            say("  " + summ["headline"].get(e, ""))
        return 0
    except StopRun as e:
        say(f"STOPPED: {e}")
        return 3
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


# ----------------------------------------------------------------------
def _bars3_ids(spec: str, T: pd.DataFrame) -> List[str]:
    s = (spec or "none").strip()
    if s == "none":
        return []
    if s == "traded":
        return T.loc[T["traded"], "trade_id"].tolist()
    if s == "all":
        return T["trade_id"].tolist()
    ids = [x.strip() for x in s.split(",") if x.strip()]
    miss = [x for x in ids if x not in set(T["trade_id"])]
    if miss:
        raise TLError(f"--bars3: unknown trade ids {miss[:5]} (format ENGINE-YYYYMMDD-RANK, e.g. D-20240425-2)")
    return ids


def _feature_list(ws: Workspace, spec: str) -> List[str]:
    s = (spec or "none").strip()
    if s == "none":
        return []
    P = ws.market.panel(ws.panel_name)
    if s == "all":
        return list(P.allowed)
    cols = [x.strip() for x in s.split(",") if x.strip()]
    P.check(cols)
    return cols


def window_mfe_mae(ds, sig: int, hold: int = 5):
    """pick_meta's definition: best high / worst low of sessions 1..hold vs the session-1 open."""
    if ds is None or sig < 0 or sig + hold >= len(ds):
        return np.nan, np.nan
    e = float(ds.o[sig + 1])
    return float(ds.h[sig + 1:sig + hold + 1].max()) / e - 1, float(ds.l[sig + 1:sig + hold + 1].min()) / e - 1


def reconcile(T: pd.DataFrame, res: List[E.TradeResult], market=None) -> dict:
    rows = []
    for p, r in zip(T.to_dict("records"), res):
        ds = market.series(p["symbol"]) if market is not None else None
        sig = ds.idx(np.datetime64(p["signal_day"], "D")) if ds is not None else -1
        mfe, mae = window_mfe_mae(ds, sig)
        rows.append({"trade_id": p["trade_id"], "engine": p["engine"], "symbol": p["symbol"],
                     "signal_day": p["signal_day"], "rank": p["rank"], "status": r.status,
                     "status_recorded": p.get("status_recorded"), "net": r.net if r.status == "ok" else np.nan,
                     "net_recorded": p.get("net_recorded"), "mfe": mfe, "mfe_recorded": p.get("mfe_recorded"),
                     "mae": mae, "mae_recorded": p.get("mae_recorded"), "note": r.note})
    X = pd.DataFrame(rows)
    rs = X["status_recorded"].astype(str)
    mine = X["status"].astype(str)
    settled_since = (rs == "pending") & (mine == "ok")
    comparable = ~settled_since
    st_ok = (rs == mine) | settled_since
    both_ok = (rs == "ok") & (mine == "ok")

    def close(a, b):
        a, b = a.astype(float), b.astype(float)
        return (np.abs(a - b) <= RECON_TOL) | (np.isnan(a) & np.isnan(b))

    net_ok = ~both_ok | close(X["net"], X["net_recorded"])
    path_ok = ~both_ok | (close(X["mfe"], X["mfe_recorded"]) & close(X["mae"], X["mae_recorded"]))
    X["match"] = st_ok & net_ok                  # the stop: status and net (the money)
    X["path_match"] = path_ok                    # reported: MFE / MAE under pick_meta's 5-session definition
    X["settled_since_record"] = settled_since
    per = {}
    ok = True
    for e, g in X.groupby("engine"):
        c = g[comparable.loc[g.index]]
        share = float(c["match"].mean()) if len(c) else 1.0
        bo = g[both_ok.loc[g.index]]
        dm = float((bo["net"].astype(float).mean() - bo["net_recorded"].astype(float).mean()) * 1e4) if len(bo) else 0.0
        e_ok = share >= RECON_SHARE and abs(dm) <= RECON_MEAN_BP
        ok &= e_ok
        per[e] = {"picks": int(len(g)), "comparable": int(len(c)), "matched": int(c["match"].sum()),
                  "share": share, "mfe_mae_share": float(g.loc[both_ok.loc[g.index], "path_match"].mean())
                  if both_ok.loc[g.index].any() else float("nan"), "mean_net_bp": float(bo["net"].astype(float).mean() * 1e4) if len(bo) else np.nan,
                  "mean_net_recorded_bp": float(bo["net_recorded"].astype(float).mean() * 1e4) if len(bo) else np.nan,
                  "mean_diff_bp": dm, "settled_since_record": int(settled_since.loc[g.index].sum()), "ok": e_ok}
    line = "; ".join(f"{e} {v['matched']:,} of {v['comparable']:,} ({v['share']:.2%}), mean net {v['mean_net_bp']:+.2f} "
                     f"bp vs recorded {v['mean_net_recorded_bp']:+.2f} (diff {v['mean_diff_bp']:+.4f}); MFE/MAE agree on "
                     f"{v['mfe_mae_share']:.2%}" for e, v in per.items())
    line = ("OK - " if ok else "FAILED - ") + line
    mism = X[~X["match"] | ~X["path_match"]].head(500)
    return {"ok": ok, "per_engine": per, "line": line, "mismatches": mism, "table": X}


def build_trades(ws: Workspace, T: pd.DataFrame, res: Dict[str, List[E.TradeResult]], rec: dict) -> pd.DataFrame:
    m = ws.market
    keep = ["trade_id", "engine", "signal_day", "symbol", "rank", "traded", "score", "other_rank", "both_engines",
            "repeat_of", "repeat", "fold"] + [c for c in T.columns if c.startswith(("pred_", "prob_"))] + \
           [c for c in ("s_atr14", "meta_rank") if c in T.columns]
    out = T[[c for c in keep if c in T.columns]].copy().reset_index(drop=True)
    plan, o6, h10 = res["plan"], res["open6"], res["hold10"]
    cols: Dict[str, list] = {k: [] for k in (
        "status", "note", "signal_close", "entry_day", "entry", "entry_gap", "exit_day", "exit_price", "exit_kind",
        "locked_exit", "sessions_held", "gross_bp", "net_bp", "win", "mfe", "mae", "mfe_session", "mae_session",
        "mfe_held", "mae_held",
        "best_close_session", "worst_close_session", "open6_status", "open6_net_bp", "hold10_status",
        "hold10_net_bp")}
    for kk in range(1, 6):
        cols[f"close_ret_s{kk}"] = []
    for kk in range(2, 7):
        cols[f"open_ret_s{kk}"] = []
    for x in TOUCH_UP:
        cols[f"touch_up{int(x * 100)}_session"] = []
    for x in TOUCH_DN:
        cols[f"touch_dn{int(x * 100)}_session"] = []
    cols["up5_and_dn5_same_session"] = []
    for p, r, a6, a10 in zip(T.to_dict("records"), plan, o6, h10):
        ds = m.series(p["symbol"])
        sig = ds.idx(np.datetime64(p["signal_day"], "D")) if ds is not None else -1
        cols["status"].append(r.status)
        cols["note"].append(r.note)
        good = ds is not None and sig >= 0 and sig + 1 < len(ds)
        entry = float(ds.o[sig + 1]) if good else np.nan
        cols["signal_close"].append(float(ds.c[sig]) if ds is not None and sig >= 0 else np.nan)
        cols["entry_day"].append(str(ds.dates[sig + 1]) if good else None)
        cols["entry"].append(entry)
        cols["entry_gap"].append(entry / float(ds.c[sig]) - 1 if good else np.nan)
        sells = [f for f in r.fills if f.side == "sell"]
        cols["exit_day"].append(sells[-1].when if sells else None)
        cols["exit_price"].append(sells[-1].price if sells else np.nan)
        cols["exit_kind"].append(sells[-1].kind if sells else None)
        cols["locked_exit"].append(bool(r.locked_exit))
        cols["sessions_held"].append(int(r.exit_session) if sells else np.nan)
        fin = r.status in ("ok", "stuck")
        cols["gross_bp"].append(r.gross * 1e4 if r.status == "ok" else np.nan)
        cols["net_bp"].append(r.net * 1e4 if r.status == "ok" else np.nan)
        cols["win"].append(float(r.net > 0) if r.status == "ok" else np.nan)
        wm, wa = window_mfe_mae(ds, sig)
        cols["mfe"].append(wm)
        cols["mae"].append(wa)
        cols["mfe_held"].append(r.mfe if r.fills else np.nan)
        cols["mae_held"].append(r.mae if r.fills else np.nan)
        cols["open6_status"].append(a6.status)
        cols["open6_net_bp"].append(a6.net * 1e4 if a6.status == "ok" else np.nan)
        cols["hold10_status"].append(a10.status)
        cols["hold10_net_bp"].append(a10.net * 1e4 if a10.status == "ok" else np.nan)
        win = list(range(sig + 1, sig + 6)) if good and sig + 5 < len(ds) else []
        for kk in range(1, 6):
            j = sig + kk
            cols[f"close_ret_s{kk}"].append(float(ds.c[j]) / entry - 1 if good and j < len(ds) else np.nan)
        for kk in range(2, 7):
            j = sig + kk
            cols[f"open_ret_s{kk}"].append(float(ds.o[j]) / entry - 1 if good and j < len(ds) else np.nan)
        if win:
            hh, ll = ds.h[win], ds.l[win]
            cols["mfe_session"].append(int(np.argmax(hh)) + 1)
            cols["mae_session"].append(int(np.argmin(ll)) + 1)
            cl = ds.c[win]
            cols["best_close_session"].append(int(np.argmax(cl)) + 1)
            cols["worst_close_session"].append(int(np.argmin(cl)) + 1)
            hi, lo = ds.h[win] / entry - 1, ds.l[win] / entry - 1
            for x in TOUCH_UP:
                w = np.flatnonzero(hi >= x - 1e-12)
                cols[f"touch_up{int(x * 100)}_session"].append(int(w[0]) + 1 if len(w) else np.nan)
            for x in TOUCH_DN:
                w = np.flatnonzero(lo <= -x + 1e-12)
                cols[f"touch_dn{int(x * 100)}_session"].append(int(w[0]) + 1 if len(w) else np.nan)
            both = np.flatnonzero((hi >= 0.05 - 1e-12) & (lo <= -0.05 + 1e-12))
            cols["up5_and_dn5_same_session"].append(bool(len(both)))
        else:
            cols["mfe_session"].append(np.nan)
            cols["mae_session"].append(np.nan)
            cols["best_close_session"].append(np.nan)
            cols["worst_close_session"].append(np.nan)
            for x in TOUCH_UP:
                cols[f"touch_up{int(x * 100)}_session"].append(np.nan)
            for x in TOUCH_DN:
                cols[f"touch_dn{int(x * 100)}_session"].append(np.nan)
            cols["up5_and_dn5_same_session"].append(np.nan)
    for k, v in cols.items():
        out[k] = v
    X = rec["table"].reset_index(drop=True)
    out["status_recorded"] = X["status_recorded"].values
    out["net_recorded_bp"] = X["net_recorded"].astype(float).values * 1e4
    out["mfe_recorded"] = X["mfe_recorded"].astype(float).values
    out["mae_recorded"] = X["mae_recorded"].astype(float).values
    out["matches_record"] = X["match"].values
    out["mfe_mae_match_record"] = X["path_match"].values
    out["settled_since_record"] = X["settled_since_record"].values
    return out


def build_days(ws: Workspace, T: pd.DataFrame, plan: List[E.TradeResult]) -> pd.DataFrame:
    m = ws.market
    N = m.daily["NIFTY50"]
    P = path_frame(plan)
    if P.empty:
        return P
    P = P.drop(columns=["strategy", "mtm_net", "day_net"])
    meta = T.set_index("trade_id")[["signal_day", "traded"]]
    P["signal_day"] = P["trade_id"].map(meta["signal_day"])
    P["traded"] = P["trade_id"].map(meta["traded"])
    ext = {k: [] for k in ("entry", "ret_open_vs_entry", "ret_high_vs_entry", "ret_low_vs_entry",
                           "ret_close_vs_entry", "day_ret", "gap", "range_pct", "clv", "vol_ratio20", "atr_ratio",
                           "nifty_day_ret", "rel_nifty_day", "held_at_close", "in_window", "is_entry_day",
                           "is_exit_day", "after_exit", "mfe_sofar", "mae_sofar")}
    exit_sess = {r.pick["trade_id"]: (max([f.session for f in r.fills if f.side == "sell"], default=np.nan))
                 for r in plan}
    cur_id, hi_s, lo_s = None, -np.inf, np.inf
    for row in P.itertuples(index=False):
        ds = m.series(row.symbol)
        sig = ds.idx(np.datetime64(row.signal_day, "D"))
        j = sig + int(row.session)
        if row.trade_id != cur_id:
            cur_id, hi_s, lo_s = row.trade_id, -np.inf, np.inf
        entry = float(ds.o[sig + 1]) if sig + 1 < len(ds) else np.nan
        pc = float(ds.c[j - 1]) if j >= 1 else np.nan
        E._daily_context(ds)
        atr_prev = ds._atr14[j - 1] if j >= 1 else np.nan
        vm = ds._volmed20[j - 1] if j >= 1 else np.nan
        ni = N.idx(ds.dates[j])
        nret = float(N.c[ni] / N.c[ni - 1] - 1) if ni >= 1 else np.nan
        dret = float(ds.c[j]) / pc - 1 if np.isfinite(pc) else np.nan
        rng = float(ds.h[j] - ds.l[j])
        ext["entry"].append(entry)
        ext["ret_open_vs_entry"].append(float(ds.o[j]) / entry - 1)
        ext["ret_high_vs_entry"].append(float(ds.h[j]) / entry - 1)
        ext["ret_low_vs_entry"].append(float(ds.l[j]) / entry - 1)
        ext["ret_close_vs_entry"].append(float(ds.c[j]) / entry - 1)
        ext["day_ret"].append(dret)
        ext["gap"].append(float(ds.o[j]) / pc - 1 if np.isfinite(pc) else np.nan)
        ext["range_pct"].append(rng / pc if np.isfinite(pc) else np.nan)
        ext["clv"].append((float(ds.c[j]) - float(ds.l[j])) / rng if rng > 0 else 0.5)
        ext["vol_ratio20"].append(float(ds.v[j]) / vm if np.isfinite(vm) and vm > 0 else np.nan)
        ext["atr_ratio"].append(rng / atr_prev if np.isfinite(atr_prev) and atr_prev > 0 else np.nan)
        ext["nifty_day_ret"].append(nret)
        ext["rel_nifty_day"].append(dret - nret if np.isfinite(dret) and np.isfinite(nret) else np.nan)
        ext["held_at_close"].append(bool(row.pos > 0))
        ext["in_window"].append(1 <= int(row.session) <= 5)
        ext["is_entry_day"].append(int(row.session) == 1)
        es = exit_sess.get(row.trade_id, np.nan)
        ext["is_exit_day"].append(bool(np.isfinite(es) and int(row.session) == int(es)))
        ext["after_exit"].append(bool(np.isfinite(es) and int(row.session) > int(es)))
        if int(row.session) >= 1 and (not np.isfinite(es) or int(row.session) <= int(es)):
            hi_s, lo_s = max(hi_s, float(ds.h[j])), min(lo_s, float(ds.l[j]))
        ext["mfe_sofar"].append(hi_s / entry - 1 if np.isfinite(hi_s) else np.nan)
        ext["mae_sofar"].append(lo_s / entry - 1 if np.isfinite(lo_s) else np.nan)
    for k, v in ext.items():
        P[k] = v
    P = P.rename(columns={"mtm_net_bp": "cum_pnl_bp", "day_net_bp": "day_pnl_bp"})
    order = ["trade_id", "engine", "rank", "traded", "symbol", "signal_day", "session", "date", "in_window",
             "is_entry_day", "is_exit_day", "after_exit", "held_at_close", "open", "high", "low", "close", "volume",
             "entry", "ret_open_vs_entry", "ret_high_vs_entry", "ret_low_vs_entry", "ret_close_vs_entry",
             "mfe_sofar", "mae_sofar", "day_ret", "gap", "range_pct", "clv", "vol_ratio20", "atr_ratio",
             "nifty_day_ret", "rel_nifty_day", "day_pnl_bp", "cum_pnl_bp", "pos", "avg_entry", "buys", "sells"]
    return P[[c for c in order if c in P.columns]]


def feature_table(ws: Workspace, days: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    W = days.loc[days["session"] <= 5, ["trade_id", "symbol", "session", "date"]].copy()
    W["day"] = pd.to_datetime(W["date"]).astype("datetime64[ns]")
    F = ws.market.panel(ws.panel_name).fetch(W[["symbol", "day"]], cols)
    out = W.merge(F, on=["symbol", "day"], how="left").drop(columns=["day"])
    return out


def build_book(days: pd.DataFrame, T: pd.DataFrame) -> pd.DataFrame:
    """Per engine and session: the traded picks' book with 1/15 of capital per slot (a proxy, no compounding)."""
    d = days[days["traded"] & (days["session"] >= 1) & (days["after_exit"] == False)].copy()  # noqa: E712
    if d.empty:
        return pd.DataFrame()
    g = d.groupby(["engine", "date"])
    book = pd.DataFrame({"positions_at_close": g["held_at_close"].sum(), "new": g["is_entry_day"].sum(),
                         "exits": g["is_exit_day"].sum(), "day_pnl_bp_sum": g["day_pnl_bp"].sum(min_count=1),
                         "day_pnl_bp_mean": g["day_pnl_bp"].mean()}).reset_index()
    book["book_day_ret_slot"] = book["day_pnl_bp_sum"] / 1e4 / 15.0
    book["book_cum_ret_slot"] = book.groupby("engine")["book_day_ret_slot"].cumsum()
    return book.sort_values(["engine", "date"]).reset_index(drop=True)


def bars3_table(ws: Workspace, T: pd.DataFrame, bars: Dict[int, Dict], ids: List[str], sessions=(0, 5)) -> pd.DataFrame:
    want = set(ids)
    parts = []
    for i, p in enumerate(T.to_dict("records")):
        if p["trade_id"] not in want:
            continue
        ds = ws.market.series(p["symbol"])
        if ds is None:
            continue
        sig = ds.idx(np.datetime64(p["signal_day"], "D"))
        if sig < 0:
            continue
        entry = float(ds.o[sig + 1]) if sig + 1 < len(ds) else np.nan
        sess = bars.get(i, {})
        for kk in range(int(sessions[0]), int(sessions[1]) + 1):
            j = sig + kk
            if j < 0 or j >= len(ds):
                continue
            s = sess.get(ds.dates[j])
            if s is None:
                continue
            tp = (s.h + s.l + s.c) / 3
            cv = np.cumsum(s.v)
            vw = np.where(cv > 0, np.cumsum(tp * s.v) / np.where(cv > 0, cv, 1), tp)
            pc = float(ds.c[j - 1]) if j >= 1 else np.nan
            nb = len(s.slot)
            parts.append(pd.DataFrame({
                "trade_id": p["trade_id"], "symbol": p["symbol"], "session": kk,
                "time": pd.DatetimeIndex(s.ts()).strftime("%Y-%m-%d %H:%M"), "bar_in_session": s.slot,
                "usable_session": bool(s.usable), "open": s.o, "high": s.h, "low": s.l, "close": s.c, "volume": s.v,
                "vwap": vw, "cum_volume": cv, "ret_vs_entry": s.c / entry - 1, "ret_vs_prev_close": s.c / pc - 1,
                "session_high": np.maximum.accumulate(s.h), "session_low": np.minimum.accumulate(s.l)}, index=range(nb)))
    if not parts:
        return pd.DataFrame()
    return pd.concat(parts, ignore_index=True)


def benchmark(ws: Workspace, days) -> pd.DataFrame:
    """Buy everything: the plan's net on every panel stock that signal day, equal weight (context for 'excess').
    Same plan rule as the picks (entry at the next session's open, exit at the 5th close, honest exits, 35 bp)."""
    P = ws.market.panel(ws.panel_name)
    U = P.universe(days)
    by_sym: Dict[str, List[np.datetime64]] = {}
    for d, lst in U.items():
        for sym in lst:
            by_sym.setdefault(sym, []).append(d)
    ws.market.load(sorted(by_sym))
    cost = COST_RT_BP_DEFAULT / 1e4
    nxt = {np.datetime64(d, "D"): ws.market.next_session(d) for d in U}
    per_day: Dict[np.datetime64, List[float]] = {}
    for sym, dl in by_sym.items():
        ds = ws.market.series(sym)
        if ds is None:
            continue
        for d in dl:
            i = ds.idx(d)
            if i < 0 or i + 5 >= len(ds) or nxt.get(np.datetime64(d, "D")) is None:
                continue
            if ds.idx(nxt[np.datetime64(d, "D")]) != i + 1:
                continue
            x = i + 5
            if ds.c[x] <= ds.l[x] * (1 + 1e-9) and ds.locked(x, "close"):
                q, how = ds.honest_open_after(x)
                exitp = float(ds.o[q]) if how == "ok" else np.nan
            else:
                exitp = float(ds.c[x])
            if np.isfinite(exitp):
                per_day.setdefault(np.datetime64(d, "D"), []).append(exitp / float(ds.o[i + 1]) - 1 - cost)
    rows = [{"signal_day": d, "mkt_net_bp": float(np.mean(v)) * 1e4, "mkt_n": len(v)} for d, v in per_day.items()]
    B = pd.DataFrame(rows, columns=["signal_day", "mkt_net_bp", "mkt_n"])
    B["signal_day"] = pd.to_datetime(B["signal_day"]).astype("datetime64[ns]")
    return B


def summarize(T, trades, rec, info, ws, a, has_bench, feats_cols, written, t0) -> dict:
    head = {}
    stats = {}
    for e in sorted(trades["engine"].unique()):
        g = trades[(trades["engine"] == e) & trades["traded"] & (trades["status"] == "ok")]
        m_, lo, hi, nd = bootstrap_mean_by_day(g["signal_day"].values, g["net_bp"].values)
        line = f"{e} ranks 1-3: {len(g):,} finished trades, mean net {fmt_bp(m_, lo, hi)} bp over {nd:,} signal days"
        st = {"trades": int(len(g)), "mean_net_bp": m_, "ci": [lo, hi], "win_rate": float(g["win"].mean()),
              "median_mfe": float(g["mfe"].median()), "median_mae": float(g["mae"].median()),
              "locked_exits": int(g["locked_exit"].sum())}
        if has_bench and "excess_bp" in g:
            mx, lox, hix, _ = bootstrap_mean_by_day(g["signal_day"].values, g["excess_bp"].values)
            line += f"; excess over buy-everything {fmt_bp(mx, lox, hix)} bp"
            st["mean_excess_bp"], st["excess_ci"] = mx, [lox, hix]
        head[e] = line
        by_rank = trades[(trades["engine"] == e) & (trades["status"] == "ok")].groupby("rank")["net_bp"].agg(
            ["count", "mean"])
        st["by_rank"] = {int(k): {"n": int(v["count"]), "mean_net_bp": float(v["mean"])} for k, v in by_rank.iterrows()}
        stats[e] = st
    return {"tool": TOOL, "version": VERSION, "pm_run": a.pm_run, "picks_info": ws.picks_info,
            "selection": {"engines": a.engines, "ranks": parse_ranks(a.ranks), "from": a.d_from, "to": a.d_to},
            "status_counts": trades["status"].value_counts().to_dict(), "reconcile": {k: v for k, v in rec.items()
                                                                                     if k in ("ok", "line", "per_engine")},
            "headline": head, "stats": stats, "features": {"count": len(feats_cols)},
            "panel_dropped": {k: (len(v) if isinstance(v, list) else v) for k, v in
                              (ws.market.panel(ws.panel_name).dropped.items() if feats_cols else [])},
            "benchmark": has_bench, "files": written, "simulation": info,
            "production": ws.prod.describe(), "provenance": provenance(), "seconds": round(time.time() - t0, 1),
            "bootstrap": BOOT}


def report_md(s: dict, trades: pd.DataFrame) -> str:
    L = [f"# tradelab export - {s['pm_run']}", "",
         f"{s['tool']} ({s['version']}), {s['provenance']['created']}. Picks: {s['picks_info']['rows_selected']:,} "
         f"(engines {s['selection']['engines']}, ranks {s['selection']['ranks']}).", "",
         "## Headline (the plan: buy the session-1 open, sell the session-5 close, honest exits, 35 bp)", ""]
    for e, line in s["headline"].items():
        L.append(f"- {line}")
    L += ["", "Intervals: 95% circular block bootstrap over signal days (blocks of 10, 2,000 resamples, seed 7). "
          "Same history the engines were built and studied on - a description, not new evidence.", "",
          "## Reconciliation (safety stop)", "", f"- {s['reconcile']['line']}", "",
          "## Status of every pick", ""]
    for k, v in s["status_counts"].items():
        L.append(f"- {k}: {v:,}")
    L += ["", "## Mean net by rank (finished trades, bp)", "", "| engine | " + " | ".join(str(r) for r in range(1, 11)) + " |",
          "|---|" + "---|" * 10]
    for e, st in s["stats"].items():
        cells = [f"{st['by_rank'].get(r, {}).get('mean_net_bp', float('nan')):+.1f}" for r in range(1, 11)]
        L.append(f"| {e} | " + " | ".join(cells) + " |")
    L += ["", "## Files", ""] + [f"- {f}" for f in s["files"]] + ["",
          "## Column notes", "",
          "- Returns (ret_*, mfe, mae, close_ret_sK, open_ret_sK) are fractions of the entry price (session-1 open). "
          "P&L columns ending _bp are basis points of the trade's size, after costs.",
          "- mfe / mae: best high / worst low of sessions 1-5 vs entry (pick_meta's definition; mfe_session / "
          "mae_session = the session it happened). mfe_held / mae_held: the same while actually held (a locked exit "
          "holds longer). touch_* = first session (1-5) whose high / low reached the level; blank = never.",
          "- open6_net_bp: sold at the 6th session's open instead; hold10_net_bp: held to the 10th close (both with "
          "honest exits). These are alternatives on the same history, not tested rules.",
          "- trade_days: day_pnl_bp is the change in the trade's marked-to-close P&L that session (half of the 35 bp is "
          "charged at the buy, half at the sale); cum_pnl_bp ends at net_bp. Rows after the exit (after_exit) show what "
          "the stock did next with no position.",
          "- daily_book: positions are the traded ranks 1-3; 1/15 of capital a slot, additive - a proxy, not the "
          "execution simulator.",
          "- Features are panel values at each session's close (the firewall removed labels, forward-looking names and "
          "raw price / volume levels). Never use label_* or outcome columns as model inputs."]
    return "\n".join(L) + "\n"


COST_RT = COST_RT_BP_DEFAULT

if __name__ == "__main__":
    raise SystemExit(main())
