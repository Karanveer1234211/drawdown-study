# MANIFEST - tradelab v1

Built 2026-10-24. Folder: C:\Users\karanvsi\PyCharmMiscProject\tradelab (beside bigmove_deploy, never inside it). Outputs: C:\QuantData\tradelab. Production files are read, never written.

| file | version | sha256 (first 16) | role |
|---|---|---|---|
| README_TRADELAB.md | tradelab v1 | b204332db65d2ba2 | how to install, run and write strategies |
| env_tradelab.bat | tradelab v1 | fc1a395d0e460583 | start a session: env_daily.bat, PYTHONPATH (tradelab, open_close, bigmove_deploy), TRADELAB_OUT (CRLF) |
| plugins/example_plugin.py | tradelab v1 | 52b7f8a1462d4a50 | example plugin: vol_surge, range_pos20, above_for() |
| strategies/dip_or_fallback.py | tradelab v1 | fce97d839c256931 | example strategy |
| strategies/filtered_rsi_entry.py | tradelab v1 | af30c8ad09315f78 | example strategy |
| strategies/half_target_stop.py | tradelab v1 | 8f5ebeb98f88cf03 | example strategy |
| strategies/open6.py | tradelab v1 | 86a67db320a11d6f | example strategy |
| strategies/orb_add_on.py | tradelab v1 | e7ac4b38b71d56da | example strategy |
| strategies/plan.py | tradelab v1 | 98481fc8789d03e3 | example strategy |
| strategies/plan_intraday.py | tradelab v1 | fca2e77d51d4af68 | example strategy |
| strategies/scale_20_80_vwap.py | tradelab v1 | 629d2b225be2814a | example strategy |
| strategies/trail_after_5pct.py | tradelab v1 | cc08706cd7df6fd6 | example strategy |
| strategies/weak_close_exit.py | tradelab v1 | 64f072d7314c6535 | example strategy |
| tests/test_tradelab.py | tradelab v1 | 48f3b4057ec8e1fc | the test suite (must end VERIFIED (tradelab v1)) |
| tests/tl_world.py | tradelab v1 | d70cd0564be62ba0 | synthetic worlds + stand-in production modules for the tests |
| tl_backtest.py | tradelab v1 | c4f8dde6fcff6646 | COMMAND: a strategy vs the plan on the same picks, paired 95% intervals, money view, ledger |
| tl_check.py | tradelab v1 | 8809a85e35375d3f | COMMAND: 30-second preflight on real data (reads only) |
| tl_common.py | tradelab v1 | 5723e568b1554c73 | versions, path guards (never writes into the cache or production), hashing, tables, ledger, block bootstrap |
| tl_data.py | tradelab v1 | 9c76b18beaead2fa | read-only production access: picks (pick_meta run, hash-checked), daily bars + lock rule (stage E), calendar, 3-minute sessions (intraday_cache), panel features (label firewall) |
| tl_engine.py | tradelab v1 | 2b19c9d0805669e0 | strategies (entries, exits, windows, costs) and the bar-by-bar trade engine (fills, intrabar policy, honest exits, path, timeline) |
| tl_export.py | tradelab v1 | b99b289ac0b12be7 | COMMAND: every pick with outcomes, day by day (+ features, daily book, 3-minute bars), reconcile safety stop |
| tl_portfolio.py | tradelab v1 | a8a0f686b1807741 | the money layer: sizing rules, capital, cash, integer shares, limits, equity, drawdown |
| tl_rules.py | tradelab v1 | eaee2a7433d08630 | the rule language: safe expression compiler, built-in values, functions, events, plugin registry (@variable / @function) |
| tl_run.py | tradelab v1 | b10ec0067fe77c75 | one run's data and simulation, symbol by symbol (memory stays flat) |
| tl_sim.py | tradelab v1 | 10d01f3a795e6d5e | COMMAND: replay trades bar by bar: story, timeline, chart |

Read-only production dependencies (on your PC, unchanged): bigmove_deploy\open_close\stage_e_execution.py (v1.2, 158883f0af70728d - checked at start; --stage-e-any to accept another), EXECUTION_DECLARATION.json, intraday_cache.py (+ its declaration), research_common.py; bigmove_deploy\data_quality.py, panel_build.py (optional); %CACHE_DAILY_ROOT% (daily bars, intraday_3m, panel_oc, research2\pick_meta\PM_20261017_001).

