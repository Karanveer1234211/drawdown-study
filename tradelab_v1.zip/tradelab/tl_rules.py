"""
tl_rules.py - tradelab v1: the rule language.

A rule is one Python-like expression, written as text in a strategy file:

    "crosses_above(close, vwap) and hhmm < 1430"
    "upnl < -0.05 or (session >= 3 and close < prev_low)"
    "avg_entry * 0.95"                                   (a price level, for a stop)

Allowed: numbers, True/False, + - * / ** % //, comparisons (chains too), and / or / not,
`x if cond else y`, names from the catalog (bar values, session values, daily context, pick attributes,
panel features, trade-state values, named events) and the functions below. Nothing else parses: no
attributes, indexing, strings, lambdas or imports.

Point in time: every value at bar t uses bars up to and including t. A rule that fires at bar t acts at
bar t+1 (next-bar fills) unless a strategy explicitly allows same-bar close fills. shift(x, n) needs n >= 1.
Label firewall: names starting with label_ and forward-looking names are refused everywhere.

Two kinds of names:
  market values  - known for every bar from the bars alone; computed once per trade as vectors.
  trade state    - pos, avg_entry, upnl, ... - known only while simulating; evaluated bar by bar.
Series functions (shift, ema, crosses_above, ...) look back over bars, so they take market values only.

Custom values and functions: write a plugin (see plugins/example_plugin.py) with @variable / @function.
Every plugin output is checked for look-ahead (values before bar t must not change when bars after t change).
"""
from __future__ import annotations

import ast
import functools
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd

from tl_common import TLError
from tl_data import is_forbidden_name, suggest


class RuleError(TLError):
    pass


# ======================================================================
# catalog of names
# ======================================================================
# mode: 'both' | 'intraday' (needs 3-minute bars)
MARKET_VARS: Dict[str, Tuple[str, str]] = {
    # bar
    "open": ("both", "bar open (daily mode: the official open)"),
    "high": ("both", "bar high"),
    "low": ("both", "bar low"),
    "close": ("both", "bar close (daily mode: the official close)"),
    "volume": ("both", "bar volume"),
    "typical": ("both", "(high + low + close) / 3"),
    "hl_range": ("both", "high - low"),
    "body": ("both", "close - open"),
    "upper_wick": ("both", "high - max(open, close)"),
    "lower_wick": ("both", "min(open, close) - low"),
    "clv": ("both", "close location in the bar's range, 0 = at the low, 1 = at the high"),
    "bar_ret": ("both", "close / previous bar's close - 1"),
    # clock
    "session": ("both", "0 = signal day, 1 = entry day (first session after the signal), 2, 3, ..."),
    "bar_in_session": ("both", "0..124 for 3-minute bars (0 = the 09:15 bar); always 0 in daily mode"),
    "minute": ("both", "minutes from 09:15 to the bar's start (daily mode: 0)"),
    "hhmm": ("both", "bar start time as a number, e.g. 945 for 09:45 (daily mode: 915)"),
    "is_first_bar": ("both", "1 on the session's first bar"),
    "is_last_bar": ("both", "1 on the session's last bar"),
    "weekday": ("both", "0 = Monday ... 4 = Friday"),
    "sessions_left": ("both", "max_sessions - session"),
    # session
    "vwap": ("intraday", "session VWAP from 09:15 to this bar (typical price x volume)"),
    "session_open": ("both", "the session's official open (daily bar)"),
    "session_high": ("both", "highest high of the session so far"),
    "session_low": ("both", "lowest low of the session so far"),
    "session_volume": ("both", "volume of the session so far"),
    "day_ret": ("both", "close / previous session's close - 1"),
    "gap": ("both", "session_open / previous session's close - 1"),
    "prev_close": ("both", "previous session's official close"),
    "prev_open": ("both", "previous session's open"),
    "prev_high": ("both", "previous session's high"),
    "prev_low": ("both", "previous session's low"),
    "prev_volume": ("both", "previous session's volume"),
    "dist_prev_high": ("both", "close / prev_high - 1"),
    "dist_prev_low": ("both", "close / prev_low - 1"),
    # trade references (market facts, not position facts)
    "entry_open": ("both", "official open of session 1 (the plan's entry price)"),
    "signal_close": ("both", "official close of session 0 (the signal day)"),
    "ret_vs_entry_open": ("both", "close / entry_open - 1"),
    # daily context (values known when the rule is checked)
    "atr14": ("both", "simple mean true range of 14 sessions (through the last completed session)"),
    "atr14_pct": ("both", "atr14 / last completed close"),
    "vol_med20": ("both", "median daily volume of 20 sessions (through the last completed session)"),
    "rvol": ("both", "session_volume / vol_med20"),
    "nifty": ("both", "NIFTY 50 level (3-minute close in intraday mode when its file exists, else daily close)"),
    "nifty_day_ret": ("both", "NIFTY 50 return of the session so far vs its previous close"),
    "rel_nifty_day": ("both", "day_ret - nifty_day_ret"),
    "nifty_ret5": ("both", "NIFTY 50 5-session return through the last completed session"),
}

STATE_VARS: Dict[str, str] = {
    "pos": "fraction of the trade's target size held now (0..1)",
    "in_pos": "1 while anything is held",
    "avg_entry": "average entry price of what is held (NaN when flat)",
    "first_entry": "price of the first buy",
    "upnl": "close / avg_entry - 1 (NaN when flat)",
    "upnl_first": "close / first_entry - 1",
    "mfe_sofar": "highest high since the first buy / first_entry - 1",
    "mae_sofar": "lowest low since the first buy / first_entry - 1",
    "peak_close": "highest close since the first buy",
    "bars_in_trade": "bars since the first buy (0 on the buy bar)",
    "sessions_in_trade": "sessions since the first buy (0 on the buy session)",
    "legs_filled": "number of entry legs filled",
    "exits_done": "number of exit rules that have sold",
    "realized": "realized gross P&L so far (before costs), as a fraction of the target size",
}

FUNC_HELP: Dict[str, str] = {
    "shift(x, n=1)": "x n bars ago (n >= 1)",
    "prev(x)": "x one bar ago",
    "sma(x, n) / mean(x, n)": "simple moving average of n bars",
    "ema(x, n)": "exponential moving average (span n)",
    "rsi(x, n=14)": "Wilder RSI",
    "std(x, n)": "rolling standard deviation",
    "zscore(x, n)": "(x - sma) / std over n bars",
    "highest(x, n) / lowest(x, n)": "max / min of the last n bars INCLUDING this one (use shift() for breakouts)",
    "roc(x, n)": "x / x n bars ago - 1",
    "change(x, n)": "x - x n bars ago",
    "rsum(x, n)": "rolling sum of n bars",
    "crosses_above(a, b) / crosses_below(a, b)": "a crossed b on this bar",
    "rising(x, n=1) / falling(x, n=1)": "x above / below its value n bars ago",
    "bars_since(cond)": "bars since cond was last true (0 if true now, NaN if never)",
    "held_for(cond, n)": "cond true on each of the last n bars",
    "count_true(cond, n)": "how many of the last n bars had cond true",
    "trade_max(x) / trade_min(x)": "max / min of x since session 1 began (NaN before)",
    "session_max(x) / session_min(x) / session_sum(x) / session_first(x)": "running value within each session",
    "prev_session(x)": "x at the previous session's last bar",
    "opening_range_high(n=5) / opening_range_low(n=5)": "high / low of the session's first n bars, known from bar n-1 on (intraday)",
    "abs, min, max, log, exp, sqrt, sign, round, clip(x, lo, hi), where(c, a, b), isnan(x), nz(x, v=0)": "elementwise",
}

INTRADAY_ONLY_FUNCS = {"opening_range_high", "opening_range_low"}
ELEM_FUNCS = {"abs", "min", "max", "log", "exp", "sqrt", "sign", "round", "clip", "where", "isnan", "nz"}
SERIES_FUNCS = {"shift", "prev", "sma", "mean", "ema", "rsi", "std", "zscore", "highest", "lowest", "roc", "change",
                "rsum", "crosses_above", "crosses_below", "rising", "falling", "bars_since", "held_for", "count_true",
                "trade_max", "trade_min", "session_max", "session_min", "session_sum", "session_first",
                "prev_session", "opening_range_high", "opening_range_low"}
# argument positions that must be integer constants (>= 1)
INT_ARGS = {"shift": {1: "n"}, "sma": {1: "n"}, "mean": {1: "n"}, "ema": {1: "n"}, "rsi": {1: "n"},
            "std": {1: "n"}, "zscore": {1: "n"}, "highest": {1: "n"}, "lowest": {1: "n"}, "roc": {1: "n"},
            "change": {1: "n"}, "rsum": {1: "n"}, "rising": {1: "n"}, "falling": {1: "n"}, "held_for": {1: "n"},
            "count_true": {1: "n"}, "opening_range_high": {0: "n"}, "opening_range_low": {0: "n"}}
ARITY = {"shift": (1, 2), "prev": (1, 1), "sma": (2, 2), "mean": (2, 2), "ema": (2, 2), "rsi": (1, 2), "std": (2, 2),
         "zscore": (2, 2), "highest": (2, 2), "lowest": (2, 2), "roc": (2, 2), "change": (2, 2), "rsum": (2, 2),
         "crosses_above": (2, 2), "crosses_below": (2, 2), "rising": (1, 2), "falling": (1, 2), "bars_since": (1, 1),
         "held_for": (2, 2), "count_true": (2, 2), "trade_max": (1, 1), "trade_min": (1, 1), "session_max": (1, 1),
         "session_min": (1, 1), "session_sum": (1, 1), "session_first": (1, 1), "prev_session": (1, 1),
         "opening_range_high": (0, 1), "opening_range_low": (0, 1), "abs": (1, 1), "min": (2, 9), "max": (2, 9),
         "log": (1, 1), "exp": (1, 1), "sqrt": (1, 1), "sign": (1, 1), "round": (1, 2), "clip": (3, 3),
         "where": (3, 3), "isnan": (1, 1), "nz": (1, 2)}

# --- plugin registries ---------------------------------------------------------------------------------
PLUGIN_VARS: Dict[str, Tuple[Callable, str, str]] = {}      # name -> (fn(ctx) -> array, mode, help)
PLUGIN_FUNCS: Dict[str, Tuple[Callable, int, int, str]] = {}  # name -> (fn(*arrays/consts) -> array, min, max, help)


def variable(name: str, help: str = "", mode: str = "both"):
    """Decorator for a plugin market value: fn(ctx) -> numpy array over the trade's bars (point in time!)."""
    def deco(fn):
        _check_new_name(name)
        PLUGIN_VARS[name] = (fn, mode, help)
        return fn
    return deco


def function(name: str, min_args: int = 1, max_args: int = 3, help: str = ""):
    """Decorator for a plugin series function: fn(x, ...) -> numpy array (must look only backward)."""
    def deco(fn):
        _check_new_name(name)
        PLUGIN_FUNCS[name] = (fn, int(min_args), int(max_args), help)
        return fn
    return deco


def _check_new_name(name: str) -> None:
    if not name.isidentifier() or name.startswith("_"):
        raise RuleError(f"plugin name '{name}' must be a plain identifier not starting with '_'")
    if is_forbidden_name(name):
        raise RuleError(f"plugin name '{name}' looks like a label / forward-looking name (firewall)")
    if name in MARKET_VARS or name in STATE_VARS or name in SERIES_FUNCS or name in ELEM_FUNCS:
        raise RuleError(f"plugin name '{name}' clashes with a built-in name")


def clear_plugins() -> None:
    PLUGIN_VARS.clear()
    PLUGIN_FUNCS.clear()


# ======================================================================
# function library (vector implementations; every one looks only backward)
# ======================================================================
def _f(x, n: int) -> np.ndarray:
    a = np.asarray(x, dtype=float)
    if a.ndim == 0:
        return np.full(n, float(a))
    return a


def _b(x) -> np.ndarray:
    """Truth of a value: NaN is False."""
    a = np.asarray(x)
    if a.dtype == bool:
        return a
    a = a.astype(float)
    return np.where(np.isnan(a), False, a != 0)


def _and(*xs):
    return functools.reduce(np.logical_and, (_b(x) for x in xs))


def _or(*xs):
    return functools.reduce(np.logical_or, (_b(x) for x in xs))


def _not(x):
    return np.logical_not(_b(x))


def _where(c, a, b):
    return np.where(_b(c), a, b)


class Ctx:
    """What series functions and plugin values see for one trade: the bar clock (no future beyond its end)."""

    def __init__(self, n: int, session: np.ndarray, bar_in_session: np.ndarray, first_active: int,
                 arrays: Dict[str, np.ndarray], getter: Optional[Callable] = None, daily=None, day_pos=None):
        self.n = n
        self.session = session
        self.bar_in_session = bar_in_session
        self.first_active = first_active
        self._arrays = arrays
        self._getter = getter
        self.daily = daily                 # a DailyView (truncated to the clock's last day)
        self.day_pos = day_pos             # position in daily of each bar's session

    def var(self, name: str) -> np.ndarray:
        if name in self._arrays:
            return self._arrays[name]
        if self._getter is None:
            raise RuleError(f"value '{name}' not available here")
        return self._getter(name)

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self.var(name)


def _roll(x, n, how):
    s = pd.Series(x)
    r = s.rolling(int(n), min_periods=int(n))
    return getattr(r, how)().to_numpy(float)


def f_shift(ctx, x, n=1):
    a = _f(x, ctx.n)
    n = int(n)
    out = np.full(len(a), np.nan)
    if n < len(a):
        out[n:] = a[:len(a) - n]
    return out


def f_prev(ctx, x):
    return f_shift(ctx, x, 1)


def f_sma(ctx, x, n):
    return _roll(_f(x, ctx.n), n, "mean")


def f_ema(ctx, x, n):
    return pd.Series(_f(x, ctx.n)).ewm(span=int(n), adjust=False, min_periods=int(n)).mean().to_numpy(float)


def f_rsi(ctx, x, n=14):
    a = _f(x, ctx.n)
    d = np.diff(a, prepend=np.nan)
    up = pd.Series(np.where(d > 0, d, np.where(np.isnan(d), np.nan, 0.0)))
    dn = pd.Series(np.where(d < 0, -d, np.where(np.isnan(d), np.nan, 0.0)))
    au = up.ewm(alpha=1.0 / int(n), adjust=False, min_periods=int(n)).mean().to_numpy(float)
    ad = dn.ewm(alpha=1.0 / int(n), adjust=False, min_periods=int(n)).mean().to_numpy(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = au / ad
        out = 100.0 - 100.0 / (1.0 + rs)
    out = np.where((ad == 0) & np.isfinite(au), 100.0, out)
    return out


def f_std(ctx, x, n):
    return _roll(_f(x, ctx.n), n, "std")


def f_zscore(ctx, x, n):
    a = _f(x, ctx.n)
    m = _roll(a, n, "mean")
    s = _roll(a, n, "std")
    with np.errstate(divide="ignore", invalid="ignore"):
        return (a - m) / s


def f_highest(ctx, x, n):
    return _roll(_f(x, ctx.n), n, "max")


def f_lowest(ctx, x, n):
    return _roll(_f(x, ctx.n), n, "min")


def f_roc(ctx, x, n):
    a = _f(x, ctx.n)
    with np.errstate(divide="ignore", invalid="ignore"):
        return a / f_shift(ctx, a, n) - 1.0


def f_change(ctx, x, n):
    a = _f(x, ctx.n)
    return a - f_shift(ctx, a, n)


def f_rsum(ctx, x, n):
    return _roll(_f(x, ctx.n), n, "sum")


def f_crosses_above(ctx, a, b):
    a, b = _f(a, ctx.n), _f(b, ctx.n)
    a0, b0 = f_shift(ctx, a, 1), f_shift(ctx, b, 1)
    with np.errstate(invalid="ignore"):
        return (a > b) & (a0 <= b0)


def f_crosses_below(ctx, a, b):
    a, b = _f(a, ctx.n), _f(b, ctx.n)
    a0, b0 = f_shift(ctx, a, 1), f_shift(ctx, b, 1)
    with np.errstate(invalid="ignore"):
        return (a < b) & (a0 >= b0)


def f_rising(ctx, x, n=1):
    a = _f(x, ctx.n)
    with np.errstate(invalid="ignore"):
        return a > f_shift(ctx, a, n)


def f_falling(ctx, x, n=1):
    a = _f(x, ctx.n)
    with np.errstate(invalid="ignore"):
        return a < f_shift(ctx, a, n)


def f_bars_since(ctx, c):
    c = _b(c) if np.ndim(c) else np.full(ctx.n, bool(_b(c)))
    ar = np.arange(len(c))
    last = np.maximum.accumulate(np.where(c, ar, -1))
    out = (ar - last).astype(float)
    out[last < 0] = np.nan
    return out


def f_held_for(ctx, c, n):
    c = _b(c).astype(float) if np.ndim(c) else np.full(ctx.n, float(_b(c)))
    return _roll(c, n, "sum") >= int(n)


def f_count_true(ctx, c, n):
    c = _b(c).astype(float) if np.ndim(c) else np.full(ctx.n, float(_b(c)))
    return _roll(c, n, "sum")


def _from_active(ctx, a, acc):
    out = np.full(ctx.n, np.nan)
    s = ctx.first_active
    if s < ctx.n:
        seg = a[s:].copy()
        seg = pd.Series(seg)
        out[s:] = getattr(seg, acc)().to_numpy(float)
    return out


def f_trade_max(ctx, x):
    return _from_active(ctx, _f(x, ctx.n), "cummax")


def f_trade_min(ctx, x):
    return _from_active(ctx, _f(x, ctx.n), "cummin")


def _by_session(ctx, x, how):
    s = pd.Series(_f(x, ctx.n))
    return getattr(s.groupby(ctx.session), how)().to_numpy(float)


def f_session_max(ctx, x):
    return _by_session(ctx, x, "cummax")


def f_session_min(ctx, x):
    return _by_session(ctx, x, "cummin")


def f_session_sum(ctx, x):
    return _by_session(ctx, x, "cumsum")


def f_session_first(ctx, x):
    # the session's first bar's value is known from that bar on (point in time)
    a = _f(x, ctx.n)
    out = np.full(ctx.n, np.nan)
    first_idx = {}
    for i, s in enumerate(ctx.session):
        if s not in first_idx:
            first_idx[s] = i
        out[i] = a[first_idx[s]]
    return out


def f_prev_session(ctx, x):
    a = _f(x, ctx.n)
    out = np.full(ctx.n, np.nan)
    last_of = {}
    for i, s in enumerate(ctx.session):
        last_of[s] = i
    sess = list(dict.fromkeys(ctx.session.tolist()))
    prev_val = {}
    for k, s in enumerate(sess):
        prev_val[s] = a[last_of[sess[k - 1]]] if k > 0 else np.nan
    for i, s in enumerate(ctx.session):
        out[i] = prev_val[s]
    return out


def _orng(ctx, n, which):
    n = int(n)
    h = ctx.var("high") if which == "high" else ctx.var("low")
    out = np.full(ctx.n, np.nan)
    bis = ctx.bar_in_session
    cur, val, start = None, np.nan, 0
    for i in range(ctx.n):
        s = ctx.session[i]
        if s != cur:
            cur, val = s, np.nan
        if bis[i] < n:
            val = h[i] if not np.isfinite(val) else (max(val, h[i]) if which == "high" else min(val, h[i]))
        if bis[i] >= n - 1:
            out[i] = val
    return out


def f_opening_range_high(ctx, n=5):
    return _orng(ctx, n, "high")


def f_opening_range_low(ctx, n=5):
    return _orng(ctx, n, "low")


def _elem(name):
    def mn(*xs):
        return functools.reduce(np.fmin, [np.asarray(x, float) for x in xs])

    def mx(*xs):
        return functools.reduce(np.fmax, [np.asarray(x, float) for x in xs])

    def lg(x):
        with np.errstate(divide="ignore", invalid="ignore"):
            return np.log(np.asarray(x, float))

    def sq(x):
        with np.errstate(invalid="ignore"):
            return np.sqrt(np.asarray(x, float))

    def nz(x, v=0.0):
        a = np.asarray(x, float)
        return np.where(np.isnan(a), v, a)

    def rnd(x, nd=0):
        return np.round(np.asarray(x, float), int(nd))

    table = {"abs": lambda x: np.abs(np.asarray(x, float)), "min": mn, "max": mx, "log": lg,
             "exp": lambda x: np.exp(np.asarray(x, float)), "sqrt": sq, "sign": lambda x: np.sign(np.asarray(x, float)),
             "round": rnd, "clip": lambda x, lo, hi: np.clip(np.asarray(x, float), lo, hi), "where": _where,
             "isnan": lambda x: np.isnan(np.asarray(x, float)), "nz": nz}
    return table[name]


SERIES_IMPL = {"shift": f_shift, "prev": f_prev, "sma": f_sma, "mean": f_sma, "ema": f_ema, "rsi": f_rsi,
               "std": f_std, "zscore": f_zscore, "highest": f_highest, "lowest": f_lowest, "roc": f_roc,
               "change": f_change, "rsum": f_rsum, "crosses_above": f_crosses_above,
               "crosses_below": f_crosses_below, "rising": f_rising, "falling": f_falling,
               "bars_since": f_bars_since, "held_for": f_held_for, "count_true": f_count_true,
               "trade_max": f_trade_max, "trade_min": f_trade_min, "session_max": f_session_max,
               "session_min": f_session_min, "session_sum": f_session_sum, "session_first": f_session_first,
               "prev_session": f_prev_session, "opening_range_high": f_opening_range_high,
               "opening_range_low": f_opening_range_low}
ELEM_IMPL = {k: _elem(k) for k in ELEM_FUNCS}


def series_namespace(ctx: Ctx) -> Dict[str, Callable]:
    ns = {k: functools.partial(f, ctx) for k, f in SERIES_IMPL.items()}
    for k, (fn, _, _, _) in PLUGIN_FUNCS.items():
        ns[k] = _plugin_func_wrapper(ctx, k, fn)
    return ns


def _plugin_func_wrapper(ctx, name, fn):
    def call(*args):
        args2 = [(_f(a, ctx.n) if np.ndim(a) else a) for a in args]
        out = np.asarray(fn(*args2), dtype=float)
        if out.shape != (ctx.n,):
            raise RuleError(f"plugin function {name} returned shape {out.shape}, expected ({ctx.n},)")
        return out
    return call


BASE_NS = {"_and": _and, "_or": _or, "_not": _not, "_where": _where, **ELEM_IMPL}


# ======================================================================
# compiler
# ======================================================================
_ALLOWED = (ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub, ast.UAdd, ast.BinOp,
            ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.FloorDiv, ast.Compare, ast.Lt, ast.LtE,
            ast.Gt, ast.GtE, ast.Eq, ast.NotEq, ast.Name, ast.Load, ast.Constant, ast.Call, ast.IfExp, ast.keyword)


class Names:
    """The names a strategy's rules may use (built once per strategy and run)."""

    def __init__(self, mode: str, pick_attrs: Iterable[str] = (), features: Optional[Set[str]] = None,
                 leg_names: Iterable[str] = (), events: Optional[Dict[str, str]] = None):
        self.mode = mode
        self.pick_attrs = set(pick_attrs)
        self.features = features                         # None = not known yet (collect, check later)
        self.filled = {f"filled_{n}" for n in leg_names}
        self.events = dict(events or {})
        self.state = set(STATE_VARS) | self.filled
        self.unknown_features: Set[str] = set()

    def all_known(self) -> Set[str]:
        s = set(MARKET_VARS) | set(PLUGIN_VARS) | self.pick_attrs | self.state | set(self.events)
        if self.features:
            s |= self.features
        return s

    def kind(self, name: str) -> str:
        if name in self.state:
            return "state"
        if name in self.events:
            return "event"
        if name in MARKET_VARS:
            return "market"
        if name in PLUGIN_VARS:
            return "plugin"
        if name in self.pick_attrs:
            return "pick"
        if self.features is not None and name in self.features:
            return "feature"
        return "unknown"


class Rule:
    """One compiled rule. kind = 'bool' (a condition) or 'num' (a level / number)."""

    def __init__(self, src, names: Names, what: str, kind: str = "bool"):
        if isinstance(src, (int, float)) and not isinstance(src, bool):
            src = repr(float(src))
        if not isinstance(src, str) or not src.strip():
            raise RuleError(f"{what}: a rule must be non-empty text")
        self.src = src.strip()
        self.what = what
        self.kind = kind
        self.names = names
        try:
            tree = ast.parse(self.src, mode="eval")
        except SyntaxError as e:
            raise RuleError(f"{what}: cannot parse '{self.src}': {e.msg}") from None
        self.used: Set[str] = set()
        self.features: Set[str] = set()
        self.market: Set[str] = set()
        self.plugins: Set[str] = set()
        self.picks: Set[str] = set()
        self.state_used: Set[str] = set()
        self.events_used: Set[str] = set()
        body = self._expand(tree.body, stack=())
        self.stateful = bool(self.state_used)
        self.intraday_only = any(MARKET_VARS.get(n, ("both",))[0] == "intraday" for n in self.market) or \
            any(PLUGIN_VARS[n][1] == "intraday" for n in self.plugins) or self._uses_funcs(body, INTRADAY_ONLY_FUNCS)
        if self.intraday_only and names.mode == "daily":
            raise RuleError(f"{what}: '{self.src}' needs 3-minute bars (vwap / opening range / intraday plugin); "
                            f"set the strategy's mode to 'intraday'")
        tbody = _Lower().visit(body)
        if self.stateful:
            h = _Hoist(names.state)
            tbody = h.visit(tbody)
            self.hoisted = [(nm, compile(ast.fix_missing_locations(ast.Expression(body=sub)), f"<{what}:{nm}>", "eval"))
                            for nm, sub in h.subtrees]
            self.code = compile(ast.fix_missing_locations(ast.Expression(body=tbody)), f"<{what}>", "eval")
        else:
            self.hoisted = []
            self.code = compile(ast.fix_missing_locations(ast.Expression(body=tbody)), f"<{what}>", "eval")

    # --- validation and event expansion ---
    def _expand(self, node, stack):
        for sub in ast.walk(node):
            if not isinstance(sub, _ALLOWED):
                raise RuleError(f"{self.what}: '{type(sub).__name__}' is not allowed in rules ('{self.src}')")
            if isinstance(sub, ast.Constant) and not isinstance(sub.value, (int, float, bool)):
                raise RuleError(f"{self.what}: only numbers and True/False are allowed as constants ('{self.src}')")
            if isinstance(sub, ast.Call):
                self._check_call(sub)
        return _Expander(self, stack).visit(node)

    def _check_call(self, c: ast.Call) -> None:
        if not isinstance(c.func, ast.Name):
            raise RuleError(f"{self.what}: only plain function calls are allowed ('{self.src}')")
        fn = c.func.id
        if fn not in SERIES_FUNCS and fn not in ELEM_FUNCS and fn not in PLUGIN_FUNCS:
            raise RuleError(f"{self.what}: unknown function '{fn}'."
                            f"{suggest(fn, list(SERIES_FUNCS | ELEM_FUNCS | set(PLUGIN_FUNCS)))}")
        if any(isinstance(a, ast.Starred) for a in c.args):
            raise RuleError(f"{self.what}: *args are not allowed")
        if fn in PLUGIN_FUNCS:
            lo, hi = PLUGIN_FUNCS[fn][1], PLUGIN_FUNCS[fn][2]
            if c.keywords:
                raise RuleError(f"{self.what}: plugin function {fn} takes positional arguments only")
        else:
            lo, hi = ARITY[fn]
            if c.keywords:
                names = INT_ARGS.get(fn, {})
                allowed = set(names.values()) | ({"v"} if fn == "nz" else set()) | ({"nd"} if fn == "round" else set())
                for k in c.keywords:
                    if k.arg not in allowed:
                        raise RuleError(f"{self.what}: {fn}() has no argument '{k.arg}'")
        nargs = len(c.args) + len(c.keywords)
        if not (lo <= nargs <= hi):
            raise RuleError(f"{self.what}: {fn}() takes {lo}..{hi} arguments, got {nargs} ('{self.src}')")
        for pos, nm in INT_ARGS.get(fn, {}).items():
            node = c.args[pos] if pos < len(c.args) else next((k.value for k in c.keywords if k.arg == nm), None)
            if node is None:
                continue
            v = node.value if isinstance(node, ast.Constant) else None
            if not (isinstance(v, int) and not isinstance(v, bool) and v >= 1):
                extra = " (shift looks back: n must be 1 or more - future bars are never readable)" if fn == "shift" else ""
                raise RuleError(f"{self.what}: {fn}(): '{nm}' must be a whole number >= 1{extra} ('{self.src}')")

    def _uses_funcs(self, node, names) -> bool:
        return any(isinstance(s, ast.Call) and isinstance(s.func, ast.Name) and s.func.id in names
                   for s in ast.walk(node))

    # --- evaluation ---
    def vector(self, env: dict, n: int):
        """Whole-trade evaluation (state-free rules only)."""
        if self.stateful:
            raise RuleError(f"{self.what}: a trade-state rule cannot be evaluated as a vector")
        return self._finish(eval(self.code, env), n)

    def prepare(self, env: dict, n: int) -> List[Tuple[str, np.ndarray]]:
        """Hoisted state-free parts as vectors (stateful rules)."""
        return [(nm, _fullv(eval(code, env), n)) for nm, code in self.hoisted]

    def scalar(self, ns: dict):
        r = eval(self.code, ns)
        if self.kind == "bool":
            r = np.asarray(r)
            if r.dtype == bool:
                return bool(r)
            v = float(r)
            return (not np.isnan(v)) and v != 0.0
        return float(r)

    def _finish(self, r, n: int):
        a = _fullv(r, n)
        if self.kind == "bool":
            return _b(a)
        return a.astype(float)


def _fullv(r, n: int) -> np.ndarray:
    a = np.asarray(r)
    if a.ndim == 0:
        a = np.full(n, a.item())
    if a.shape != (n,):
        raise RuleError(f"rule produced shape {a.shape}, expected ({n},)")
    return a


class _Expander(ast.NodeTransformer):
    def __init__(self, rule: Rule, stack):
        self.r = rule
        self.stack = stack

    def visit_Call(self, node: ast.Call):
        node.args = [self.visit(a) for a in node.args]
        for k in node.keywords:
            k.value = self.visit(k.value)
        return node

    def visit_Name(self, node: ast.Name):
        nm = node.id
        r = self.r
        if nm.startswith("_"):
            raise RuleError(f"{r.what}: names starting with '_' are reserved ('{nm}')")
        if nm.startswith("label_"):
            raise RuleError(f"{r.what}: '{nm}' is a label - the label firewall refuses it")
        kind = r.names.kind(nm)
        if kind in ("feature", "unknown") and is_forbidden_name(nm):
            raise RuleError(f"{r.what}: '{nm}' is a label or forward-looking name - the label firewall refuses it")
        if kind == "event":
            if nm in self.stack:
                raise RuleError(f"{r.what}: event '{nm}' refers to itself (cycle {' -> '.join(self.stack + (nm,))})")
            r.events_used.add(nm)
            src = r.names.events[nm]
            if isinstance(src, (int, float)) and not isinstance(src, bool):
                src = repr(float(src))
            try:
                sub = ast.parse(str(src), mode="eval").body
            except SyntaxError as e:
                raise RuleError(f"event '{nm}': cannot parse '{src}': {e.msg}") from None
            for s in ast.walk(sub):
                if not isinstance(s, _ALLOWED):
                    raise RuleError(f"event '{nm}': '{type(s).__name__}' is not allowed")
                if isinstance(s, ast.Constant) and not isinstance(s.value, (int, float, bool)):
                    raise RuleError(f"event '{nm}': only numbers and True/False are allowed as constants")
                if isinstance(s, ast.Call):
                    r._check_call(s)
            return _Expander(r, self.stack + (nm,)).visit(sub)
        if kind == "unknown":
            if r.names.features is None and not nm.startswith(("filled_",)) and nm.isidentifier():
                # a panel feature, checked against the panel's allowed list once the panel is opened
                r.names.unknown_features.add(nm)
                r.features.add(nm)
                r.used.add(nm)
                return node
            raise RuleError(f"{r.what}: unknown name '{nm}'.{suggest(nm, r.names.all_known())}")
        r.used.add(nm)
        {"state": r.state_used, "market": r.market, "plugin": r.plugins, "pick": r.picks,
         "feature": r.features}[kind].add(nm)
        return node


class _Lower(ast.NodeTransformer):
    """and/or/not, chained comparisons and x-if-c-else-y -> numpy-safe helper calls."""

    def visit_BoolOp(self, node):
        vals = [self.visit(v) for v in node.values]
        fn = "_and" if isinstance(node.op, ast.And) else "_or"
        return ast.Call(func=ast.Name(id=fn, ctx=ast.Load()), args=vals, keywords=[])

    def visit_UnaryOp(self, node):
        node.operand = self.visit(node.operand)
        if isinstance(node.op, ast.Not):
            return ast.Call(func=ast.Name(id="_not", ctx=ast.Load()), args=[node.operand], keywords=[])
        return node

    def visit_Compare(self, node):
        left = self.visit(node.left)
        comps = [self.visit(c) for c in node.comparators]
        if len(node.ops) == 1:
            return ast.Compare(left=left, ops=node.ops, comparators=comps)
        parts, a = [], left
        for op, b in zip(node.ops, comps):
            parts.append(ast.Compare(left=a, ops=[op], comparators=[b]))
            a = b
        return ast.Call(func=ast.Name(id="_and", ctx=ast.Load()), args=parts, keywords=[])

    def visit_IfExp(self, node):
        return ast.Call(func=ast.Name(id="_where", ctx=ast.Load()),
                        args=[self.visit(node.test), self.visit(node.body), self.visit(node.orelse)], keywords=[])


class _Hoist:
    """Replace every maximal state-free part of a stateful rule by a name holding its precomputed vector."""

    def __init__(self, state: Set[str]):
        self.state = state
        self.subtrees: List[Tuple[str, ast.AST]] = []

    def _stateful(self, node) -> bool:
        return any(isinstance(s, ast.Name) and s.id in self.state for s in ast.walk(node))

    def visit(self, node):
        if isinstance(node, ast.Constant):
            return node
        if not self._stateful(node):
            nm = f"_h{len(self.subtrees)}"
            self.subtrees.append((nm, node))
            return ast.Name(id=nm, ctx=ast.Load())
        if isinstance(node, ast.Name):                       # a trade-state value
            return node
        if isinstance(node, ast.Call):
            fn = node.func.id if isinstance(node.func, ast.Name) else ""
            if fn in SERIES_FUNCS or fn in PLUGIN_FUNCS:
                bad = sorted({s.id for s in ast.walk(node) if isinstance(s, ast.Name) and s.id in self.state})
                raise RuleError(f"{fn}() looks back over bars, so it takes market values only - trade-state values "
                                f"({', '.join(bad)}) are known one bar at a time. Compare them directly instead "
                                f"(e.g. upnl > 0.02).")
            node.args = [self.visit(a) for a in node.args]
            for k in node.keywords:
                k.value = self.visit(k.value)
            return node
        if isinstance(node, ast.BinOp):
            node.left, node.right = self.visit(node.left), self.visit(node.right)
            return node
        if isinstance(node, ast.Compare):
            node.left = self.visit(node.left)
            node.comparators = [self.visit(c) for c in node.comparators]
            return node
        if isinstance(node, ast.UnaryOp):
            node.operand = self.visit(node.operand)
            return node
        raise RuleError(f"internal: cannot hoist node {type(node).__name__}")


def catalog_text(pick_attrs: Iterable[str] = (), features: Iterable[str] = ()) -> str:
    """Everything a rule can use, as text (tl_backtest.py --list-names)."""
    lines = ["MARKET VALUES (vectors; 'intraday' needs mode: intraday)"]
    for k, (m, h) in MARKET_VARS.items():
        lines.append(f"  {k:<20} {'[intraday] ' if m == 'intraday' else ''}{h}")
    lines.append("\nTRADE STATE (bar by bar; not inside series functions)")
    for k, h in STATE_VARS.items():
        lines.append(f"  {k:<20} {h}")
    lines.append("  filled_<leg>         1 once the entry leg <leg> has filled")
    lines.append("\nFUNCTIONS")
    for k, h in FUNC_HELP.items():
        lines.append(f"  {k}: {h}")
    if PLUGIN_VARS or PLUGIN_FUNCS:
        lines.append("\nPLUGINS")
        for k, (_, m, h) in PLUGIN_VARS.items():
            lines.append(f"  {k:<20} value [{m}] {h}")
        for k, (_, lo, hi, h) in PLUGIN_FUNCS.items():
            lines.append(f"  {k}({lo}..{hi} args) {h}")
    pa = list(pick_attrs)
    if pa:
        lines.append("\nPICK ATTRIBUTES (constants per trade): " + ", ".join(pa))
    fl = list(features)
    if fl:
        lines.append(f"\nPANEL FEATURES ({len(fl)}; daily values - in intraday mode the previous session's): "
                     + ", ".join(fl[:400]) + (" ..." if len(fl) > 400 else ""))
    return "\n".join(lines)
