"""
tl_backtest.py - tradelab v1: run a strategy on the frozen engines' picks and compare it with the plan.

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\scale_20_80_vwap.py
        [--compare auto | strategies\\open6.py]   auto = the plan, run on the same picks and the same clock
        [--engines D ENS] [--ranks 1-3] [--from 2021-10-01] [--to 2026-09-15]   (override the strategy's picks)
        [--capital 1000000] [--no-portfolio] [--timeline D-20240425-2,ENS-20250102-1]
        [--tag "what I am trying"] [--declare "PASS if the paired difference's lower bound > 0"]
        [--list-names]    print every value / function a rule can use, and exit

What it reports (report.md, summary.json):
  - per pick slot: the strategy's mean net (bp, after costs, measured on the trade's full target size so an
    unfilled leg counts as cash), the plan's mean on the SAME picks, and the paired difference - each with a 95%
    circular block bootstrap over signal days (blocks of 10, 2,000 resamples, seed 7) and a verdict
    BETTER / WORSE / NOT SHOWN for the difference;
  - win rates, how often each leg filled, exit reasons, MFE / MAE, by year / engine / rank;
  - the money view (unless --no-portfolio): both through one account with the strategy's sizing - CAGR, worst
    drawdown with dates, Sharpe, exposure, skipped trades, and the paired difference of daily returns.
Every run is logged in <out>\\tradelab_ledger.jsonl BEFORE it starts (with --declare: your decision rule) and again
with its result. The report says how many backtests the ledger holds: every extra variant you try on the same
years makes a 'BETTER' easier to get by luck. A result here is exploratory until a declared rule passes on
trades it has not seen (the forward paper ledger).

Writes <out>\\backtest\\TLB_YYYYMMDD_NNN\\: trades, fills, trade_days (.csv + .parquet), portfolio_daily.csv,
portfolio_trades.csv, timelines\\<trade>.csv (with --timeline), the strategy files, report.md, summary.json,
outputs.sha256.
"""
from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (BOOT, StopRun, TLError, VERSION, bootstrap_daily, bootstrap_mean_by_day, fmt_bp,
                       ledger_append, ledger_read, new_run_dir, out_base, parse_ranks, provenance, require_root, say,
                       sha256_text, verdict_from_interval, write_outputs_sha, write_table)
import tl_data as D
import tl_engine as E
import tl_rules as R
from tl_portfolio import run_portfolio
from tl_run import Workspace, fills_frame, path_frame

TOOL = "tl_backtest v1"
EVALUABLE_S = ("ok", "not_entered", "filtered")


def parse_args(argv):
    ap = argparse.ArgumentParser(description="tradelab backtest: a strategy on the frozen picks, paired with the plan")
    ap.add_argument("--root")
    ap.add_argument("--pm-run")
    ap.add_argument("--strategy")
    ap.add_argument("--compare", default="auto")
    ap.add_argument("--engines", nargs="+", default=None)
    ap.add_argument("--ranks", default=None)
    ap.add_argument("--from", dest="d_from", default=None)
    ap.add_argument("--to", dest="d_to", default=None)
    ap.add_argument("--capital", type=float, default=None)
    ap.add_argument("--no-portfolio", action="store_true")
    ap.add_argument("--timeline", default="")
    ap.add_argument("--tag", default="")
    ap.add_argument("--declare", default="")
    ap.add_argument("--list-names", action="store_true")
    ap.add_argument("--values", default="", help="extra values recorded in the timelines, e.g. vwap,rvol,clv,D_rsi14")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--out", default=None)
    ap.add_argument("--stage-e-any", action="store_true")
    return ap.parse_args(argv)


def plan_like(s: E.Strategy, pick_attrs) -> E.Strategy:
    """The plan on the same picks and the same clock as strategy s (so the comparison is paired)."""
    raw = {"name": "plan" if s.mode == "daily" else "plan_intraday", "mode": s.mode, "picks": copy.deepcopy(s.picks),
           "max_sessions": 5, "warmup_sessions": s.warmup,
           "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
           "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
           "costs": copy.deepcopy(s.raw.get("costs") or {"model": "flat", "round_trip_bp": 35}),
           "slippage_bp": s.slippage_bp,
           "sizing": copy.deepcopy(s.sizing), "portfolio": copy.deepcopy(s.portfolio)}
    raw["picks"]["filter"] = None
    return E.Strategy(raw, None, pick_attrs)


def main(argv=None) -> int:
    a = parse_args(sys.argv[1:] if argv is None else argv)
    t0 = time.time()
    try:
        if a.list_names:
            names = R.catalog_text()
            if a.root and a.pm_run:
                root = require_root(a.root)
                ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel, quiet=True)
                T = ws.picks(["D", "ENS"], "1-10")
                feats = ws.market.panel(a.panel).allowed
                names = R.catalog_text(ws.pick_attrs(T), feats)
            say(names)
            return 0
        if not a.strategy:
            raise TLError("--strategy is required (e.g. --strategy strategies\\scale_20_80_vwap.py)")
        root = require_root(a.root)
        base = out_base(a.out, root)
        ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel)
        raw0, _ = E.read_strategy(a.strategy)          # first pass: only the picks to load
        pk0 = dict(raw0.get("picks") or {})
        picks = {"engines": list(pk0.get("engines", ["D"])), "ranks": list(pk0.get("ranks", [1, 2, 3])),
                 "from": pk0.get("from"), "to": pk0.get("to"), "filter": pk0.get("filter")}
        if a.engines:
            picks["engines"] = a.engines
        if a.ranks:
            picks["ranks"] = parse_ranks(a.ranks)
        if a.d_from:
            picks["from"] = a.d_from
        if a.d_to:
            picks["to"] = a.d_to
        T = ws.picks(picks["engines"], picks["ranks"], picks["from"], picks["to"])
        S = ws.strategy(a.strategy, T)
        S.picks.update({k: picks[k] for k in ("engines", "ranks", "from", "to")})
        if a.capital:
            S.portfolio["capital"] = a.capital
        extra_vals = [x.strip() for x in a.values.split(",") if x.strip()]
        if extra_vals:
            allowed = ws.market.panel(a.panel).allowed if any(
                x not in R.MARKET_VARS and x not in R.PLUGIN_VARS for x in extra_vals) else []
            S.observe(extra_vals, allowed)
        C = plan_like(S, ws.pick_attrs(T)) if a.compare == "auto" else ws.strategy(a.compare, T)
        if a.compare != "auto":
            C.picks.update({k: picks[k] for k in ("engines", "ranks", "from", "to")})
            if C.mode != S.mode and S.mode == "intraday":
                say("note: the comparison runs in daily mode; picks without 3-minute bars are left out of the "
                    "pairing anyway (the strategy cannot trade them)")
        prior = [r for r in ledger_read(base) if r.get("tool") == TOOL and r.get("event") == "backtest_run"]
        n_prior = len(prior)
        distinct = len({r.get("strategy_sha") for r in prior})
        declared = {"tool": TOOL, "event": "backtest_declared", "strategy": S.name, "strategy_sha": S.sha,
                    "compare": C.name, "compare_sha": C.sha, "pm_run": a.pm_run, "picks": S.picks,
                    "tag": a.tag, "declared_rule": a.declare or None, "decision_rule": S.decision_rule}
        ledger_append(base, declared)
        say(f"{TOOL} ({VERSION}) | {S.name} ({S.mode}, sha {S.sha}) vs {C.name} | picks {len(T):,} | "
            f"engines {S.picks['engines']} ranks {S.picks['ranks']} | ledger: {n_prior} earlier backtests "
            f"({distinct} distinct strategies)")
        tl_ids = [x.strip() for x in a.timeline.split(",") if x.strip()]
        bad = [x for x in tl_ids if x not in set(T["trade_id"])]
        if bad:
            raise TLError(f"--timeline: unknown trade ids {bad[:5]}")
        res, extra = ws.simulate([S, C] if C.name != S.name else [S], T, timeline_ids=tl_ids)
        rS, rC = res[S.name], res[C.name]
        run_dir = new_run_dir(base, "backtest", "TLB")
        A = pd.DataFrame([r.row() for r in rS])
        B = pd.DataFrame([r.row() for r in rC])
        ev = paired_eval(T, A, B)
        port = None
        if not a.no_portfolio:
            say("money view: both through one account ...")
            pS = run_portfolio([r for r, ok in zip(rS, ev["mask"]) if ok], S, ws.market)
            pC = run_portfolio([r for r, ok in zip(rC, ev["mask"]) if ok], C, ws.market)
            port = portfolio_compare(pS, pC)
        decision = decide(S.decision_rule, ev, port)
        # outputs
        A2 = A.copy()
        A2["net_bp_compare"] = B["net_bp"].values
        A2["status_compare"] = B["status"].values
        A2["diff_bp"] = np.where(ev["mask"], A2["net_bp"] - A2["net_bp_compare"], np.nan)
        A2["paired"] = ev["mask"]
        for c in ("signal_day",):
            A2[c] = T[c].values
        written = write_table(A2, run_dir / "trades")
        written += write_table(fills_frame(rS + rC), run_dir / "fills")
        written += write_table(path_frame(rS), run_dir / "trade_days")
        if port is not None:
            dd = port["daily"]
            dd.to_csv(run_dir / "portfolio_daily.csv", index=False)
            port["trades"].to_csv(run_dir / "portfolio_trades.csv", index=False)
            written += ["portfolio_daily.csv", "portfolio_trades.csv"]
        if tl_ids:
            (run_dir / "timelines").mkdir()
            for r in rS:
                if r.timeline is not None:
                    r.timeline.to_csv(run_dir / "timelines" / f"{r.pick['trade_id']}.csv", index=False)
                    written.append(f"timelines/{r.pick['trade_id']}.csv")
        for src, nm in ((S.path, "strategy"), (C.path, "compare")):
            if src is not None:
                shutil.copy2(src, run_dir / f"{nm}_{Path(src).name}")
        summ = {"tool": TOOL, "version": VERSION, "pm_run": a.pm_run, "strategy": S.summary(), "compare": C.summary(),
                "picks": len(T), "picks_info": ws.picks_info, "paired": ev["summary"], "portfolio": port["stats"] if port
                else None, "decision": decision, "tag": a.tag, "declared_rule": a.declare or None,
                "ledger": {"earlier_backtests": n_prior, "distinct_strategies": distinct},
                "simulation": extra["info"], "production": ws.prod.describe(), "provenance": provenance(),
                "files": written, "seconds": round(time.time() - t0, 1), "bootstrap": BOOT}
        (run_dir / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
        (run_dir / "report.md").write_text(report_md(summ, ev, port), encoding="utf-8")
        write_outputs_sha(run_dir)
        ledger_append(base, {"tool": TOOL, "event": "backtest_run", "run": run_dir.name, "strategy": S.name,
                             "strategy_sha": S.sha, "compare": C.name, "picks": S.picks, "tag": a.tag,
                             "paired_diff_bp": ev["summary"]["diff"], "decision": decision,
                             "seconds": round(time.time() - t0, 1)})
        for line in headline_lines(summ, ev, port):
            say(line)
        say(f"DONE {run_dir}  ({time.time() - t0:,.0f} s)")
        return 0
    except StopRun as e:
        say(f"STOPPED: {e}")
        return 3
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


# ----------------------------------------------------------------------
def paired_eval(T: pd.DataFrame, A: pd.DataFrame, B: pd.DataFrame) -> dict:
    mask = (A["status"].isin(EVALUABLE_S) & (B["status"] == "ok")).to_numpy()
    days = T["signal_day"].to_numpy()
    a = A["net_bp"].to_numpy(float)
    b = B["net_bp"].to_numpy(float)
    ms, los, his, nd = bootstrap_mean_by_day(days[mask], a[mask])
    mc, loc, hic, _ = bootstrap_mean_by_day(days[mask], b[mask])
    md, lod, hid, _ = bootstrap_mean_by_day(days[mask], (a - b)[mask])
    ent = A["entered"].to_numpy(bool) & mask
    traded = A["status"].isin(("ok",)).to_numpy() & mask
    mt, lot, hit, _ = bootstrap_mean_by_day(days[traded], (a - b)[traded])
    left = (~mask) & (B["status"] == "ok").to_numpy()          # the plan finished but the strategy could not trade
    ml, lol, hil, _ = bootstrap_mean_by_day(days[left], b[left]) if left.any() else (np.nan, np.nan, np.nan, 0)
    summ = {"picks_paired": int(mask.sum()), "picks_total": int(len(T)), "signal_days": nd,
            "left_out_plan": {"picks": int(left.sum()), "plan_mean_bp": [ml, lol, hil],
                              "reasons": A.loc[left, "status"].value_counts().to_dict()},
            "excluded": A.loc[~mask, "status"].value_counts().to_dict(),
            "compare_excluded": B.loc[~mask, "status"].value_counts().to_dict(),
            "strategy": [ms, los, his], "compare": [mc, loc, hic], "diff": [md, lod, hid],
            "verdict": verdict_from_interval(lod, hid),
            "diff_on_traded": [mt, lot, hit], "traded": int(traded.sum()),
            "entered_share": float(ent.sum() / max(1, mask.sum())),
            "avg_deployed": float(A.loc[mask, "deployed"].mean()),
            "win_strategy": float((a[mask] > 0).mean()) if mask.any() else np.nan,
            "win_compare": float((b[mask] > 0).mean()) if mask.any() else np.nan,
            "net_on_deployed_bp": float(np.nanmean(A.loc[ent, "net_deployed_bp"])) if ent.any() else np.nan,
            "median_mfe": float(A.loc[ent, "mfe"].median()) if ent.any() else np.nan,
            "median_mae": float(A.loc[ent, "mae"].median()) if ent.any() else np.nan,
            "exit_reasons": A.loc[ent, "exit_reason"].value_counts().to_dict(),
            "legs": _leg_rates(A, ent), "ambiguous_bars": int(A.loc[mask, "ambiguous_bars"].sum()),
            "locked_exits": int(A.loc[mask, "locked_exit"].sum()),
            "avg_exit_session": float(A.loc[ent, "exit_session"].mean()) if ent.any() else np.nan}
    yrs = pd.DatetimeIndex(days).year
    by_year = []
    for y in sorted(set(yrs[mask])):
        m = mask & (yrs == y)
        by_year.append({"year": int(y), "picks": int(m.sum()), "strategy": float(a[m].mean()),
                        "compare": float(b[m].mean()), "diff": float((a - b)[m].mean())})
    summ["by_year"] = by_year
    by = []
    for (e, rk), g in A[mask].assign(diff=(a - b)[mask], cmp=b[mask]).groupby(["engine", "rank"]):
        by.append({"engine": e, "rank": int(rk), "picks": int(len(g)), "strategy": float(g["net_bp"].mean()),
                   "compare": float(g["cmp"].mean()), "diff": float(g["diff"].mean())})
    summ["by_engine_rank"] = by
    return {"mask": mask, "summary": summ}


def _leg_rates(A: pd.DataFrame, ent: np.ndarray) -> Dict[str, float]:
    out: Dict[str, int] = {}
    for s in A.loc[ent, "legs_filled"].fillna(""):
        for leg in [x for x in s.split(";") if x]:
            out[leg] = out.get(leg, 0) + 1
    n = max(1, int(ent.sum()))
    return {k: v / n for k, v in out.items()}


def portfolio_compare(pS, pC) -> dict:
    d = pS.daily.merge(pC.daily[["date", "day_ret", "equity"]], on="date", how="outer", suffixes=("", "_compare"))
    d = d.sort_values("date").reset_index(drop=True)
    diff = (d["day_ret"] - d["day_ret_compare"]).to_numpy(float)
    m, lo, hi = bootstrap_daily(diff)
    stats = {"strategy": pS.stats, "compare": pC.stats,
             "daily_ret_diff_bp": [m * 1e4, lo * 1e4 if np.isfinite(lo) else lo, hi * 1e4 if np.isfinite(hi) else hi],
             "daily_ret_diff_verdict": verdict_from_interval(lo, hi)}
    return {"daily": d, "trades": pS.trades, "stats": stats}


def decide(rule, ev: dict, port: Optional[dict]) -> Optional[dict]:
    """Strategy file's decision_rule: {"metric": "diff_mean_bp" | "strategy_mean_bp", "pass_if": "lower > 0"}."""
    if not rule:
        return None
    s = ev["summary"]
    metric = rule.get("metric", "diff_mean_bp")
    vals = {"diff_mean_bp": s["diff"], "strategy_mean_bp": s["strategy"]}.get(metric)
    if vals is None:
        return {"rule": rule, "verdict": f"UNKNOWN METRIC {metric}"}
    m, lo, hi = vals
    cond = str(rule.get("pass_if", "lower > 0")).strip()
    try:
        side, op, x = cond.split()
        x = float(x)
        v = {"lower": lo, "upper": hi, "mean": m}[side]
        ok = {">": v > x, ">=": v >= x, "<": v < x, "<=": v <= x}[op]
    except Exception:
        return {"rule": rule, "verdict": f"UNREADABLE pass_if '{cond}' (use e.g. 'lower > 0')"}
    if not np.isfinite(v):
        return {"rule": rule, "verdict": "NO INTERVAL"}
    return {"rule": rule, "value": v, "verdict": "PASS" if ok else "FAIL"}


def headline_lines(summ, ev, port) -> List[str]:
    s = ev["summary"]
    L = [f"paired picks: {s['picks_paired']:,} of {s['picks_total']:,} over {s['signal_days']:,} signal days "
         f"(left out: {s['excluded']})",
         f"strategy {fmt_bp(*s['strategy'])} bp per pick | {summ['compare']['name']} {fmt_bp(*s['compare'])} bp | "
         f"difference {fmt_bp(*s['diff'])} bp -> {s['verdict']}",
         f"entered {s['entered_share']:.1%} of picks, average size used {s['avg_deployed']:.2f}, legs {s['legs']}"]
    if port is not None:
        ps, pc = port["stats"]["strategy"], port["stats"]["compare"]
        if "cagr" in ps and "cagr" in pc:
            L.append(f"money: strategy CAGR {ps['cagr']:+.1%}, worst drawdown {ps['max_drawdown']:+.1%} | "
                     f"{summ['compare']['name']} CAGR {pc['cagr']:+.1%}, worst drawdown {pc['max_drawdown']:+.1%}")
    if summ.get("decision"):
        L.append(f"decision rule: {summ['decision']}")
    L.append(f"ledger: {summ['ledger']['earlier_backtests']} earlier backtests, "
             f"{summ['ledger']['distinct_strategies']} distinct strategies - exploratory unless declared and forward-tested")
    return L


def report_md(summ, ev, port) -> str:
    s = ev["summary"]
    S, C = summ["strategy"], summ["compare"]
    L = [f"# tradelab backtest - {S['name']}", "",
         f"{summ['tool']} ({summ['version']}), {summ['provenance']['created']}. pick_meta run {summ['pm_run']}. "
         f"Strategy {S['path']} (sha {S['sha16']}, mode {S['mode']}), compared with {C['name']}.",
         f"Tag: {summ['tag'] or '-'}. Declared rule: {summ['declared_rule'] or '-'}.", "",
         "## Verdict first", "",
         f"- Per pick slot: strategy **{fmt_bp(*s['strategy'])} bp**, {C['name']} {fmt_bp(*s['compare'])} bp, "
         f"difference **{fmt_bp(*s['diff'])} bp -> {s['verdict']}** ({s['picks_paired']:,} picks, "
         f"{s['signal_days']:,} signal days).",
         f"- On the picks the strategy actually traded ({s['traded']:,}): difference {fmt_bp(*s['diff_on_traded'])} bp.",
         f"- Picks the plan finished but the strategy could not trade ({s['left_out_plan']['picks']:,}, "
         f"{s['left_out_plan']['reasons']}): the plan made {fmt_bp(*s['left_out_plan']['plan_mean_bp'])} bp on them vs "
         f"{fmt_bp(*s['compare'])} bp on the paired picks - a large gap means the pairing is not a fair sample.",
         f"- Entered {s['entered_share']:.1%} of picks; average size used {s['avg_deployed']:.2f} of the target; "
         f"net on the money actually used {s['net_on_deployed_bp']:+.1f} bp.", ""]
    if port is not None and "cagr" in port["stats"]["strategy"]:
        ps, pc = port["stats"]["strategy"], port["stats"]["compare"]
        L += ["## Money view (one account, the strategy's sizing)", "",
              "| | strategy | " + C["name"] + " |", "|---|---|---|",
              f"| CAGR | {ps['cagr']:+.2%} | {pc['cagr']:+.2%} |",
              f"| worst drawdown | {ps['max_drawdown']:+.2%} ({ps['dd_peak']} -> {ps['dd_trough']}) | "
              f"{pc['max_drawdown']:+.2%} ({pc['dd_peak']} -> {pc['dd_trough']}) |",
              f"| Sharpe (daily x sqrt 252) | {ps['sharpe']:.2f} | {pc['sharpe']:.2f} |",
              f"| average exposure | {ps['avg_exposure']:.2f} | {pc['avg_exposure']:.2f} |",
              f"| trades opened | {ps['trades_opened']:,} | {pc['trades_opened']:,} |",
              f"| skipped (reason) | {ps['trades_skipped']} | {pc['trades_skipped']} |",
              f"| legs trimmed / skipped by cash | {ps['legs_trimmed_by_cash']} / {ps['legs_skipped_by_cash']} | "
              f"{pc['legs_trimmed_by_cash']} / {pc['legs_skipped_by_cash']} |", "",
              f"Daily return difference: {fmt_bp(*port['stats']['daily_ret_diff_bp'], nd=2)} bp a day -> "
              f"{port['stats']['daily_ret_diff_verdict']}.", ""]
    L += ["## Detail", "", f"- Win rate: strategy {s['win_strategy']:.1%}, {C['name']} {s['win_compare']:.1%}.",
          f"- Legs filled (share of entered picks): {s['legs']}.", f"- Exit reasons: {s['exit_reasons']}.",
          f"- Median MFE {s['median_mfe']:+.2%}, median MAE {s['median_mae']:+.2%} (from the first buy, while held).",
          f"- Average exit session {s['avg_exit_session']:.2f}; locked exits {s['locked_exits']}; bars where a stop and "
          f"a target were both inside the bar (settled by the '{S['intrabar']}' policy): {s['ambiguous_bars']}.",
          f"- Left out of the pairing: strategy {s['excluded']}, {C['name']} {s['compare_excluded']}.", "",
          "### By year (bp per pick)", "", "| year | picks | strategy | " + C["name"] + " | difference |",
          "|---|---|---|---|---|"]
    for y in s["by_year"]:
        L.append(f"| {y['year']} | {y['picks']:,} | {y['strategy']:+.1f} | {y['compare']:+.1f} | {y['diff']:+.1f} |")
    L += ["", "### By engine and rank (bp per pick)", "", "| engine | rank | picks | strategy | " + C["name"] +
          " | difference |", "|---|---|---|---|---|---|"]
    for r in s["by_engine_rank"]:
        L.append(f"| {r['engine']} | {r['rank']} | {r['picks']:,} | {r['strategy']:+.1f} | {r['compare']:+.1f} | "
                 f"{r['diff']:+.1f} |")
    lg = summ["ledger"]
    L += ["", "## How much to trust this", "",
          f"- The tradelab ledger held {lg['earlier_backtests']} earlier backtests ({lg['distinct_strategies']} distinct "
          f"strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at "
          f"the 95% level by luck alone.",
          "- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: "
          "declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.",
          f"- Costs: {S['costs']}; slippage {S['slippage_bp']} bp a side. Fills: next-bar opens, stop / limit "
          "levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.",
          "- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model."]
    if summ.get("decision"):
        L += ["", f"## Decision rule: {summ['decision']}"]
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    raise SystemExit(main())
