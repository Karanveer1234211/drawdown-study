"""
tl_data.py - tradelab v1: read-only access to production data.

  picks        pick_meta's research run (research2\\pick_meta\\<run>\\predictions.parquet, SHA-256 checked against the
               run's outputs.sha256): frozen D and ENS walk-forward top 10 per signal day with the recorded honest
               outcome of each pick (status, net, mfe, mae) - the record the plain plan must reproduce.
  daily bars   stage E's loader (stage_e_execution.load_bars) - the same bars and the same lower-circuit rule
               (stage_e_execution.lower_locked) every honest exit in the project uses.
  calendar     NIFTY50's sessions.
  3-minute     intraday_cache.store(root): <SYMBOL>_3m.parquet, 125 bars a session, bar k starts 09:15 + 3k (IST).
  features     panel_oc\\panel.parquet, filtered by the label firewall (label_*, forward-looking names, raw levels).

Nothing here writes anywhere.
"""
from __future__ import annotations

import difflib
import importlib
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from tl_common import (IST, SESSION_START_MIN, StopRun, TLError, hash_matches, read_hash_file, sha16, sha256_file,
                       to_day)

STAGE_E_SHA16 = "158883f0af70728d"            # stage_e_execution.py v1.2, the shipped version
STAGE_E_VERSION = "stage_e_execution v1.2"
BAR_MIN = 3
BARS_PER_SESSION = 125
USABLE_SHARE = 0.80                            # a session needs >= 80% of its 125 bars ...
PRICE_TOL = 0.005                              # ... a 09:15 bar, first open / high / low within 0.5% of the daily bar
LOCK_SEARCH = 20                               # honest exits: first unlocked open within 20 sessions, else stuck

# --- label firewall (copies of production's rules; production's own functions are used when importable) ----
FORWARD_PATTERNS = ("_fwd", "fwd_", "future_", "_ahead", "lookahead", "mfe", "mae", "target_", "label_", "_next",
                    "ret_1d_close_pct", "ret_3d_close_pct", "ret_5d_close_pct")   # = features_daily.FORWARD_PATTERNS
FORWARD_COLUMNS = frozenset({"ret_5d_close_pct"})                               # = research_common.FORWARD_COLUMNS
RAW_LEVELS = frozenset({"open", "high", "low", "close", "volume", "vwap", "turnover", "adj_close", "prev_close",
                        "value", "oi", "price", "ltp"})
IDENTIFIERS = ("timestamp", "symbol", "date")

# --- pick_meta columns --------------------------------------------------------------------------------------
PM_REQUIRED = ["engine", "signal_day", "symbol", "rank", "status", "net", "mfe", "mae"]
PM_OUTCOMES = ["status", "net", "mfe", "mae", "trap", "entry_day", "exit_day", "r5", "win", "big", "deep"]


def is_forbidden_name(name: str) -> bool:
    """True for a label or forward-looking column name (never a feature, never usable in a rule)."""
    n = str(name)
    low = n.lower()
    if n.startswith("label_") or n in FORWARD_COLUMNS or any(p in low for p in FORWARD_PATTERNS):
        return True
    try:
        import research_common as RC                 # production firewall, when importable
        if hasattr(RC, "is_forbidden_feature") and RC.is_forbidden_feature(n):
            return True
    except Exception:
        pass
    return False


def suggest(name: str, options: Iterable[str], n: int = 4) -> str:
    m = difflib.get_close_matches(name, list(options), n=n, cutoff=0.55)
    return f" Did you mean: {', '.join(m)}?" if m else ""


# ======================================================================
# production modules (read only)
# ======================================================================
class Production:
    """stage_e_execution (load_bars, lower_locked), data_quality (_paths), intraday_cache (store, BAR_MIN)."""

    def __init__(self, stage_e_any: bool = False):
        try:
            self.EX = importlib.import_module("stage_e_execution")
        except ImportError as e:
            raise TLError(f"cannot import stage_e_execution ({e}). Start with env_tradelab.bat: it puts "
                          f"bigmove_deploy\\open_close on PYTHONPATH (read only)") from e
        miss = [n for n in ("load_bars", "lower_locked") if not hasattr(self.EX, n)]
        if miss:
            raise TLError(f"stage_e_execution ({self.EX.__file__}) lacks {miss} - not the shipped version?")
        self.stage_e_file = str(Path(self.EX.__file__).resolve())
        self.stage_e_sha16 = sha16(self.EX.__file__)
        self.stage_e_version = str(getattr(self.EX, "CODE_VERSION", "unknown"))
        if self.stage_e_sha16 != STAGE_E_SHA16 and not stage_e_any:
            raise TLError(f"stage_e_execution.py at {self.stage_e_file} has SHA {self.stage_e_sha16}, not the shipped "
                          f"v1.2 ({STAGE_E_SHA16}). Its lower-circuit rule decides every honest exit, so tradelab "
                          f"refuses. Send Claude the file, or pass --stage-e-any to accept it knowingly.")
        try:
            self.DQ = importlib.import_module("data_quality")
        except ImportError:
            self.DQ = None
        self._IC = None

    @property
    def IC(self):
        if self._IC is None:
            try:
                self._IC = importlib.import_module("intraday_cache")
            except ImportError as e:
                raise TLError(f"cannot import intraday_cache ({e}) - needed for 3-minute bars") from e
            miss = [n for n in ("store", "BAR_MIN") if not hasattr(self._IC, n)]
            if miss:
                raise TLError(f"intraday_cache ({self._IC.__file__}) lacks {miss} - not the shipped version?")
            if int(self._IC.BAR_MIN) != BAR_MIN:
                raise TLError(f"intraday_cache.BAR_MIN = {self._IC.BAR_MIN}; tradelab needs {BAR_MIN}-minute bars")
        return self._IC

    def describe(self) -> dict:
        d = {"stage_e_file": self.stage_e_file, "stage_e_sha16": self.stage_e_sha16,
             "stage_e_version": self.stage_e_version, "stage_e_is_shipped": self.stage_e_sha16 == STAGE_E_SHA16}
        if self._IC is not None:
            d["intraday_cache_file"] = str(Path(self._IC.__file__).resolve())
            d["intraday_cache_version"] = str(getattr(self._IC, "CODE_VERSION", "unknown"))
        return d


# ======================================================================
# daily bars
# ======================================================================
class DailySeries:
    """One symbol's daily bars by IST day (a two-bar day keeps its later bar, as the forensics)."""

    def __init__(self, sym: str, b, prod: Production, root: Path, diag: dict):
        self.sym = sym
        self.prod = prod
        ts = np.asarray(b.ts).astype("datetime64[ns]")
        o, h, l, c = (np.asarray(getattr(b, k), dtype=float) for k in ("o", "h", "l", "c"))
        days = ts.astype("datetime64[D]")
        if len(ts):
            tod = (ts - days.astype("datetime64[ns]")).astype("timedelta64[m]").astype(np.int64)
            if np.mean(tod == 18 * 60 + 30) > 0.5:          # IST midnight stored as a UTC instant
                days = (ts + np.timedelta64(330, "m")).astype("datetime64[D]")
                diag["utc_shifted"] = diag.get("utc_shifted", 0) + 1
        vol = getattr(b, "v", None)
        v = np.asarray(vol, dtype=float) if vol is not None and len(np.asarray(vol)) == len(ts) else None
        if v is not None and len(v) and not np.nansum(np.abs(v)) > 0:     # an all-zero volume array: read the file
            v = None
        order = np.argsort(ts, kind="mergesort")
        changed = not np.array_equal(order, np.arange(len(ts)))
        days_s = days[order]
        keep = np.ones(len(order), dtype=bool)
        if len(order) > 1:
            keep[:-1] = days_s[1:] != days_s[:-1]           # keep the LAST bar of each day
        if (~keep).any():
            diag["two_bar_days"] = diag.get("two_bar_days", 0) + int((~keep).sum())
            changed = True
        sel = order[keep]
        self.dates = days[sel]
        self.ts = ts[sel]
        self.o, self.h, self.l, self.c = o[sel], h[sel], l[sel], c[sel]
        if v is None:
            v = self._volume_from_file(root, sym, ts, diag)
        self.v = v[sel] if v is not None else np.full(len(sel), np.nan)
        self.borig = b                      # stage E's own object: its lock rule sees exactly its own bars
        self.orig_idx = sel.astype(np.int64)  # my position -> stage E's position
        self._lock: Dict[Tuple[int, str], bool] = {}
        self._pos = {d: i for i, d in enumerate(self.dates.tolist())}

    def _volume_from_file(self, root: Path, sym: str, ts: np.ndarray, diag: dict) -> Optional[np.ndarray]:
        if self.prod.DQ is None or not hasattr(self.prod.DQ, "_paths"):
            diag["no_volume"] = diag.get("no_volume", 0) + 1
            return None
        try:
            p = self.prod.DQ._paths(Path(root), sym)[0]
            df = pd.read_parquet(p, columns=["timestamp", "volume"])
        except Exception:
            diag["no_volume"] = diag.get("no_volume", 0) + 1
            return None
        d = pd.Series(df["volume"].to_numpy(float), index=to_day(df["timestamp"]))
        d = d[~d.index.duplicated(keep="last")]
        want = ts.astype("datetime64[D]")
        return d.reindex(want).to_numpy(float)

    def __len__(self) -> int:
        return len(self.dates)

    def idx(self, day) -> int:
        """Position of an IST day, -1 when the symbol has no bar that day."""
        return self._pos.get(np.datetime64(day, "D").item(), -1) if day is not None else -1

    def first_after(self, day) -> int:
        """Position of the first bar strictly after `day` (len when none)."""
        return int(np.searchsorted(self.dates, np.datetime64(day, "D"), side="right"))

    def locked(self, i: int, side: str) -> bool:
        """stage E's rule: is bar i's close / open locked at the lower circuit band?"""
        if i <= 0 or i >= len(self.dates):
            return False
        k = (i, side)
        r = self._lock.get(k)
        if r is None:
            try:
                r = bool(self.prod.EX.lower_locked(self.borig, int(self.orig_idx[i]), side))
            except Exception as e:
                raise TLError(f"stage_e_execution.lower_locked(bars, i, '{side}') failed for {self.sym} "
                              f"({type(e).__name__}: {e}). Send Claude this line.") from None
            self._lock[k] = r
        return r

    def frozen(self, i: int) -> bool:
        """A bar that never traded off the lower band (o = h = l = c and locked at the close): nothing sells."""
        return bool(self.o[i] == self.h[i] == self.l[i] == self.c[i]) and self.locked(i, "close")

    def honest_open_after(self, i: int, search: int = LOCK_SEARCH) -> Tuple[int, str]:
        """First open after bar i that is not lower-locked, within `search` sessions.
        Returns (position, 'ok'), (last searched position, 'stuck') or (len-1, 'pending') when the data ends."""
        n = len(self.dates)
        last = i + search
        for k in range(i + 1, min(last, n - 1) + 1):
            if not self.locked(k, "open"):
                return k, "ok"
        if last <= n - 1:
            return last, "stuck"
        return n - 1, "pending"


class Market:
    """Everything a run reads, loaded once (daily bars for the needed symbols, calendar, NIFTY, ATR, medians)."""

    def __init__(self, root: Path, prod: Production):
        self.root = Path(root)
        self.prod = prod
        self.daily: Dict[str, DailySeries] = {}
        self.diag: dict = {}
        self.missing: List[str] = []
        self._load(["NIFTY50"])
        if "NIFTY50" not in self.daily:
            raise TLError("NIFTY50 bars missing from the cache (the trading calendar)")
        self.cal = self.daily["NIFTY50"].dates
        self._intraday = None
        self._panel = None

    def _load(self, syms: Sequence[str]) -> None:
        want = [s for s in dict.fromkeys(syms) if s not in self.daily and s not in self.missing]
        if not want:
            return
        try:
            bars = self.prod.EX.load_bars(self.root, list(want))
        except Exception as e:
            raise TLError(f"stage_e_execution.load_bars(root, symbols) failed ({type(e).__name__}: {e}). tradelab "
                          f"expects load_bars(root, list_of_symbols) -> {{symbol: Bars(ts, o, h, l, c, ...)}}. Send Claude "
                          f"this line.") from None
        for s in want:
            b = bars.get(s) if isinstance(bars, dict) else None
            if b is None or len(np.asarray(b.ts)) == 0:
                self.missing.append(s)
                continue
            self.daily[s] = DailySeries(s, b, self.prod, self.root, self.diag)

    def load(self, syms: Sequence[str]) -> None:
        self._load(list(syms))

    def series(self, sym: str) -> Optional[DailySeries]:
        if sym not in self.daily and sym not in self.missing:
            self._load([sym])
        return self.daily.get(sym)

    def next_session(self, day) -> Optional[np.datetime64]:
        j = int(np.searchsorted(self.cal, np.datetime64(day, "D"), side="right"))
        return self.cal[j] if j < len(self.cal) else None

    def nifty_close_on(self, day) -> float:
        n = self.daily["NIFTY50"]
        i = n.idx(day)
        return float(n.c[i]) if i >= 0 else float("nan")

    @property
    def intraday(self) -> "IntradayStore":
        if self._intraday is None:
            self._intraday = IntradayStore(self.root, self.prod)
        return self._intraday

    def panel(self, name: str = "panel_oc") -> "PanelFeatures":
        if self._panel is None or self._panel.name != name:
            self._panel = PanelFeatures(self.root, name)
        return self._panel


# ======================================================================
# picks (pick_meta research run)
# ======================================================================
def rule_pick_columns(cols: Iterable[str]) -> List[str]:
    """Pick attributes a rule may read: rank, score, overlap flags, s_atr14 and the forecasts (pred_*, prob_*).
    Recorded outcomes (status, net, mfe, mae, trap, win, big, deep, r5, exit_day...) are never readable."""
    base = ["rank", "score", "other_rank", "both_engines", "repeat", "engine_D", "s_atr14"]
    out = [c for c in base if c in cols]
    out += sorted(c for c in cols if (c.startswith("pred_") or c.startswith("prob_")) and not c.startswith("label_"))
    return out


def load_picks(root: Path, run: str, engines: Sequence[str], ranks: Sequence[int],
               d_from=None, d_to=None, hold: int = 5) -> Tuple[pd.DataFrame, dict]:
    if not run:
        raise TLError("--pm-run is required (e.g. --pm-run PM_20261017_001)")
    rdir = Path(root) / "research2" / "pick_meta" / run
    pf = rdir / "predictions.parquet"
    if not pf.exists():
        raise TLError(f"{pf} not found")
    sha = sha256_file(pf)
    rec = read_hash_file(rdir / "outputs.sha256").get("predictions.parquet")
    if not hash_matches(rec, sha):
        raise TLError(f"{pf} does not match {rdir / 'outputs.sha256'} (recorded {rec}, file {sha[:16]}...) - refusing")
    T = pd.read_parquet(pf)
    miss = [c for c in PM_REQUIRED if c not in T.columns]
    if miss:
        raise TLError(f"{pf.name} lacks columns {miss}; it has {sorted(T.columns)[:40]}")
    T = T.copy()
    T["engine"] = T["engine"].astype(str)
    sd = to_day(T["signal_day"])                                   # numpy datetime64[D]
    T["signal_day"] = pd.DatetimeIndex(sd.astype("datetime64[ns]"))
    T["symbol"] = T["symbol"].astype(str)
    T["rank"] = pd.to_numeric(T["rank"]).astype(int)
    if T.duplicated(["engine", "signal_day", "rank"]).any():
        raise TLError(f"{pf.name} holds two picks for the same (engine, signal day, rank)")
    all_days = np.unique(sd)
    dpos = {d: i for i, d in enumerate(all_days)}
    eng = T["engine"].to_numpy()
    rk = T["rank"].to_numpy()
    sym = T["symbol"].to_numpy()
    # overlap flags on the WHOLE file (every engine, ranks 1-10), before any filter
    by_key: Dict[tuple, List[Tuple[str, int]]] = {}
    for d_, s_, e_, r_ in zip(sd, sym, eng, rk):
        by_key.setdefault((d_, s_), []).append((e_, int(r_)))
    other = np.full(len(T), np.nan)
    for i, (d_, s_, e_) in enumerate(zip(sd, sym, eng)):
        rs = [r_ for e2, r_ in by_key[(d_, s_)] if e2 != e_]
        if rs:
            other[i] = min(rs)
    T["other_rank"] = other
    T["traded"] = T["rank"] <= 3
    T["both_engines"] = T["traded"] & (T["other_rank"] <= 3)
    T["trade_id"] = [f"{e}-{str(d_).replace('-', '')}-{r}" for e, d_, r in zip(eng, sd, rk)]
    # repeat_of: the same engine's previous TRADED pick of the stock, fewer than `hold` signal days back (forensics rule)
    rep = np.array([""] * len(T), dtype=object)
    traded = T["traded"].to_numpy()
    tid = T["trade_id"].to_numpy()
    last_traded: Dict[Tuple[str, str], List[Tuple[int, str]]] = {}
    order = sorted((i for i in range(len(T)) if traded[i]), key=lambda i: (eng[i], sym[i], sd[i]))
    for i in order:
        last_traded.setdefault((eng[i], sym[i]), []).append((dpos[sd[i]], tid[i]))
    for i in range(len(T)):
        lst = last_traded.get((eng[i], sym[i]))
        if not lst:
            continue
        p = dpos[sd[i]]
        prev = [x for x in lst if x[0] < p]
        if prev and p - prev[-1][0] < hold:
            rep[i] = prev[-1][1]
    T["repeat_of"] = rep
    T["repeat"] = T["repeat_of"] != ""
    T["engine_D"] = (T["engine"] == "D").astype(float)
    # recorded outcomes keep their values under *_recorded names (display / reconciliation only)
    for c in PM_OUTCOMES:
        if c in T.columns:
            T[f"{c}_recorded"] = T[c]
    T = T.drop(columns=[c for c in PM_OUTCOMES if c in T.columns])
    for c in ("entry_day_recorded", "exit_day_recorded"):
        if c in T.columns:
            T[c] = pd.to_datetime(T[c], errors="coerce")
    info = {"file": str(pf), "sha256": sha, "rows_in_file": int(len(T)), "engines_in_file": sorted(set(eng)),
            "first_day": str(all_days[0]) if len(all_days) else None,
            "last_day": str(all_days[-1]) if len(all_days) else None, "signal_days_in_file": int(len(all_days))}
    T = T[T["engine"].isin(list(engines)) & T["rank"].isin(list(ranks))]
    if d_from is not None:
        T = T[T["signal_day"] >= np.datetime64(d_from, "D")]
    if d_to is not None:
        T = T[T["signal_day"] <= np.datetime64(d_to, "D")]
    if T.empty:
        raise TLError(f"no picks for engines {list(engines)} ranks {list(ranks)} in the chosen dates")
    T = T.sort_values(["signal_day", "engine", "rank"], kind="mergesort").reset_index(drop=True)
    T["signal_pos"] = [dpos[d] for d in to_day(T["signal_day"])]
    info.update({"rows_selected": int(len(T)), "engines": list(engines), "ranks": list(ranks),
                 "rule_attributes": rule_pick_columns(T.columns)})
    return T, info


# ======================================================================
# 3-minute bars
# ======================================================================
class Session:
    """One session's 3-minute bars: slot 0..124 (bar start = 09:15 + 3 x slot), IST."""
    __slots__ = ("day", "slot", "o", "h", "l", "c", "v", "usable", "reason")

    def __init__(self, day, slot, o, h, l, c, v, usable, reason):
        self.day, self.slot, self.o, self.h, self.l, self.c, self.v = day, slot, o, h, l, c, v
        self.usable, self.reason = usable, reason

    @property
    def minute(self) -> np.ndarray:
        return self.slot.astype(np.int64) * BAR_MIN

    def ts(self) -> np.ndarray:
        base = np.datetime64(self.day, "m") + np.timedelta64(SESSION_START_MIN, "m")
        return base + self.slot.astype("timedelta64[m]") * BAR_MIN


class IntradayStore:
    def __init__(self, root: Path, prod: Production):
        IC = prod.IC
        self.root = Path(root)
        self.dir = Path(IC.store(self.root))
        if not self.dir.is_dir():
            raise TLError(f"3-minute folder {self.dir} not found")
        self.path_for = getattr(IC, "path_for", None)
        self.asked = 0
        self.with_bars = 0
        self.usable = 0
        self.reasons: Dict[str, int] = {}

    def path(self, sym: str) -> Path:
        if self.path_for is not None:
            try:
                return Path(self.path_for(self.root, sym))
            except Exception:
                pass
        return self.dir / f"{sym}_{BAR_MIN}m.parquet"

    def sessions(self, sym: str, days: Sequence, daily: Optional[DailySeries]) -> Dict[np.datetime64, Session]:
        want = sorted({np.datetime64(d, "D") for d in days})
        self.asked += len(want)
        fp = self.path(sym)
        if not fp.exists():
            self._count("no 3-minute file", len(want))
            return {}
        try:
            df = pd.read_parquet(fp, columns=["timestamp", "open", "high", "low", "close", "volume"])
        except Exception as e:
            self._count(f"unreadable file ({type(e).__name__})", len(want))
            return {}
        return self._split(df, want, daily)

    def _count(self, why: str, n: int = 1) -> None:
        self.reasons[why] = self.reasons.get(why, 0) + n

    def _split(self, df: pd.DataFrame, want: List[np.datetime64], daily: Optional[DailySeries]) -> Dict:
        ts = pd.to_datetime(df["timestamp"])
        if getattr(ts.dt, "tz", None) is not None:
            ts = ts.dt.tz_convert(IST).dt.tz_localize(None)
        t = ts.to_numpy(dtype="datetime64[ns]")
        day = t.astype("datetime64[D]")
        m = np.isin(day, np.array(want, dtype="datetime64[D]"))
        out: Dict[np.datetime64, Session] = {}
        have = set(np.unique(day[m]).tolist()) if m.any() else set()
        for d in want:
            if d.item() not in have:
                self._count("no bars that day")
        if not m.any():
            return out
        t, day = t[m], day[m]
        mins = (t - day.astype("datetime64[ns]")).astype("timedelta64[s]").astype(np.int64) / 60.0 - SESSION_START_MIN
        slot = mins / BAR_MIN
        cols = {k: pd.to_numeric(df[k], errors="coerce").to_numpy(float)[m] for k in ("open", "high", "low", "close", "volume")}
        okslot = (slot >= -1e-9) & (slot <= BARS_PER_SESSION - 1 + 1e-9) & (np.abs(slot - np.round(slot)) < 1e-6)
        F = pd.DataFrame({"day": day, "slot": np.round(slot).astype(np.int64), "ok": okslot, **cols})
        F = F[F["ok"]].sort_values(["day", "slot"], kind="mergesort").drop_duplicates(["day", "slot"], keep="last")
        for d, g in F.groupby("day", sort=True):
            dd = np.datetime64(d, "D")
            self.with_bars += 1
            s = Session(dd, g["slot"].to_numpy(np.int64), g["open"].to_numpy(float), g["high"].to_numpy(float),
                        g["low"].to_numpy(float), g["close"].to_numpy(float), np.nan_to_num(g["volume"].to_numpy(float)),
                        False, "")
            s.usable, s.reason = self._judge(s, daily)
            if s.usable:
                self.usable += 1
            else:
                self._count(s.reason)
            out[dd] = s
        return out

    @staticmethod
    def _judge(s: Session, daily: Optional[DailySeries]) -> Tuple[bool, str]:
        n = len(s.slot)
        if n < USABLE_SHARE * BARS_PER_SESSION:
            return False, "under 80% of bars"
        if s.slot[0] != 0:
            return False, "no 09:15 bar"
        if not (np.isfinite(s.o).all() and np.isfinite(s.h).all() and np.isfinite(s.l).all() and np.isfinite(s.c).all()):
            return False, "missing prices"
        if daily is not None:
            i = daily.idx(s.day)
            if i < 0:
                return False, "no daily bar that day"
            for got, ref, nm in ((s.o[0], daily.o[i], "open"), (s.h.max(), daily.h[i], "high"),
                                 (s.l.min(), daily.l[i], "low")):
                if not (np.isfinite(ref) and ref > 0 and abs(got / ref - 1) <= PRICE_TOL):
                    return False, f"first {nm} off the daily bar by > 0.5%"
        return True, ""

    def layout_check(self) -> dict:
        """Stop when fewer than half of the asked sessions that have bars are usable (wrong stamps / layout)."""
        d = {"asked": self.asked, "with_bars": self.with_bars, "usable": self.usable, "reasons": dict(self.reasons)}
        if self.with_bars >= 20 and self.usable < 0.5 * self.with_bars:
            raise StopRun(f"3-minute layout check: only {self.usable} of {self.with_bars} sessions with bars are usable "
                          f"({self.reasons}). Bars stamped with their END time, UTC stamps without a zone, or another "
                          f"layout would do this. Send Claude one <SYMBOL>_3m.parquet and intraday_cache.py.")
        return d


# ======================================================================
# panel features (label firewall)
# ======================================================================
def feature_columns(schema) -> Tuple[List[str], dict]:
    import pyarrow as pa
    names = list(schema.names)
    canon, rule = None, "tradelab rules (identifiers, label firewall, forward patterns, raw levels)"
    try:
        import panel_build as PB
        canon = set(PB.panel_feature_columns(pd.DataFrame(columns=names)))
        rule = "panel_build.panel_feature_columns + tradelab rules"
    except Exception as e:
        rule += f" (panel_build not usable: {type(e).__name__})"
    keep: List[str] = []
    dropped = {"identifier": [], "label_or_forward": [], "not_a_feature (panel_build)": [], "raw_level": [],
               "not_numeric": []}
    for f in schema:
        nm, low = f.name, f.name.lower()
        if nm in IDENTIFIERS or "warmup" in low:
            dropped["identifier"].append(nm)
        elif is_forbidden_name(nm):
            dropped["label_or_forward"].append(nm)
        elif canon is not None and nm not in canon:
            dropped["not_a_feature (panel_build)"].append(nm)
        elif low in RAW_LEVELS or low.endswith(("_close", "_open", "_high", "_low")) or "turnover" in low:
            dropped["raw_level"].append(nm)
        elif not (pa.types.is_floating(f.type) or pa.types.is_integer(f.type) or pa.types.is_boolean(f.type)):
            dropped["not_numeric"].append(nm)
        else:
            keep.append(nm)
    info = {k: v for k, v in dropped.items()}
    info["rule"] = rule
    return keep, info


class PanelFeatures:
    def __init__(self, root: Path, name: str = "panel_oc"):
        import pyarrow.parquet as pq
        self.name = name
        self.path = Path(root) / name / "panel.parquet"
        if not self.path.exists():
            raise TLError(f"{self.path} not found")
        self.pf = pq.ParquetFile(self.path)
        names = list(self.pf.schema_arrow.names)
        self.tcol = "timestamp" if "timestamp" in names else ("date" if "date" in names else None)
        if self.tcol is None or "symbol" not in names:
            raise TLError(f"{self.path.name} has no timestamp/date or symbol column")
        self.allowed, self.dropped = feature_columns(self.pf.schema_arrow)

    def check(self, cols: Sequence[str]) -> None:
        for c in cols:
            if c not in self.allowed:
                why = next((k for k, v in self.dropped.items() if isinstance(v, list) and c in v), None)
                if why:
                    raise TLError(f"panel column '{c}' is not usable ({why})")
                raise TLError(f"'{c}' is not a panel feature.{suggest(c, self.allowed)}")

    def fetch(self, pairs: pd.DataFrame, cols: Sequence[str], batch: Optional[int] = None) -> pd.DataFrame:
        """Feature values at the CLOSE of each (symbol, day) in `pairs` (columns symbol, day)."""
        cols = list(dict.fromkeys(cols))
        self.check(cols)
        if batch is None:
            batch = int(max(20_000, min(200_000, 6_000_000 // max(1, len(cols) + 2))))
        keys = pairs[["symbol", "day"]].drop_duplicates().copy()
        keys["day"] = keys["day"].astype("datetime64[ns]")
        out = []
        syms = set(keys["symbol"])
        for rb in self.pf.iter_batches(batch_size=batch, columns=[self.tcol, "symbol"] + cols):
            b = rb.to_pandas()
            b = b[b["symbol"].isin(syms)]
            if b.empty:
                continue
            b = b.rename(columns={self.tcol: "day"})
            b["day"] = to_day(b["day"]).astype("datetime64[ns]")
            j = b.merge(keys, on=["symbol", "day"], how="inner")
            if len(j):
                for c in cols:
                    if j[c].dtype == bool:
                        j[c] = j[c].astype(float)
                out.append(j)
        if not out:
            return pd.DataFrame(columns=["symbol", "day"] + cols)
        F = pd.concat(out, ignore_index=True).drop_duplicates(["symbol", "day"], keep="last")
        for c in cols:
            F[c] = pd.to_numeric(F[c], errors="coerce").astype("float32")
        return F

    def universe(self, days: Sequence) -> Dict[np.datetime64, List[str]]:
        """Symbols with a panel row on each day (the liquid universe the engines choose from)."""
        want = np.array(sorted({np.datetime64(d, "D") for d in days}), dtype="datetime64[D]")
        out: Dict[np.datetime64, List[str]] = {}
        for rb in self.pf.iter_batches(batch_size=500_000, columns=[self.tcol, "symbol"]):
            b = rb.to_pandas()
            d = to_day(b[self.tcol])
            m = np.isin(d, want)
            for dd, s in zip(d[m], b["symbol"].to_numpy()[m]):
                out.setdefault(dd, []).append(str(s))
        return out
