"""
tl_check.py - tradelab v1: a 30-second preflight on your PC (reads only; writes nothing).

    python tl_check.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001

Prints what tradelab sees: library versions; the production modules it borrows (stage E's loader and lock rule,
intraday_cache, data_quality, research_common, panel_build) with their files and fingerprints; pick_meta's run
(hash check, rows, engines, ranks, columns, statuses); the daily bars (calendar, time stamps); one 3-minute file
(columns, stamps on the 09:15 + 3k grid, usable sessions); the panel (features kept / dropped by the firewall);
and the plan reproduced on 300 random picks against pick_meta's record. Ends with CHECK OK or the problems found.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import StopRun, TLError, VERSION, provenance, require_root, say
import tl_data as D
import tl_engine as E

TOOL = "tl_check v1"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab preflight")
    ap.add_argument("--root")
    ap.add_argument("--pm-run")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--stage-e-any", action="store_true")
    ap.add_argument("--sample", type=int, default=300)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    problems = []
    try:
        root = require_root(a.root)
        pv = provenance()
        say(f"{TOOL} ({VERSION}) | python {pv['python']} pandas {pv['pandas']} numpy {pv['numpy']} "
            f"pyarrow {pv.get('pyarrow', 'MISSING')}")
        if "pyarrow" not in pv:
            problems.append("pyarrow is not installed (pip install pyarrow)")
        prod = D.Production(stage_e_any=a.stage_e_any)
        d = prod.describe()
        say(f"stage_e_execution: {d['stage_e_file']} sha {d['stage_e_sha16']} ({d['stage_e_version']}) "
            f"{'= shipped v1.2' if d['stage_e_is_shipped'] else 'NOT the shipped v1.2'}")
        for mod in ("data_quality", "research_common", "panel_build"):
            try:
                m = __import__(mod)
                say(f"{mod}: {Path(m.__file__).resolve()}")
            except Exception as e:
                say(f"{mod}: not importable ({type(e).__name__}) - tradelab uses its own copy of the rules")
        m = D.Market(root, prod)
        cal = m.cal
        say(f"calendar (NIFTY50): {len(cal):,} sessions {cal[0]} .. {cal[-1]}; daily stamp notes {m.diag or 'none'}")
        T, info = D.load_picks(root, a.pm_run, ["D", "ENS"], list(range(1, 11)))
        say(f"pick_meta {a.pm_run}: hash OK; {info['rows_in_file']:,} rows, engines {info['engines_in_file']}, "
            f"{info['signal_days_in_file']:,} signal days {info['first_day']} .. {info['last_day']}")
        say(f"   ranks {sorted(T['rank'].unique().tolist())}; recorded status {T['status_recorded'].value_counts().to_dict()}")
        say(f"   rule attributes: {info['rule_attributes']}")
        # daily bars of a recent pick
        recent = T.sort_values("signal_day").iloc[-1]
        m.load([recent["symbol"]])
        ds = m.series(recent["symbol"])
        if ds is None:
            problems.append(f"no daily bars for {recent['symbol']}")
        else:
            say(f"daily bars {recent['symbol']}: {len(ds):,} sessions {ds.dates[0]} .. {ds.dates[-1]}; volume "
                f"{'present' if np.isfinite(ds.v).any() else 'MISSING'}")
        # 3-minute bars
        try:
            st = m.intraday
            say(f"3-minute folder: {st.dir} ({len(list(st.dir.glob('*.parquet'))):,} files); intraday_cache "
                f"{prod.describe().get('intraday_cache_file')}")
            cand = T[T["signal_day"] >= pd.Timestamp("2022-01-01")].sort_values("signal_day")
            sym = None
            for s_ in cand["symbol"].iloc[::-1].unique()[:30]:
                if st.path(s_).exists():
                    sym = s_
                    break
            if sym is None:
                problems.append("no 3-minute file found for recent picks")
            else:
                fp = st.path(sym)
                X = pd.read_parquet(fp)
                say(f"   sample {fp.name}: columns {list(X.columns)}; timestamp dtype {X['timestamp'].dtype}; "
                    f"{X['timestamp'].iloc[0]} .. {X['timestamp'].iloc[-1]}; {len(X):,} bars")
                ts = pd.to_datetime(X["timestamp"])
                if getattr(ts.dt, "tz", None) is not None:
                    ts = ts.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
                mins = (ts - ts.dt.normalize()).dt.total_seconds() / 60 - (9 * 60 + 15)
                on_grid = ((mins >= 0) & (mins <= 372) & (np.abs(mins / 3 - np.round(mins / 3)) < 1e-6)).mean()
                first_slot = (mins == 0).groupby(ts.dt.normalize()).any().mean()
                say(f"   bars on the 09:15 + 3k grid: {on_grid:.1%}; days with a 09:15 bar: {first_slot:.1%}")
                if on_grid < 0.95 or first_slot < 0.9:
                    problems.append(f"3-minute layout looks wrong in {fp.name} (end-stamped bars or another zone?)")
                dsx = m.series(sym)
                days = list(dsx.dates[-20:]) if dsx is not None else []
                ss = st.sessions(sym, days, dsx)
                ok = sum(1 for s in ss.values() if s.usable)
                say(f"   last 20 sessions of {sym}: {ok} usable ({st.reasons})")
        except TLError as e:
            problems.append(str(e))
        # panel
        try:
            P = m.panel(a.panel)
            md = P.pf.metadata
            say(f"panel {P.path}: {md.num_rows:,} rows, {md.num_columns} columns; features kept {len(P.allowed)}; "
                f"dropped " + ", ".join(f"{k} {len(v)}" for k, v in P.dropped.items() if isinstance(v, list))
                + f" ({P.dropped['rule']})")
        except TLError as e:
            problems.append(str(e))
        # plan reproduction on a sample
        from tl_export import PLAN, reconcile
        smp = T.sample(min(a.sample, len(T)), random_state=7).reset_index(drop=True)
        m.load(sorted(smp["symbol"].unique()))
        plan = E.Strategy(dict(PLAN), None, D.rule_pick_columns(T.columns))
        sim = E.TradeSim(plan, m)
        res = [sim.run(p) for p in smp.to_dict("records")]
        rec = reconcile(smp, res, m)
        say(f"plan on {len(smp)} random picks: {rec['line']}")
        if not rec["ok"]:
            problems.append("the plan does not reproduce pick_meta's record on the sample")
            say(rec["mismatches"].head(10).to_string())
    except (TLError, StopRun) as e:
        problems.append(str(e))
    if problems:
        say("PROBLEMS:")
        for p in problems:
            say(f"  - {p}")
        say("CHECK FAILED - send Claude everything above")
        return 2
    say("CHECK OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
