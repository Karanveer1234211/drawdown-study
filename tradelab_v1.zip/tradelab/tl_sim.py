"""
tl_sim.py - tradelab v1: replay single trades bar by bar.

    python tl_sim.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --trade D-20240425-2
        [--trade ENS-20250102-1 ...] [--strategy strategies\\scale_20_80_vwap.py --strategy strategies\\plan.py]
    python tl_sim.py ... --symbol RELIANCE --signal-day 2024-04-25      (any stock and day, picked or not)

For every trade and strategy it writes, under <out>\\sim\\TLS_YYYYMMDD_NNN\\:
  <trade>__<strategy>_story.md      what happened, in order: every buy / sell with its reason, when each named
                                    event first fired, a day-by-day table (prices, position, the day's P&L)
  <trade>__<strategy>_timeline.csv  one row per bar: prices, VWAP, every value the strategy's rules use, each
                                    event true/false, position, average entry, unrealised P&L, MFE / MAE so far,
                                    armed orders and trailing levels, fills on that bar
  <trade>_chart.html                price (3-minute closes or daily candles), VWAP, session lines, every strategy's
                                    buys and sells, and below it each strategy's position and running P&L
and prints the story. The numbers are the same as tl_backtest.py's for that trade (same engine, same rules).
"""
from __future__ import annotations

import argparse
import html
import json
import sys
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (StopRun, TLError, VERSION, ledger_append, new_run_dir, out_base, parse_day, provenance,
                       require_root, say, write_outputs_sha)
import tl_engine as E
from tl_run import Workspace

TOOL = "tl_sim v1"
COLORS = ["#1f6feb", "#d1242f", "#1a7f37", "#9a6700"]


def parse_args(argv):
    ap = argparse.ArgumentParser(description="tradelab sim: replay trades bar by bar")
    ap.add_argument("--root")
    ap.add_argument("--pm-run")
    ap.add_argument("--trade", action="append", default=[])
    ap.add_argument("--symbol", default=None)
    ap.add_argument("--signal-day", default=None)
    ap.add_argument("--engine", default="X")
    ap.add_argument("--strategy", action="append", default=[])
    ap.add_argument("--values", default="", help="extra values recorded in the timelines, e.g. vwap,rvol,clv,D_rsi14")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--out", default=None)
    ap.add_argument("--stage-e-any", action="store_true")
    return ap.parse_args(argv)


def main(argv=None) -> int:
    a = parse_args(sys.argv[1:] if argv is None else argv)
    t0 = time.time()
    try:
        root = require_root(a.root)
        base = out_base(a.out, root)
        ws = Workspace(root, a.pm_run, stage_e_any=a.stage_e_any, panel=a.panel, quiet=True)
        allp = ws.picks(["D", "ENS"], "1-10")
        rows = []
        for tid in a.trade:
            m = allp[allp["trade_id"] == tid]
            if m.empty:
                raise TLError(f"trade {tid} not found (format ENGINE-YYYYMMDD-RANK, e.g. D-20240425-2)")
            rows.append(m.iloc[0].to_dict())
        if a.symbol:
            d = parse_day(a.signal_day)
            if d is None:
                raise TLError("--symbol needs --signal-day YYYY-MM-DD")
            hit = allp[(allp["symbol"] == a.symbol) & (allp["signal_day"] == pd.Timestamp(str(d)))]
            if len(hit):
                rows.append(hit.iloc[0].to_dict())
                say(f"note: {a.symbol} on {d} was picked ({hit.iloc[0]['trade_id']}); using that pick")
            else:
                rows.append({"trade_id": f"{a.engine}-{str(d).replace('-', '')}-{a.symbol}", "engine": a.engine,
                             "symbol": a.symbol, "signal_day": pd.Timestamp(str(d)), "rank": np.nan, "traded": False})
        if not rows:
            raise TLError("give --trade ENGINE-YYYYMMDD-RANK (repeatable) or --symbol with --signal-day")
        T = pd.DataFrame(rows).reset_index(drop=True)
        for c in allp.columns:
            if c not in T.columns:
                T[c] = np.nan
        paths = a.strategy or [str(HERE / "strategies" / "plan.py")]
        strats = [ws.strategy(p, allp) for p in paths]
        extra = [x.strip() for x in a.values.split(",") if x.strip()]
        if extra:
            allowed = ws.market.panel(a.panel).allowed if any(
                x not in E.R.MARKET_VARS and x not in E.R.PLUGIN_VARS for x in extra) else []
            for s in strats:
                s.observe(extra, allowed)
        names = [s.name for s in strats]
        if len(set(names)) != len(names):
            raise TLError(f"two strategies share a name {names}; give each STRATEGY a distinct 'name'")
        res, extra = ws.simulate(strats, T, timeline_ids=set(T["trade_id"]))
        run_dir = new_run_dir(base, "sim", "TLS")
        written = []
        for i, p in enumerate(T.to_dict("records")):
            per = []
            for s in strats:
                r = res[s.name][i]
                per.append((s, r))
                stem = f"{p['trade_id']}__{s.name}"
                story = story_md(p, s, r)
                (run_dir / f"{stem}_story.md").write_text(story, encoding="utf-8")
                written.append(f"{stem}_story.md")
                if r.timeline is not None and len(r.timeline):
                    r.timeline.to_csv(run_dir / f"{stem}_timeline.csv", index=False)
                    written.append(f"{stem}_timeline.csv")
                say(story)
            if any(r.timeline is not None and len(r.timeline) for _, r in per):
                (run_dir / f"{p['trade_id']}_chart.html").write_text(chart_html(p, per), encoding="utf-8")
                written.append(f"{p['trade_id']}_chart.html")
        (run_dir / "summary.json").write_text(json.dumps(
            {"tool": TOOL, "version": VERSION, "trades": T["trade_id"].tolist(), "strategies":
             [s.summary() for s in strats], "results": {s.name: [r.row() for r in res[s.name]] for s in strats},
             "files": written, "production": ws.prod.describe(), "provenance": provenance()}, indent=2, default=str),
            encoding="utf-8")
        write_outputs_sha(run_dir)
        ledger_append(base, {"tool": TOOL, "event": "sim", "run": run_dir.name, "trades": T["trade_id"].tolist(),
                             "strategies": [(s.name, s.sha) for s in strats]})
        say(f"DONE {run_dir}  ({time.time() - t0:,.1f} s)")
        return 0
    except StopRun as e:
        say(f"STOPPED: {e}")
        return 3
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


# ----------------------------------------------------------------------
def story_md(p: dict, s: E.Strategy, r: E.TradeResult) -> str:
    head = (f"## {p['trade_id']} {p['symbol']} - {s.name}\n\n"
            f"{p.get('engine')} rank {p.get('rank')}, signal day {pd.Timestamp(p['signal_day']).date()}, "
            f"mode {s.mode}. Status: **{r.status}**{(' - ' + r.note) if r.note else ''}.\n")
    if r.status not in ("ok", "not_entered", "stuck", "pending"):
        return head
    L = [head]
    if r.fills:
        L.append(f"Result: **net {r.net * 1e4:+.1f} bp** of the target size (gross {r.gross * 1e4:+.1f}, costs "
                 f"{r.costs * 1e4:.1f}); bought {r.deployed:.0%} of the target, average entry {r.avg_entry:.2f}, last "
                 f"sale {r.exit_price:.2f} ({r.exit_reason}, session {r.exit_session}); MFE {r.mfe:+.2%} (session "
                 f"{r.mfe_session}), MAE {r.mae:+.2%} (session {r.mae_session}).\n")
    else:
        L.append("Result: never entered (no entry condition fired) - 0 bp, the slot stayed in cash.\n")
    ev = []
    for f in r.fills:
        ev.append((str(f.ts) if f.ts is not None else f.when, f"**{f.side.upper()} {f.leg}** "
                   f"{f.frac:.0%} {'of the target' if f.side == 'buy' else 'of the position'} @ {f.price:.2f} "
                   f"({f.kind}: {f.reason})"))
    for nm, when in r.events_first.items():
        ev.append((when.replace(" ", "T") if " " in when else when, f"event *{nm}* first true"))
    ev.sort(key=lambda x: x[0])
    L.append("### What happened, in order\n")
    for w, txt in ev:
        L.append(f"- {w.replace('T', ' ')[:16]}  {txt}")
    if r.path:
        L.append("\n### Day by day (official daily prices)\n")
        L.append("| session | date | open | high | low | close | position | day P&L bp | total bp | trades |")
        L.append("|---|---|---|---|---|---|---|---|---|---|")
        for row in r.path:
            tr = " ".join(x for x in (row.get("buys") and "buy " + row["buys"], row.get("sells") and "sell " + row["sells"]) if x)
            L.append(f"| {row['session']} | {row['date']} | {row['open']:.2f} | {row['high']:.2f} | {row['low']:.2f} | "
                     f"{row['close']:.2f} | {row['pos']:.0%} | {row['day_net'] * 1e4:+.1f} | {row['mtm_net'] * 1e4:+.1f} | "
                     f"{tr} |")
    return "\n".join(L) + "\n"


def chart_html(p: dict, per: List) -> str:
    """Self-contained SVG chart: price + VWAP + fills on top; position and running P&L per strategy below."""
    tl = next(r.timeline for _, r in per if r.timeline is not None and len(r.timeline))
    n = len(tl)
    W, PH, QH, ML, MR, MT = 1100, 330, 150, 64, 16, 28
    H = MT + PH + 40 + QH + 40
    x = lambda i: ML + (W - ML - MR) * (i / max(1, n - 1))
    lo = float(np.nanmin(tl["low"]))
    hi = float(np.nanmax(tl["high"]))
    pad = (hi - lo) * 0.06 or 1.0
    lo, hi = lo - pad, hi + pad
    y = lambda v: MT + PH * (1 - (v - lo) / (hi - lo))
    parts = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="Segoe UI, Arial" font-size="11">']
    parts.append(f'<rect x="{ML}" y="{MT}" width="{W - ML - MR}" height="{PH}" fill="#fafbfc" stroke="#d0d7de"/>')
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        parts.append(f'<line x1="{ML}" x2="{W - MR}" y1="{y(v):.1f}" y2="{y(v):.1f}" stroke="#eaeef2"/>')
        parts.append(f'<text x="{ML - 6}" y="{y(v) + 4:.1f}" text-anchor="end" fill="#57606a">{v:.2f}</text>')
    sess = tl["session"].to_numpy()
    starts = [0] + [i for i in range(1, n) if sess[i] != sess[i - 1]]
    for i in starts:
        parts.append(f'<line x1="{x(i):.1f}" x2="{x(i):.1f}" y1="{MT}" y2="{MT + PH}" stroke="#d0d7de" stroke-dasharray="3,3"/>')
        parts.append(f'<text x="{x(i) + 3:.1f}" y="{MT - 8}" fill="#57606a">s{sess[i]} {html.escape(str(tl["time"].iloc[i])[:10])}</text>')
    daily = "bar_in_session" in tl and int(tl["bar_in_session"].max()) == 0
    if daily:
        bw = max(2.0, (W - ML - MR) / max(1, n) * 0.6)
        for i, row in tl.iterrows():
            col = "#1a7f37" if row["close"] >= row["open"] else "#d1242f"
            parts.append(f'<line x1="{x(i):.1f}" x2="{x(i):.1f}" y1="{y(row["high"]):.1f}" y2="{y(row["low"]):.1f}" stroke="{col}"/>')
            top, bot = y(max(row["open"], row["close"])), y(min(row["open"], row["close"]))
            parts.append(f'<rect x="{x(i) - bw / 2:.1f}" y="{top:.1f}" width="{bw:.1f}" height="{max(1, bot - top):.1f}" fill="{col}"/>')
    else:
        pts = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in enumerate(tl["close"]) if np.isfinite(v))
        parts.append(f'<polyline points="{pts}" fill="none" stroke="#24292f" stroke-width="1.2"/>')
        if "vwap" in tl:
            seg = []
            for i in range(n):
                if i in starts and seg:
                    parts.append(f'<polyline points="{" ".join(seg)}" fill="none" stroke="#bf8700" stroke-width="1.2" stroke-dasharray="4,2"/>')
                    seg = []
                v = tl["vwap"].iloc[i]
                if np.isfinite(v):
                    seg.append(f"{x(i):.1f},{y(v):.1f}")
            if seg:
                parts.append(f'<polyline points="{" ".join(seg)}" fill="none" stroke="#bf8700" stroke-width="1.2" stroke-dasharray="4,2"/>')
    # fills
    for si, (s, r) in enumerate(per):
        col = COLORS[si % len(COLORS)]
        for f in r.fills:
            i = f.bar if 0 <= f.bar < n else n - 1
            yy = y(min(max(f.price, lo), hi))
            if f.side == "buy":
                parts.append(f'<path d="M{x(i):.1f},{yy - 1:.1f} l-6,11 l12,0 z" fill="{col}"><title>{html.escape(s.name)} BUY {html.escape(f.leg)} {f.frac:.0%} @ {f.price:.2f} ({html.escape(f.reason)})</title></path>')
            else:
                parts.append(f'<path d="M{x(i):.1f},{yy + 1:.1f} l-6,-11 l12,0 z" fill="none" stroke="{col}" stroke-width="2"><title>{html.escape(s.name)} SELL {html.escape(f.leg)} {f.frac:.0%} @ {f.price:.2f} ({html.escape(f.reason)})</title></path>')
    # lower panel: running P&L (bp) per strategy
    top2 = MT + PH + 40
    vals = []
    for s, r in per:
        if r.timeline is not None and len(r.timeline) == n:
            pos = r.timeline["pos"].to_numpy(float)
            up = r.timeline["upnl"].to_numpy(float)
            vals.append((s, pos, up))
    allv = np.concatenate([np.nan_to_num(v[2] * 1e4) for v in vals]) if vals else np.array([0.0])
    vlo, vhi = min(-10.0, float(np.nanmin(allv))), max(10.0, float(np.nanmax(allv)))
    y2 = lambda v: top2 + QH * (1 - (v - vlo) / (vhi - vlo))
    parts.append(f'<rect x="{ML}" y="{top2}" width="{W - ML - MR}" height="{QH}" fill="#fafbfc" stroke="#d0d7de"/>')
    parts.append(f'<line x1="{ML}" x2="{W - MR}" y1="{y2(0):.1f}" y2="{y2(0):.1f}" stroke="#8c959f"/>')
    parts.append(f'<text x="{ML - 6}" y="{y2(vhi) + 10:.1f}" text-anchor="end" fill="#57606a">{vhi:+.0f}</text>')
    parts.append(f'<text x="{ML - 6}" y="{y2(vlo):.1f}" text-anchor="end" fill="#57606a">{vlo:+.0f}</text>')
    parts.append(f'<text x="{ML}" y="{top2 - 8}" fill="#57606a">unrealised P&amp;L on the position held (bp of the average entry); shaded = position size</text>')
    for si, (s, pos, up) in enumerate(vals):
        col = COLORS[si % len(COLORS)]
        pts = " ".join(f"{x(i):.1f},{y2(v * 1e4):.1f}" for i, v in enumerate(up) if np.isfinite(v))
        if pts:
            parts.append(f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="1.4"/>')
        for i in range(n):
            if pos[i] > 0:
                parts.append(f'<rect x="{x(i):.1f}" y="{top2 + QH - 6 - 6 * si:.1f}" width="{max(1.0, (W - ML - MR) / n):.1f}" height="4" fill="{col}" opacity="{0.25 + 0.6 * min(1, pos[i]):.2f}"/>')
    parts.append("</svg>")
    legend = " ".join(f'<span style="color:{COLORS[i % len(COLORS)]}">&#9632; {html.escape(s.name)}: net '
                      f'{r.net * 1e4:+.1f} bp ({html.escape(r.status)})</span>' for i, (s, r) in enumerate(per))
    title = f"{p['trade_id']} {p['symbol']} - signal {pd.Timestamp(p['signal_day']).date()}"
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(title)}</title>"
            f"<style>body{{font-family:Segoe UI,Arial;margin:18px;color:#24292f}}h1{{font-size:18px}}"
            f".lg span{{margin-right:18px}}</style></head><body><h1>{html.escape(title)}</h1>"
            f"<div class='lg'>{legend}</div><p style='color:#57606a'>Triangles: filled = buy, outline = sell "
            f"(hover for the reason). Dashed gold = session VWAP. Dashed grey = session starts.</p>"
            f"{''.join(parts)}</body></html>")


if __name__ == "__main__":
    raise SystemExit(main())
