# Panel Reader & Exporter

A small local Streamlit app to inspect a panel file and export:
1. First N rows (default 500)
2. All rows for one selected stock
3. First N rows for one selected stock

Supported formats: CSV, Parquet, Excel.

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Choose your panel file in the browser. Exports are downloaded to your computer; the source file is never overwritten.

## Best first handoff
- Export the first 500 rows.
- Also download the schema report (column names, data types, missingness and unique values).
- If each row is a stock-date observation, choose “All rows for one stock” when you want me to inspect the complete history and how dates/features are represented.
