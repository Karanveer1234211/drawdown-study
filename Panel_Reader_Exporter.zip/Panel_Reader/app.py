from pathlib import Path
import io
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Panel Reader & Exporter", layout="wide")
st.title("Panel Reader & Exporter")
st.write("Load a panel, inspect its schema, then export either the first N rows or every row for one selected stock.")
st.warning("This utility only reads and exports rows. It does not modify the source file or calculate trading signals.")

uploaded = st.file_uploader("Choose your panel file", type=["csv", "parquet", "pq", "xlsx", "xls"])

def load_upload(file):
    name = file.name.lower()
    raw = file.getvalue()
    if name.endswith(".csv"):
        # Read all rows so stock filtering works across the entire file.
        return pd.read_csv(io.BytesIO(raw), low_memory=False)
    if name.endswith((".parquet", ".pq")):
        return pd.read_parquet(io.BytesIO(raw))
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(raw))
    raise ValueError("Unsupported file format.")

if uploaded:
    try:
        df = load_upload(uploaded)
        st.success(f"Loaded {len(df):,} rows × {len(df.columns):,} columns from {uploaded.name}")
        st.subheader("1. Inspect the panel")
        a, b = st.columns(2)
        with a:
            st.metric("Rows", f"{len(df):,}")
            st.metric("Columns", f"{len(df.columns):,}")
        with b:
            st.metric("Unique symbols (if detected)", f"{df[next((c for c in df.columns if c.lower() in ['symbol','ticker','stock','tradingsymbol']), df.columns[0])].nunique(dropna=True):,}")
            st.metric("File size", f"{len(uploaded.getvalue()) / (1024*1024):.2f} MB")
        schema = pd.DataFrame({
            "column": [str(c) for c in df.columns],
            "dtype": [str(x) for x in df.dtypes],
            "missing_rows": [int(df[c].isna().sum()) for c in df.columns],
            "missing_pct": [(df[c].isna().mean()*100).round(3) for c in df.columns],
            "unique_values": [int(df[c].nunique(dropna=True)) for c in df.columns],
        })
        with st.expander("View all columns and missingness", expanded=False):
            st.dataframe(schema, use_container_width=True, hide_index=True)
            st.download_button("Download column/schema report", schema.to_csv(index=False).encode("utf-8"),
                               file_name="panel_schema_report.csv", mime="text/csv")
        st.subheader("2. Preview")
        preview_n = st.number_input("Preview rows", min_value=1, max_value=max(1, min(500, len(df))), value=min(20, max(1, len(df))))
        st.dataframe(df.head(int(preview_n)), use_container_width=True, hide_index=True)

        st.subheader("3. Export data")
        mode = st.radio("What do you want to export?", [
            "First N rows (e.g. first 500 rows)",
            "All rows for one stock",
            "First N rows for one stock"
        ], index=0)
        fmt = st.selectbox("Export format", ["CSV", "Parquet", "Excel (.xlsx)"], index=0)
        stock_candidates = [c for c in df.columns if c.lower() in ["symbol", "ticker", "stock", "tradingsymbol", "security", "instrument"]]
        date_candidates = [c for c in df.columns if c.lower() in ["date", "signal_day", "signal_date", "trading_date", "timestamp", "datetime"]]
        if mode == "First N rows (e.g. first 500 rows)":
            n = st.number_input("Number of rows", min_value=1, max_value=max(1, len(df)), value=min(500, max(1, len(df))), step=1)
            out = df.head(int(n)).copy()
            suffix = f"first_{len(out)}_rows"
        else:
            if not stock_candidates:
                st.error("I couldn't detect a symbol column. Choose a file with a symbol/ticker column, or rename the column to 'symbol'.")
                st.stop()
            sym_col = st.selectbox("Symbol column", stock_candidates)
            symbols = sorted(df[sym_col].dropna().astype(str).unique().tolist())
            selected_symbol = st.selectbox("Stock", symbols)
            out = df[df[sym_col].astype(str) == selected_symbol].copy()
            if mode == "First N rows for one stock":
                n = st.number_input("Rows for this stock", min_value=1, max_value=max(1, len(out)), value=min(500, max(1, len(out))), step=1)
                out = out.head(int(n))
            suffix = f"{selected_symbol}_{len(out)}_rows"
            if date_candidates:
                date_col = st.selectbox("Date column for ordering (optional)", ["Keep original row order"] + date_candidates)
                if date_col != "Keep original row order":
                    out = out.sort_values(date_col, kind="stable")
        st.info(f"Ready to export: {len(out):,} rows × {len(out.columns):,} columns.")
        st.dataframe(out.head(30), use_container_width=True, hide_index=True)
        if fmt == "CSV":
            payload = out.to_csv(index=False).encode("utf-8")
            mime = "text/csv"
            filename = f"panel_{suffix}.csv"
        elif fmt == "Parquet":
            buf = io.BytesIO()
            out.to_parquet(buf, index=False)
            payload = buf.getvalue()
            mime = "application/octet-stream"
            filename = f"panel_{suffix}.parquet"
        else:
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as writer:
                out.to_excel(writer, index=False, sheet_name="PanelExport")
                schema.to_excel(writer, index=False, sheet_name="Schema")
            payload = buf.getvalue()
            mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            filename = f"panel_{suffix}.xlsx"
        st.download_button("Export selected rows", data=payload, file_name=filename, mime=mime, type="primary")
        st.subheader("4. Suggested first handoff")
        st.write("For the initial schema review, export the **first 500 rows** and share the column/schema report. If the panel is sorted by symbol/date and you want to understand a stock's full history, export **all rows for one stock** instead.")
    except Exception as e:
        st.error(f"Could not read this file: {e}")
        st.write("If it is a very large file, try Parquet or split the CSV into smaller files.")
else:
    st.info("Choose your panel file above to begin.")
