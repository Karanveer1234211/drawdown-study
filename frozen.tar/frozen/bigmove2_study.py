#!/usr/bin/env python3
"""
bigmove2_study.py - BIGMOVE v2 'LEVIATHAN': the intraday setups of the Leviathan State-Adaptive Protocol (LSAP), tested
as eight pre-declared families on NIFTY and liquid NSE stocks, long and short (declaration: BIGMOVE2_DECLARATION.json,
fixed before any BIGMOVE v1 or v2 result was seen).

    python bigmove2_study.py --root %CACHE_DAILY_ROOT% --coverage-only     (first: index files and liquid-stock coverage)
    python bigmove2_study.py --root %CACHE_DAILY_ROOT%                     (the study)

In plain words: LSAP says the market shows its state by 10:00 (a trap, a trend, a range), that each state has its own
setup (fade the failed breakout, buy the pullback in a trend, trade the late break of a midday coil, fade an exhausted
move, follow the relative-strength leader), that BANK and IT must agree before you press a trend, and that you should add
to winners and trail instead of taking profits. Every one of those claims is a family, a gate or a variant here, with a
declared grid and a fixed verdict rule:

  H6  first, the phenomenon: is a late-day expansion more likely after a midday coil? (before any trading rule)
  G1  8 families, 40 cells per side (80 trials): X1 trap-and-snap, X2 kinetic slingshot, X3 late coil break on NIFTY
      (futures costs); S1 trap reversal, S2 breakout retest, S3 late coil break, S4 exhaustion fade, S5 relative-strength
      leader on stocks (cash-intraday costs). Discovery selects ONE cell per family and side.
  G2  gates on each selected cell, paired: the 10:00 state LSAP names for it, BANK/IT agreement or sector sync, breadth,
      participation >= 2x (time-of-day normalised)
  G3  management on each selected cell, paired: add at +1R (P1), add again at +2R (P2), EMA(22) trail (T1), SuperTrend
      (17, 2) trail (T2), P1 + T1 - per initial capital and per peak exposure, with the risk numbers
Every trigger is a bar CLOSE and every entry a market order at the NEXT bar's open. Stock books have N slots filled first
come, first served (no look-ahead); the benchmark is the exposure-matched average of all the day's triggers.

Writes only <root>\\research2\\bigmove2\\ (BM2_<date>_<n>\\ per run; coverage files beside them) and appends one line to
<root>\\panel\\research_ledger.jsonl. Needs bigmove_study.py v1.1 (shared, tested helpers) and intraday_cache.py.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import platform
import sys
import warnings
import zlib
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import bigmove_study as BM               # v1.1: bar slots, usable sessions, VWAP, statistics, coverage, lists (tested)

SI = BM.SI
CODE_VERSION = "bigmove2_study v1"
DECL_RAW = (HERE / "BIGMOVE2_DECLARATION.json").read_bytes()
DECL = json.loads(DECL_RAW.decode("utf-8"))
CFG = DECL["config"]
NB, BAR = int(CFG["session_bars"]), int(CFG["bar_min"])
XS, XI = int(CFG["stock_time_exit_bar"]), int(CFG["index_time_exit_bar"])     # 15:03 and 15:15
E_LAST = int(CFG["entry_last_bar"])                                          # entries up to the bar starting 14:30
T_LAST = E_LAST - 1                                                          # the last bar whose close can trigger
IBL = int(CFG["ib_last_bar"])                                                # the initial balance: bars 0-14
KIND_NONE, KIND_STOP, KIND_TIME, KIND_TRAIL = BM.KIND_NONE, BM.KIND_STOP, BM.KIND_TIME, BM.KIND_TRAIL
SIDES = ((1, "L"), (-1, "S"))
STATES = ("TRAP", "KINETIC", "RANGE")
INDEX_FAMS = ("X1", "X2", "X3")
STOCK_FAMS = ("S1", "S2", "S3", "S4", "S5")
FAMS = INDEX_FAMS + STOCK_FAMS
FAMILY_NAME = {"X1": "trap and snap (NIFTY)", "X2": "kinetic slingshot (NIFTY)", "X3": "late coil break (NIFTY)",
               "S1": "trap reversal (stocks)", "S2": "breakout retest (stocks)", "S3": "late coil break (stocks)",
               "S4": "exhaustion fade (stocks)", "S5": "relative-strength leader (stocks)"}
MGMT = ("P1", "P2", "T1", "T2", "P1T1")
INDEX_FILES = {"NIFTY 50": ("NIFTY 50", "NIFTY50"), "NIFTY BANK": ("NIFTY BANK", "NIFTYBANK", "BANKNIFTY"),
               "NIFTY IT": ("NIFTY IT", "NIFTYIT")}
INDEX_DAILY = {"NIFTY 50": "NIFTY50", "NIFTY BANK": "NIFTYBANK", "NIFTY IT": "NIFTYIT"}
# v1's helpers read v1's frozen configuration: these values must be the same in both declarations, or the run refuses
SHARED_CFG = ("bar_min", "session_bars", "min_bar_share", "min_price", "min_value_cr", "value_window", "beta_window",
              "beta_min_sessions", "brokerage_rate", "brokerage_cap_rs", "stt_cash_sell", "txn_cash", "stamp_cash_buy",
              "stt_fut_sell", "txn_fut", "stamp_fut_buy", "sebi_per_crore_rs", "gst", "notional_rs", "nifty_lot", "min_coverage",
              "regime_dates")


class PreconditionError(SystemExit):
    pass


def shared_config_problems() -> List[str]:
    return [f"{k}: v1 {BM.CFG.get(k)!r} vs v2 {CFG.get(k)!r}" for k in SHARED_CFG if BM.CFG.get(k) != CFG.get(k)]


def _log(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def family_cells() -> Dict[str, List[Tuple[str, dict]]]:
    """Every family's trigger variants (its grid without N): family -> [(name, parameters)]."""
    c = CFG
    return {"X1": [(f"m{m}|{lv}|div{int(dv)}", {"m": int(m), "level": lv, "div": bool(dv)})
                   for m in c["x1_m"] for lv in c["x1_level"] for dv in c["x1_divergence"]],
            "X2": [(f"{p}|v{v:g}", {"pull": p, "v": float(v)}) for p in c["x2_pull"] for v in c["x2_v"]],
            "X3": [(f"c{c_ * 100:.2f}|exp{int(x)}", {"c": float(c_), "exp": bool(x)}) for c_ in c["x3_c"] for x in c["x3_expansion"]],
            "S1": [(f"m{m}|{lv}", {"m": int(m), "level": lv}) for m in c["s1_m"] for lv in c["s1_level"]],
            "S2": [(f"{lv}", {"level": lv}) for lv in c["s2_level"]],
            "S3": [(f"q{int(round(q * 100))}", {"q": float(q)}) for q in c["s3_q"]],
            "S4": [(f"k{k:g}", {"k": float(k)}) for k in c["s4_k"]],
            "S5": [(f"c{b}", {"check": int(b)}) for b in c["s5_check_bar"]]}


CELLS = family_cells()


def cell_keys() -> List[Tuple[str, str, int]]:
    """(family, trigger variant, N) for every G1 cell of one side (N = 0 for the index families)."""
    out = []
    for f in FAMS:
        for tv, _ in CELLS[f]:
            if f in INDEX_FAMS:
                out.append((f, tv, 0))
            else:
                out += [(f, tv, int(n)) for n in CFG["top_n"]]
    return out


def key_str(fam: str, tv: str, n: int, side: str = "") -> str:
    return "|".join(([side] if side else []) + [fam, tv, f"N{n}"])


# ----------------------------------------------------------------------
# costs
# ----------------------------------------------------------------------
COST_BPS = BM.cash_cost_bps(float(CFG["notional_rs"]))


def stock_cost_bp(sizes: List[np.ndarray]) -> np.ndarray:
    """Statutory and brokerage cost (bp of one base position) of the units a trade traded, each at its own notional."""
    tot = np.zeros(len(sizes[0]))
    for z in sizes:
        z = np.asarray(z, float)
        c = np.array([BM.cash_cost_bps(float(CFG["notional_rs"]) * v) if v > 0 else 0.0 for v in z]) if len(z) else np.zeros(0)
        tot += z * c
    return tot


def stock_slip_bp(kind: np.ndarray) -> np.ndarray:
    """Slippage per unit traded (entry and exit), bp: entry 5, exit 5 for a stop, 3 for a time or trail exit."""
    return CFG["slip_entry_bps"] + np.where(np.asarray(kind) == KIND_STOP, CFG["slip_stop_bps"], CFG["slip_time_bps"])


def index_cost_bp(sizes: List[np.ndarray], entry: np.ndarray) -> np.ndarray:
    tot = np.zeros(len(entry))
    for z in sizes:
        z = np.asarray(z, float)
        tot += z * np.array([BM.fut_cost_bps(float(CFG["nifty_lot"]) * v * e) if (v > 0 and np.isfinite(e) and e > 0) else 0.0
                             for v, e in zip(z, entry)])
    return tot


def index_slip_bp(entry: np.ndarray) -> np.ndarray:
    """One index point a side per unit, in bp of the entry."""
    with np.errstate(invalid="ignore", divide="ignore"):
        return 2.0 * float(CFG["slip_nifty_points"]) / np.asarray(entry, float) * 1e4


def net_of(gross, kind, Z, slip_bp, cost_bp, mult: float = 1.0) -> np.ndarray:
    """Net return (fraction of one base position): gross minus slippage on every unit (x mult) minus costs; no trade = 0."""
    out = np.asarray(gross, float) - (mult * np.asarray(Z, float) * np.asarray(slip_bp, float) + np.asarray(cost_bp, float)) / 1e4
    return np.where(np.asarray(kind) == KIND_NONE, 0.0, out)


# ----------------------------------------------------------------------
# bar helpers and indicators (every row a session, every column a 3-minute bar)
# ----------------------------------------------------------------------
def ffill_rows(A: np.ndarray) -> np.ndarray:
    A = np.asarray(A, float)
    return pd.DataFrame(A).ffill(axis=1).to_numpy(float) if A.size else A.copy()


def prev_closes(C: np.ndarray, pc) -> np.ndarray:
    """The close before each bar: the last close that exists before it, the previous session's close pc when none does."""
    X = np.concatenate([np.broadcast_to(np.asarray(pc, float), (C.shape[0],))[:, None], np.asarray(C, float)], 1)
    return ffill_rows(X)[:, :-1]


def prev_bar(A: np.ndarray) -> np.ndarray:
    """The previous bar's value (NaN for bar 0)."""
    return np.concatenate([np.full((A.shape[0], 1), np.nan), A[:, :-1]], 1)


def running_tp_mean(H, L, C) -> np.ndarray:
    """Indices: the running mean of typical prices from 09:15 (the declared stand-in for VWAP)."""
    tp = (H + L + C) / 3.0
    ok = np.isfinite(tp)
    n = np.cumsum(ok, 1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(n > 0, np.cumsum(np.where(ok, tp, 0.0), 1) / n, np.nan)


def ema_rows(C: np.ndarray, n: int) -> np.ndarray:
    """EMA of closes within the day (seeded with the first close; a missing bar carries the last close)."""
    Cf = ffill_rows(C)
    a = 2.0 / (n + 1.0)
    out = np.full_like(Cf, np.nan)
    if not Cf.size:
        return out
    out[:, 0] = Cf[:, 0]
    for k in range(1, Cf.shape[1]):
        p, x = out[:, k - 1], Cf[:, k]
        out[:, k] = np.where(np.isfinite(p), a * x + (1 - a) * p, x)
    return out


def supertrend_bands(H, L, C, n: int, mult: float) -> Tuple[np.ndarray, np.ndarray]:
    """SuperTrend's final lower and upper bands within the day: Wilder ATR(n) seeded at bar n-1 with the mean true range of
    bars 0..n-1; basic bands = (H + L) / 2 -/+ mult x ATR; the lower band only rises (and the upper only falls) unless
    the previous close broke it. NaN before bar n-1."""
    Hf, Lf, Cf = ffill_rows(H), ffill_rows(L), ffill_rows(C)
    D, K = Cf.shape
    LBf, UBf = np.full((D, K), np.nan), np.full((D, K), np.nan)
    if K < n or not D:
        return LBf, UBf
    pc = np.concatenate([np.full((D, 1), np.nan), Cf[:, :-1]], 1)
    tr = np.fmax(Hf - Lf, np.fmax(np.abs(Hf - pc), np.abs(Lf - pc)))
    atr = np.full((D, K), np.nan)
    first = tr[:, :n]
    cnt = np.isfinite(first).sum(1)
    atr[:, n - 1] = np.where(cnt > 0, np.where(np.isfinite(first), first, 0.0).sum(1) / np.maximum(cnt, 1), np.nan)
    for k in range(n, K):
        atr[:, k] = np.where(np.isfinite(tr[:, k]), (atr[:, k - 1] * (n - 1) + tr[:, k]) / n, atr[:, k - 1])
    hl2 = (Hf + Lf) / 2.0
    ub, lb = hl2 + mult * atr, hl2 - mult * atr
    LBf[:, n - 1], UBf[:, n - 1] = lb[:, n - 1], ub[:, n - 1]
    for k in range(n, K):
        pl, pu, cp = LBf[:, k - 1], UBf[:, k - 1], Cf[:, k - 1]
        LBf[:, k] = np.where((lb[:, k] > pl) | (cp < pl) | ~np.isfinite(pl), lb[:, k], pl)
        UBf[:, k] = np.where((ub[:, k] < pu) | (cp > pu) | ~np.isfinite(pu), ub[:, k], pu)
    return LBf, UBf


def exit_open(O: np.ndarray, C: np.ndarray, xbar: int) -> Tuple[np.ndarray, np.ndarray]:
    """Time exit: the open of bar xbar; if missing, the next open that exists; else the last close before xbar."""
    D = O.shape[0]
    j = BM.first_true(np.isfinite(O), xbar, NB - 1)
    px = np.where(j >= 0, O[np.arange(D), np.maximum(j, 0)], np.nan)
    Cb = ffill_rows(C[:, :xbar])[:, -1] if xbar > 0 else np.full(D, np.nan)
    return np.where(np.isfinite(px), px, Cb), np.where(j >= 0, j, xbar)


def _win(shape, lo, hi) -> np.ndarray:
    D, K = shape
    lo = np.broadcast_to(np.asarray(lo), (D,))
    hi = np.broadcast_to(np.asarray(hi), (D,))
    cols = np.arange(K)[None, :]
    return (cols >= lo[:, None]) & (cols <= hi[:, None]) & (lo[:, None] >= 0)


def masked_max(A, lo, hi) -> np.ndarray:
    m = _win(A.shape, lo, hi) & np.isfinite(A)
    v = np.where(m, A, -np.inf).max(1) if A.size else np.zeros(A.shape[0])
    return np.where(m.any(1), v, np.nan)


def masked_min(A, lo, hi) -> np.ndarray:
    m = _win(A.shape, lo, hi) & np.isfinite(A)
    v = np.where(m, A, np.inf).min(1) if A.size else np.zeros(A.shape[0])
    return np.where(m.any(1), v, np.nan)


def masked_mean(A, lo, hi) -> np.ndarray:
    m = _win(A.shape, lo, hi) & np.isfinite(A)
    n = m.sum(1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(n > 0, np.where(m, A, 0.0).sum(1) / np.maximum(n, 1), np.nan)


def masked_argmax(A, lo, hi) -> np.ndarray:
    """First column of the maximum within [lo, hi] (-1 when the window is empty)."""
    m = _win(A.shape, lo, hi) & np.isfinite(A)
    i = np.where(m, A, -np.inf).argmax(1) if A.size else np.zeros(A.shape[0], int)
    return np.where(m.any(1), i, -1)


def masked_argmin(A, lo, hi) -> np.ndarray:
    m = _win(A.shape, lo, hi) & np.isfinite(A)
    i = np.where(m, A, np.inf).argmin(1) if A.size else np.zeros(A.shape[0], int)
    return np.where(m.any(1), i, -1)


def last_true_upto(M: np.ndarray) -> np.ndarray:
    """For every bar k, the last bar <= k where M is True (-1 if none)."""
    idx = np.where(M, np.arange(M.shape[1])[None, :], -1)
    return np.maximum.accumulate(idx, axis=1) if M.size else idx


def rvol(TV: np.ndarray, use: np.ndarray, w: int) -> np.ndarray:
    """Participation RVOL at every bar k: turnover of bars k-w+1..k (missing bars 0) / the mean of the same bars over the
    previous 14 sessions in the file with at least 10 usable (time-of-day normalised). NaN on unusable sessions."""
    D = TV.shape[0]
    if not D:
        return np.zeros((0, NB))
    Tz = np.where(np.isfinite(TV), TV, 0.0)
    cs = np.cumsum(Tz, 1)
    S = cs.copy()
    if w < NB:
        S[:, w:] = cs[:, w:] - cs[:, :-w]
    hist = pd.DataFrame(np.where(np.asarray(use, bool)[:, None], S, np.nan)).shift(1).rolling(
        int(CFG["rvol_lookback_sessions"]), min_periods=int(CFG["rvol_min_sessions"])).mean().to_numpy(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        out = S / hist
    return np.where(np.asarray(use, bool)[:, None] & (hist > 0), out, np.nan)


def history_ok(use: np.ndarray) -> np.ndarray:
    """At least 10 usable sessions among the previous 14 in the file (participation needs them)."""
    return pd.Series(np.asarray(use, float)).shift(1).rolling(int(CFG["rvol_lookback_sessions"]), min_periods=1).sum().fillna(0).to_numpy() \
        >= int(CFG["rvol_min_sessions"])


def _windows(x: np.ndarray, n: int) -> np.ndarray:
    """Row t: the values at t-n .. t-1 (NaN before the start)."""
    pad = np.concatenate([np.full(n, np.nan), np.asarray(x, float)])
    return sliding_window_view(pad, n)[: len(x)]


def hist_share_below(x: np.ndarray, valid: np.ndarray, n: int, nmin: int) -> np.ndarray:
    """Share of the previous n sessions' valid values strictly below today's (at least nmin of them), else NaN."""
    v = np.where(valid, x, np.nan)
    if not len(v):
        return v
    Wn = _windows(v, n)
    cnt = np.isfinite(Wn).sum(1)
    below = (Wn < v[:, None]).sum(1)
    out = np.where(cnt >= nmin, below / np.maximum(cnt, 1), np.nan)
    return np.where(np.isfinite(v), out, np.nan)


def hist_median(x: np.ndarray, valid: np.ndarray, n: int, nmin: int) -> np.ndarray:
    v = np.where(valid, x, np.nan)
    if not len(v):
        return v
    Wn = _windows(v, n)
    cnt = np.isfinite(Wn).sum(1)
    Ws = np.sort(np.where(np.isfinite(Wn), Wn, np.inf), 1)
    lo_i = np.clip((cnt - 1) // 2, 0, n - 1)
    hi_i = np.clip(cnt // 2, 0, n - 1)
    r = np.arange(len(v))
    med = (Ws[r, lo_i] + Ws[r, hi_i]) / 2.0
    return np.where(cnt >= nmin, med, np.nan)


def box_stats(H, L, C) -> Dict[str, np.ndarray]:
    """The 11:00-13:00 box (bars 35-74): high, low, width / the close of bar 74, the median bar range, and whether bars
    75-79 all closed inside it."""
    b0, b1 = CFG["box_bars"]
    h0, h1 = CFG["box_hold_bars"]
    D = H.shape[0]
    bh, bl = masked_max(H, np.full(D, b0), np.full(D, b1)), masked_min(L, np.full(D, b0), np.full(D, b1))
    c74 = ffill_rows(C[:, : b1 + 1])[:, -1] if D else np.zeros(0)
    with np.errstate(invalid="ignore", divide="ignore"):
        width = (bh - bl) / c74
    rng = (H - L)[:, b0: b1 + 1]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        med = np.nanmedian(np.where(np.isfinite(rng), rng, np.nan), 1) if D else np.zeros(0)
    Ch = C[:, h0: h1 + 1]
    out_ = (Ch > bh[:, None]) | (Ch < bl[:, None])
    holds = ~out_.any(1) & np.isfinite(bh) & np.isfinite(bl)
    return {"bh": bh, "bl": bl, "width": width, "med_range": med, "holds": holds}


def h6_flags(H, L, C, use) -> Dict[str, np.ndarray]:
    """H6, per session: a COIL (box width in the instrument's own lowest 20% of its previous 60 sessions, at least 40), an
    EXPANSION (late range, bars 80-119 / the close of bar 79, above 1.5x the own median of the previous 60 sessions)."""
    D = H.shape[0]
    bx = box_stats(H, L, C)
    l0, l1 = CFG["h6_late_bars"]
    lh, ll = masked_max(H, np.full(D, l0), np.full(D, l1)), masked_min(L, np.full(D, l0), np.full(D, l1))
    c79 = ffill_rows(C[:, :l0])[:, -1] if D else np.zeros(0)
    with np.errstate(invalid="ignore", divide="ignore"):
        late = (lh - ll) / c79
    n, nmin = int(CFG["coil_history_sessions"]), int(CFG["coil_min_sessions"])
    vb = np.asarray(use, bool) & np.isfinite(bx["width"])
    vl = np.asarray(use, bool) & np.isfinite(late)
    share = hist_share_below(bx["width"], vb, n, nmin)
    med = hist_median(late, vl, n, nmin)
    defined = vb & vl & np.isfinite(share) & np.isfinite(med)
    return {"coil": defined & (share < float(CFG["h6_coil_q"])), "exp": defined & (late > float(CFG["h6_expansion_mult"]) * med),
            "defined": defined, "box_share": share}


# ----------------------------------------------------------------------
# pass 0: market-wide paths (breadth, sector counts, market participation)
# ----------------------------------------------------------------------
class Market:
    """Bar-by-bar counts over the liquid stocks with a usable session: how many are up / down since the open (all, and per
    sector), and the turnover of the day's 50 most liquid stocks (NIFTY's participation stand-in)."""

    def __init__(self, calendar: np.ndarray, sectors=()):
        self.cal = pd.DatetimeIndex(calendar)
        self.pos = pd.Series(np.arange(len(self.cal)), index=self.cal)
        self.sec = {s: i for i, s in enumerate(sorted(set(sectors)))}
        S, D = len(self.sec), len(self.cal)
        self.s_pos, self.s_neg, self.s_fin = (np.zeros((S, D, NB), np.int16) for _ in range(3))
        self.b_pos, self.b_fin = np.zeros((D, NB), np.int32), np.zeros((D, NB), np.int32)
        self.mp, self.mp_n = np.zeros((D, NB)), np.zeros(D, np.int32)

    def _idx(self, days) -> np.ndarray:
        return self.pos.reindex(pd.DatetimeIndex(days)).fillna(-1).astype(int).to_numpy()

    def add(self, sector: Optional[str], days: np.ndarray, P: np.ndarray, TV: np.ndarray, top: np.ndarray) -> None:
        di = self._idx(days)
        ok = di >= 0
        if not ok.any():
            return
        Pk = P[ok]
        pos, neg, fin = Pk > 0, Pk < 0, np.isfinite(Pk)
        self.b_pos[di[ok]] += pos
        self.b_fin[di[ok]] += fin
        if sector and sector in self.sec:
            s = self.sec[sector]
            self.s_pos[s, di[ok]] += pos.astype(np.int16)
            self.s_neg[s, di[ok]] += neg.astype(np.int16)
            self.s_fin[s, di[ok]] += fin.astype(np.int16)
        t = ok & np.asarray(top, bool)
        if t.any():
            self.mp[di[t]] += np.where(np.isfinite(TV[t]), TV[t], 0.0)
            self.mp_n[di[t]] += 1

    def breadth(self, days) -> np.ndarray:
        di = self._idx(days)
        out = np.full((len(di), NB), np.nan)
        ok = di >= 0
        with np.errstate(invalid="ignore", divide="ignore"):
            out[ok] = np.where(self.b_fin[di[ok]] > 0, self.b_pos[di[ok]] / self.b_fin[di[ok]], np.nan)
        return out

    def sync(self, sector: Optional[str], days, P: np.ndarray, own: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Share of the stock's sector peers up (long) and down (short) since the open, its own path removed where it was
        added (so a stock never confirms itself). NaN without a sector or a peer."""
        D = len(days)
        out_l, out_s = np.full((D, NB), np.nan), np.full((D, NB), np.nan)
        if not sector or sector not in self.sec:
            return out_l, out_s
        s = self.sec[sector]
        di = self._idx(days)
        ok = di >= 0
        if not ok.any():
            return out_l, out_s
        o = np.asarray(own, bool)[ok][:, None]
        Pk = P[ok]
        sp = self.s_pos[s, di[ok]].astype(float) - o * (Pk > 0)
        sn = self.s_neg[s, di[ok]].astype(float) - o * (Pk < 0)
        sf = self.s_fin[s, di[ok]].astype(float) - o * np.isfinite(Pk)
        with np.errstate(invalid="ignore", divide="ignore"):
            out_l[ok] = np.where(sf > 0, sp / sf, np.nan)
            out_s[ok] = np.where(sf > 0, sn / sf, np.nan)
        return out_l, out_s

    def participation(self, days) -> np.ndarray:
        di = self._idx(days)
        out = np.full((len(di), NB), np.nan)
        ok = di >= 0
        good = np.zeros(len(di), bool)
        good[ok] = self.mp_n[di[ok]] > 0
        out[good] = self.mp[di[good]]
        return out


def top_liquid(feats: Dict[str, pd.DataFrame], calendar: np.ndarray, n: int) -> Dict[pd.Timestamp, set]:
    """Each day's n most liquid stocks by 20-session median traded value at the PREVIOUS close (point in time)."""
    cols = {}
    for s, F in feats.items():
        v = F["value20"].shift(1).to_numpy(float)
        cols[s] = pd.Series(np.where(BM.liquid_ok(F), v, np.nan), index=pd.DatetimeIndex(F["day"]))
    if not cols:
        return {}
    V = pd.DataFrame(cols).reindex(pd.DatetimeIndex(calendar))
    R = V.rank(axis=1, ascending=False, method="first")
    names = np.asarray(V.columns)
    return {d: set(names[(R.iloc[i] <= n).to_numpy()]) for i, d in enumerate(V.index)}


# ----------------------------------------------------------------------
# trigger rules (vectorised over sessions; each returns, per side, the trigger bar, entry bar, initial stop [, score])
# ----------------------------------------------------------------------
def trap(H, L, C, avg, up, dn, pc, first_break: int, m: int, extra_up=None, extra_dn=None) -> Dict[int, tuple]:
    """Failed breakouts. A fresh break up through `up` at bar b >= first_break, then a SNAP: a bar s in [b, b + m - 1]
    closing below `up` and below `avg` -> side -1 (short). Mirror -> side +1. A snap belongs to the most recent break.
    Returns {side: (s, b, extreme from b to s)}; extra_* (sessions x bars) must also hold at the snap bar."""
    D = C.shape[0]
    cols = np.arange(NB)[None, :]
    Cp = prev_closes(C, pc)
    out = {}
    for side in (-1, 1):
        lv = np.asarray(up if side < 0 else dn, float)[:, None]
        if side < 0:
            brk = (H > lv) & (Cp <= lv)
            back = (C < lv) & (C < avg)
        else:
            brk = (L < lv) & (Cp >= lv)
            back = (C > lv) & (C > avg)
        brk &= cols >= first_break
        lb = last_true_upto(brk)
        snap = back & (lb >= 0) & (cols - lb <= m - 1)
        extra = extra_up if side < 0 else extra_dn
        if extra is not None:
            snap &= extra
        s = BM.first_true(snap, 0, T_LAST)
        b = np.where(s >= 0, lb[np.arange(D), np.maximum(s, 0)], -1)
        ext = masked_max(H, b, s) if side < 0 else masked_min(L, b, s)
        out[side] = (s, b, np.where(s >= 0, ext, np.nan))
    return out


def pullback_cont(O, H, L, C, b_up, b_dn, pull_up, pull_dn, rv1, rev_up, rev_dn) -> Dict[int, tuple]:
    """Break -> first pullback -> reversal. Side +1: b = the given break bar; t = the first bar > b with pull_up; the
    pullback bars are those after the highest high of [b, t] up to t (t alone if t holds that high); their mean per-bar
    participation must be < 1 (the first pullback decides); r = the first bar in (t, t + 10] with rev_up.
    Returns {side: (r, first pullback bar)} (r = -1: no trigger)."""
    win = int(CFG["reversal_window_bars"])
    out = {}
    for side, b, pull, rev in ((1, b_up, pull_up, rev_up), (-1, b_dn, pull_dn, rev_dn)):
        t = BM.first_true(pull, np.where(b >= 0, b + 1, NB), T_LAST)
        t = np.where(b >= 0, t, -1)
        p = masked_argmax(H, b, t) if side > 0 else masked_argmin(L, b, t)
        lo = np.where(t >= 0, np.where((p >= 0) & (p < t), p + 1, t), -1)
        ok = (t >= 0) & (masked_mean(rv1, lo, t) < 1.0)
        r = BM.first_true(rev, np.where(ok, t + 1, NB), np.minimum(np.where(ok, t, 0) + win, T_LAST))
        out[side] = (np.where(ok, r, -1), lo)
    return out


def coil_break(H, L, C, coil: np.ndarray, bx: dict, exp_mult: Optional[float] = None) -> Dict[int, tuple]:
    """Late coil break: on a coil day whose box held through bars 75-79, the first bar in 80-104 closing above the box
    (long; stop = the box low) or below it (short; stop = the box high); with exp_mult the bar's range must also be >=
    exp_mult x the median bar range inside the box. Returns {side: (k, stop)}."""
    t0, t1 = CFG["late_trigger_bars"]
    ok_day = np.asarray(coil, bool) & bx["holds"]
    rng = H - L
    out = {}
    for side in (1, -1):
        brk = (C > bx["bh"][:, None]) if side > 0 else (C < bx["bl"][:, None])
        if exp_mult is not None:
            brk &= rng >= exp_mult * bx["med_range"][:, None]
        k = BM.first_true(brk, t0, min(t1, T_LAST))
        k = np.where(ok_day, k, -1)
        out[side] = (k, bx["bl"] if side > 0 else bx["bh"])
    return out


# ----------------------------------------------------------------------
# the trade engine: market entry at the open, initial stop, optional adds and trail, time exit
# ----------------------------------------------------------------------
def trade_outcomes(B: Dict[str, np.ndarray], side, e, stop0, xbar: int, adds=(), trail: Optional[np.ndarray] = None) -> dict:
    """Every row a session with one trade. side +1 / -1; e = entry bar (the open; a missing bar uses the next that exists
    up to bar 105; -1 = no trade); stop0 = initial stop price; xbar = the time-exit bar; adds = ((trigger in R, size,
    new stop in R), ...) - stop orders, each live from the bar after the previous fill; trail = sessions x bars of
    'a close on the wrong side' (exit at the next open). A stop and an add in the same bar: add, then the old stop (worst
    order) unless the bar's open settles it (open through the stop: stopped at the open, no add). Returns gross (all units,
    fraction of one base position, before costs), Z (units), unit sizes, kind, entry / exit bars and prices, risk and
    audit flags."""
    O, H, L, C = (np.asarray(B[k], float) for k in ("open", "high", "low", "close"))
    D = O.shape[0]
    rows = np.arange(D)
    side = np.asarray(side, int) * np.ones(D, int)
    long = side > 0
    e = np.asarray(e, int) * np.ones(D, int)
    S0 = np.asarray(stop0, float) * np.ones(D)
    ee = np.where(e >= 0, BM.first_true(np.isfinite(O), np.clip(e, 0, NB), E_LAST), -1)
    ee = np.where(e >= 0, ee, -1)
    E = np.where(ee >= 0, O[rows, np.maximum(ee, 0)], np.nan)
    with np.errstate(invalid="ignore"):
        beyond = (ee >= 0) & np.isfinite(E) & np.isfinite(S0) & np.where(long, E <= S0, E >= S0)
    has = (ee >= 0) & np.isfinite(E) & np.isfinite(S0) & ~beyond & (side != 0)
    R = np.abs(E - S0)
    px_time, xb_time = exit_open(O, C, xbar)
    BIG = 10 ** 6
    jt = BM.first_true(trail, np.where(has, ee, NB), xbar - 2) if trail is not None else np.full(D, -1)
    jt = np.where(has, jt, -1)
    tt = np.where(jt >= 0, jt, BIG)
    cur_stop, cur_start, add_start = S0.copy(), ee.copy(), ee + 1
    unit_px, unit_sz = [np.where(has, E, np.nan)], [np.where(has, 1.0, 0.0)]
    done = ~has
    kind = np.full(D, KIND_NONE, np.int8)
    xb = np.full(D, -1)
    xpx = np.full(D, np.nan)
    worst = np.zeros(D, bool)
    hitH, hitL = H, L
    for st in range(len(adds) + 1):
        act = ~done
        if not act.any():
            break
        hit = np.where(long[:, None], hitL <= cur_stop[:, None], hitH >= cur_stop[:, None])
        js = BM.first_true(hit, np.where(act, cur_start, NB), xbar - 1)
        js = np.where(act, js, -1)
        if st < len(adds):
            trigR, size, newR = (float(x) for x in adds[st])
            A = E + side * trigR * R
            reach = np.where(long[:, None], H >= A[:, None], L <= A[:, None])
            a = BM.first_true(reach, np.where(act, add_start, NB), xbar - 1)
            a = np.where(act, a, -1)
        else:
            trigR, size, newR, A = 0.0, 0.0, 0.0, np.full(D, np.nan)
            a = np.full(D, -1)
        tjs, ta = np.where(js >= 0, js, BIG), np.where(a >= 0, a, BIG)
        Oj = O[rows, np.maximum(js, 0)]
        with np.errstate(invalid="ignore"):
            open_through = (js >= 0) & (js == a) & np.where(long, Oj <= cur_stop, Oj >= cur_stop)
        stop_now = act & (js >= 0) & ((tjs < ta) | open_through) & (tjs <= tt)
        add_now = act & ~stop_now & (a >= 0) & (ta <= tjs) & (ta <= tt)
        trail_now = act & ~stop_now & ~add_now & (jt >= 0) & (tt < tjs) & (tt < ta)
        none_now = act & ~stop_now & ~add_now & ~trail_now
        # stop: the stop price, or the open when the bar opens through it; in the entry bar the open is the entry itself
        spx = np.where(js == ee, cur_stop, np.where(long, np.fmin(cur_stop, Oj), np.fmax(cur_stop, Oj)))
        xpx = np.where(stop_now, spx, xpx)
        xb = np.where(stop_now, js, xb)
        kind = np.where(stop_now, KIND_STOP, kind)
        done |= stop_now
        if st < len(adds):
            Oa = O[rows, np.maximum(a, 0)]
            apx = np.where(long, np.fmax(A, Oa), np.fmin(A, Oa))
            unit_px.append(np.where(add_now, apx, np.nan))
            unit_sz.append(np.where(add_now, size, 0.0))
            same = add_now & (js == a)                    # the add bar also reached the current stop: add, then that stop
            with np.errstate(invalid="ignore"):
                worst |= same & ~np.where(long, Oa >= A, Oa <= A)   # ambiguous only when the bar opened between them
            xpx = np.where(same, cur_stop, xpx)
            xb = np.where(same, a, xb)
            kind = np.where(same, KIND_STOP, kind)
            done |= same
            cont = add_now & ~same
            cur_stop = np.where(cont, E + side * newR * R, cur_stop)
            cur_start = np.where(cont, a + 1, cur_start)
            add_start = np.where(cont, a + 1, add_start)
        # trail: a close on the wrong side -> the next open that exists (up to the time-exit bar)
        jn = BM.first_true(np.isfinite(O), np.where(trail_now, jt + 1, NB), xbar)
        tpx = np.where(jn >= 0, O[rows, np.maximum(jn, 0)], px_time)
        xpx = np.where(trail_now, tpx, xpx)
        xb = np.where(trail_now, np.where(jn >= 0, jn, xb_time), xb)
        kind = np.where(trail_now, KIND_TRAIL, kind)
        done |= trail_now
        xpx = np.where(none_now, px_time, xpx)
        xb = np.where(none_now, xb_time, xb)
        kind = np.where(none_now, KIND_TIME, kind)
        done |= none_now
    gross = np.zeros(D)
    for p_, z_ in zip(unit_px, unit_sz):
        with np.errstate(invalid="ignore", divide="ignore"):
            gross += np.where(z_ > 0, z_ * side * (xpx / p_ - 1), 0.0)
    Z = np.sum(unit_sz, 0)
    ok = has & np.isfinite(gross) & np.isfinite(xpx)
    nan_c = np.cumsum(~np.isfinite(C), 1)
    last_held = np.clip(np.where(ok, np.where(kind == KIND_STOP, xb, xb - 1), 0), 0, NB - 1)
    before = np.where(ee > 0, nan_c[rows, np.maximum(ee - 1, 0)], 0)
    gaps = np.where(ok & (last_held >= ee), nan_c[rows, last_held] - before, 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        risk = np.where(ok, R / E * 1e4, np.nan)
    return {"gross": np.where(ok, gross, np.nan), "kind": np.where(ok, kind, KIND_NONE).astype(np.int8), "Z": np.where(ok, Z, 0.0),
            "sizes": [np.where(ok, z, 0.0) for z in unit_sz], "entry_bar": np.where(ok, ee, -1), "exit_bar": np.where(ok, xb, -1),
            "entry": np.where(ok, E, np.nan), "exit": np.where(ok, xpx, np.nan), "risk_bp": risk,
            "stop_in_entry_bar": ok & (kind == KIND_STOP) & (xb == ee), "gap_in_trade": gaps > 0, "worst_order": ok & worst,
            "beyond_stop": beyond, "no_exit_price": has & ~ok, "last_held": np.where(ok, last_held, -1)}


def excursions(B: Dict[str, np.ndarray], side, res: dict) -> Tuple[np.ndarray, np.ndarray]:
    """MFE and MAE of a trade (fractions of the entry; MAE <= 0) over the bars it was held."""
    H, L = np.asarray(B["high"], float), np.asarray(B["low"], float)
    side = np.asarray(side, int) * np.ones(H.shape[0], int)
    ee, lh, E = res["entry_bar"], res["last_held"], res["entry"]
    hi, lo = masked_max(H, ee, lh), masked_min(L, ee, lh)
    with np.errstate(invalid="ignore", divide="ignore"):
        mfe = np.where(side > 0, hi / E - 1, 1 - lo / E)
        mae = np.where(side > 0, lo / E - 1, 1 - hi / E)
    return mfe, mae


def wrong_side(C, line_lo, line_hi, side) -> np.ndarray:
    """A close on the wrong side of a trail: below line_lo for longs, above line_hi for shorts."""
    side = np.asarray(side, int)
    with np.errstate(invalid="ignore"):
        return np.where((side > 0)[:, None], C < line_lo, C > line_hi)


def variants(B: Dict[str, np.ndarray], side, e, stop0, xbar: int) -> Dict[str, dict]:
    """The base trade, G3's management variants and the mirrored trade (the random-side control) for the same entries."""
    ema = ema_rows(B["close"], int(CFG["ema_trail_bars"]))
    lb, ub = supertrend_bands(B["high"], B["low"], B["close"], int(CFG["supertrend_atr_bars"]), float(CFG["supertrend_mult"]))
    w_ema = wrong_side(B["close"], ema, ema, side)
    w_st = wrong_side(B["close"], lb, ub, side)
    P1, P2 = [tuple(a) for a in CFG["pyramid"]["P1"]], [tuple(a) for a in CFG["pyramid"]["P2"]]
    out = {"base": trade_outcomes(B, side, e, stop0, xbar), "P1": trade_outcomes(B, side, e, stop0, xbar, adds=P1),
           "P2": trade_outcomes(B, side, e, stop0, xbar, adds=P2), "T1": trade_outcomes(B, side, e, stop0, xbar, trail=w_ema),
           "T2": trade_outcomes(B, side, e, stop0, xbar, trail=w_st), "P1T1": trade_outcomes(B, side, e, stop0, xbar, adds=P1, trail=w_ema)}
    E = out["base"]["entry"]
    out["mirror"] = trade_outcomes(B, -np.asarray(side, int), e, 2 * E - np.asarray(stop0, float), xbar)
    return out


# ----------------------------------------------------------------------
# NIFTY and the other indices
# ----------------------------------------------------------------------
def prev_levels(daily: Optional[pd.DataFrame], days: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Previous session's high, low and close from a daily file, for each day in `days` (NaN when unknown)."""
    if daily is None or not len(daily):
        z = np.full(len(days), np.nan)
        return z, z.copy(), z.copy()
    d = daily.sort_values("day").drop_duplicates("day", keep="last").set_index("day")
    p = d[["high", "low", "close"]].shift(1).reindex(pd.DatetimeIndex(days))
    return p["high"].to_numpy(float), p["low"].to_numpy(float), p["close"].to_numpy(float)


def reconcile_index(bars: pd.DataFrame, daily: Optional[pd.DataFrame], tol: float) -> Tuple[Optional[set], dict]:
    """Index sessions against the daily index file: first open, high, low within tol of the day's open, high, low and the
    15:00-15:30 mean typical price within tol of its close (prices only: an index has no volume). Returns the set of days
    that pass (None when there is no daily file to check against) and counts."""
    if daily is None or not len(daily) or bars is None or not len(bars):
        return None, {"checked": 0, "failed": 0}
    X = bars.assign(timestamp=BM.ist_naive(bars["timestamp"]).to_numpy())
    X = X.drop_duplicates("timestamp", keep="last").sort_values("timestamp")
    g = X.groupby(X["timestamp"].dt.normalize())
    agg = pd.DataFrame({"o": g["open"].first(), "h": g["high"].max(), "l": g["low"].min()})
    late = X[X["timestamp"].dt.hour * 60 + X["timestamp"].dt.minute >= 15 * 60]
    tp = (late["high"] + late["low"] + late["close"]) / 3.0
    agg["c"] = tp.groupby(late["timestamp"].dt.normalize()).mean()
    d = daily.sort_values("day").drop_duplicates("day", keep="last").set_index("day")[["open", "high", "low", "close"]]
    J = agg.join(d, how="left")
    rel = lambda a, b: (J[a] / J[b] - 1).abs()
    ok = (rel("o", "open") <= tol) & (rel("h", "high") <= tol) & (rel("l", "low") <= tol) & (rel("c", "close") <= tol)
    ok = ok.fillna(False)
    return set(pd.DatetimeIndex(J.index[ok.to_numpy()])), {"checked": int(len(J)), "failed": int((~ok).sum())}


def aligned(days: np.ndarray, bars: Optional[pd.DataFrame], keep: Optional[set]) -> Optional[Dict[str, np.ndarray]]:
    """Another index's sessions on NIFTY's days (NaN where it has no usable session)."""
    if bars is None or not len(bars):
        return None
    d2, B2 = BM.bar_matrix(bars)
    if not len(d2):
        return None
    use = BM.usable_sessions(B2)
    if keep is not None:
        use &= pd.DatetimeIndex(d2).isin(pd.DatetimeIndex(sorted(keep)))
    pos = {pd.Timestamp(d): i for i, d in enumerate(d2)}
    out = {k: np.full((len(days), NB), np.nan) for k in ("open", "high", "low", "close")}
    for j, d in enumerate(days):
        i = pos.get(pd.Timestamp(d))
        if i is not None and use[i]:
            for k in out:
                out[k][j] = B2[k][i]
    return out


def index_ctx(nifty_bars, nifty_daily, other: Dict[str, Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame]]],
              mkt: Optional[Market], keep: Dict[str, Optional[set]]) -> Optional[dict]:
    """NIFTY's sessions with everything the index families, the state and the gates need."""
    days, B = BM.bar_matrix(nifty_bars)
    if not len(days):
        return None
    use = BM.usable_sessions(B)
    if keep.get("NIFTY 50") is not None:
        use &= pd.DatetimeIndex(days).isin(pd.DatetimeIndex(sorted(keep["NIFTY 50"])))
    O, H, L, C = (np.where(use[:, None], B[k], np.nan) for k in ("open", "high", "low", "close"))
    D = len(days)
    O0 = O[:, 0]
    Cf = ffill_rows(C)
    P = BM.since_open(C, O0)
    avg = running_tp_mean(H, L, C)
    pdh, pdl, pdc = prev_levels(nifty_daily, days)
    ibh, ibl = BM._rowmax(H[:, : IBL + 1]), BM._rowmin(L[:, : IBL + 1])
    with np.errstate(invalid="ignore", divide="ignore"):
        a14 = np.abs(Cf[:, IBL] / O0 - 1)
    sig = pd.Series(np.where(use, a14, np.nan)).shift(1).rolling(int(CFG["noise_sigma_lookback"]),
                                                                min_periods=int(CFG["noise_sigma_min"])).mean().to_numpy(float)
    state = market_state(H, L, Cf, O0, pdh, pdl, sig, use)
    mp = mkt.participation(days) if mkt is not None else np.full((D, NB), np.nan)
    mp_ok = np.isfinite(mp).any(1)
    rv1, rv3 = rvol(mp, use & mp_ok, 1), rvol(mp, use & mp_ok, int(CFG["rvol_window_bars"]))
    br = mkt.breadth(days) if mkt is not None else np.full((D, NB), np.nan)
    cx = {"days": days, "use": use, "open": O, "high": H, "low": L, "close": C, "O0": O0, "P": P, "avg": avg,
          "ema9": ema_rows(C, int(CFG["x2_ema_bars"])), "pdh": pdh, "pdl": pdl, "pdc": pdc, "ibh": ibh, "ibl": ibl,
          "state": state, "rv1": rv1, "rv3": rv3, "breadth": br, "h6": h6_flags(H, L, C, use), "have": {}}
    # NIFTY BANK and NIFTY IT: since-open paths (index sync) and the divergence of X1
    sync_l, sync_s, nsync = np.zeros((D, NB)), np.zeros((D, NB)), np.zeros((D, NB))
    div = {lv: (np.zeros((D, NB), bool), np.zeros((D, NB), bool)) for lv in ("IB", "PD")}
    cols = np.arange(NB)[None, :]
    cx["others"] = {}
    for name in ("NIFTY BANK", "NIFTY IT"):
        bars_o, daily_o = other.get(name, (None, None))
        A = aligned(days, bars_o, keep.get(name))
        cx["have"][name] = int(np.isfinite(A["open"][:, 0]).sum()) if A is not None else 0
        cx["others"][name] = A
        if A is None:
            continue
        Po = BM.since_open(A["close"], A["open"][:, 0])
        sync_l += Po > 0
        sync_s += Po < 0
        nsync += np.isfinite(Po)
        av_o = running_tp_mean(A["high"], A["low"], A["close"])
        lv = {"IB": (BM._rowmax(A["high"][:, : IBL + 1]), BM._rowmin(A["low"][:, : IBL + 1]))}
        ph, pl, _ = prev_levels(daily_o, days)
        lv["PD"] = (ph, pl)
        A["pdh"], A["pdl"] = ph, pl
        Hs = np.where((cols > IBL) & np.isfinite(A["high"]), A["high"], -np.inf)
        Ls = np.where((cols > IBL) & np.isfinite(A["low"]), A["low"], np.inf)
        cmH, cmL = np.maximum.accumulate(Hs, 1), np.minimum.accumulate(Ls, 1)
        for name_lv, (u, d_) in lv.items():
            with np.errstate(invalid="ignore"):
                du = (cmH <= u[:, None]) & (A["close"] < av_o)        # not above its own level since 10:00, below its average
                dd = (cmL >= d_[:, None]) & (A["close"] > av_o)
            div[name_lv] = (div[name_lv][0] | du, div[name_lv][1] | dd)
    both = nsync == 2
    cx["isync"] = {1: np.where(both, sync_l, np.nan), -1: np.where(both, sync_s, np.nan)}
    cx["div"] = div
    return cx


def market_state(H, L, Cf, O0, pdh, pdl, sig, use) -> np.ndarray:
    """The 10:00 state from NIFTY: TRAP (bars 0-14 traded beyond PDH or PDL, bar 14 closes back inside), KINETIC (bar 14
    closes outside [PDL, PDH], or |return since the open| >= sigma(14)), RANGE otherwise; NA when undecidable."""
    hi, lo = BM._rowmax(H[:, : IBL + 1]), BM._rowmin(L[:, : IBL + 1])
    c14 = Cf[:, IBL]
    with np.errstate(invalid="ignore", divide="ignore"):
        r14 = np.abs(c14 / O0 - 1)
        known = np.asarray(use, bool) & np.isfinite(c14) & np.isfinite(pdh) & np.isfinite(pdl) & np.isfinite(hi) & np.isfinite(lo)
        inside = (c14 <= pdh) & (c14 >= pdl)
        swept = (hi > pdh) | (lo < pdl)
        trap = known & swept & inside
        beyond = known & ~inside
        kin_sig = known & np.isfinite(sig) & (r14 >= sig)
    st = np.full(len(c14), "NA", dtype=object)
    st[known & np.isfinite(sig)] = "RANGE"
    st[beyond | kin_sig] = "KINETIC"
    st[trap] = "TRAP"
    return st


def index_triggers(fam: str, prm: dict, cx: dict) -> Dict[int, tuple]:
    """{side: (trigger bar, entry bar, initial stop)} for an index family cell on NIFTY's sessions."""
    H, L, C, O = cx["high"], cx["low"], cx["close"], cx["open"]
    D = len(cx["days"])
    buf = float(CFG["index_stop_buffer"])
    out = {}
    if fam == "X1":
        up, dn = (cx["ibh"], cx["ibl"]) if prm["level"] == "IB" else (cx["pdh"], cx["pdl"])
        eu, ed = (cx["div"][prm["level"]] if prm["div"] else (None, None))
        tr = trap(H, L, C, cx["avg"], up, dn, cx["pdc"], IBL + 1, prm["m"], eu, ed)
        for side, (s, b, ext) in tr.items():
            out[side] = (s, np.where(s >= 0, s + 1, -1), np.where(side < 0, ext * (1 + buf), ext * (1 - buf)))
    elif fam == "X2":
        pull = cx["avg"] if prm["pull"] == "avg" else cx["ema9"]
        ph, pl = prev_bar(H), prev_bar(L)
        rv1 = cx["rv1"]
        with np.errstate(invalid="ignore"):
            b_up = BM.first_true(H > cx["ibh"][:, None], IBL + 1, T_LAST)
            b_dn = BM.first_true(L < cx["ibl"][:, None], IBL + 1, T_LAST)
            rev_up = (C > O) & (C > ph) & (rv1 >= prm["v"])
            rev_dn = (C < O) & (C < pl) & (rv1 >= prm["v"])
            pc = pullback_cont(O, H, L, C, b_up, b_dn, L <= pull, H >= pull, rv1, rev_up, rev_dn)
        rows = np.arange(D)
        for side, (r, lo) in pc.items():
            av = cx["avg"][rows, np.maximum(r, 0)]
            if side > 0:
                stop = np.fmin(av, masked_min(L, lo, r)) * (1 - buf)
            else:
                stop = np.fmax(av, masked_max(H, lo, r)) * (1 + buf)
            out[side] = (r, np.where(r >= 0, r + 1, -1), np.where(r >= 0, stop, np.nan))
    elif fam == "X3":
        bx = box_stats(H, L, C)
        coil = np.isfinite(bx["width"]) & (bx["width"] < prm["c"])
        cb = coil_break(H, L, C, coil, bx, float(CFG["expansion_mult"]) if prm["exp"] else None)
        for side, (k, stop) in cb.items():
            out[side] = (k, np.where(k >= 0, k + 1, -1), np.where(k >= 0, stop, np.nan))
    return out


def index_rows(cx: dict) -> Dict[Tuple[str, str], pd.DataFrame]:
    """Every index cell's trades (one per day and side), with the gate values at the trigger bar."""
    out = {}
    D = len(cx["days"])
    rows_ = np.arange(D)
    Bfull = {k: cx[k] for k in ("open", "high", "low", "close")}
    for fam in INDEX_FAMS:
        for tv, prm in CELLS[fam]:
            parts = []
            for side, (tb, e, S0) in index_triggers(fam, prm, cx).items():
                sel = np.flatnonzero(cx["use"] & (tb >= 0))
                if not len(sel):
                    continue
                Bs = {k: v[sel] for k, v in Bfull.items()}
                res = trade_outcomes(Bs, side, e[sel], S0[sel], XI)
                t = tb[sel]
                isy = cx["isync"][side][sel, t]
                parts.append(pd.DataFrame({
                    "day": cx["days"][sel], "symbol": "NIFTY 50", "side": np.int8(side), "tb": t.astype(np.int16),
                    "eb": res["entry_bar"].astype(np.int16), "score": np.zeros(len(sel), np.float32), "entry": res["entry"],
                    "stop": S0[sel], "gross": res["gross"], "kind": res["kind"], "xb": res["exit_bar"].astype(np.int16),
                    "risk": res["risk_bp"], "sb": res["stop_in_entry_bar"], "gp": res["gap_in_trade"], "nx": res["no_exit_price"],
                    "skip": res["beyond_stop"], "rvol": cx["rv3"][sel, t], "isync": isy, "sync": np.full(len(sel), np.nan),
                    "breadth": cx["breadth"][sel, t]}))
            T = pd.concat(parts, ignore_index=True) if parts else empty_rows()
            out[(fam, tv)] = finish_rows(T, index=True)
    return out


def empty_rows() -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(dtype=t) for c, t in (("day", "datetime64[ns]"), ("symbol", object), ("side", np.int8),
                         ("tb", np.int16), ("eb", np.int16), ("score", np.float32), ("entry", float), ("stop", float),
                         ("gross", float), ("kind", np.int8), ("xb", np.int16), ("risk", float), ("sb", bool), ("gp", bool),
                         ("nx", bool), ("skip", bool), ("rvol", float), ("isync", float), ("sync", float), ("breadth", float))})


def finish_rows(T: pd.DataFrame, index: bool) -> pd.DataFrame:
    """Keep real trades (a trigger whose entry bar opened beyond its stop is no trade; one without an exit price is
    counted, never silently kept), and the slippage and cost of each base trade."""
    n_skip = int(T["skip"].sum()) if len(T) else 0
    n_nx = int(T["nx"].sum()) if len(T) else 0
    T = T[(T["kind"] != KIND_NONE) & np.isfinite(T["gross"])].reset_index(drop=True).copy()
    if index:
        T["slip_bp"] = index_slip_bp(T["entry"].to_numpy(float))
        T["cost_bp"] = index_cost_bp([np.ones(len(T))], T["entry"].to_numpy(float))
    else:
        T["slip_bp"] = stock_slip_bp(T["kind"].to_numpy())
        T["cost_bp"] = COST_BPS
    T.attrs["skipped_beyond_stop"], T.attrs["no_exit_price"] = n_skip, n_nx
    return T


# ----------------------------------------------------------------------
# pass 1: one stock, every usable session
# ----------------------------------------------------------------------
def agg_mask(F: pd.DataFrame, days: np.ndarray, B: Dict[str, np.ndarray], liq_days: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(row of each session in the daily frame, usable session, counts for the market paths): a session counts for
    breadth, sectors and participation when it is usable and the stock was liquid at the previous close. Pass 0 and
    pass 1 both use this, so a stock's own path is removed from its sector exactly where it was added."""
    D = len(days)
    rowmap = {pd.Timestamp(d): i for i, d in enumerate(F["day"])}
    trow = np.array([rowmap.get(pd.Timestamp(d), -1) for d in days], int)
    okr = trow >= 1
    use = BM.usable_sessions(B) if D else np.zeros(0, bool)
    liq = np.zeros(D, bool)
    liq[okr] = np.asarray(liq_days, bool)[trow[okr]]
    return trow, use, use & liq & okr


def stock_ctx(F: pd.DataFrame, days: np.ndarray, B: Dict[str, np.ndarray], liq_days: np.ndarray,
              first_day: Optional[pd.Timestamp] = None) -> dict:
    """A stock's sessions with everything its triggers need. Everything except outcomes is known at the trigger bar's
    close (bars) or at the previous close (ATR, PDH / PDL / PDC, liquidity)."""
    D = len(days)
    trow, use, agg_ok = agg_mask(F, days, B, liq_days)
    okr = trow >= 1

    def prev(col):
        return np.where(okr, F[col].to_numpy(float)[np.maximum(trow - 1, 0)], np.nan)

    pdh, pdl, pdc, atr = prev("high"), prev("low"), prev("close"), prev("atr14")
    O, H, L, C, V = (np.asarray(B[k], float) for k in ("open", "high", "low", "close", "volume"))
    TV = V * C
    hist = history_ok(use)
    cand = agg_ok & hist & np.isfinite(atr) & (atr > 0) & np.isfinite(pdc)
    if first_day is not None:
        cand &= days >= np.datetime64(pd.Timestamp(first_day))
    O0 = O[:, 0] if D else np.zeros(0)
    w = int(CFG["rvol_window_bars"])
    cx = {"days": days, "trow": trow, "use": use, "agg_ok": agg_ok, "cand": cand, "open": O, "high": H, "low": L, "close": C,
          "volume": V, "O0": O0, "P": BM.since_open(C, O0) if D else np.zeros((0, NB)), "vwap": BM.session_vwap(H, L, C, V),
          "pdh": pdh, "pdl": pdl, "pdc": pdc, "atr": atr, "atrpx": atr * pdc, "rv1": rvol(TV, use, 1), "rv3": rvol(TV, use, w),
          "rv15": rvol(TV, use, int(CFG["s4_rvol_bars"]))[:, int(CFG["s4_rvol_bars"]) - 1] if D else np.zeros(0),
          "orh": BM._rowmax(H[:, : int(CFG["or_bars"])]) if D else np.zeros(0),
          "orl": BM._rowmin(L[:, : int(CFG["or_bars"])]) if D else np.zeros(0), "TV": TV}
    bx = box_stats(H, L, C)
    vb = use & np.isfinite(bx["width"])
    cx["box"] = bx
    cx["box_share"] = hist_share_below(bx["width"], vb, int(CFG["coil_history_sessions"]), int(CFG["coil_min_sessions"]))
    return cx


def stock_triggers(fam: str, prm: dict, cx: dict, nifty_P: Optional[np.ndarray] = None, beta: Optional[np.ndarray] = None,
                   sync: Optional[Dict[int, np.ndarray]] = None) -> Dict[int, tuple]:
    """{side: (trigger bar, entry bar, initial stop, score)} for a stock family cell on every session of one stock.
    nifty_P: NIFTY's return since the open on the stock's days (S5); beta: beta at the previous close (S5);
    sync: {side: sector sync} (S5's eligibility)."""
    H, L, C, O = cx["high"], cx["low"], cx["close"], cx["open"]
    D = len(cx["days"])
    rows = np.arange(D)
    apx = cx["atrpx"]
    out = {}
    if fam == "S1":
        if prm["level"] == "OR2":
            up, dn, pc, fb = cx["orh"], cx["orl"], np.full(D, np.nan), int(CFG["or_bars"])
        else:
            up, dn, pc, fb = cx["pdh"], cx["pdl"], cx["pdc"], 0
        k = float(CFG["s1_stop_atr"])
        for side, (s, b, ext) in trap(H, L, C, cx["vwap"], up, dn, pc, fb, prm["m"]).items():
            stop = ext + k * apx if side < 0 else ext - k * apx
            out[side] = (s, np.where(s >= 0, s + 1, -1), np.where(s >= 0, stop, np.nan), cx["rv3"][rows, np.maximum(s, 0)])
    elif fam == "S2":
        ta, sa = float(CFG["s2_touch_atr"]), float(CFG["s2_stop_atr"])
        if prm["level"] == "level":
            lu, ld = cx["orh"][:, None], cx["orl"][:, None]
        else:
            lu = ld = cx["vwap"]
        ph, pl = prev_bar(H), prev_bar(L)
        orb = int(CFG["or_bars"])
        with np.errstate(invalid="ignore"):
            b_up = BM.first_true(H > cx["orh"][:, None], orb, T_LAST)
            b_dn = BM.first_true(L < cx["orl"][:, None], orb, T_LAST)
            pc_ = pullback_cont(O, H, L, C, b_up, b_dn, L <= lu + ta * apx[:, None], H >= ld - ta * apx[:, None],
                                cx["rv1"], C > ph, C < pl)
        for side, (r, lo) in pc_.items():
            stop = masked_min(L, lo, r) - sa * apx if side > 0 else masked_max(H, lo, r) + sa * apx
            out[side] = (r, np.where(r >= 0, r + 1, -1), np.where(r >= 0, stop, np.nan), cx["rv3"][rows, np.maximum(r, 0)])
    elif fam == "S3":
        coil = np.isfinite(cx["box_share"]) & (cx["box_share"] < prm["q"])
        for side, (k, stop) in coil_break(H, L, C, coil, cx["box"]).items():
            out[side] = (k, np.where(k >= 0, k + 1, -1), np.where(k >= 0, stop, np.nan), cx["rv3"][rows, np.maximum(k, 0)])
    elif fam == "S4":
        mb = int(CFG["s4_move_bar"])
        sa = float(CFG["s4_stop_atr"])
        Cf = ffill_rows(C)
        with np.errstate(invalid="ignore", divide="ignore"):
            ret = Cf[:, mb] / cx["O0"] - 1
            big = cx["rv15"] >= float(CFG["s4_rvol_min"])
            up = big & (ret >= prm["k"] * cx["atr"])
            dn = big & (ret <= -prm["k"] * cx["atr"])
            score = np.abs(ret) / cx["atr"]
            hiH = np.maximum.accumulate(np.where(np.isfinite(H), H, -np.inf), 1)
            loL = np.minimum.accumulate(np.where(np.isfinite(L), L, np.inf), 1)
            prevmax, prevmin = prev_bar(hiH), prev_bar(loL)
            ph, pl = prev_bar(H), prev_bar(L)
            f_s = BM.first_true((H > prevmax) & (C < pl), mb + 1, T_LAST)      # after an up move: a new high that closes below
            f_l = BM.first_true((L < prevmin) & (C > ph), mb + 1, T_LAST)      # the previous bar's low -> short (mirror -> long)
        f_s, f_l = np.where(up, f_s, -1), np.where(dn, f_l, -1)
        out[-1] = (f_s, np.where(f_s >= 0, f_s + 1, -1), np.where(f_s >= 0, H[rows, np.maximum(f_s, 0)] + sa * apx, np.nan), score)
        out[1] = (f_l, np.where(f_l >= 0, f_l + 1, -1), np.where(f_l >= 0, L[rows, np.maximum(f_l, 0)] - sa * apx, np.nan), score)
    elif fam == "S5":
        c = int(prm["check"])
        Cf = ffill_rows(C)
        npc = nifty_P[:, c] if nifty_P is not None else np.full(D, np.nan)
        bet = beta if beta is not None else np.full(D, np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            rs = (Cf[:, c] / cx["O0"] - 1 - bet * npc) / cx["atr"]
        smin = float(CFG["s5_sync_min"])
        for side in (1, -1):
            sy = sync[side][:, c] if sync is not None else np.full(D, np.nan)
            with np.errstate(invalid="ignore"):
                ok = np.isfinite(rs) & ((rs > 0) if side > 0 else (rs < 0)) & (~np.isfinite(sy) | (sy >= smin))
            tb = np.where(ok, c, -1)
            out[side] = (tb, np.where(ok, c + 1, -1), np.where(ok, s5_stop(cx, c, side), np.nan), side * rs)
    return out


def s5_stop(cx: dict, c: int, side: int) -> np.ndarray:
    """S5's initial stop: the day's low up to the check bar minus 0.05 ATR (shorts: the high plus 0.05 ATR)."""
    sa = float(CFG["s5_stop_atr"])
    if side > 0:
        return BM._rowmin(cx["low"][:, : c + 1]) - sa * cx["atrpx"]
    return BM._rowmax(cx["high"][:, : c + 1]) + sa * cx["atrpx"]


def stock_rows(sym: str, F: pd.DataFrame, days: np.ndarray, B: Dict[str, np.ndarray], liq_days: np.ndarray,
               mkt: Optional[Market], nifty_P: Dict[pd.Timestamp, np.ndarray], beta: np.ndarray, sector: Optional[str],
               first_day: Optional[pd.Timestamp] = None) -> Tuple[Dict[Tuple[str, str], pd.DataFrame], dict]:
    """Pass 1 for one stock: every cell's triggers with their base outcome and gate values, and the stock's H6 flags."""
    cx = stock_ctx(F, days, B, liq_days, first_day)
    D = len(days)
    h6 = h6_flags(cx["high"], cx["low"], cx["close"], cx["use"]) if D else {"coil": np.zeros(0, bool)}
    h6 = {"days": days, "ok": cx["cand"], **h6}
    out: Dict[Tuple[str, str], pd.DataFrame] = {}
    if not cx["cand"].any():
        return out, h6
    sync = dict(zip((1, -1), mkt.sync(sector, days, cx["P"], cx["agg_ok"]))) if mkt is not None else \
        {1: np.full((D, NB), np.nan), -1: np.full((D, NB), np.nan)}
    br = mkt.breadth(days) if mkt is not None else np.full((D, NB), np.nan)
    NP = np.full((D, NB), np.nan)
    for k, d in enumerate(days):
        v = nifty_P.get(pd.Timestamp(d))
        if v is not None:
            NP[k] = v
    trow = cx["trow"]
    bet = np.where(trow >= 1, np.asarray(beta, float)[np.maximum(trow - 1, 0)], np.nan) if len(beta) else np.full(D, np.nan)
    Bfull = {k: cx[k] for k in ("open", "high", "low", "close")}
    for fam in STOCK_FAMS:
        for tv, prm in CELLS[fam]:
            parts = []
            for side, (tb, e, S0, score) in stock_triggers(fam, prm, cx, NP, bet, sync).items():
                sel = np.flatnonzero(cx["cand"] & (tb >= 0))
                if not len(sel):
                    continue
                res = trade_outcomes({k: v[sel] for k, v in Bfull.items()}, side, e[sel], S0[sel], XS)
                t = tb[sel]
                parts.append(pd.DataFrame({
                    "day": days[sel], "symbol": sym, "side": np.int8(side), "tb": t.astype(np.int16), "eb": res["entry_bar"].astype(np.int16),
                    "score": np.asarray(score, float)[sel].astype(np.float32), "entry": res["entry"], "stop": S0[sel],
                    "gross": res["gross"], "kind": res["kind"], "xb": res["exit_bar"].astype(np.int16), "risk": res["risk_bp"],
                    "sb": res["stop_in_entry_bar"], "gp": res["gap_in_trade"], "nx": res["no_exit_price"], "skip": res["beyond_stop"],
                    "rvol": cx["rv3"][sel, t], "isync": np.full(len(sel), np.nan), "sync": sync[side][sel, t], "breadth": br[sel, t]}))
            if parts:
                out[(fam, tv)] = finish_rows(pd.concat(parts, ignore_index=True), index=False)
    return out, h6


# ----------------------------------------------------------------------
# pass 2: books, cells, statistics
# ----------------------------------------------------------------------
def rnd(days, syms, salt: str = "tie") -> np.ndarray:
    """A fixed random number in [0, 1) per stock-day: the same on every run and machine (crc32 of the symbol, the seed and
    a salt, mixed with the day number by splitmix64). Different salts give independent numbers (the slot tie-break and
    the random-side coin must not share them: winning ties would bias the coin)."""
    s = pd.Series(np.asarray(syms, dtype=object)).astype(str)
    if not len(s):
        return np.zeros(0)
    code = {u: zlib.crc32(f"{u}|{CFG['seed']}|{salt}".encode()) for u in s.unique()}
    a = s.map(code).to_numpy(np.uint64)
    # whole days since 1970, whatever the index's time unit (pandas 3 does not always store nanoseconds)
    d = pd.DatetimeIndex(days).normalize().values.astype("datetime64[D]").astype(np.int64).astype(np.uint64)
    with np.errstate(over="ignore"):
        x = a * np.uint64(0x9E3779B97F4A7C15) + d * np.uint64(0xD1B54A32D192ED03) + np.uint64(0x632BE59BD9B4E019)
        x = (x ^ (x >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
        x = (x ^ (x >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
        x = x ^ (x >> np.uint64(31))
    return (x >> np.uint64(11)).astype(np.float64) / float(2 ** 53)


def fcfs(T: pd.DataFrame, n: int) -> pd.DataFrame:
    """The N-slot book: per day, triggers in order of entry bar; a shared entry bar goes to the higher score (ties by a
    fixed random number); the first n are taken; no slot is reused."""
    if not len(T):
        return T.assign(w=pd.Series(dtype=float))
    T = T.assign(_r=rnd(T["day"], T["symbol"].astype(str)))
    T = T.sort_values(["day", "eb", "score", "_r"], ascending=[True, True, False, True], kind="stable")
    return T.groupby("day", sort=False).head(n).drop(columns="_r").assign(w=1.0 / n)


def day_index(days, calendar: np.ndarray) -> np.ndarray:
    pos = pd.Series(np.arange(len(calendar)), index=pd.DatetimeIndex(calendar))
    return pos.reindex(pd.DatetimeIndex(days)).fillna(-1).astype(int).to_numpy()


def daily_of(T: pd.DataFrame, calendar: np.ndarray) -> Dict[float, np.ndarray]:
    """A book's daily return (fraction of its capital; cash days 0) at every slippage multiplier, from its picks' base
    trades (columns gross, kind, slip_bp, cost_bp, w)."""
    out = {}
    if not len(T):
        return {float(m): np.zeros(len(calendar)) for m in CFG["stress"]}
    di = day_index(T["day"], calendar)
    ok = di >= 0
    w = T["w"].to_numpy(float) if "w" in T else np.ones(len(T))
    for m in CFG["stress"]:
        net = net_of(T["gross"].to_numpy(float), T["kind"].to_numpy(), 1.0, T["slip_bp"].to_numpy(float), T["cost_bp"].to_numpy(float), float(m))
        out[float(m)] = np.bincount(di[ok], weights=(w * net)[ok], minlength=len(calendar))
    return out


def matched_daily(T: pd.DataFrame, calendar: np.ndarray, n: int) -> np.ndarray:
    """The exposure-matched average trigger: min(count, n)/n x the mean net of all the day's triggers (base slippage)."""
    if not len(T):
        return np.zeros(len(calendar))
    di = day_index(T["day"], calendar)
    ok = di >= 0
    net = net_of(T["gross"].to_numpy(float), T["kind"].to_numpy(), 1.0, T["slip_bp"].to_numpy(float), T["cost_bp"].to_numpy(float))
    cnt = np.bincount(di[ok], minlength=len(calendar)).astype(float)
    sm = np.bincount(di[ok], weights=net[ok], minlength=len(calendar))
    with np.errstate(invalid="ignore", divide="ignore"):
        mean = np.where(cnt > 0, sm / cnt, 0.0)
    return np.minimum(cnt, n) / n * mean


def windows(calendar: np.ndarray) -> Dict[str, np.ndarray]:
    d = pd.DatetimeIndex(calendar)
    return {"disc": np.asarray((d >= pd.Timestamp(CFG["discovery_start"])) & (d <= pd.Timestamp(CFG["discovery_end"]))),
            "conf": np.asarray((d >= pd.Timestamp(CFG["confirmation_start"])) & (d <= pd.Timestamp(CFG["confirmation_end"]))),
            "post": np.asarray(d >= pd.Timestamp(CFG["post_cas_start"]))}


def boot_idx(n: int) -> Optional[np.ndarray]:
    return BM._block_idx(n, int(CFG["boot_B"]), int(CFG["boot_block"]), np.random.default_rng(int(CFG["seed"]))) if n >= 20 else None


def bstats(x: np.ndarray, idx_cache: Dict[int, np.ndarray]) -> Tuple[float, float, float, float]:
    n = len(x)
    if n not in idx_cache:
        idx_cache[n] = boot_idx(n)
    return BM.boot_stats(np.asarray(x, float), idx_cache[n])


def wstats(daily: Dict[float, np.ndarray], picks: pd.DataFrame, net: np.ndarray, W: np.ndarray, calendar: np.ndarray,
           idx_cache: Dict[int, np.ndarray]) -> dict:
    """One book in one window: daily mean (bp of capital), interval, p, Sharpe, drawdown, stress, trades, per trade, R."""
    x = daily[1.0][W]
    m, lo, hi, p = bstats(x, idx_cache)
    inw = np.zeros(len(picks), bool)
    if len(picks):
        di = day_index(picks["day"], calendar)
        inw = (di >= 0) & W[np.maximum(di, 0)]
    nt = net[inw]
    T = picks[inw]
    out = {"days": int(len(x)), "mean_bp": m * 1e4, "lo_bp": lo * 1e4, "hi_bp": hi * 1e4, "p": p, "sharpe": BM.sharpe(x),
           "maxdd_pct": BM.max_dd(x) * 100, "mean_bp_x1.5": float(daily[1.5][W].mean() * 1e4) if len(x) else np.nan,
           "mean_bp_x2": float(daily[2.0][W].mean() * 1e4) if len(x) else np.nan, "trades": int(inw.sum()),
           "trade_days": int(len(np.unique(T["day"]))) if len(T) else 0,
           "net_per_trade_bp": float(nt.mean() * 1e4) if len(nt) else np.nan, "hit": float((nt > 0).mean()) if len(nt) else np.nan,
           "stopped": float((T["kind"] == KIND_STOP).mean()) if len(T) else np.nan}
    if len(T) and "risk" in T:
        with np.errstate(invalid="ignore", divide="ignore"):
            Rm = nt * 1e4 / T["risk"].to_numpy(float)
        out["avg_R"] = float(np.nanmean(Rm)) if np.isfinite(Rm).any() else np.nan
    for flag, name in (("sb", "stop_in_entry_bar_share"), ("gp", "gap_in_trade_share")):
        if len(T) and flag in T:
            out[name] = float(T[flag].astype(bool).mean())
    return out


def paired(a: np.ndarray, b: np.ndarray, W: Dict[str, np.ndarray], idx_cache, prefix: str = "diff") -> dict:
    out = {}
    d = a - b
    for wn, wm in W.items():
        m_, lo_, hi_, p_ = bstats(d[wm], idx_cache)
        out[f"{wn}_{prefix}_bp"], out[f"{wn}_{prefix}_lo_bp"], out[f"{wn}_{prefix}_hi_bp"], out[f"{wn}_{prefix}_p"] = m_ * 1e4, lo_ * 1e4, hi_ * 1e4, p_
    return out


POS_TOL = 1e-9          # bp (or Sharpe units): a bound of exactly zero plus floating-point noise is not above zero


def _pos(x) -> bool:
    """Strictly above zero. A paired difference that is exactly 0 on most days (an N-slot book equals its matched
    benchmark whenever a day has N or fewer triggers) can put the bootstrap's lower percentile at 0 + 1e-18: not a pass."""
    return x is not None and np.isfinite(x) and x > POS_TOL


def rule_met(disc: dict, psearch: float) -> bool:
    """The discovery half of a cell's rule: lower bound > 0, p (search) below the bar, enough trades."""
    return bool(_pos(disc.get("lo_bp")) and psearch is not None and np.isfinite(psearch) and psearch < float(CFG["search_p_max"])
                and disc.get("trades", 0) >= int(CFG["min_trades_verdict"]))


def verdict(disc: dict, conf: dict, dsr: float, psearch: float) -> str:
    ok = rule_met(disc, psearch)
    if (ok and np.isfinite(dsr) and dsr >= CFG["dsr_min"] and _pos(disc.get("mean_bp_x1.5")) and _pos(conf.get("mean_bp"))
            and _pos(conf.get("sharpe")) and _pos(disc.get("sharpe")) and conf["sharpe"] >= 0.5 * disc["sharpe"]
            and _pos(conf.get("mean_bp_x1.5"))):
        return "CHAMPION"
    if ok and _pos(conf.get("mean_bp")):
        return "PROMISING"
    if _pos(disc.get("mean_bp")) or _pos(conf.get("mean_bp")):
        return "WATCH"
    return "DEAD"


def gate_pass(T: pd.DataFrame, gate: str, fam: str, states: pd.Series) -> Tuple[np.ndarray, np.ndarray]:
    """(passes, judged) per trigger for one G2 gate; a trigger the gate cannot judge passes."""
    n = len(T)
    side = T["side"].to_numpy(int) if n else np.zeros(0, int)
    if gate == "state":
        st = states.reindex(pd.DatetimeIndex(T["day"])).to_numpy(object) if n else np.zeros(0, object)
        judged = (T["tb"].to_numpy(int) >= IBL) & np.isin(st, STATES) if n else np.zeros(0, bool)
        good = np.isin(st, CFG["family_states"][fam])
    elif gate in ("isync2", "isync1"):
        v = T["isync"].to_numpy(float) if n else np.zeros(0)
        judged = np.isfinite(v)
        good = v >= (2 if gate == "isync2" else 1)
    elif gate == "sector":
        v = T["sync"].to_numpy(float) if n else np.zeros(0)
        judged = np.isfinite(v)
        good = v >= float(CFG["sector_sync_gate"]) - 1e-9
    elif gate == "breadth":
        v = T["breadth"].to_numpy(float) if n else np.zeros(0)
        judged = np.isfinite(v)
        good = np.where(side > 0, v > float(CFG["breadth_gate"]), v < float(CFG["breadth_gate"]))
    elif gate == "participation":
        v = T["rvol"].to_numpy(float) if n else np.zeros(0)
        judged = np.isfinite(v)
        good = v >= float(CFG["participation_gate"])
    else:
        raise ValueError(gate)
    with np.errstate(invalid="ignore"):
        return (~judged) | (judged & good), judged


def gates_for(fam: str) -> List[str]:
    g = ["state"] if CFG["family_states"].get(fam) else []
    g += ["isync2", "isync1"] if fam in INDEX_FAMS else ["sector"]
    return g + ["breadth", "participation"]


def book_of(T: pd.DataFrame, fam: str, n: int) -> pd.DataFrame:
    """A cell's picks: index cells trade every trigger (one a day per side, the whole book); stock cells take N slots."""
    if fam in INDEX_FAMS:
        return T.assign(w=1.0)
    return fcfs(T, n)


def run_books(rows: Dict[Tuple[str, str], pd.DataFrame], calendar: np.ndarray, states: pd.Series, log=None) -> dict:
    """Every G1 cell per side, the search check and selection per family-side, verdicts, DSR, Reality Check and FDR."""
    W = windows(calendar)
    idx_cache: Dict[int, np.ndarray] = {}
    for wm in W.values():
        if int(wm.sum()) >= 20:
            idx_cache.setdefault(int(wm.sum()), boot_idx(int(wm.sum())))
    disc_idx = idx_cache.get(int(W["disc"].sum()))
    cells, store = [], {}
    for side, sname in SIDES:
        for fam, tv, n in cell_keys():
            T_all = rows.get((fam, tv))
            T = T_all[T_all["side"] == side] if T_all is not None and len(T_all) else empty_rows().assign(slip_bp=[], cost_bp=[])
            P = book_of(T, fam, n)
            dly = daily_of(P, calendar)
            net = net_of(P["gross"].to_numpy(float), P["kind"].to_numpy(), 1.0, P["slip_bp"].to_numpy(float), P["cost_bp"].to_numpy(float)) if len(P) else np.zeros(0)
            k = (sname, fam, tv, n)
            store[k] = {"daily": dly, "picks": P.assign(net=net), "triggers": T}
            rec = {"side": sname, "family": fam, "module": "index" if fam in INDEX_FAMS else "stock", "cell": tv, "top_n": n,
                   "triggers_all": int(len(T))}
            for wn, wm in W.items():
                for kk, vv in wstats(dly, P, net, wm, calendar, idx_cache).items():
                    rec[f"{wn}_{kk}"] = vv
            if fam in STOCK_FAMS:
                md = matched_daily(T, calendar, n)
                store[k]["matched"] = md
                rec.update(paired(dly[1.0], md, W, idx_cache, "excess"))
            cells.append(rec)
        if log:
            log(f"  books for side {sname} done")
    cells = pd.DataFrame(cells)
    trial_sh = cells["disc_sharpe"].to_numpy(float)
    n_tr = len(cells)
    cells["disc_dsr"] = [BM.deflated_sharpe(store[(r["side"], r["family"], r["cell"], int(r["top_n"]))]["daily"][1.0][W["disc"]], trial_sh, n_tr)
                         for _, r in cells.iterrows()]
    cells["p_search"] = np.nan
    cells["disc_fdr"] = False
    rc = {}
    for sname in ("L", "S"):
        ms = cells["side"] == sname
        cells.loc[ms, "disc_fdr"] = BM.bh(cells.loc[ms, "disc_p"].to_numpy(float), CFG["fdr_q"])
        for fam in FAMS:
            m = ms & (cells["family"] == fam)
            idx = np.flatnonzero(m.to_numpy())
            if disc_idx is not None and len(idx):
                M = np.column_stack([store[(sname, fam, cells.iloc[i]["cell"], int(cells.iloc[i]["top_n"]))]["daily"][1.0][W["disc"]] for i in idx])
                cells.iloc[idx, cells.columns.get_loc("p_search")] = BM.max_t_pvalues(M, disc_idx)
        for mod in ("index", "stock"):
            m = ms & (cells["module"] == mod)
            idx = np.flatnonzero(m.to_numpy())
            if disc_idx is not None and len(idx):
                M = np.column_stack([store[(sname, cells.iloc[i]["family"], cells.iloc[i]["cell"], int(cells.iloc[i]["top_n"]))]["daily"][1.0][W["disc"]] for i in idx])
                rc[f"G1 {mod} {sname}"] = BM.reality_check(M, disc_idx)
                cells.loc[cells.index[idx], "p_module"] = BM.max_t_pvalues(M, disc_idx)
    # selection (discovery only) and verdicts
    sel_rows = []
    for sname in ("L", "S"):
        for fam in FAMS:
            S_ = cells[(cells["side"] == sname) & (cells["family"] == fam)]
            if S_.empty:
                continue
            order = S_.assign(_s=S_["disc_sharpe"].fillna(-np.inf), _m=S_["disc_mean_bp"].fillna(-np.inf)).sort_values(["_s", "_m"], ascending=False)
            meets = np.array([rule_met({k_[5:]: r_[k_] for k_ in r_.index if k_.startswith("disc_")}, r_["p_search"]) for _, r_ in order.iterrows()], bool)
            best = order[meets].iloc[0] if meets.any() else order.iloc[0]
            picks = [("selected", best, "met the discovery rule" if meets.any() else "none met the discovery rule: highest Sharpe"),
                     ("median", order.iloc[len(order) // 2], "")]
            for label, rr, why in picks:
                disc = {k_[5:]: rr[k_] for k_ in rr.index if k_.startswith("disc_")}
                conf = {k_[5:]: rr[k_] for k_ in rr.index if k_.startswith("conf_")}
                vd = verdict(disc, conf, rr["disc_dsr"], rr["p_search"]) if label == "selected" else "(reported)"
                sel_rows.append({"side": sname, "family": fam, "pick": label, "cell": rr["cell"], "top_n": int(rr["top_n"]), "verdict": vd,
                                 "chosen_by": why, "p_search": rr["p_search"], "p_module": rr.get("p_module", np.nan),
                                 **{k_: rr[k_] for k_ in rr.index if k_.startswith(("disc_", "conf_", "post_"))}})
    selected = pd.DataFrame(sel_rows)
    mod_best = []
    for sname in ("L", "S"):
        for mod, fams in (("index", INDEX_FAMS), ("stock", STOCK_FAMS)):
            S_ = selected[(selected["side"] == sname) & (selected["pick"] == "selected") & selected["family"].isin(fams)]
            if len(S_):
                b = S_.assign(_s=S_["disc_sharpe"].fillna(-np.inf)).sort_values("_s", ascending=False).iloc[0]
                mod_best.append({"side": sname, "module": mod, "family": b["family"], "cell": b["cell"], "top_n": int(b["top_n"]),
                                 "p_module": b["p_module"], "verdict": b["verdict"]})
    return {"cells": cells, "selected": selected, "module_best": pd.DataFrame(mod_best), "store": store, "reality_check": rc,
            "n_trials": n_tr, "W": W, "idx_cache": idx_cache, "calendar": calendar, "trial_sh": trial_sh,
            "windows": {k_: int(v.sum()) for k_, v in W.items()}}


def run_gates(res: dict, states: pd.Series) -> pd.DataFrame:
    """G2: every gate on every selected cell, paired with the cell (the gated stock book refills its slots)."""
    W, cal, store, idx_cache = res["W"], res["calendar"], res["store"], res["idx_cache"]
    S = res["selected"]
    rows_ = []
    var_daily = {}
    for _, b in S[S["pick"] == "selected"].iterrows():
        k = (b["side"], b["family"], b["cell"], int(b["top_n"]))
        base = store[k]
        T = base["triggers"]
        dd = day_index(base["picks"]["day"], cal) if len(base["picks"]) else np.zeros(0, int)
        disc_picks = (dd >= 0) & W["disc"][np.maximum(dd, 0)] if len(dd) else np.zeros(0, bool)
        for g in gates_for(b["family"]):
            ok, judged = gate_pass(T, g, b["family"], states)
            Tg = T[ok]
            Pg = book_of(Tg, b["family"], int(b["top_n"]))
            dly = daily_of(Pg, cal)
            net = net_of(Pg["gross"].to_numpy(float), Pg["kind"].to_numpy(), 1.0, Pg["slip_bp"].to_numpy(float), Pg["cost_bp"].to_numpy(float)) if len(Pg) else np.zeros(0)
            _, jb = gate_pass(base["picks"], g, b["family"], states)
            rec = {"side": b["side"], "family": b["family"], "on_cell": f"{b['cell']}|N{int(b['top_n'])}", "gate": g,
                   "disc_judged_share": float(jb[disc_picks].mean()) if disc_picks.any() else np.nan}
            for wn, wm in W.items():
                for kk, vv in wstats(dly, Pg, net, wm, cal, idx_cache).items():
                    rec[f"{wn}_{kk}"] = vv
            rec.update(paired(dly[1.0], base["daily"][1.0], W, idx_cache, "diff"))
            rec["disc_dsr"] = BM.deflated_sharpe(dly[1.0][W["disc"]], res["trial_sh"], res["n_trials"])
            disc = {k_[5:]: rec[k_] for k_ in rec if k_.startswith("disc_")}
            conf = {k_[5:]: rec[k_] for k_ in rec if k_.startswith("conf_")}
            rec["verdict"] = verdict(disc, conf, rec["disc_dsr"], b["p_search"])
            rec["adds"] = bool(_pos(rec["disc_diff_lo_bp"]) and _pos(rec["conf_diff_bp"]) and _pos(b["disc_mean_bp"]))
            if not (judged.any()):
                rec["verdict"], rec["adds"] = "NOT RUN (no data for this gate)", False
            var_daily[(b["side"], b["family"], g)] = dly
            rows_.append(rec)
    G = pd.DataFrame(rows_)
    res["gate_daily"] = var_daily
    if len(G):
        G["disc_fdr"] = False
        for sname, Gs in G.groupby("side"):
            run_ = Gs[~Gs["verdict"].astype(str).str.startswith("NOT RUN")]
            if len(run_):
                G.loc[run_.index, "disc_fdr"] = BM.bh(run_["disc_diff_p"].to_numpy(float), CFG["fdr_q"])
                di = res["idx_cache"].get(int(W["disc"].sum()))
                if di is not None:
                    M = np.column_stack([var_daily[(sname, r_["family"], r_["gate"])][1.0][W["disc"]]
                                         - store[(sname, r_["family"], r_["on_cell"].rsplit("|N", 1)[0], int(r_["on_cell"].rsplit("|N", 1)[1]))]["daily"][1.0][W["disc"]]
                                         for _, r_ in run_.iterrows()])
                    res["reality_check"][f"G2 {sname}"] = BM.reality_check(M, di)
    return G


def mgmt_frame(P: pd.DataFrame, V: Dict[str, dict], index: bool) -> pd.DataFrame:
    """The picks with every variant's gross, units, kind, slippage and cost (and the random-side control's)."""
    P = P.reset_index(drop=True).copy()
    entry = V["base"]["entry"]
    for name, r in V.items():
        P[f"{name}_gross"], P[f"{name}_Z"], P[f"{name}_kind"] = r["gross"], r["Z"], r["kind"]
        if index:
            P[f"{name}_slip"] = index_slip_bp(r["entry"])
            P[f"{name}_cost"] = index_cost_bp(r["sizes"], r["entry"])
        else:
            P[f"{name}_slip"] = stock_slip_bp(r["kind"])
            P[f"{name}_cost"] = stock_cost_bp(r["sizes"])
        P[f"{name}_worst"] = r["worst_order"]
    coin = rnd(P["day"], P["symbol"].astype(str), salt="side") < 0.5
    for c in ("gross", "Z", "kind", "slip", "cost"):
        P[f"null_{c}"] = np.where(coin, P[f"base_{c}"], P[f"mirror_{c}"])
    P["null_flipped"] = ~coin
    P["recomputed_entry"] = entry
    return P


def vdaily(P: pd.DataFrame, calendar: np.ndarray, name: str, per_peak: bool = False) -> Dict[float, np.ndarray]:
    out = {}
    if not len(P):
        return {float(m): np.zeros(len(calendar)) for m in CFG["stress"]}
    di = day_index(P["day"], calendar)
    ok = di >= 0
    w = P["w"].to_numpy(float)
    z = P[f"{name}_Z"].to_numpy(float)
    for m in CFG["stress"]:
        net = net_of(P[f"{name}_gross"].to_numpy(float), P[f"{name}_kind"].to_numpy(), z, P[f"{name}_slip"].to_numpy(float),
                     P[f"{name}_cost"].to_numpy(float), float(m))
        if per_peak:
            net = np.where(z > 0, net / np.maximum(z, 1e-12), 0.0)
        out[float(m)] = np.bincount(di[ok], weights=(w * net)[ok], minlength=len(calendar))
    return out


def risk_numbers(P: pd.DataFrame, name: str, dly: np.ndarray, W: np.ndarray, calendar: np.ndarray) -> dict:
    """Expectancy in R, MFE capture, MAE, worst day, longest losing streak (days), share of profit from the best 5% of
    trades, units traded per day - for one variant in one window."""
    di = day_index(P["day"], calendar) if len(P) else np.zeros(0, int)
    inw = (di >= 0) & W[np.maximum(di, 0)] if len(P) else np.zeros(0, bool)
    T = P[inw]
    out = {}
    if not len(T):
        return out
    net = net_of(T[f"{name}_gross"].to_numpy(float), T[f"{name}_kind"].to_numpy(), T[f"{name}_Z"].to_numpy(float),
                 T[f"{name}_slip"].to_numpy(float), T[f"{name}_cost"].to_numpy(float))
    with np.errstate(invalid="ignore", divide="ignore"):
        Rm = net * 1e4 / T["risk"].to_numpy(float)
    out["expectancy_R"] = float(np.nanmean(Rm)) if np.isfinite(Rm).any() else np.nan
    mfe = T["mfe"].to_numpy(float)
    g = T[f"{name}_gross"].to_numpy(float) / np.maximum(T[f"{name}_Z"].to_numpy(float), 1e-12)
    out["mfe_capture"] = float(np.nanmean(g) / np.nanmean(mfe)) if np.nanmean(mfe) > 0 else np.nan
    out["mae_bp"] = float(np.nanmean(T["mae"].to_numpy(float)) * 1e4)
    x = dly[W]
    out["worst_day_bp"] = float(x.min() * 1e4) if len(x) else np.nan
    neg = x < 0
    run = best = 0
    for v in neg:
        run = run + 1 if v else 0
        best = max(best, run)
    out["longest_losing_days"] = int(best)
    pos = np.sort(net[net > 0])[::-1]
    k = max(1, int(np.ceil(0.05 * len(net))))
    tot = net.sum()
    out["top5pct_profit_share"] = float(pos[:k].sum() / tot) if tot > 0 and len(pos) else np.nan
    out["units_per_day"] = float(T[f"{name}_Z"].sum() / max(int(W.sum()), 1))
    out["worst_order_share"] = float(T[f"{name}_worst"].astype(bool).mean())
    return out


def run_management(res: dict, mg: Dict[Tuple[str, str, str, int], pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """G3 (management variants) and the random-side control on each selected cell, from the recomputed outcomes `mg`."""
    W, cal, idx_cache = res["W"], res["calendar"], res["idx_cache"]
    rows_, ctl = [], []
    res["mgmt_daily"] = {}
    for key, P in mg.items():
        sname, fam, tv, n = key
        base = vdaily(P, cal, "base")
        stored = res["store"][key]["daily"][1.0]
        for name in ("base",) + MGMT:
            dly = vdaily(P, cal, name)
            pe = vdaily(P, cal, name, per_peak=True)
            res["mgmt_daily"][(sname, fam, name)] = dly
            net = net_of(P[f"{name}_gross"].to_numpy(float), P[f"{name}_kind"].to_numpy(), P[f"{name}_Z"].to_numpy(float),
                         P[f"{name}_slip"].to_numpy(float), P[f"{name}_cost"].to_numpy(float))
            Pv = P.assign(kind=P[f"{name}_kind"], gross=P[f"{name}_gross"])
            rec = {"side": sname, "family": fam, "on_cell": f"{tv}|N{n}", "variant": name}
            for wn, wm in W.items():
                for kk, vv in wstats(dly, Pv, net, wm, cal, idx_cache).items():
                    rec[f"{wn}_{kk}"] = vv
                rec[f"{wn}_per_peak_bp"] = float(pe[1.0][wm].mean() * 1e4) if wm.any() else np.nan
                for kk, vv in risk_numbers(P, name, dly[1.0], wm, cal).items():
                    rec[f"{wn}_{kk}"] = vv
            if name != "base":
                rec.update(paired(dly[1.0], base[1.0], W, idx_cache, "diff"))
                rec.update({f"{k_}_pp": v_ for k_, v_ in paired(pe[1.0], base[1.0], W, idx_cache, "diff").items()})
                rec["adds"] = bool(_pos(rec["disc_diff_lo_bp"]) and _pos(rec["conf_diff_bp"]))
            else:
                rec["matches_pass1"] = bool(np.allclose(dly[1.0], stored, atol=1e-12))
            rows_.append(rec)
        nd = vdaily(P, cal, "null")
        rec = {"side": sname, "family": fam, "on_cell": f"{tv}|N{n}", "control": "random side"}
        for wn, wm in W.items():
            m_, lo_, hi_, _ = bstats(nd[1.0][wm], idx_cache)
            rec[f"{wn}_null_bp"], rec[f"{wn}_null_lo_bp"], rec[f"{wn}_null_hi_bp"] = m_ * 1e4, lo_ * 1e4, hi_ * 1e4
        rec.update(paired(base[1.0], nd[1.0], W, idx_cache, "skill"))
        rec["flipped_share"] = float(P["null_flipped"].mean()) if len(P) else np.nan
        ctl.append(rec)
    M = pd.DataFrame(rows_)
    if len(M):
        M["disc_fdr"] = False
        di = idx_cache.get(int(W["disc"].sum()))
        for sname, Ms in M[M["variant"] != "base"].groupby("side"):
            M.loc[Ms.index, "disc_fdr"] = BM.bh(Ms["disc_diff_p"].to_numpy(float), CFG["fdr_q"])
            if di is not None:
                cols = [res["mgmt_daily"][(sname, r_["family"], r_["variant"])][1.0][W["disc"]]
                        - res["mgmt_daily"][(sname, r_["family"], "base")][1.0][W["disc"]] for _, r_ in Ms.iterrows()]
                res["reality_check"][f"G3 {sname}"] = BM.reality_check(np.column_stack(cols), di)
    return M, pd.DataFrame(ctl)


def h2_table(res: dict) -> pd.DataFrame:
    """H2 on each selected stock cell: its excess over the exposure-matched average trigger, and the per-trade net of ALL
    the day's triggers by participation bucket (descriptive)."""
    W, cal, idx_cache, store = res["W"], res["calendar"], res["idx_cache"], res["store"]
    out = []
    S = res["selected"]
    for _, b in S[(S["pick"] == "selected") & S["family"].isin(STOCK_FAMS)].iterrows():
        k = (b["side"], b["family"], b["cell"], int(b["top_n"]))
        rec = {"side": b["side"], "family": b["family"], "on_cell": f"{b['cell']}|N{int(b['top_n'])}"}
        rec.update(paired(store[k]["daily"][1.0], store[k]["matched"], W, idx_cache, "excess"))
        rec["adds"] = bool(_pos(rec["disc_excess_lo_bp"]) and _pos(rec["conf_excess_bp"]))
        T = store[k]["triggers"]
        if len(T):
            di = day_index(T["day"], cal)
            net = net_of(T["gross"].to_numpy(float), T["kind"].to_numpy(), 1.0, T["slip_bp"].to_numpy(float), T["cost_bp"].to_numpy(float))
            rv = T["rvol"].to_numpy(float)
            for wn in ("disc", "conf"):
                inw = (di >= 0) & W[wn][np.maximum(di, 0)]
                for lab, m_ in (("rvol_lt1", rv < 1), ("rvol_1to2", (rv >= 1) & (rv < 2)), ("rvol_ge2", rv >= 2)):
                    sel = inw & m_
                    rec[f"{wn}_{lab}_trades"] = int(sel.sum())
                    rec[f"{wn}_{lab}_net_bp"] = float(net[sel].mean() * 1e4) if sel.any() else np.nan
        out.append(rec)
    return pd.DataFrame(out)


def state_table(res: dict, states: pd.Series) -> pd.DataFrame:
    """Each selected cell's daily mean by the day's 10:00 state (descriptive)."""
    W, cal, store = res["W"], res["calendar"], res["store"]
    st = states.reindex(pd.DatetimeIndex(cal)).fillna("NA").to_numpy(object)
    S = res["selected"]
    out = []
    for _, b in S[S["pick"] == "selected"].iterrows():
        x = store[(b["side"], b["family"], b["cell"], int(b["top_n"]))]["daily"][1.0]
        for wn in ("disc", "conf"):
            rec = {"side": b["side"], "family": b["family"], "on_cell": f"{b['cell']}|N{int(b['top_n'])}", "window": wn}
            for s_ in STATES + ("NA",):
                m = W[wn] & (st == s_)
                m_, lo_, hi_, _ = BM.boot_stats(x[m], boot_idx(int(m.sum())))
                rec[f"{s_}_days"], rec[f"{s_}_bp"], rec[f"{s_}_lo_bp"], rec[f"{s_}_hi_bp"] = int(m.sum()), m_ * 1e4, lo_ * 1e4, hi_ * 1e4
            out.append(rec)
    return pd.DataFrame(out)


def h6_stats(nifty_h6: Optional[dict], nifty_days: Optional[np.ndarray], stock_h6: Optional[pd.DataFrame], calendar: np.ndarray,
             idx_cache: Dict[int, np.ndarray]) -> pd.DataFrame:
    """H6: P(expansion | coil) - P(expansion | no coil) with 95% block-bootstrap intervals, NIFTY and pooled stocks."""
    W = windows(calendar)
    rows_ = []
    if stock_h6 is not None and len(stock_h6):
        A = stock_h6.reindex(pd.DatetimeIndex(calendar)).fillna(0)
        with np.errstate(invalid="ignore", divide="ignore"):
            pc = A["coil_exp"] / A["coil"]
            pn = A["nocoil_exp"] / A["nocoil"]
        d = (pc - pn).to_numpy(float)
        ok = np.isfinite(d)
        for wn, wm in W.items():
            m = wm & ok
            m_, lo_, hi_, p_ = BM.boot_stats(d[m], boot_idx(int(m.sum())))
            tc, tn = A.loc[wm, "coil"].sum(), A.loc[wm, "nocoil"].sum()
            rows_.append({"instrument": "stocks (pooled)", "window": wn, "days": int(m.sum()), "coil_stock_days": int(tc),
                          "p_exp_given_coil": float(A.loc[wm, "coil_exp"].sum() / tc) if tc else np.nan,
                          "p_exp_given_no_coil": float(A.loc[wm, "nocoil_exp"].sum() / tn) if tn else np.nan,
                          "diff_pp": m_ * 100, "diff_lo_pp": lo_ * 100, "diff_hi_pp": hi_ * 100, "p_le0": p_})
    if nifty_h6 is not None and nifty_days is not None and len(nifty_days):
        S = pd.DataFrame({"defined": nifty_h6["defined"], "coil": nifty_h6["coil"], "exp": nifty_h6["exp"]},
                         index=pd.DatetimeIndex(nifty_days)).reindex(pd.DatetimeIndex(calendar))
        dfd = S["defined"].fillna(False).to_numpy(bool)
        coil = S["coil"].fillna(False).to_numpy(bool) & dfd
        exp = S["exp"].fillna(False).to_numpy(bool) & dfd
        for wn, wm in W.items():
            m = wm & dfd
            n = int(m.sum())
            rec = {"instrument": "NIFTY 50", "window": wn, "days": n, "coil_stock_days": int((coil & m).sum())}
            if n >= 20 and (coil & m).any() and (~coil & m).any():
                c_, e_ = coil[m], exp[m]
                pc = e_[c_].mean()
                pn = e_[~c_].mean()
                idx = boot_idx(n)
                bs = []
                for r in idx:
                    cr, er = c_[r], e_[r]
                    if cr.any() and (~cr).any():
                        bs.append(er[cr].mean() - er[~cr].mean())
                bs = np.array(bs)
                d0 = pc - pn
                rec.update({"p_exp_given_coil": float(pc), "p_exp_given_no_coil": float(pn), "diff_pp": d0 * 100,
                            "diff_lo_pp": float(np.percentile(bs, 2.5) * 100) if len(bs) else np.nan,
                            "diff_hi_pp": float(np.percentile(bs, 97.5) * 100) if len(bs) else np.nan,
                            "p_le0": float((1 + np.sum(bs - d0 >= d0)) / (1 + len(bs))) if len(bs) else np.nan})
            rows_.append(rec)
    T = pd.DataFrame(rows_)
    if len(T):
        T["holds"] = False
        for inst, G in T.groupby("instrument"):
            d_ = G.set_index("window")
            ok = ("disc" in d_.index and "conf" in d_.index and _pos(d_.loc["disc"].get("diff_lo_pp")) and _pos(d_.loc["conf"].get("diff_pp")))
            T.loc[G.index, "holds"] = bool(ok)
    return T


def regime_table(series: Dict[str, np.ndarray], calendar: np.ndarray) -> pd.DataFrame:
    return BM.regime_table(series, calendar)            # the same regime dates in both declarations (checked)


def v1_by_state(root: Path, states: pd.Series) -> Tuple[pd.DataFrame, str]:
    """v1's best L and S cells (latest BM_* run) by this study's 10:00 state - descriptive."""
    base = root / "research2" / "bigmove"
    runs = sorted(p for p in base.glob("BM_*") if (p / "selected.csv").exists() and (p / "daily_returns.parquet").exists()) if base.is_dir() else []
    if not runs:
        return pd.DataFrame(), "NOT RUN (no BIGMOVE v1 run found)"
    run = runs[-1]
    try:
        S = pd.read_csv(run / "selected.csv")
        D = pd.read_parquet(run / "daily_returns.parquet")
    except Exception as e:
        return pd.DataFrame(), f"NOT RUN ({type(e).__name__}: {e})"
    D["day"] = pd.to_datetime(D["day"])
    st = states.reindex(pd.DatetimeIndex(D["day"])).fillna("NA").to_numpy(object)
    out = []
    for _, r in S[S["pick"] == "best"].iterrows():
        col = "|".join(map(str, (r["side"], r["score"], int(r["or_bars"]), int(r["top_n"]), r["stop"])))
        if col not in D:
            continue
        x = D[col].to_numpy(float)
        for s_ in STATES + ("NA",):
            m = st == s_
            m_, lo_, hi_, _ = BM.boot_stats(x[m], boot_idx(int(m.sum())))
            out.append({"run": run.name, "side": r["side"], "v1_cell": col, "state": s_, "days": int(m.sum()), "bp_per_day": m_ * 1e4,
                        "lo_bp": lo_ * 1e4, "hi_bp": hi_ * 1e4})
    return pd.DataFrame(out), f"from {run.name}"


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------
_f, _ci, _yes = BM._f, BM._ci, BM._yes


def write_report(out_dir: Path, res: dict, sha: str, cov: dict) -> None:
    S, G, M, CT, H2, H6, ST = (res.get(k) for k in ("selected", "gates", "management", "controls", "h2", "h6", "states_tab"))
    rc = res["reality_check"]
    prev = cov.get("previous_runs") or []
    banner = ([f"**RERUN #{len(prev) + 1} of {DECL['family_id']}: the confirmation window was already seen in "
               f"{', '.join(str(x['run']) for x in prev)}. These results are NOT fresh evidence.**", ""] if prev else [])
    L = ["# BIGMOVE v2 'LEVIATHAN' - LSAP's setups as declared families", ""] + banner + [
         f"{CODE_VERSION} | declaration {sha} | {dt.datetime.now():%Y-%m-%d %H:%M} | stocks: cash-intraday costs {COST_BPS:.2f} bp a round "
         f"trip at Rs {CFG['notional_rs']:,.0f} plus slippage (entry {CFG['slip_entry_bps']:.0f} bp, stop {CFG['slip_stop_bps']:.0f} bp, "
         f"time / trail {CFG['slip_time_bps']:.0f} bp); NIFTY: futures costs, {CFG['slip_nifty_points']:g} point a side", "",
         f"Days: discovery {res['windows']['disc']}, confirmation {res['windows']['conf']}, after the closing auction {res['windows']['post']} "
         f"({cov.get('bar_period', 'n/a')}). Liquid stock-days with a 3-minute session: {cov.get('covered_share', float('nan')) * 100:.1f}% of "
         f"{cov.get('liquid_stock_days', 0):,}; usable after reconciliation and the 80% rule: {cov.get('usable_share', float('nan')) * 100:.1f}%.", "",
         BM._hygiene_line(cov.get("data_hygiene")), "",
         f"Index data: {cov.get('index_note', 'n/a')}", "",
         f"Sectors: {cov.get('sectors', 'n/a')}. Breadth and participation from {cov.get('market_stocks', 0):,} liquid stocks.", ""]
    L += ["## H6 first: is a late-day expansion more likely after a midday coil?", "",
          "An EXPANSION day: late range (13:15-15:15) above 1.5x the instrument's own 60-session median; a COIL day: the 11:00-13:00 "
          "box in its own lowest 20%. Volatility clustering predicts a NEGATIVE difference (calm middays stay calm); LSAP claims a "
          "positive one. Stocks: the daily difference of the two shares, pooled; NIFTY: one instrument.", "",
          "| instrument | window | days | coil days | P(exp given coil) | P(exp given no coil) | difference (pp) [95%] | holds |", "|---|---|---|---|---|---|---|---|"]
    for _, r in (H6.iterrows() if H6 is not None and len(H6) else []):
        L.append(f"| {r['instrument']} | {r['window']} | {r['days']} | {r.get('coil_stock_days', 0)} | {_pct(r.get('p_exp_given_coil'))} | "
                 f"{_pct(r.get('p_exp_given_no_coil'))} | {_ci(r.get('diff_pp', np.nan), r.get('diff_lo_pp', np.nan), r.get('diff_hi_pp', np.nan), 2)} | "
                 f"{_yes(r.get('holds'))} |")
    L += ["", "## Verdicts (discovery selects one cell per family and side; confirmation used once)", "",
          f"Daily return of the book in bp of its capital per day [95% block-bootstrap interval]; Sharpe annualised; DSR = deflated Sharpe "
          f"over {res['n_trials']} trials; p (search) = max-t p of the cell against the best of its family-side's cells (PROMISING and "
          f"CHAMPION need it below {CFG['search_p_max']}, and at least {CFG['min_trades_verdict']} discovery trades); FDR = Benjamini-Hochberg "
          f"q {CFG['fdr_q']} over the side's 40 cells. Index books hold one NIFTY trade a day; stock books N slots, first come, first served.", "",
          "| side | family | cell | N | discovery bp/day | Sharpe | trades | per trade bp | DSR | p (search) | FDR | x1.5 slip | confirmation bp/day | Sharpe | trades | x1.5 slip | after CAS | verdict |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in S[S["pick"] == "selected"].iterrows():
        L.append(f"| {r['side']} | {r['family']} {FAMILY_NAME[r['family']]} | {r['cell']} | {r['top_n'] or '-'} | "
                 f"{_ci(r['disc_mean_bp'], r['disc_lo_bp'], r['disc_hi_bp'])} | {_f(r['disc_sharpe'], 2)} | {r['disc_trades']} | "
                 f"{_f(r['disc_net_per_trade_bp'])} | {_f(r.get('disc_dsr', np.nan), 2)} | {_p(r['p_search'])} | {_yes(r.get('disc_fdr'))} | "
                 f"{_f(r['disc_mean_bp_x1.5'])} | {_ci(r['conf_mean_bp'], r['conf_lo_bp'], r['conf_hi_bp'])} | {_f(r['conf_sharpe'], 2)} | "
                 f"{r['conf_trades']} | {_f(r['conf_mean_bp_x1.5'])} | {_f(r['post_mean_bp'])} | **{r['verdict']}** |")
    MB = res.get("module_best")
    if MB is not None and len(MB):
        L += ["", "Best selected cell of each module (highest discovery Sharpe), judged against all the module's cells of that side "
                  "(p module, max-t): " + "; ".join(f"{r['side']} {r['module']}: {r['family']} {r['cell']}|N{r['top_n']} p {_p(r['p_module'])} "
                                                     f"-> {r['verdict']}" for _, r in MB.iterrows()) + "."]
    L += ["", "White's Reality Check (best cell vs zero, discovery): " + ", ".join(f"{k} p = {_f(v, 3)}" for k, v in rc.items() if k.startswith("G1")) + ".", ""]
    L += ["Median cell of each family (reported, no verdict):", "", "| side | family | cell | N | discovery bp/day | confirmation bp/day |", "|---|---|---|---|---|---|"]
    for _, r in S[S["pick"] == "median"].iterrows():
        L.append(f"| {r['side']} | {r['family']} | {r['cell']} | {r['top_n'] or '-'} | {_ci(r['disc_mean_bp'], r['disc_lo_bp'], r['disc_hi_bp'])} | "
                 f"{_ci(r['conf_mean_bp'], r['conf_lo_bp'], r['conf_hi_bp'])} |")
    SEL = S[S["pick"] == "selected"]
    if len(SEL):
        L += ["", "Fill audit of the selected cells (discovery): stops inside the entry bar (the entry is the open, so these are real), "
                  "missing bars inside a trade (a hidden bar could hide a stop):", "", "| side | family | stopped in entry bar | missing bar inside |", "|---|---|---|---|"]
        for _, r in SEL.iterrows():
            L.append(f"| {r['side']} | {r['family']} | {_pct(r.get('disc_stop_in_entry_bar_share'))} | {_pct(r.get('disc_gap_in_trade_share'), 2)} |")
    if H2 is not None and len(H2):
        L += ["", "## H2: does the N-slot book beat the average trigger of its own rule? (stock families)", "",
              "Excess = the book minus every trigger of the same rule that day with the same capital in use (min(count, N)/N of the book), "
              "paired by day. Per-trade net of ALL triggers by participation at the trigger (descriptive).", "",
              "| side | family | cell | discovery excess | confirmation excess | adds | disc net/trade: RVOL < 1 | 1-2 | >= 2 |", "|---|---|---|---|---|---|---|---|---|"]
        for _, r in H2.iterrows():
            L.append(f"| {r['side']} | {r['family']} | {r['on_cell']} | {_ci(r['disc_excess_bp'], r['disc_excess_lo_bp'], r['disc_excess_hi_bp'])} | "
                     f"{_ci(r['conf_excess_bp'], r['conf_excess_lo_bp'], r['conf_excess_hi_bp'])} | {_yes(r['adds'])} | "
                     + " | ".join(f"{_f(r.get(f'disc_{b}_net_bp', np.nan))} ({r.get(f'disc_{b}_trades', 0)})" for b in ("rvol_lt1", "rvol_1to2", "rvol_ge2")) + " |")
    L += ["", "## G2: gates on each selected cell (paired)", "",
          "'adds' = paired discovery lower bound > 0 and paired confirmation mean > 0, on a cell with a positive discovery mean. "
          "'judged' = the share of the cell's discovery picks the gate could judge (the rest pass through).", "",
          "| side | family | gate | judged | discovery bp/day | vs cell (paired) | confirmation bp/day | vs cell | FDR | verdict | adds |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in (G.iterrows() if G is not None and len(G) else []):
        jd = f"{r['disc_judged_share'] * 100:.0f}%" if np.isfinite(r.get("disc_judged_share", np.nan)) else "-"
        L.append(f"| {r['side']} | {r['family']} | {r['gate']} | {jd} | {_ci(r['disc_mean_bp'], r['disc_lo_bp'], r['disc_hi_bp'])} | "
                 f"{_ci(r['disc_diff_bp'], r['disc_diff_lo_bp'], r['disc_diff_hi_bp'])} | {_ci(r['conf_mean_bp'], r['conf_lo_bp'], r['conf_hi_bp'])} | "
                 f"{_ci(r['conf_diff_bp'], r['conf_diff_lo_bp'], r['conf_diff_hi_bp'])} | {_yes(r.get('disc_fdr'))} | {r['verdict']} | {_yes(r['adds'])} |")
    L += ["", "Reality Check on the best paired improvement: " + ", ".join(f"{k} p = {_f(v, 3)}" for k, v in rc.items() if k.startswith(("G2", "G3"))) + "."]
    L += ["", "## G3: management on each selected cell (paired with the time exit)", "",
          "Per initial capital; 'per peak' divides each trade by its largest position (1.5x after P1, 1.75x after P2). "
          "'adds' = paired discovery lower bound > 0 and paired confirmation mean > 0.", "",
          "| side | family | variant | discovery bp/day | per peak | vs time exit | confirmation bp/day | vs time exit | exp. R | MFE capture | MAE bp | worst day bp | losing streak | top 5% share | adds |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in (M.iterrows() if M is not None and len(M) else []):
        base = r["variant"] == "base"
        L.append(f"| {r['side']} | {r['family']} | {r['variant']} | {_ci(r['disc_mean_bp'], r['disc_lo_bp'], r['disc_hi_bp'])} | {_f(r.get('disc_per_peak_bp', np.nan))} | "
                 f"{'-' if base else _ci(r['disc_diff_bp'], r['disc_diff_lo_bp'], r['disc_diff_hi_bp'])} | {_ci(r['conf_mean_bp'], r['conf_lo_bp'], r['conf_hi_bp'])} | "
                 f"{'-' if base else _ci(r['conf_diff_bp'], r['conf_diff_lo_bp'], r['conf_diff_hi_bp'])} | {_f(r.get('disc_expectancy_R', np.nan), 3)} | "
                 f"{_f(r.get('disc_mfe_capture', np.nan), 2)} | {_f(r.get('disc_mae_bp', np.nan))} | {_f(r.get('disc_worst_day_bp', np.nan))} | "
                 f"{r.get('disc_longest_losing_days', '-')} | {_pct(r.get('disc_top5pct_profit_share'))} | {'-' if base else _yes(r.get('adds'))} |")
    if M is not None and len(M) and "matches_pass1" in M:
        mm = M[M["variant"] == "base"]
        L += ["", f"Recomputation check: the time-exit book rebuilt from the bars matches pass 1 in {int(mm['matches_pass1'].sum())} of {len(mm)} cells (expected all)."]
    if CT is not None and len(CT):
        L += ["", "## Controls: the same entry times with a random side", "",
              "Each selected cell's trades with a fixed random side per trade (the stop mirrored at the same distance). 'Direction skill' "
              "= the cell minus this book, paired.", "",
              "| side | family | random side disc bp/day | direction skill disc | conf bp/day | direction skill conf |", "|---|---|---|---|---|---|"]
        for _, r in CT.iterrows():
            L.append(f"| {r['side']} | {r['family']} | {_ci(r['disc_null_bp'], r['disc_null_lo_bp'], r['disc_null_hi_bp'])} | "
                     f"{_ci(r['disc_skill_bp'], r['disc_skill_lo_bp'], r['disc_skill_hi_bp'])} | {_f(r['conf_null_bp'])} | "
                     f"{_ci(r['conf_skill_bp'], r['conf_skill_lo_bp'], r['conf_skill_hi_bp'])} |")
    if ST is not None and len(ST):
        L += ["", "## Where each selected cell makes its money: by the day's 10:00 state (descriptive)", "",
              "| side | family | window | TRAP bp/day (days) | KINETIC | RANGE | NA |", "|---|---|---|---|---|---|---|"]
        for _, r in ST.iterrows():
            L.append(f"| {r['side']} | {r['family']} | {r['window']} | " + " | ".join(
                f"{_ci(r[f'{s_}_bp'], r[f'{s_}_lo_bp'], r[f'{s_}_hi_bp'])} ({r[f'{s_}_days']})" for s_ in STATES + ("NA",)) + " |")
    V1 = res.get("v1_states")
    L += ["", f"v1's best cells by this state ({res.get('v1_note', 'n/a')}):"]
    if V1 is not None and len(V1):
        L += ["", "| side | v1 cell | state | days | bp/day [95%] |", "|---|---|---|---|---|"]
        for _, r in V1.iterrows():
            L.append(f"| {r['side']} | {r['v1_cell']} | {r['state']} | {r['days']} | {_ci(r['bp_per_day'], r['lo_bp'], r['hi_bp'])} |")
    C = res.get("composite") or {}
    if C:
        L += ["", f"All {C['cells']} selected cells, equal weight (reported, no verdict): discovery {_ci(C['disc_mean_bp'], C['disc_lo_bp'], C['disc_hi_bp'])} "
                  f"bp/day, Sharpe {_f(C['disc_sharpe'], 2)}; confirmation {_ci(C['conf_mean_bp'], C['conf_lo_bp'], C['conf_hi_bp'])}, Sharpe "
                  f"{_f(C['conf_sharpe'], 2)}; after CAS {_f(C['post_mean_bp'])}."]
    RG = res.get("regimes")
    if RG is not None and len(RG):
        cols = [c for c in RG.columns if c not in ("from", "to", "days")]
        L += ["", "## Regimes (bp/day of each selected cell between the declared dates; reported only)", "",
              "| from | to | days | " + " | ".join(cols) + " |", "|" + "---|" * (3 + len(cols))]
        for _, r in RG.iterrows():
            L.append(f"| {r['from']} | {r['to']} | {r['days']} | " + " | ".join(_f(r[c]) for c in cols) + " |")
    L += ["", "## Limits (from the declaration)", ""] + [f"- {x}" for x in DECL["limitations_stated_in_report"]]
    L += ["", "Every cell with all statistics is in cells.csv; selected.csv, gates.csv, management.csv, h2.csv, h6.csv, states.csv, "
              "controls.csv, regimes.csv; daily book returns in daily_returns.parquet; the selected cells' trades in trades_selected.parquet.", ""]
    (out_dir / "report.md").write_text("\n".join(L), encoding="utf-8")


def _pct(x, d=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:.{d}f}%"


def _p(x) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x:.3f}"


def save(res: dict, out_dir: Path, sha: str, cov: dict) -> None:
    out_dir.mkdir(parents=True, exist_ok=False)
    res["cells"].to_csv(out_dir / "cells.csv", index=False)
    res["selected"].to_csv(out_dir / "selected.csv", index=False)
    for k, fn in (("gates", "gates.csv"), ("management", "management.csv"), ("h2", "h2.csv"), ("h6", "h6.csv"), ("states_tab", "states.csv"),
                  ("controls", "controls.csv"), ("regimes", "regimes.csv")):
        X = res.get(k)
        (X if X is not None else pd.DataFrame()).to_csv(out_dir / fn, index=False)
    cal = pd.DatetimeIndex(res["calendar"])
    D = pd.DataFrame({"|".join(map(str, k)): v["daily"][1.0] for k, v in res["store"].items()}, index=cal)
    D.index.name = "day"
    D.reset_index().to_parquet(out_dir / "daily_returns.parquet", index=False)
    parts = []
    for key, P in (res.get("mgmt_frames") or {}).items():
        X = P.drop(columns=[c for c in P.columns if c.startswith("mirror_")], errors="ignore").copy()
        X["symbol"] = X["symbol"].astype(str)
        parts.append(X.assign(cell=key_str(key[1], key[2], key[3], key[0])))
    if parts:
        pd.concat(parts, ignore_index=True).to_parquet(out_dir / "trades_selected.parquet", index=False)
    (out_dir / "coverage.json").write_text(json.dumps(cov, indent=2, default=str), encoding="utf-8")
    write_report(out_dir, res, sha, cov)
    S = res["selected"]
    verd = S[S["pick"] == "selected"][["side", "family", "cell", "top_n", "verdict", "p_search"]].to_dict("records") if len(S) else []
    for r_ in verd:
        if not (isinstance(r_["p_search"], (int, float)) and np.isfinite(r_["p_search"])):
            r_["p_search"] = None
    G, M = res.get("gates"), res.get("management")
    summ = {"tool": CODE_VERSION, "declaration": sha, "coverage": cov, "windows": res["windows"], "reality_check": res["reality_check"],
            "verdicts": verd, "gate_verdicts": G[["side", "family", "gate", "verdict", "adds"]].to_dict("records") if G is not None and len(G) else [],
            "management": M[M["variant"] != "base"][["side", "family", "variant", "adds"]].to_dict("records") if M is not None and len(M) else [],
            "h6": res["h6"].reindex(columns=["instrument", "window", "diff_pp", "diff_lo_pp", "diff_hi_pp", "holds"]).to_dict("records")
            if res.get("h6") is not None and len(res["h6"]) else [],
            "composite": {k: v for k, v in (res.get("composite") or {}).items() if k == "cells" or k.endswith(("mean_bp", "lo_bp", "hi_bp", "sharpe"))},
            "cost_bps_round_trip_stock": COST_BPS}
    (out_dir / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")


# ----------------------------------------------------------------------
# the run
# ----------------------------------------------------------------------
def load_index(root: Path, dq, IC, name: str) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame], str]:
    """An index's 3-minute file (any of its names) and its daily file."""
    bars, used = None, None
    for nm in INDEX_FILES[name]:
        f = IC.store(root) / f"{nm}_{IC.BAR_MIN}m.parquet"
        if f.exists():
            try:
                bars, used = pd.read_parquet(f), f.name
            except Exception as e:
                return None, None, f"{name}: {f.name} unreadable ({type(e).__name__})"
            break
    daily = None
    fp = Path(dq._paths(root, INDEX_DAILY[name])[0])
    if fp.exists():
        daily = pd.read_parquet(fp)
        daily["day"] = SI._naive_days(daily["timestamp"]).to_numpy()
    note = (f"{name}: bars {used}" if used else f"{name}: NO 3-minute file") + ("" if daily is not None else f"; no daily file {fp.name}")
    return bars, daily, note


def previous_runs(root: Path) -> List[dict]:
    f = root / "panel" / "research_ledger.jsonl"
    out = []
    if not f.exists():
        return out
    for line in f.read_text(encoding="utf-8").splitlines():
        try:
            rec = json.loads(line)
        except Exception:
            continue
        if rec.get("family") == DECL["family_id"] and rec.get("kind") == "exploration":
            out.append({"run": rec.get("run"), "at": rec.get("at"), "declaration": rec.get("declaration")})
    return out


def data_fingerprint(rows: Dict[Tuple[str, str], pd.DataFrame], calendar: np.ndarray) -> str:
    h = hashlib.sha256(np.asarray(calendar, dtype="datetime64[ns]").astype(np.int64).tobytes())
    for k in sorted(rows):
        T = rows[k]
        if not len(T):
            continue
        num = [c for c in T.columns if c not in ("symbol",)]
        h.update(pd.util.hash_pandas_object(T[num], index=False).to_numpy().tobytes())
        h.update(pd.util.hash_pandas_object(T["symbol"].astype(str), index=False).to_numpy().tobytes())
    return h.hexdigest()[:16]


_WARNINGS: List[str] = []


def _record_warning(message, category, filename, lineno, file=None, line=None):
    _WARNINGS.append(f"{category.__name__}: {message} ({Path(str(filename)).name}:{lineno})")
    _record_warning.original(message, category, filename, lineno, file, line)


def provenance(sha: str, rows, calendar, dq, IC) -> dict:
    try:
        import pyarrow
        pa_v = pyarrow.__version__
    except Exception:
        pa_v = None
    return {"tool": CODE_VERSION, "declaration": sha,
            "code_sha256_16": {"bigmove2_study.py": BM._sha_path(Path(__file__)), "bigmove_study.py": BM._sha_path(getattr(BM, "__file__", "")),
                               "soul_intraday_study.py": BM._sha_path(getattr(SI, "__file__", "")),
                               "data_quality.py": BM._sha_path(getattr(dq, "__file__", "") or ""),
                               "intraday_cache.py": BM._sha_path(getattr(IC, "__file__", "") or "")},
            "v1_declaration_sha256_16": hashlib.sha256(BM.DECL_RAW).hexdigest()[:16],
            "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "pyarrow": pa_v,
            "platform": platform.platform(), "seed": CFG["seed"], "boot_B": CFG["boot_B"], "boot_block": CFG["boot_block"],
            "data_fingerprint": data_fingerprint(rows, calendar), "trigger_rows": {"|".join(k): int(len(v)) for k, v in rows.items()},
            "warnings": sorted(set(_WARNINGS))[:100]}


def main(argv=None) -> int:
    _WARNINGS.clear()
    _record_warning.original = warnings.showwarning
    warnings.showwarning = _record_warning
    try:
        return _main(argv)
    finally:
        warnings.showwarning = _record_warning.original


def _main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="BIGMOVE v2 LEVIATHAN: LSAP's setups as declared families (NIFTY and stocks, long and short)")
    ap.add_argument("--root", required=True)
    ap.add_argument("--coverage-only", action="store_true", help="report the index files and the liquid stocks' 3-minute coverage")
    ap.add_argument("--allow-partial-universe", action="store_true", help="run even when under 90%% of liquid stock-days are covered")
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.is_dir():
        raise PreconditionError(f"--root {root} is not a folder - run 'call env_daily.bat' and pass --root %CACHE_DAILY_ROOT%")
    bad = shared_config_problems()
    if bad:
        raise PreconditionError("bigmove_study.py's frozen configuration differs from this declaration on: " + "; ".join(bad))
    sha = hashlib.sha256(DECL_RAW).hexdigest()[:16]
    import data_quality as dq
    import intraday_cache as IC
    secmap, etf_set, lists_used = BM.read_lists(root)
    syms = BM.equity_symbols(root, dq, etf_set)
    if not syms:
        raise PreconditionError("no equity daily files found - check CACHE_DAILY_ROOT")
    _log(f"{CODE_VERSION}: {len(syms):,} equity symbols; " + (f"ETF list read ({len(etf_set):,})" if etf_set else "NO ETF list (name rule only)"))
    base = root / "research2" / "bigmove2"
    base.mkdir(parents=True, exist_ok=True)
    cov, feats, missing, by_stock, by_month = BM.coverage(root, syms, dq, IC, CFG["discovery_start"])
    (base / "missing_liquid.txt").write_text("\n".join(missing) + ("\n" if missing else ""), encoding="utf-8")
    by_stock.to_csv(base / "coverage_by_stock.csv", index=False)
    _log(f"  liquid stock-days {cov['liquid_stock_days']:,} (to {cov['last_bar_day']}); with a 3-minute session "
         f"{cov['covered_share'] * 100:.1f}%; {len(missing)} liquid stocks under 90% covered -> {base / 'missing_liquid.txt'}")
    idx_data, notes = {}, []
    tol = float(CFG["index_reconcile_tol"])
    keep, rec_counts = {}, {}
    for name in INDEX_FILES:
        bars, daily, note = load_index(root, dq, IC, name)
        idx_data[name] = (bars, daily)
        k_, cnt = reconcile_index(bars, daily, tol) if bars is not None else (None, {"checked": 0, "failed": 0})
        rec_counts[name] = cnt
        # a FILE check, not a session filter: dropping single sessions whose late average strays from the close would drop
        # the days with big late moves (the outcome); a file that disagrees on more than 20% of sessions is the wrong instrument
        wrong = bool(cnt["checked"] and cnt["failed"] > float(CFG["index_file_max_fail"]) * cnt["checked"])
        keep[name] = set() if wrong else None
        notes.append(note + (f"; {cnt['failed']} of {cnt['checked']} sessions disagree with the daily index file"
                             + (" - NOT USED (wrong instrument?)" if wrong else " (reported; the file is used)") if k_ is not None else ""))
    cov["index_note"] = " | ".join(notes)
    cov["index_reconciliation"] = rec_counts
    cov["sectors"] = f"{len(secmap)} symbols mapped" if secmap else "no sector files (the sector gate is NOT RUN)"
    _log("  " + cov["index_note"])
    for name, cnt in rec_counts.items():
        if keep.get(name) == set():
            _log(f"  WARNING {name}: {cnt['failed']} of {cnt['checked']} sessions disagree with its daily file - a wrong instrument token? "
                 f"The file is not used. Run 'python intraday_cache.py check --root ...' and look at the index lines")
    if a.coverage_only:
        return 0
    if not (cov["covered_share"] >= CFG["min_coverage"]) and not a.allow_partial_universe:
        raise PreconditionError(f"only {cov['covered_share'] * 100:.1f}% of liquid stock-days have 3-minute bars (need "
                                f"{CFG['min_coverage'] * 100:.0f}%): fetch the stocks in {base / 'missing_liquid.txt'} with the intraday "
                                f"cacher, or rerun with --allow-partial-universe (the report will say so)")
    prev = previous_runs(root)
    cov["previous_runs"] = prev
    if prev:
        _log(f"  WARNING: rerun #{len(prev) + 1} of {DECL['family_id']} - the confirmation window was already seen in "
             f"{', '.join(str(x['run']) for x in prev)}; this run's results are NOT fresh evidence (the report says so)")
    t0 = pd.Timestamp(CFG["discovery_start"])
    t_hist = t0 - pd.Timedelta(days=int(CFG["history_days_before_start"]))
    last_bar = pd.Timestamp(cov["last_bar_day"]) if cov["last_bar_day"] else None
    tol_p, tol_v = IC.DECL["reconcile_price_tol"], IC.DECL["reconcile_volume_tol"]
    hyg = {"sessions_with_bars": 0, "failed_reconciliation": 0, "no_first_bar_or_under_80pct_bars": 0, "unreadable_files": 0}
    recon: Dict[str, tuple] = {}             # reconciled days per stock, computed once (pass 0) and reused by passes 1 and 3

    def load_bars(s: str, count: bool = False):
        f = IC.store(root) / f"{s}_{IC.BAR_MIN}m.parquet"
        if not f.exists():
            return None, None
        try:
            X = pd.read_parquet(f)
            if s not in recon:
                daily = pd.read_parquet(Path(dq._paths(root, s)[0]), columns=["timestamp", "open", "high", "low", "close", "volume"])
                J = IC.reconcile_symbol(X, daily, tol_p, tol_v)
                if not len(J):
                    recon[s] = (pd.DatetimeIndex([]), 0, 0)
                else:
                    jd = BM.ist_naive(pd.to_datetime(J["day"])).dt.normalize()
                    okc = J["ok"].eq(True).to_numpy()            # a missing verdict is not a pass
                    w_ = (jd >= t0).to_numpy()
                    recon[s] = (pd.DatetimeIndex(jd[okc]), int(w_.sum()), int((w_ & ~okc).sum()))
        except Exception as e:
            if count:
                hyg["unreadable_files"] += 1
                _log(f"  WARNING {s}: 3-minute file not usable ({type(e).__name__}: {e}) - skipped")
            return None, None
        ok_days, n_w, n_fail = recon[s]
        if not len(ok_days) and not n_w:
            return None, None
        if count:                                                # whole-session data checks, counted once (pass 1)
            hyg["sessions_with_bars"] += n_w
            hyg["failed_reconciliation"] += n_fail
        X = X.assign(timestamp=BM.ist_naive(X["timestamp"]).to_numpy())
        X = X[X["timestamp"].dt.normalize().isin(ok_days) & (X["timestamp"] >= t_hist)]
        days, B = BM.bar_matrix(X)
        if count and len(days):
            hyg["no_first_bar_or_under_80pct_bars"] += int((~BM.usable_sessions(B)[days >= np.datetime64(t0)]).sum())
        return days, B

    cal_days = set()
    for F in feats.values():
        cal_days.update(pd.DatetimeIndex(F.loc[F["day"] >= t0, "day"]))
    calendar = np.array(sorted(cal_days), dtype="datetime64[ns]")
    stocks = [s for s in feats if (IC.store(root) / f"{s}_{IC.BAR_MIN}m.parquet").exists()]
    top = top_liquid(feats, calendar, int(CFG["market_participation_top"]))
    mkt = Market(calendar, [secmap[s.upper()] for s in stocks if s.upper() in secmap])
    _log(f"pass 0: breadth, sector counts and market participation ({len(stocks):,} stocks)")
    n_mkt = 0
    for k, s in enumerate(stocks):
        days, B = load_bars(s)
        if days is None or not len(days):
            continue
        _, _, ok = agg_mask(feats[s], days, B, BM.liquid_ok(feats[s]))
        if ok.any():
            n_mkt += 1
            tp = np.array([s in top.get(pd.Timestamp(d), ()) for d in days[ok]])
            mkt.add(secmap.get(s.upper()), days[ok], BM.since_open(B["close"][ok], B["open"][ok, 0]),
                    (B["volume"] * B["close"])[ok], tp)
        if (k + 1) % 200 == 0:
            _log(f"  {k + 1:,}/{len(stocks):,}")
    cov["market_stocks"] = n_mkt
    nb, nd = idx_data["NIFTY 50"]
    ix = index_ctx(nb, nd, {n_: idx_data[n_] for n_ in ("NIFTY BANK", "NIFTY IT")}, mkt, keep) if nb is not None else None
    nifty_P = {pd.Timestamp(d): ix["P"][i] for i, d in enumerate(ix["days"]) if ix["use"][i]} if ix is not None else {}
    states = pd.Series(ix["state"], index=pd.DatetimeIndex(ix["days"])) if ix is not None else pd.Series(dtype=object)
    cov["index_sessions"] = {"NIFTY 50": int(ix["use"].sum()) if ix is not None else 0, **(ix["have"] if ix is not None else {})}
    rows: Dict[Tuple[str, str], pd.DataFrame] = index_rows(ix) if ix is not None else {}
    _log(f"pass 1: {len(stocks):,} stocks (eight families' triggers with their outcomes)")
    parts: Dict[Tuple[str, str], List[pd.DataFrame]] = {}
    h6_parts, usable_days, usable_by, use_mon, first, last = [], 0, {}, [], None, None
    for k, s in enumerate(stocks):
        days, B = load_bars(s, count=True)
        if days is None or not len(days):
            continue
        inwin = days >= np.datetime64(t0)
        if inwin.any():
            first = days[inwin].min() if first is None else min(first, days[inwin].min())
            last = days[inwin].max() if last is None else max(last, days[inwin].max())
        F = feats[s]
        lq = pd.DatetimeIndex(F.loc[BM.liquid_ok(F) & (F["day"] >= t0).to_numpy(), "day"])
        if last_bar is not None:
            lq = lq[lq <= last_bar]
        u_ = lq.isin(pd.DatetimeIndex(days[BM.usable_sessions(B)]))
        usable_by[s] = int(u_.sum())
        usable_days += usable_by[s]
        if len(lq):
            use_mon.append(pd.DataFrame({"month": lq.to_period("M").astype(str), "usable": u_.astype(int)}))
        r_, h6 = stock_rows(s, F, days, B, BM.liquid_ok(F), mkt, nifty_P, BM.beta_series(F, nd), secmap.get(s.upper()), t0)
        for key, df in r_.items():
            parts.setdefault(key, []).append(df)
        okh = h6["ok"] & h6.get("defined", np.zeros(len(days), bool))
        if okh.any():
            h6_parts.append(pd.DataFrame({"day": days[okh], "coil": h6["coil"][okh], "exp": h6["exp"][okh]}))
        if (k + 1) % 100 == 0:
            _log(f"  {k + 1:,}/{len(stocks):,}")
    cov["usable_stock_days"] = usable_days
    cov["usable_share"] = usable_days / cov["liquid_stock_days"] if cov["liquid_stock_days"] else float("nan")
    cov["data_hygiene"] = hyg
    by_stock["usable_days"] = by_stock["symbol"].map(usable_by).fillna(0).astype(int)
    by_stock.to_csv(base / "coverage_by_stock.csv", index=False)
    _log(f"  usable after reconciliation and the 80% rule: {cov['usable_share'] * 100:.1f}% of liquid stock-days")
    if not (cov["usable_share"] >= CFG["min_coverage"]) and not a.allow_partial_universe:
        raise PreconditionError(f"after reconciliation only {cov['usable_share'] * 100:.1f}% of liquid stock-days are usable (need "
                                f"{CFG['min_coverage'] * 100:.0f}%); check the 3-minute data, or rerun with --allow-partial-universe")
    skipped, noexit = 0, 0
    for key, lst in parts.items():
        T = pd.concat(lst, ignore_index=True)
        skipped += sum(int(x.attrs.get("skipped_beyond_stop", 0)) for x in lst)
        noexit += sum(int(x.attrs.get("no_exit_price", 0)) for x in lst)
        T["symbol"] = T["symbol"].astype("category")
        rows[key] = T
    for key, T in rows.items():
        if key[0] in INDEX_FAMS:
            skipped += int(T.attrs.get("skipped_beyond_stop", 0))
            noexit += int(T.attrs.get("no_exit_price", 0))
    hyg["triggered_without_exit_price"] = noexit
    cov["entries_skipped_opened_beyond_stop"] = skipped
    if first is None or not any(len(v) for v in rows.values()):
        raise PreconditionError("no triggers at all - check the 3-minute data and the liquidity rule")
    first_t = min(v["day"].min() for v in rows.values() if len(v))
    calendar = calendar[(calendar >= np.datetime64(first_t)) & (calendar <= last)]
    cov["bar_period"] = f"3-minute data {pd.Timestamp(first).date()} to {pd.Timestamp(last).date()}; books from {pd.Timestamp(first_t).date()}"
    um = pd.concat(use_mon).groupby("month")["usable"].sum() if use_mon else pd.Series(dtype=int)
    by_month = by_month.set_index("month")
    by_month["usable"] = um.reindex(by_month.index).fillna(0).astype(int)
    by_month["usable_share"] = by_month["usable"] / by_month["liquid"].where(by_month["liquid"] > 0)
    by_month.reset_index().to_csv(base / "universe_by_month.csv", index=False)
    _log(f"pass 2: books ({sum(len(v) for v in rows.values()):,} triggers in {len(rows)} trigger variants)")
    res = run_books(rows, calendar, states, _log)
    res["gates"] = run_gates(res, states)
    # pass 3: management and the random-side control on the selected cells, rebuilt from the bars
    _log("pass 3: management variants on the selected cells")
    mg = {}
    S = res["selected"]
    need: Dict[str, List[tuple]] = {}
    for _, b in S[S["pick"] == "selected"].iterrows():
        key = (b["side"], b["family"], b["cell"], int(b["top_n"]))
        P = res["store"][key]["picks"]
        if b["family"] in INDEX_FAMS:
            mg[key] = manage_index(ix, b["family"], b["cell"], P) if ix is not None and len(P) else None
        else:
            for sym, Ps in P.groupby(P["symbol"].astype(str), observed=True):
                need.setdefault(sym, []).append((key, Ps))
    got: Dict[tuple, List[pd.DataFrame]] = {}
    for sym, lst in need.items():
        days, B = load_bars(sym)
        if days is None:
            continue
        cx = stock_ctx(feats[sym], days, B, BM.liquid_ok(feats[sym]), t0)
        for key, Ps in lst:
            got.setdefault(key, []).append(manage_stock(cx, key[1], key[2], Ps))
    for key, lst in got.items():
        mg[key] = pd.concat(lst, ignore_index=True)
    mg = {k: v for k, v in mg.items() if v is not None and len(v)}
    res["mgmt_frames"] = mg
    res["management"], res["controls"] = run_management(res, mg)
    res["h2"] = h2_table(res)
    res["states_tab"] = state_table(res, states)
    hs = None
    if h6_parts:
        Hh = pd.concat(h6_parts, ignore_index=True)
        g = Hh.groupby("day")
        hs = pd.DataFrame({"coil": g["coil"].sum(), "coil_exp": (Hh["coil"] & Hh["exp"]).groupby(Hh["day"]).sum(),
                           "nocoil": (~Hh["coil"]).groupby(Hh["day"]).sum(), "nocoil_exp": (~Hh["coil"] & Hh["exp"]).groupby(Hh["day"]).sum()})
    res["h6"] = h6_stats(ix["h6"] if ix is not None else None, ix["days"] if ix is not None else None, hs, calendar, res["idx_cache"])
    res["v1_states"], res["v1_note"] = v1_by_state(root, states)
    SEL = S[S["pick"] == "selected"]
    series = {f"{r['side']} {r['family']}": res["store"][(r["side"], r["family"], r["cell"], int(r["top_n"]))]["daily"][1.0] for _, r in SEL.iterrows()}
    res["regimes"] = regime_table(series, calendar) if series else pd.DataFrame()
    if series:
        comp = {float(m): np.mean([res["store"][(r["side"], r["family"], r["cell"], int(r["top_n"]))]["daily"][float(m)] for _, r in SEL.iterrows()], 0)
                for m in CFG["stress"]}
        res["composite"] = {"cells": len(series), **BM._series_only(comp, res["W"], res["idx_cache"])}
    day = dt.date.today().strftime("%Y%m%d")
    k = 1
    while (base / f"BM2_{day}_{k:03d}").exists():
        k += 1
    out = base / f"BM2_{day}_{k:03d}"
    save(res, out, sha, cov)
    BM.seal_outputs(out, provenance(sha, rows, calendar, dq, IC))
    led = BM.write_ledger(root, {"kind": "exploration", "tool": CODE_VERSION, "family": DECL["family_id"], "declaration": sha,
                                 "run": out.name, "trials_G1": res["n_trials"], "confirmation_used": True, "fresh_confirmation": not prev,
                                 "previous_runs": [x["run"] for x in prev], "coverage_share": cov.get("usable_share"),
                                 "reality_check": res["reality_check"],
                                 "selected": SEL[["side", "family", "cell", "top_n", "verdict"]].to_dict("records")})
    for _, r in SEL.iterrows():
        _log(f"  {r['side']} {r['family']} {r['cell']:16s} N{r['top_n']:<3}: discovery {_f(r['disc_mean_bp'])} bp/day, "
             f"confirmation {_f(r['conf_mean_bp'])} -> {r['verdict']}")
    print(f"  report: {out / 'report.md'}")
    print(f"  research ledger: {led}")
    return 0


def manage_index(ix: dict, fam: str, tv: str, P: pd.DataFrame) -> pd.DataFrame:
    """G3 variants for an index cell's picks, recomputed on NIFTY's bars."""
    prm = dict(CELLS[fam])[tv]
    trig = index_triggers(fam, prm, ix)
    pos = {pd.Timestamp(d): i for i, d in enumerate(ix["days"])}
    i_ = np.array([pos[pd.Timestamp(d)] for d in P["day"]], int)
    sd = P["side"].to_numpy(int)
    e = np.array([trig[s][1][i] for s, i in zip(sd, i_)], int)
    S0 = np.array([trig[s][2][i] for s, i in zip(sd, i_)], float)
    B = {k: ix[k][i_] for k in ("open", "high", "low", "close")}
    V = variants(B, sd, e, S0, XI)
    out = mgmt_frame(P, V, index=True)
    out["mfe"], out["mae"] = excursions(B, sd, V["base"])
    return out


def manage_stock(cx: dict, fam: str, tv: str, P: pd.DataFrame) -> pd.DataFrame:
    """G3 variants for one stock's picks in a stock cell, recomputed from its bars (the triggers are rebuilt by the same
    code; S5's entry and stop do not depend on its eligibility inputs, so they are rebuilt directly)."""
    prm = dict(CELLS[fam])[tv]
    pos = {pd.Timestamp(d): i for i, d in enumerate(cx["days"])}
    i_ = np.array([pos[pd.Timestamp(d)] for d in P["day"]], int)
    sd = P["side"].to_numpy(int)
    if fam == "S5":
        c = int(prm["check"])
        stops = {s: s5_stop(cx, c, s) for s in (1, -1)}
        e = np.full(len(i_), c + 1)
        S0 = np.array([stops[s][i] for s, i in zip(sd, i_)], float)
    else:
        trig = stock_triggers(fam, prm, cx)
        e = np.array([trig[s][1][i] for s, i in zip(sd, i_)], int)
        S0 = np.array([trig[s][2][i] for s, i in zip(sd, i_)], float)
    B = {k: cx[k][i_] for k in ("open", "high", "low", "close")}
    V = variants(B, sd, e, S0, XS)
    out = mgmt_frame(P, V, index=False)
    out["mfe"], out["mae"] = excursions(B, sd, V["base"])
    return out


if __name__ == "__main__":
    sys.exit(main())
