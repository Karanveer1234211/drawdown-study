# MANIFEST rows - dd_replay v1 (18 Oct 2026)

| file (under bigmove_deploy\open_close) | version / fingerprint | what it does | status |
|---|---|---|---|
| dd_replay.py | v1 (0481017d9ba09baf) | drawdown part 3: replays the plan, the 6th-open exit, the trap swap, the agreement tilt and their combinations in stage E's simulator (a verified copy with a size scale and per-pick weights), shrinks each until its worst drawdown is -25% and asks whether it keeps 70% of the plan's CAGR; writes research2\dd_replay\DR_YYYYMMDD_NNN\ | NEW |
| DD_REPLAY_DECLARATION.json | f81e86cf7f4deefa (family dd_replay_v1) | rules fixed before any real run: 8 books, sizing search, MEETS = CAGR kept >= 0.70 (Karan's choice: CAGR), paired bootstrap with 120-session blocks (amendment a), 3 safety stops, next step | NEW |
| tests\test_dd_replay.py | v1 (8a390874e5c15df3) | suite, 95 checks, about 2-4 minutes; must end VERIFIED (dd_replay v1) | NEW |
| tests\dd_world.py | v1 (d5ed19ca480e71e2) | synthetic markets where the truth is known: planted / absent / reverse 6th-open gaps, lower-circuit traps, ENS agreement (used by the suite) | NEW |
| stage_e_execution.py, EXECUTION_DECLARATION.json, freeze_engines.py, stage_d_forensics.py, research_common.py, tests\test_stage_e.py | unchanged (stage_e_execution v1.2, 158883f0af70728d) | dd_replay imports stage E read-only and checks at every run that its copy of simulate() reproduces stage E's exactly | unchanged - do not touch |

Outputs of `dd_replay.py` (under %CACHE_DAILY_ROOT%\research2\dd_replay\DR_YYYYMMDD_NNN\): report.md, summary.json, books.csv, sizing.csv (every simulator run), equity.csv (each book at its f*), trades.csv (window A at f*), bootstrap.csv. Ledger: dd_replay_declared before and dd_replay_run after, in panel\research_ledger.jsonl; a second run needs --rerun-reason. Never writes to the paper test, the panels, stage E's folders or any frozen file.

Verified 18 Oct: VERIFIED (dd_replay v1), 95 checks, 0 failures, identical output on pandas 2.3.3 / numpy 2.4.1 (Karan's) and pandas 3.0.5 / numpy 2.5.3.
