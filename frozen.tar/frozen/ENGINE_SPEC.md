# Autonomous Multi-Timeframe Behavioural Trading Intelligence — frozen specification

Frozen 2026-10-11 from Karan's message of the same day (sections 1-10 and the three decisions are his words, unchanged).
The machine-readable rules, periods and stage gates are in `ENGINE_DECLARATION.json`, which records this file's SHA-256.
Changing this file or the declaration makes a new version with a new fingerprint; nothing run under an old version is
overwritten or re-labelled.

Design principle: discover the stock's current behavioural state, not force it into a state or strategy defined in
advance. The question is whether the state helps predict what happens next, and only then whether that can be turned
into a profitable trade after costs. Three separate confidence measures: state confidence, historical evidence
confidence, trade confidence. They must not be confused.

Architecture: 10 selected stocks, each with its own behavioural history -> multi-timeframe context (weekly: broader
context; daily: structure and setup; intraday: current behaviour; plus NIFTY, sector, volume and volatility context) ->
behavioural state discovery (learned states, structural patterns, state transitions and mixtures of possible states) ->
confidence and historical analogues (what happened previously when this stock behaved similarly?) -> conditional trade
discovery (entry, stop, target, exit and management for the current state) -> validated trade or NO TRADE (only
approved, risk-controlled strategy versions execute).

## 1. Mission

Build an autonomous research system for 10 user-selected NSE equities.

The system must learn how each stock behaves, identify its current behavioral state from available information,
estimate what typically happens next in comparable situations, and discover a profitable trading response if the
evidence supports one.

The discovery target is Stock + Current State + Context → Appropriate Trade.

Do not constrain the system to one strategy per stock, a fixed list of states, fixed indicators, or universal entry and
exit rules.

Success means finding repeatable, statistically supported trading opportunities on unseen data—not generating many
strategies or maximizing historical backtest profits.

## 2. State definitions must be discovered, not imposed

Do not assume that RSI, MACD, VWAP, candlestick patterns, trend labels, or any other predetermined feature defines a
state.

These may be useful inputs, but the engine must be free to discover states from:

* Individual bar geometry, sequences of bars and price structure.
* Trends, ranges, transitions, compression and expansion.
* Volume behavior, relative volume, volatility and liquidity proxies.
* Momentum, reversals, breakouts and failed breakouts.
* Price location relative to VWAP, previous highs/lows, opening ranges and other relevant levels.
* RSI and other technical indicators where they contain useful information.
* Relative strength against NIFTY and the relevant sector.
* Relationships between weekly, daily and intraday behavior.
* Combinations or representations of these variables that are not obvious to a human researcher.

State discovery may use interpretable features, clustering, probabilistic latent-state models, change-point detection,
or other justified methods.

Do not automatically assume that the most sophisticated model is best. Compare candidate representations against
simpler baselines on out-of-sample predictive usefulness, state stability, interpretability and computational cost.

States must be allowed to emerge, overlap, transition and disappear. The engine must also identify observations that
do not resemble previously learned states.

## 3. Multi-timeframe context

Build a point-in-time feature system with three main time horizons.

Weekly context: Broader trend, structure, volatility, location within the weekly range, and weekly transitions.

Daily context: Previous-session structure, gap characteristics, daily compression or expansion, momentum, volatility
and relevant price levels.

Intraday context: The evolving bar sequence, opening behavior, intraday structure, volume changes, VWAP interactions,
failed attempts, momentum shifts and potential entries.

Include NIFTY and sector context where relevant.

The horizons must interact. For example, an intraday breakout may behave differently depending on whether the stock is
aligned with its daily and weekly direction.

All information must be available at the simulated decision time. During a trading session, the system may use
completed intraday bars and explicitly constructed current-session information, but it must not use that day's
eventual closing price or an incomplete future weekly candle as if already known.

Different timeframes may disagree. The engine must learn whether that disagreement is useful rather than automatically
forcing them into alignment.

## 4. Represent state uncertainty explicitly

Do not force every observation into one definitive state label.

Maintain a state probability distribution or another justified measure of membership uncertainty, with a
representation of multiple plausible states when appropriate.

The system must distinguish:

**A. State assignment confidence.** How strongly does current behavior match a learned state? Consider model
probabilities, ambiguity between competing states, distance from the training distribution and agreement across
reasonable model variants.

**B. Historical evidence confidence.** How much independent historical evidence exists for comparable situations in
this particular stock? Track usable observations, effective sample size, recency, variability and uncertainty in the
estimated outcomes.

**C. Trade confidence.** How strong is the evidence that a specific proposed trade has positive expectancy after
transaction costs and slippage? Estimate relevant outcome probabilities, expected net return, adverse excursion and
uncertainty.

These are separate quantities. A high-confidence state assignment must never automatically imply a high-confidence
trade.

Calibrate probabilistic predictions using chronological out-of-sample predictions. Evaluate reliability diagrams,
Brier scores and log loss as appropriate. Label any heuristic score honestly; do not present an uncalibrated score as a
true probability.

## 5. Learn what happens after each behavior

For each stock, maintain a historical behavioral evidence store.

At every historical decision point, record the state information that was actually available at that time. Then
analyze subsequent outcomes, including:

* Forward returns over relevant horizons.
* Maximum favorable and adverse excursions.
* The probability of reaching one price level before another.
* Time taken to reach a target, invalidation level or reversal.
* The frequency and magnitude of failed moves.
* The influence of weekly and daily context.
* Which outcomes vary with volatility, market regime and time of day.

Use the stock's own historical behavior as primary evidence, but use carefully controlled information pooling across
the 10 selected stocks when it improves reliability.

Apply statistical shrinkage where a stock/state combination has too few observations. A handful of historical examples
must not be treated as proof.

Do not confuse similarity in indicators with similarity in outcomes. The evidence store must test whether comparable
states actually produce useful predictive information.

## 6. Discover complete trades conditionally

Once a state or state combination demonstrates predictive usefulness, the engine must discover how to trade it.

Entry, stop-loss, target, exit and management must be conditional on the current behavior.

Candidate entries might include a structural break, pullback, reclaim, rejection, failed breakout or a newly
discovered sequence. These are examples, not a required menu.

Candidate stops might be based on structural invalidation, swing points, previous-session levels, volatility, or other
discovered relationships.

Candidate exits might include a fixed target, RSI threshold, VWAP, structural level, trailing stop, partial
profit-taking, momentum failure or time exit.

The same indicator may be useful in one state and irrelevant in another. A particular stock may require different
trades on different days.

For statistical discipline, first test whether a candidate entry/state relationship contains predictive information
using a simple baseline exit. Optimize stops, targets and trade management only after an entry has demonstrated
evidence worth investigating. Then validate the entire entry-to-exit plan as a complete policy.

The engine may generate new hypotheses autonomously, but every proposed variation must be implemented reproducibly,
recorded and counted as an experiment.

## 7. The decision engine

At every eligible intraday decision point:

1. Update the available weekly, daily, intraday and market-context information.
2. Estimate the current state distribution and identify novelty or uncertainty.
3. Retrieve comparable historical episodes and estimate the distribution of subsequent outcomes.
4. Evaluate eligible, validated trading policies for the current state and context.
5. Estimate trade-level probabilities, expected net return, adverse risk and uncertainty.
6. Apply portfolio-level risk limits and execution constraints.
7. Trade only when the predefined evidence and risk requirements are satisfied.

Otherwise, return NO TRADE, with a recorded reason.

A trade must not be selected merely because its historical backtest has the highest average return. The engine must
account for sample size, drawdown, costs, uncertainty, parameter sensitivity and whether the result survives
out-of-sample testing.

## 8. Leakage prevention and research integrity

Use chronological walk-forward evaluation. Fit feature transformations, state models, calibrators and predictive
models only on information available within each training window.

For every experiment, retain:

* Hypothesis and intended purpose.
* State representation and feature versions.
* Training, validation and evaluation periods.
* Entry and exit definitions.
* Parameters and model configuration.
* Number of previous and current experiments.
* Costs, slippage and execution assumptions.
* In-sample, validation and out-of-sample results.
* Confidence intervals, robustness tests and rejection reasons.

Count every failed attempt, state variant, parameter change, AI-generated revision and exit alternative in the
cumulative research history.

Protect the final holdout from iterative model development. Audit previous data exposure before calling any historical
period untouched. After historical validation, test the frozen system in forward paper trading.

## 9. Build in controlled stages

* **Stage A — Data integrity:** Validate bar timestamps, missing sessions, corporate-action adjustments, daily/weekly
  consistency, point-in-time features and executable price assumptions.
* **Stage B — State discovery:** Develop and compare state representations across the 10 selected stocks and multiple
  timeframes. Do not optimize a strategy yet.
* **Stage C — State confidence and historical evidence:** Test recurrence, ambiguity, novelty, stability, conditional
  outcome distributions and out-of-sample predictive usefulness.
* **Stage D — Conditional trade discovery:** Identify promising state-to-movement relationships and develop entry rules.
* **Stage E — Trade construction:** Test appropriate stops, targets, exits and management for each surviving
  entry/state combination.
* **Stage F — Statistical validation:** Apply chronological walk-forward evaluation, realistic costs, risk analysis,
  parameter robustness and cumulative multiple-testing controls.
* **Stage G — Forward paper trading:** Monitor state assignments, confidence calibration, predicted versus realized
  outcomes, execution assumptions and degradation.
* **Stage H — Separate live approval:** Only version-frozen strategies that pass predefined gates may be considered for
  live execution. Research autonomy does not confer permission to place live orders.

Do not advance merely because the software runs or a backtest looks profitable. Each stage must meet predeclared
evidence and engineering requirements.

## 10. Scope guardrails

The 10 user-selected stocks remain the target trading universe. Do not replace them with automatically selected stocks
unless explicitly approved.

The existing Stage 0 results must remain preserved as the baseline for the predefined setups they actually tested. Do
not alter their thresholds after seeing the results or rerun them to obtain a pass.

However, Stage 0 must not be interpreted as testing the full state-discovery hypothesis. Its failure to establish
persistence for a limited menu of fixed setups does not establish that all state-dependent behavior is absent.

The next research stage must address the original objective directly: discover how each selected stock behaves across
timeframes, identify its current state with calibrated uncertainty, and determine whether a validated trade response
exists.

**Final principle:** Learn the state. Measure uncertainty. Study what followed similar behavior. Discover the
appropriate trade. Trade only when the evidence justifies it. Otherwise, stand aside.

## Three decisions that will materially affect success

1. **Do not let Stage 0 veto the state-discovery project.** Stage 0 tested a predefined set of intraday probes with a
   common time exit, not a system that discovers unknown states and their conditional trade responses. Its result
   remains valid for the question it asked, but it cannot settle the larger question.
2. **Make calibrated uncertainty a real gate.** A state model that announces "92% confidence" is not useful unless
   similar predictions have proved reliable. Calibration must use data independent of model fitting.
3. **Treat autonomous discovery as a controlled statistical experiment.** The engine can be creative, but it cannot be
   allowed to search indefinitely and report only its winners.

Next build milestone (Karan's recommendation): Stage B, after a data-integrity audit and a synthetic test suite. Do not
start with a giant strategy generator. First prove the engine can represent states consistently, estimate uncertainty
honestly, and distinguish states with useful predictive information from states that merely describe the past.

---

## Freeze notes (how the spec is applied; written 2026-10-11, before any engine run on real data)

These do not change the spec; they record the operational choices it left open. The numbers are in the declaration.

1. **No historical period is untouched.** The data-exposure audit (declaration, `data_exposure_audit`) found that
   BIGMOVE v1.1 read every session from 2021-10-01 to 2026-10-09, including 2025-01 to 2026-07 as its one-time
   confirmation window, and that Karan's Stage 0 message says BIGMOVE v2 also produced reports. So 2025 onward is
   "lightly exposed" (pooled fixed-setup books over ~1,000 stocks were seen; no per-stock or state result was), not
   unseen. It is still the best historical holdout and is reserved for Stage F, once. The only truly unseen data is
   forward data after this freeze (Stage G).
2. **Development data** for Stages B to E is 2021-10-01 to 2024-12-31, with walk-forward folds inside it. Stage A may
   read every period, but only for structural hygiene (timestamps, sessions, reconciliation, adjustment basis); no
   return, outcome or volatility statistic is computed on data after 2024-12-31.
3. **Daily and weekly context come from the daily cache**, not from 3-minute bars: it reaches back to 2015 (weekly
   context needs a year of history before October 2021), its close is the official NSE close, and intraday_cache
   already reconciles the two. 3-minute-derived daily and weekly bars are used in Stage A only as the cross-check.
4. **The 10 stocks are an input** (`engine_stocks.txt`), recorded with every run. Until Karan names them, nothing runs
   on real data.
5. **Stage 0 stays as it is**: FAIL under its frozen rules, the baseline for the 20 fixed setup-sides it tested.
6. **Every Stage B to F variant counts as an experiment** in `<root>\research2\engine\experiments.jsonl`, on top of the
   prior research history listed in the declaration.
