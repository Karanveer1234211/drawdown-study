# MANIFEST rows - shadow_lanes v1 (19 Oct 2026)

| file (under bigmove_deploy\open_close) | version / fingerprint | what it does | status |
|---|---|---|---|
| shadow_lanes.py | v1 (f8ca9d41120fdece) | forward shadow lanes beside the paper test, from its own records: PLAN (sell at the 5th close), OPEN6 (sell at the 6th open) and OPEN6+TRAP (on-time P(stuck) >= 10% picks moved back, then OPEN6) on the paper ledger's D watchlists from 30 Sep 2026, each at full size and at its replay size (0.698 / 0.727 / 0.785), in dd_replay's simulator checked against stage E's own simulate() every run. J1 = 6th open minus 5th close on every PLAN trade; J2 = each trap swap; J3 = lane equity and drawdown (descriptive). Commands: `track` (a dated snapshot, running numbers) and `judge --checkpoint 6 / 12` (the declared verdicts, once, when settled). Writes research2\shadow_lanes\SL_YYYYMMDD_NNN\ and SLJ_M6_YYYYMMDD_NNN\ | NEW |
| SHADOW_LANES_DECLARATION.json | 5c1a4f4f448ebeb2 (family shadow_lanes_v1) | rules fixed 19 Oct 02:05 IST before any lane was computed; amendment (a) 02:25-02:40 IST before any run on real data (interval needs 20 signal days; open positions counted as open; checkpoint lanes end at the last exit; liquidity from panel_live; the paper test's late rule; no judging over a day holding two bars) | NEW |
| tests\test_shadow_lanes.py | v1 (79fc04dc24592d75) | 58 checks, about 20-60 s; must end VERIFIED (shadow_lanes v1) | NEW |
| tests\lanes_world.py | v1 (2eaf3f69c40a94b9) | synthetic forward worlds: the 6th-open gap planted / absent / reversed, traps planted / random / none, late cards, a late watchlist, missing evenings, an ETF, thin stocks, a frozen panel_oc that ends 22 Sep | NEW |
| stage_e_execution.py, EXECUTION_DECLARATION.json, dd_replay.py, DD_REPLAY_DECLARATION.json, stage_d_forensics.py, research_common.py | unchanged (stage E v1.2 158883f0af70728d / 5ba73cc0687eb482; dd_replay v1 0481017d9ba09baf / f81e86cf7f4deefa) | imported read-only; shadow_lanes refuses to run if the versions or declarations differ | unchanged - do not touch |

Reads (never writes): paper\ledger.jsonl (D's watchlists and their recording times), research2\pick_meta\forward\ (index.jsonl + PM_cards_YYYYMMDD.csv, on-time cards only, SHA-256 checked), panel_live\panel.parquet (X_turnover_med), the daily cache through stage E's loader. Writes only research2\shadow_lanes\ and ledger lines shadow_lanes_declared (first run) / shadow_lanes_track / shadow_lanes_judged in panel\research_ledger.jsonl.

Outputs of each run: report.md, summary.json, lanes_daily.csv, trades.csv (with a `closed` column), open6_pairs.csv, trap_swaps.csv, outputs.sha256.

Verified 19 Oct: VERIFIED (shadow_lanes v1), 58 checks, 0 failures, 0 warnings, identical check lines on pandas 2.3.3 / numpy 2.4.1 / pyarrow 26.0.0 (Karan's set, 19-20 s) and pandas 3.0.5 / numpy 2.5.3 (22-23 s); also VERIFIED in a clean folder holding only these files and their dependencies.
