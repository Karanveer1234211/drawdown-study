#!/usr/bin/env python3
"""
dd_replay.py - drawdown part 3: replay the levers found so far in stage E's execution simulator and answer
Karan's question directly: can the plan's worst drawdown be cut to -25% while keeping at least 70% of its
CAGR?

Run from ...\\bigmove_deploy\\open_close with PYTHONPATH = ...\\bigmove_deploy (as stage_e_execution):

    python dd_replay.py --panel %CACHE_DAILY_ROOT%\\panel_oc --root %CACHE_DAILY_ROOT% --exec-run EXEC_20260930_001
        [--isin <the NSE bhavcopy file(s) the execution backtest used>] [--pm-run PM_YYYYMMDD_NNN]

THE RULES ARE IN DD_REPLAY_DECLARATION.json (fixed before any real run)
  Eight books on stage E's PRIMARY mechanics (engine D, 3 new positions a day, Rs 10 lakh, Zerodha costs +
  impact, 2% liquidity cap, integer shares, honest locked exits):
    PLAN    the plan as traded: sell at the 5th close
    OPEN6   sell at the 6th session's open instead
    TRAP    top-10 picks with pick_meta's out-of-sample P(stuck) >= 10% go behind the unflagged ones
    AGREE   1.5 x size on picks also in ENS's top 3, the others share the rest (same daily capital)
    OPEN6+TRAP, OPEN6+AGREE, TRAP+AGREE, OPEN6+TRAP+AGREE
  Each book is shrunk - every new position f x 1/15 of equity, f <= 1 - until its worst drawdown is -25%.
  MEETS if its CAGR is then at least 70% of the plan's full-size CAGR. The plan shrunk the same way is the
  pure size cut every book is compared with. Robustness: 2,000 paired block-bootstrap histories, every book
  re-shrunk in each. Window A (headline) = pick_meta's out-of-sample signal days, all eight books; window B
  (descriptive) = the whole frozen walk-forward, the four books that need no P(stuck).

SAFETY STOPS before any book
  1. the copy of stage E's simulator (two switches added: size scale, per-pick weights) must reproduce
     stage E's simulate() exactly with the switches off - PLAN and OPEN6 over the whole history - and the
     weighted path with all weights 1 must reproduce the unweighted copy;
  2. the whole-history PLAN must reproduce the execution backtest's trades (99.5%);
  3. 99.5% of the plan's window-A picks need a P(stuck) forecast.

OUTPUT: <root>\\research2\\dd_replay\\DR_YYYYMMDD_NNN\\ report.md, summary.json, books.csv, sizing.csv,
equity.csv, trades.csv, bootstrap.csv; ledger lines dd_replay_declared (before) and dd_replay_run (after) in
<root>\\panel\\research_ledger.jsonl. Never writes to the paper test, the panels, stage E's folders or any
frozen file. DESCRIPTIVE: the same history the levers were found on - not new evidence.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import research_common as RC        # noqa: E402  (this folder's copy wins, as in stage E)
import stage_e_execution as EX      # noqa: E402  (simulator, costs, exits, perf - read only, never modified)

CODE_VERSION = "dd_replay v1"
FAMILY = "dd_replay_v1"
DECL_FILE = HERE / "DD_REPLAY_DECLARATION.json"
OUT_SUB = Path("research2") / "dd_replay"
PM_SUB = Path("research2") / "pick_meta"
CFG = {
    "engine": "D",
    "ens": "ENS",
    "books": ["PLAN", "OPEN6", "TRAP", "AGREE", "OPEN6+TRAP", "OPEN6+AGREE", "TRAP+AGREE", "OPEN6+TRAP+AGREE"],
    "books_whole_history": ["PLAN", "OPEN6", "AGREE", "OPEN6+AGREE"],
    "dd_target": 0.25,
    "keep_cagr": 0.70,
    "scale_grid": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
    "bisect_steps": 7,
    "plan_hold": 5,
    "open6_session": 6,
    "lock_search_sessions": 20,
    "trap_line_pct": 10.0,
    "trap_top": 10,
    "agree_weight": 1.5,
    "agree_ens_top": 3,
    "calendar_tail_sessions": 35,
    "boot_B": 2000,
    "boot_block": 120,
    "boot_seed": 7,
    "boot_bisect_steps": 30,
    "boot_days_per_year": 250,
    "boot_chunk": 250,
    "check_weighted_scale": 0.5,
    "min_forecast_coverage": 0.995,
    "min_exec_trade_match": 0.995,
    "exec_price_tol": 1e-09,
}
EX_TRADE_COLS = ["signal_day", "entry_day", "exit_day", "symbol", "rank", "shares", "entry_fill", "exit_raw",
                 "exit_fill", "exit_kind", "buy_value", "buy_cost", "sell_value", "sell_cost", "pnl", "ret", "raw_ret",
                 "locked_exit", "stopped", "data_end", "capped", "held"]
EX_STAT_KEYS = ["orders", "filled", "replaced", "capped", "cash_limited", "skipped_small", "n_trades", "sum_ret", "wins"]


class PreconditionError(SystemExit):
    pass


class ReconciliationError(SystemExit):
    pass


def _log(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def _day(x) -> np.datetime64:
    """A calendar date (to the day) - the key that joins watchlists, forecasts and the execution files."""
    return np.datetime64(pd.Timestamp(x).normalize().to_datetime64(), "D")


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def load_declaration(path: Path = DECL_FILE) -> Tuple[dict, str]:
    p = Path(path)
    if not p.exists():
        raise PreconditionError(f"{p.name} not found next to {Path(__file__).name}")
    raw = p.read_bytes()
    decl = json.loads(raw.decode("utf-8"))
    want, got = json.loads(json.dumps(CFG)), decl.get("config", {})
    if decl.get("family_id") != FAMILY or got != want:
        diff = sorted(k for k in set(want) | set(got) if want.get(k) != got.get(k))
        raise PreconditionError(f"settings differ from {p.name} on {diff or ['family_id']}; the declaration is fixed")
    return decl, hashlib.sha256(raw).hexdigest()[:16]


# ----------------------------------------------------------------------
# the simulator: stage_e_execution v1.2 simulate(), copied line for line, plus two switches
# ----------------------------------------------------------------------
def simulate_x(sc: "EX.Scenario", lists: Dict, bars: Dict, adv: Dict, cal: np.ndarray, keep_trades: bool = True,
               exit_planner=None, scale: float = 1.0, weigher: Optional[Callable] = None) -> dict:
    """stage_e_execution.simulate (v1.2) with two switches:
      scale    every new position gets scale x (yesterday's closing equity / (n x hold)); 1.0 = stage E's size
      weigher  weigher(signal_day, symbols, ranks) -> one weight per pick. The picks are chosen exactly as the
               plan chooses them (the checks that need no cash: bar, liquidity, one share at the plan's size),
               then each is bought at weight x its size; weight 0 = not bought; an order too small for one
               share after cash stays in cash. None = stage E's own buy loop, untouched.
    With scale 1.0 and weigher None this is stage E's simulate(); every run checks that (integrity 1)."""
    cash = float(sc.capital)
    opened: List[dict] = []
    trades: List[dict] = []
    eq_rows = []
    last_close: Dict[str, float] = {}
    cost_tot = {k: 0.0 for k in ("stt", "stamp", "txn", "sebi", "gst", "dp", "flat", "slip_entry", "slip_exit")}
    prev_equity = cash
    stats = {"orders": 0, "filled": 0, "replaced": 0, "capped": 0, "cash_limited": 0, "skipped_small": 0,
             "n_trades": 0, "sum_ret": 0.0, "wins": 0, "locked_exits": 0, "zero_weight": 0, "unfilled": 0}

    def close_position(p, day, raw, kind, dp_due):
        nonlocal cash
        b = bars[p["sym"]]
        slip = 0.0
        if kind in ("close", "open", "stop"):
            slip = EX.impact_frac(sc, p["buy_value"], p["adv"], p["vol"]) + EX.tick_frac(sc, day, raw, "exit")
        fill = raw * (1 - slip)
        sell_value = p["shares"] * fill
        c = EX.sell_costs(sell_value, sc, dp_due, p["buy_value"])
        cash += sell_value - sum(c.values())
        for k, v in c.items():
            cost_tot[k] += v
        cost_tot["slip_exit"] += p["shares"] * (raw - fill)
        pnl = sell_value - sum(c.values()) - p["buy_value"] - p["buy_cost"]
        ret = pnl / (p["buy_value"] + p["buy_cost"])
        stats["n_trades"] += 1
        stats["sum_ret"] += ret
        stats["wins"] += int(ret > 0)
        stats["locked_exits"] += int(p["flags"]["locked_exit"])
        if keep_trades:
            trades.append({"signal_day": p["signal_day"], "entry_day": p["entry_day"], "exit_day": day,
                           "symbol": p["sym"], "rank": p["rank"], "shares": p["shares"], "entry_fill": p["fill"],
                           "exit_raw": raw, "exit_fill": fill, "exit_kind": kind, "buy_value": p["buy_value"],
                           "buy_cost": p["buy_cost"], "sell_value": sell_value, "sell_cost": sum(c.values()),
                           "pnl": pnl, "ret": ret,
                           "raw_ret": raw / p["open_px"] - 1, "locked_exit": p["flags"]["locked_exit"],
                           "stopped": p["flags"]["stopped"], "data_end": p["flags"]["data_end"],
                           "capped": p["capped"], "held": p["held"], "weight": p["weight"]})

    def open_position(sym, b, e, a, vol, rank, shares, fill, capped, weight, i, day):
        nonlocal cash
        bv = shares * fill
        c = EX.buy_costs(bv, sc)
        cash -= bv + sum(c.values())
        for k, v in c.items():
            cost_tot[k] += v
        cost_tot["slip_entry"] += shares * (fill - b.o[e])
        if exit_planner is None:
            sell_bar, kind, raw, flags = EX.plan_exit(b, e, sc.hold, sc.stop)
        else:
            sell_bar, kind, raw, flags = exit_planner(sym, b, e, cal[i - 1])
        p = {"sym": sym, "shares": shares, "fill": fill, "open_px": b.o[e], "buy_value": bv,
             "buy_cost": sum(c.values()), "rank": rank, "signal_day": cal[i - 1], "entry_day": day,
             "sell_day": b.ts[sell_bar], "sell_kind": kind, "sell_raw": raw, "flags": flags,
             "adv": a, "vol": vol, "capped": capped, "held": int(sell_bar - e + 1), "weight": weight}
        opened.append(p)
        stats["filled"] += 1
        stats["capped"] += int(capped)

    for i, day in enumerate(cal):
        # ---- the open: scheduled open-sells, then buys
        dp_today = set()
        still = []
        for p in opened:
            if p["sell_day"] == day and p["sell_kind"] == "open":
                close_position(p, day, p["sell_raw"], "open", p["sym"] not in dp_today)
                dp_today.add(p["sym"])
            else:
                still.append(p)
        opened = still
        if i > 0:
            wl = lists.get(cal[i - 1])
            if wl:
                per = prev_equity / (sc.n * sc.hold) * scale
                held = {p["sym"] for p in opened}
                if weigher is None:
                    # stage E's buy loop (v1.2), unchanged
                    n_f = 0
                    for rank, sym in enumerate(wl[:sc.depth], 1):
                        if n_f >= sc.n:
                            break
                        if not sc.duplicates and sym in held:
                            continue
                        stats["orders"] += 1
                        b = bars.get(sym)
                        e = b.index.get(day) if b is not None else None
                        if e is None or not (b.o[e] > 0):
                            stats["replaced"] += 1
                            continue
                        a = adv.get((cal[i - 1], sym), float("nan"))
                        value = per
                        capped = False
                        if sc.liquidity_cap is not None:
                            cap = sc.liquidity_cap * a if np.isfinite(a) else 0.0
                            if cap <= 0:
                                stats["replaced"] += 1
                                continue
                            if cap < value:
                                value, capped = cap, True
                        vol = b.vol20[e - 1] if e >= 1 else float("nan")
                        slip = EX.impact_frac(sc, value, a, vol) + EX.tick_frac(sc, day, b.o[e], "entry")
                        fill = b.o[e] * (1 + slip)
                        budget = min(value, cash / (1 + 0.0025))
                        if budget < value:
                            stats["cash_limited"] += 1
                            if sc.min_order_frac is not None and budget < sc.min_order_frac * value:
                                stats["skipped_small"] += 1          # a sliver: the slot stays in cash
                                break
                        shares = budget / fill if not sc.integer_shares else math.floor(budget / fill)
                        if shares <= 0:
                            stats["replaced"] += 1
                            continue
                        open_position(sym, b, e, a, vol, rank, shares, fill, capped, 1.0, i, day)
                        held.add(sym)
                        n_f += 1
                else:
                    # the weighted path: choose the picks as the plan does (no cash needed), then re-size them
                    cands = []
                    for rank, sym in enumerate(wl[:sc.depth], 1):
                        if len(cands) >= sc.n:
                            break
                        if not sc.duplicates and sym in held:
                            continue
                        stats["orders"] += 1
                        b = bars.get(sym)
                        e = b.index.get(day) if b is not None else None
                        if e is None or not (b.o[e] > 0):
                            stats["replaced"] += 1
                            continue
                        a = adv.get((cal[i - 1], sym), float("nan"))
                        value = per
                        if sc.liquidity_cap is not None:
                            cap = sc.liquidity_cap * a if np.isfinite(a) else 0.0
                            if cap <= 0:
                                stats["replaced"] += 1
                                continue
                            if cap < value:
                                value = cap
                        vol = b.vol20[e - 1] if e >= 1 else float("nan")
                        fill = b.o[e] * (1 + EX.impact_frac(sc, value, a, vol) + EX.tick_frac(sc, day, b.o[e], "entry"))
                        if sc.integer_shares and math.floor(value / fill) <= 0:
                            stats["replaced"] += 1                   # not one share at the plan's size
                            continue
                        cands.append((rank, sym, b, e, a, vol))
                        held.add(sym)
                    ws = list(weigher(cal[i - 1], [c_[1] for c_ in cands], [c_[0] for c_ in cands])) if cands else []
                    if len(ws) != len(cands):
                        raise ValueError(f"weigher returned {len(ws)} weights for {len(cands)} picks")
                    for (rank, sym, b, e, a, vol), w in zip(cands, ws):
                        if not (w > 0):
                            stats["zero_weight"] += 1
                            continue
                        value = per * w
                        capped = False
                        if sc.liquidity_cap is not None:
                            cap = sc.liquidity_cap * a
                            if cap < value:
                                value, capped = cap, True
                        slip = EX.impact_frac(sc, value, a, vol) + EX.tick_frac(sc, day, b.o[e], "entry")
                        fill = b.o[e] * (1 + slip)
                        budget = min(value, cash / (1 + 0.0025))
                        if budget < value:
                            stats["cash_limited"] += 1
                            if sc.min_order_frac is not None and budget < sc.min_order_frac * value:
                                stats["skipped_small"] += 1
                                break
                        shares = budget / fill if not sc.integer_shares else math.floor(budget / fill)
                        if shares <= 0:
                            stats["unfilled"] += 1                   # too small for one share: stays in cash
                            continue
                        open_position(sym, b, e, a, vol, rank, shares, fill, capped, float(w), i, day)
        # ---- the day and the close: stop fills, time exits
        still = []
        for p in opened:
            if p["sell_day"] == day and p["sell_kind"] in ("stop", "close"):
                close_position(p, day, p["sell_raw"], p["sell_kind"], p["sym"] not in dp_today)
                dp_today.add(p["sym"])
            else:
                still.append(p)
        opened = still
        # ---- mark to market
        value = 0.0
        for p in opened:
            b = bars[p["sym"]]
            j = b.index.get(day)
            if j is not None:
                last_close[p["sym"]] = b.c[j]
            value += p["shares"] * last_close.get(p["sym"], p["fill"])
        equity = cash + value
        eq_rows.append((day, equity, cash, value, len(opened)))
        prev_equity = equity
    eq = pd.DataFrame(eq_rows, columns=["date", "equity", "cash", "invested", "positions"]).set_index("date")
    return {"scenario": sc, "equity": eq, "trades": pd.DataFrame(trades), "costs": cost_tot, "stats": stats,
            "open_at_end": len(opened)}


# ----------------------------------------------------------------------
# the levers
# ----------------------------------------------------------------------
def open6_exit(b: "EX.Bars", e: int, session: Optional[int] = None, search: Optional[int] = None):
    """Sell at the open of the 6th session held (entry bar e = session 1). An open locked at the lower band
    cannot sell: the first later open that is not locked (up to `search` sessions; none -> the close of the
    last one searched). No 6th session in the data -> the close of the last bar (data end)."""
    session = CFG["open6_session"] if session is None else session
    search = CFG["lock_search_sessions"] if search is None else search
    n = len(b.c)
    flags = {"locked_exit": False, "stopped": False, "data_end": False}
    x = e + session - 1
    if x >= n:
        flags["data_end"] = True
        return n - 1, "close", float(b.c[n - 1]), flags
    if not EX.lower_locked(b, x, "open"):
        return x, "open", float(b.o[x]), flags
    flags["locked_exit"] = True
    last = min(x + search, n - 1)
    for k in range(x + 1, last + 1):
        if not EX.lower_locked(b, k, "open"):
            return k, "open", float(b.o[k]), flags
    return last, "close", float(b.c[last]), flags


def open6_planner(sym, b, e, signal_day):
    return open6_exit(b, e)


def trap_lists(lists: Dict, prob: Dict, line: Optional[float] = None, top: Optional[int] = None) -> Tuple[Dict, dict]:
    """Picks in each day's top `top` with P(stuck) >= line move behind the unflagged ones (rank order kept);
    the rest of the list follows unchanged. prob: {(date, symbol): P(stuck) in %}; unknown = unflagged."""
    line = CFG["trap_line_pct"] if line is None else line
    top = CFG["trap_top"] if top is None else top
    out, moved, days = {}, 0, 0
    for d, wl in lists.items():
        dd = _day(d)
        head, tail = list(wl[:top]), list(wl[top:])
        flag = [s for s in head if prob.get((dd, s), float("nan")) >= line]
        if flag:
            fs = set(flag)
            out[d] = [s for s in head if s not in fs] + flag + tail
            moved += len(flag)
            days += 1
        else:
            out[d] = list(wl)
    return out, {"flagged_in_top": moved, "days_with_flags": days}


def agree_weights(syms: List[str], ens_top: set, w_agreed: Optional[float] = None) -> List[float]:
    """risk_screen_v1's AGREE_TILT: a pick also in ENS's top 3 gets w_agreed, the others share the rest so the
    weights sum to the pick count; all or none agreed -> equal weights."""
    w_agreed = CFG["agree_weight"] if w_agreed is None else w_agreed
    n = len(syms)
    if n == 0:
        return []
    ag = [s in ens_top for s in syms]
    k = sum(ag)
    if k == 0 or k == n:
        return [1.0] * n
    other = (n - w_agreed * k) / (n - k)
    if other < -1e-12:
        raise ValueError(f"agreement weight {w_agreed} x {k} exceeds the day's {n} slots")
    other = max(other, 0.0)
    return [float(w_agreed) if a_ else other for a_ in ag]


def make_agree_weigher(ens_lists: Dict, top: Optional[int] = None) -> Callable:
    top = CFG["agree_ens_top"] if top is None else top
    tops = {_day(d): set(v[:top]) for d, v in ens_lists.items()}
    tally = {"days": 0, "picks": 0, "agreed": 0, "tilted_days": 0, "zero_weight": 0}

    def weigher(signal_day, syms, ranks):
        w = agree_weights(syms, tops.get(_day(signal_day), set()))
        tally["days"] += 1
        tally["picks"] += len(syms)
        tally["agreed"] += sum(1 for s in syms if s in tops.get(_day(signal_day), set()))
        tally["tilted_days"] += int(any(abs(x - 1.0) > 1e-12 for x in w))
        tally["zero_weight"] += sum(1 for x in w if not (x > 0))
        return w
    weigher.tally = tally
    return weigher


def ones_weigher(signal_day, syms, ranks):
    return [1.0] * len(syms)


def book_setup(name: str, data: dict, prob: Dict) -> Tuple[Dict, Optional[Callable], Optional[Callable], dict]:
    parts = name.split("+")
    known = {"PLAN", "OPEN6", "TRAP", "AGREE"}
    if not set(parts) <= known:
        raise ValueError(f"unknown book {name}")
    lists, info = data["lists"][CFG["engine"]], {}
    if "TRAP" in parts:
        lists, info = trap_lists(lists, prob)
    planner = open6_planner if "OPEN6" in parts else None
    weigher = make_agree_weigher(data["lists"][CFG["ens"]]) if "AGREE" in parts else None
    return lists, planner, weigher, info


# ----------------------------------------------------------------------
# windows, sizing, measures
# ----------------------------------------------------------------------
def window_inputs(lists: Dict, cal: np.ndarray, first, last, tail: Optional[int] = None) -> Tuple[Dict, np.ndarray]:
    tail = CFG["calendar_tail_sessions"] if tail is None else tail
    f_, l_ = np.datetime64(first, "ns"), np.datetime64(last, "ns")
    lw = {d: v for d, v in lists.items() if f_ <= np.datetime64(d, "ns") <= l_}
    c = cal[cal >= f_]
    i_last = int(np.searchsorted(c, l_, side="right")) - 1
    return lw, c[: i_last + 1 + tail]


def worst_drawdown(eq: pd.Series) -> dict:
    """Worst drawdown of daily closing equity from its running peak (the start counts as a peak)."""
    eq = eq.dropna()
    dd = eq / eq.cummax() - 1
    if len(dd) == 0 or dd.min() >= 0:
        return {"max_dd": 0.0, "peak": None, "trough": None, "recovered": None}
    t = dd.idxmin()
    pk = eq.loc[:t].idxmax()
    after = eq.loc[t:]
    rec = after[after >= eq.loc[pk]]
    return {"max_dd": float(dd.min()), "peak": str(pd.Timestamp(pk).date()), "trough": str(pd.Timestamp(t).date()),
            "recovered": str(pd.Timestamp(rec.index[0]).date()) if len(rec) else None}


def measure(res: dict) -> dict:
    eq = res["equity"]["equity"]
    p = EX.perf(eq)
    st = res["stats"]
    n_t = st["n_trades"]
    wd = worst_drawdown(eq)
    return {"cagr": p["cagr"], "total_return": p["total_return"], "max_dd": p["max_dd"], "dd_peak": wd["peak"],
            "dd_trough": wd["trough"], "dd_recovered": wd["recovered"], "dd_sessions": p["max_dd_sessions"],
            "sharpe": p["sharpe"], "vol": p["vol"], "calmar": p["calmar"], "final_equity": p["final_equity"],
            "trades": int(n_t), "avg_trade_bp": st["sum_ret"] / n_t * 1e4 if n_t else float("nan"),
            "win_rate": st["wins"] / n_t if n_t else float("nan"), "locked_exits": int(st["locked_exits"]),
            "costs": float(sum(res["costs"].values())), "cash_limited": int(st["cash_limited"]),
            "zero_weight": int(st["zero_weight"]), "unfilled": int(st["unfilled"]), "capped": int(st["capped"]),
            "replaced": int(st["replaced"]), "open_at_end": int(res["open_at_end"]),
            "exposure": float((res["equity"]["invested"] / res["equity"]["equity"]).mean())}


def find_scale(dd_of: Callable[[float], float], grid=None, steps: Optional[int] = None,
               target: Optional[float] = None) -> Tuple[float, List[Tuple[float, float]]]:
    """f* = the largest f found whose worst drawdown (dd_of(f), a positive fraction) is no deeper than
    target: up the grid until the first f that fails, then `steps` halvings between the last that held and
    that one. A full-size book that holds keeps f* = 1 (the last grid point)."""
    grid = CFG["scale_grid"] if grid is None else grid
    steps = CFG["bisect_steps"] if steps is None else steps
    target = CFG["dd_target"] if target is None else target
    seen: List[Tuple[float, float]] = []

    def dd(f):
        v = float(dd_of(f))
        seen.append((float(f), v))
        return v
    lo, hi = 0.0, None
    for f in grid:
        if dd(f) <= target:
            lo = float(f)
        else:
            hi = float(f)
            break
    if hi is None:
        return lo, seen
    for _ in range(steps):
        mid = (lo + hi) / 2
        if dd(mid) <= target:
            lo = mid
        else:
            hi = mid
    return lo, seen


def kept_ratio(x: float, base: float) -> float:
    return float(x / base) if (np.isfinite(x) and np.isfinite(base) and base > 0) else float("nan")


# ----------------------------------------------------------------------
# robustness: paired block bootstrap, every book re-shrunk in every resample
# ----------------------------------------------------------------------
def _dd_rows(M: np.ndarray, f: np.ndarray) -> np.ndarray:
    L = np.cumsum(np.log1p(f[:, None] * M), axis=1)
    L = np.concatenate([np.zeros((len(M), 1)), L], axis=1)
    return 1.0 - np.exp((L - np.maximum.accumulate(L, axis=1)).min(axis=1))


def solve_f_rows(M: np.ndarray, target: float, steps: int) -> np.ndarray:
    """Per row: the largest f in [0, 1] whose scaled path (daily return x f) has a worst drawdown no deeper
    than target (to 2^-steps); 1 when the full-size path already holds."""
    n = len(M)
    full_ok = _dd_rows(M, np.ones(n)) <= target
    lo, hi = np.zeros(n), np.ones(n)
    for _ in range(steps):
        mid = (lo + hi) / 2
        ok = _dd_rows(M, mid) <= target
        lo = np.where(ok, mid, lo)
        hi = np.where(ok, hi, mid)
    return np.where(full_ok, 1.0, lo)


def cagr_rows(M: np.ndarray, f: np.ndarray, per_year: int) -> np.ndarray:
    return np.exp(np.log1p(f[:, None] * M).sum(axis=1) * per_year / M.shape[1]) - 1


def block_indices(n: int, B: int, block: int, seed: int, chunk: int):
    """Circular moving blocks over sessions, the project's bootstrap (research_common.block_bootstrap_mean)."""
    rng = np.random.default_rng(seed)
    nb = int(np.ceil(n / block))
    for a in range(0, B, chunk):
        bb = min(chunk, B - a)
        st = rng.integers(0, n, size=(bb, nb))
        yield ((st[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(bb, -1)[:, :n]


def bootstrap_books(R: Dict[str, np.ndarray], plan: str = "PLAN", B: Optional[int] = None,
                    block: Optional[int] = None, seed: Optional[int] = None) -> Dict[str, dict]:
    """R: book -> daily returns at full size, all on the same sessions. Paired: the same resamples for every
    book. Per resample each book is shrunk to the drawdown target again (return x f, rebalanced daily)."""
    B = CFG["boot_B"] if B is None else B
    block = CFG["boot_block"] if block is None else block
    seed = CFG["boot_seed"] if seed is None else seed
    tgt, steps, py, keep = CFG["dd_target"], CFG["boot_bisect_steps"], CFG["boot_days_per_year"], CFG["keep_cagr"]
    names = list(R)
    n = len(R[plan])
    if any(len(R[k]) != n for k in names):
        raise ValueError("bootstrap: books on different sessions")
    cf = {k: [] for k in names}
    ff = {k: [] for k in names}
    full = []
    for idx in block_indices(n, B, block, seed, CFG["boot_chunk"]):
        for k in names:
            M = R[k][idx]
            f = solve_f_rows(M, tgt, steps)
            ff[k].append(f)
            cf[k].append(cagr_rows(M, f, py))
            if k == plan:
                full.append(cagr_rows(M, np.ones(len(M)), py))
    full = np.concatenate(full)
    base = np.concatenate(cf[plan])
    valid = full > 0
    out = {}
    for k in names:
        c = np.concatenate(cf[k])
        f = np.concatenate(ff[k])
        d = c - base
        meets = c[valid] >= keep * full[valid]
        lo, hi = (float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5)))
        if k == plan:
            v = "the size cut"
        elif lo > 0:
            v = "BEATS THE SIZE CUT"
        elif hi < 0:
            v = "WORSE THAN THE SIZE CUT"
        else:
            v = "NOT SHOWN"
        out[k] = {"B": int(len(c)), "share_meets": float(meets.mean()) if valid.any() else float("nan"),
                  "excluded_plan_not_positive": int((~valid).sum()), "median_f": float(np.median(f)),
                  "median_cagr_shrunk": float(np.median(c)),
                  "median_kept": float(np.median(c[valid] / full[valid])) if valid.any() else float("nan"),
                  "vs_size_cut": {"mean": float(d.mean()), "lo": lo, "hi": hi}, "verdict": v}
    return out


def approx_on_path(r: np.ndarray, r_plan: np.ndarray) -> dict:
    """The bootstrap's approximation applied to the real path: scaled-returns f* and CAGR kept."""
    tgt, steps, py = CFG["dd_target"], CFG["boot_bisect_steps"], CFG["boot_days_per_year"]
    M, P = r[None, :], r_plan[None, :]
    f = solve_f_rows(M, tgt, steps)
    c = cagr_rows(M, f, py)[0]
    base = cagr_rows(P, np.ones(1), py)[0]
    return {"f": float(f[0]), "cagr_shrunk": float(c), "kept": kept_ratio(c, base)}


# ----------------------------------------------------------------------
# integrity
# ----------------------------------------------------------------------
def _same_frame(a: pd.DataFrame, b: pd.DataFrame, cols) -> Tuple[bool, str]:
    if len(a) != len(b):
        return False, f"{len(a)} vs {len(b)} rows"
    for c in cols:
        if c not in a or c not in b:
            return False, f"column {c} missing"
        x, y = a[c].to_numpy(), b[c].to_numpy()
        if x.dtype.kind in "fc" or y.dtype.kind in "fc":
            xx, yy = np.asarray(x, float), np.asarray(y, float)
            same = (xx == yy) | (np.isnan(xx) & np.isnan(yy))
        else:
            same = x == y
        if not np.all(same):
            k = int(np.argmin(same))
            return False, f"column {c} differs first at row {k} ({x[k]!r} vs {y[k]!r})"
    return True, "identical"


def same_run(a: dict, b: dict) -> Tuple[bool, str]:
    """Two simulator results identical: every day's equity book and every trade (stage E's columns)."""
    ok, why = _same_frame(a["equity"].reset_index(), b["equity"].reset_index(),
                          ["date", "equity", "cash", "invested", "positions"])
    if not ok:
        return False, "equity: " + why
    if len(a["trades"]) or len(b["trades"]):
        ok, why = _same_frame(a["trades"], b["trades"], EX_TRADE_COLS)
        if not ok:
            return False, "trades: " + why
    if any(a["costs"][k] != b["costs"][k] for k in a["costs"]):
        return False, "costs differ"
    if any(a["stats"][k] != b["stats"][k] for k in EX_STAT_KEYS):
        return False, "counters differ"
    return True, f"identical ({len(a['equity']):,} days, {len(a['trades']):,} trades)"


def exec_reproduction(tr: pd.DataFrame, eq: pd.Series, ex_trades: pd.DataFrame, ex_equity: pd.Series,
                      tol: Optional[float] = None) -> dict:
    """How much of the execution backtest's trade list the replay's whole-history PLAN reproduces: same
    signal day, symbol, entry day, exit day, exit kind, and price return within tol."""
    tol = CFG["exec_price_tol"] if tol is None else tol
    key = ["signal_day", "symbol"]
    A = ex_trades.copy()
    X = tr.copy()
    for T in (A, X):
        for c in ("signal_day", "entry_day", "exit_day"):
            T[c] = pd.to_datetime(T[c]).dt.normalize()
        T["symbol"] = T["symbol"].astype(str)
        T["exit_kind"] = T["exit_kind"].astype(str)
    m = A[key + ["entry_day", "exit_day", "exit_kind", "raw_ret"]].merge(
        X[key + ["entry_day", "exit_day", "exit_kind", "raw_ret"]], on=key, how="left", suffixes=("_e", "_x"))
    ok = ((m["entry_day_e"] == m["entry_day_x"]) & (m["exit_day_e"] == m["exit_day_x"])
          & (m["exit_kind_e"] == m["exit_kind_x"])
          & ((m["raw_ret_e"].astype(float) - m["raw_ret_x"].astype(float)).abs() <= tol))
    ok = ok.fillna(False).astype(bool)
    e1 = ex_equity.copy()
    e1.index = pd.to_datetime(e1.index).normalize()
    e2 = eq.copy()
    e2.index = pd.to_datetime(e2.index).normalize()
    common = e1.index.intersection(e2.index)
    diff = ((e1.loc[common] - e2.loc[common]).abs() > 1e-9 * e1.loc[common].abs().clip(lower=1.0))
    first = str(common[np.argmax(diff.to_numpy())].date()) if diff.any() else None
    bad = m.loc[~ok, key].head(10)
    return {"exec_trades": int(len(A)), "replay_trades": int(len(X)), "matched": int(ok.sum()),
            "share": float(ok.mean()) if len(ok) else float("nan"), "common_days": int(len(common)),
            "equity_first_difference": first, "examples_not_matched": [
                f"{pd.Timestamp(r.signal_day).date()} {r.symbol}" for r in bad.itertuples()]}


# ----------------------------------------------------------------------
# inputs
# ----------------------------------------------------------------------
def load_forecasts(path: Path, engine: str) -> Tuple[Dict, np.datetime64, np.datetime64, int]:
    P = pd.read_csv(path, usecols=["engine", "signal_day", "symbol", "rank", "prob_trap"])
    P = P[P["engine"].astype(str) == engine]
    if P.empty:
        raise PreconditionError(f"{path} holds no rows for engine {engine}")
    d = pd.to_datetime(P["signal_day"]).dt.normalize()
    prob = {(_day(t), str(s)): float(v) for t, s, v in zip(d, P["symbol"].astype(str), P["prob_trap"].astype(float))}
    return prob, _day(d.min()), _day(d.max()), int(d.nunique())


def forecast_coverage(trades: pd.DataFrame, prob: Dict) -> float:
    if trades.empty:
        return float("nan")
    keys = [(_day(t), str(s)) for t, s in zip(trades["signal_day"], trades["symbol"])]
    return float(np.mean([k in prob for k in keys]))


def top_coverage(lists: Dict, prob: Dict, first, last, top: int) -> float:
    hit = tot = 0
    for d, wl in lists.items():
        dd = _day(d)
        if _day(first) <= dd <= _day(last):
            for s in wl[:top]:
                tot += 1
                hit += int((dd, s) in prob)
    return hit / tot if tot else float("nan")


def stage_e_preconditions(pp: Path) -> Tuple[dict, str]:
    """The checks stage E's main() makes before it simulates: manifest, panel, frozen engines, its own
    declaration."""
    man_, man_sha = EX.SB.load_manifest()
    EX.SB.check_panel(pp, man_sha)
    man = EX.FZ.verify_frozen(pp)
    _, sha_e = EX.load_declaration()
    return man, sha_e


def prepare_data(pp: Path, root: Path, man: dict, isin) -> dict:
    return EX.prepare(pp, root, man, isin)


def find_exec_run(pp: Path, run: Optional[str]) -> Tuple[str, Path]:
    runs = [e for e in RC.ledger_entries(pp) if e.get("kind") == "stage_e_run"]
    if not runs:
        raise PreconditionError(f"no execution backtest (stage_e_run) in {RC.ledger_path(pp)}")
    rid = run or runs[-1].get("run_id")
    if rid not in {e.get("run_id") for e in runs}:
        raise PreconditionError(f"{rid} is not an execution backtest in {RC.ledger_path(pp)}")
    folder = pp.parent / "stage_e" / rid
    for f in ("equity_primary.csv", "trades_primary.csv", "stats.json"):
        if not (folder / f).exists():
            raise PreconditionError(f"{folder / f} is missing")
    return rid, folder


def find_pm_run(root: Path, run: Optional[str]) -> Tuple[str, Path]:
    base = Path(root) / PM_SUB
    if run:
        f = base / run / "predictions_oos.csv"
        if not f.exists():
            raise PreconditionError(f"{f} not found")
        return run, f
    c = sorted(p for p in base.glob("PM_????????_???") if (p / "predictions_oos.csv").exists())
    if not c:
        raise PreconditionError(f"no pick_meta research run with predictions_oos.csv under {base}")
    return c[-1].name, c[-1] / "predictions_oos.csv"


def read_exec(folder: Path) -> Tuple[pd.DataFrame, pd.Series, dict]:
    tr = pd.read_csv(folder / "trades_primary.csv")
    eq = pd.read_csv(folder / "equity_primary.csv", index_col=0, parse_dates=True)["equity"]
    st = json.loads((folder / "stats.json").read_text(encoding="utf-8"))
    return tr, eq, st


# ----------------------------------------------------------------------
# the replay
# ----------------------------------------------------------------------
def check_integrity(data: dict, prob: Dict, win_a: Tuple, exec_in: Optional[Tuple], say=lambda m: None) -> Tuple[dict, dict]:
    """The three safety stops. Returns (integrity report, runs already made that the books reuse)."""
    P0 = EX.primary_scenario()
    D = data["lists"][CFG["engine"]]
    integ = {}
    # ---- 1: the copy is stage E's simulator
    ex_plan = EX.simulate(P0, D, data["bars"], data["adv"], data["cal"])
    x_plan = simulate_x(P0, D, data["bars"], data["adv"], data["cal"])
    ok1, why1 = same_run(ex_plan, x_plan)
    ex_o6 = EX.simulate(P0, D, data["bars"], data["adv"], data["cal"], exit_planner=open6_planner)
    x_o6 = simulate_x(P0, D, data["bars"], data["adv"], data["cal"], exit_planner=open6_planner)
    ok2, why2 = same_run(ex_o6, x_o6)
    la, ca = window_inputs(D, data["cal"], win_a[0], win_a[1])
    fw = CFG["check_weighted_scale"]
    w0 = simulate_x(P0, la, data["bars"], data["adv"], ca, scale=fw)
    w1 = simulate_x(P0, la, data["bars"], data["adv"], ca, scale=fw, weigher=ones_weigher)
    ok3, why3 = same_run(w0, w1)
    integ["simulator"] = {"plan_whole_history": why1, "open6_whole_history": why2,
                          f"weights_all_1_at_f_{fw}": why3, "ok": bool(ok1 and ok2 and ok3)}
    say(f"integrity 1 - simulator copy = stage E: PLAN {why1}; OPEN6 {why2}; weights 1 at f={fw}: {why3}")
    if not integ["simulator"]["ok"]:
        raise ReconciliationError("integrity 1 FAILED - the replay's simulator does not reproduce stage E's: "
                                  + "; ".join(w for ok, w in ((ok1, why1), (ok2, why2), (ok3, why3)) if not ok))
    # ---- 2: the execution backtest
    if exec_in is not None:
        etr, eeq, est = exec_in
        rep = exec_reproduction(x_plan["trades"], x_plan["equity"]["equity"], etr, eeq)
        mp = measure(x_plan)
        rep.update({"replay_cagr": mp["cagr"], "replay_max_dd": mp["max_dd"],
                    "exec_cagr": float(est.get("primary", {}).get("cagr", float("nan"))),
                    "exec_max_dd": float(est.get("primary", {}).get("max_dd", float("nan"))),
                    "exec_etf_rule": est.get("etf_rule"), "replay_etf_rule": data.get("etf_note")})
        rep["ok"] = bool(np.isfinite(rep["share"]) and rep["share"] >= CFG["min_exec_trade_match"])
        integ["execution_backtest"] = rep
        say(f"integrity 2 - execution backtest: {rep['matched']:,} of {rep['exec_trades']:,} trades reproduced "
            f"({rep['share']:.2%}); equity identical until {rep['equity_first_difference'] or 'the end'}; CAGR "
            f"{_p(rep['replay_cagr'], 2)} vs {_p(rep['exec_cagr'], 2)}, worst drawdown "
            f"{_p(rep['replay_max_dd'], 2)} vs {_p(rep['exec_max_dd'], 2)}")
        if not rep["ok"]:
            raise ReconciliationError(
                f"integrity 2 FAILED - the replay reproduces {rep['share']:.2%} of the execution backtest's trades "
                f"(need {CFG['min_exec_trade_match']:.1%}). ETF rule then: {rep['exec_etf_rule']}; now: "
                f"{rep['replay_etf_rule']} (pass the same --isin file(s) as that run). Not matched, e.g.: "
                + ", ".join(rep["examples_not_matched"]))
    else:
        integ["execution_backtest"] = {"skipped": True}
    # ---- 3: P(stuck) coverage in window A
    pa = simulate_x(P0, la, data["bars"], data["adv"], ca)
    cov = forecast_coverage(pa["trades"], prob)
    integ["forecast_coverage"] = {"plan_picks": cov,
                                  "top10_entries": top_coverage(D, prob, win_a[0], win_a[1], CFG["trap_top"]),
                                  "ok": bool(np.isfinite(cov) and cov >= CFG["min_forecast_coverage"])}
    say(f"integrity 3 - P(stuck) forecasts for {cov:.2%} of the plan's window-A picks "
        f"({integ['forecast_coverage']['top10_entries']:.2%} of top-10 entries)")
    if not integ["forecast_coverage"]["ok"]:
        raise ReconciliationError(f"integrity 3 FAILED - only {cov:.2%} of the plan's window-A picks have a P(stuck) "
                                  f"forecast (need {CFG['min_forecast_coverage']:.1%})")
    return integ, {("A", "PLAN", 1.0): pa, ("B", "PLAN", 1.0): x_plan, ("B", "OPEN6", 1.0): x_o6}


def evaluate_books(data: dict, prob: Dict, wk: str, window: Optional[Tuple], names: List[str],
                   cache: Optional[dict] = None, say=lambda m: None) -> Tuple[Dict[str, dict], List[dict]]:
    """Each book: full size, then f* (the largest f whose worst drawdown is no deeper than the target), then
    the run at f* with its trades. window None = the whole history on stage E's own calendar."""
    P0 = EX.primary_scenario()
    cache = {} if cache is None else cache
    t0 = time.perf_counter()
    books, sizing_rows = {}, []
    for name in names:
        lists, planner, _, info = book_setup(name, data, prob)
        lw, cw = (window_inputs(lists, data["cal"], window[0], window[1]) if window is not None
                  else (lists, data["cal"]))
        agree = "AGREE" in name.split("+")

        def run(f, keep=False, _lw=lw, _cw=cw, _pl=planner, _agree=agree):
            wg = make_agree_weigher(data["lists"][CFG["ens"]]) if _agree else None
            r = simulate_x(P0, _lw, data["bars"], data["adv"], _cw, keep_trades=keep, exit_planner=_pl,
                           scale=f, weigher=wg)
            if wg is not None:
                r["agree_tally"] = dict(wg.tally)
            return r
        full = cache.get((wk, name, 1.0))
        if full is None:
            full = run(1.0, keep=True)
        mf = measure(full)

        def dd_of(f, _run=run, _name=name):
            m = measure(_run(f))
            sizing_rows.append({"window": wk, "book": _name, "f": float(f), "cagr": m["cagr"], "max_dd": m["max_dd"],
                                "trades": m["trades"]})
            return -m["max_dd"]
        fstar, seen = find_scale(dd_of)
        if fstar >= 1.0:
            rs = full
        elif fstar <= 0.0:
            rs = None
        else:
            rs = run(fstar, keep=True)
        if rs is not None:
            ms = measure(rs)
        else:
            ms = {k: (0.0 if k in ("cagr", "total_return", "max_dd") else float("nan")) for k in mf}
        srt = sorted(seen)
        books[name] = {"full": mf, "f": float(fstar), "shrunk": ms, "res_full": full, "res_shrunk": rs,
                       "monotone": bool(all(b_[1] >= a_[1] - 1e-12 for a_, b_ in zip(srt, srt[1:]))),
                       "evaluations": len(seen), "info": info, "agree": full.get("agree_tally")}
        say(f"window {wk} {name:<17} full size CAGR {_p(mf['cagr'])} worst DD {_p(mf['max_dd'])} | f* {fstar:.3f}: "
            f"CAGR {_p(ms['cagr'])} worst DD {_p(ms['max_dd'])} ({len(seen)} runs, {time.perf_counter() - t0:.0f}s)")
    return books, sizing_rows


def judge(books: Dict[str, dict]) -> None:
    base = books["PLAN"]["full"]
    for bk in books.values():
        bk["kept_cagr"] = kept_ratio(bk["shrunk"]["cagr"], base["cagr"])
        bk["kept_total"] = kept_ratio(bk["shrunk"]["total_return"], base["total_return"])
        if not (np.isfinite(base["cagr"]) and base["cagr"] > 0):
            bk["verdict"] = "NO BASE"
        else:
            bk["verdict"] = "MEETS" if bk["kept_cagr"] >= CFG["keep_cagr"] else "MISSES"


def robustness(books: Dict[str, dict], B: Optional[int] = None) -> Dict[str, dict]:
    R = {name: bk["res_full"]["equity"]["equity"].pct_change().dropna().to_numpy() for name, bk in books.items()}
    boot = bootstrap_books(R, B=B)
    for name, bk in books.items():
        bk["approx_on_path"] = approx_on_path(R[name], R["PLAN"])
    return boot


def replay(data: dict, prob: Dict, win_a: Tuple, exec_in: Optional[Tuple], verbose: bool = True,
           B: Optional[int] = None) -> dict:
    """Integrity, then every book in both windows, then the bootstrap. exec_in = (trades, equity, stats) of
    the execution backtest, or None to skip integrity 2 (tests only)."""
    t0 = time.perf_counter()
    say = _log if verbose else (lambda m: None)
    integ, cache = check_integrity(data, prob, win_a, exec_in, say)
    D = data["lists"][CFG["engine"]]
    days = sorted(D)
    books, sizing, boot = {}, [], {}
    for wk, window, names in (("A", win_a, CFG["books"]), ("B", None, CFG["books_whole_history"])):
        books[wk], rows = evaluate_books(data, prob, wk, window, names, cache, say)
        sizing += rows
        judge(books[wk])
        boot[wk] = robustness(books[wk], B)
        say(f"window {wk} bootstrap done ({time.perf_counter() - t0:.0f}s)")
    la, _ = window_inputs(D, data["cal"], win_a[0], win_a[1])
    return {"books": books, "boot": boot, "integrity": integ, "sizing": pd.DataFrame(sizing),
            "windows": {"A": [str(pd.Timestamp(win_a[0]).date()), str(pd.Timestamp(win_a[1]).date())],
                        "B": [str(pd.Timestamp(days[0]).date()), str(pd.Timestamp(days[-1]).date())]},
            "signal_days": {"A": int(len(la)), "B": int(len(D))}, "seconds": round(time.perf_counter() - t0, 1)}


# ----------------------------------------------------------------------
# output
# ----------------------------------------------------------------------
def _p(x, d=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:+.{d}f}%"


def _pc(x) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:.0f}%"


def _f(x, d=3) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x:.{d}f}"


def _iv(b, d=1) -> str:
    return f"{b['mean'] * 100:+.{d}f} [{b['lo'] * 100:+.{d}f}, {b['hi'] * 100:+.{d}f}] pts"


def books_table(R: dict) -> pd.DataFrame:
    rows = []
    for wk, bks in R["books"].items():
        for name, bk in bks.items():
            bt = R["boot"][wk][name]
            row = {"window": wk, "book": name, "verdict": bk["verdict"], "f_star": bk["f"],
                   "kept_cagr": bk["kept_cagr"], "kept_total_gain": bk["kept_total"],
                   "boot_share_meets": bt["share_meets"], "boot_vs_size_cut_mean": bt["vs_size_cut"]["mean"],
                   "boot_vs_size_cut_lo": bt["vs_size_cut"]["lo"], "boot_vs_size_cut_hi": bt["vs_size_cut"]["hi"],
                   "boot_verdict": bt["verdict"], "approx_f": bk["approx_on_path"]["f"],
                   "approx_kept": bk["approx_on_path"]["kept"], "monotone": bk["monotone"]}
            for tag in ("full", "shrunk"):
                for k, v in bk[tag].items():
                    row[f"{tag}_{k}"] = v
            rows.append(row)
    return pd.DataFrame(rows)


def write_report(path: Path, R: dict, meta: dict) -> None:
    A, B = R["books"]["A"], R["books"]["B"]
    pa = A["PLAN"]
    need = CFG["keep_cagr"] * pa["full"]["cagr"]
    L = ["# Drawdown replay - " + meta["run_id"], "",
         f"{CODE_VERSION} | declaration {meta['declaration_sha']} | {EX.CODE_VERSION} (declaration "
         f"{meta['stage_e_declaration_sha']}) | D = {meta['frozen'].get('D')}, ENS = {meta['frozen'].get('ENS')} | "
         f"execution backtest {meta['exec_run']} | P(stuck) from {meta['pm_run']} | ETFs {meta['etf_rule']} | "
         f"{meta['when']}", "",
         "**Read this first.** The rules were fixed before this ran (DD_REPLAY_DECLARATION.json). It runs on the same "
         "history the levers were found on: a MEETS earns a shadow lane in the forward paper test, never money. "
         "Eight books are judged, so one can pass by luck.", "",
         f"## 1. The answer - window A, signal days {R['windows']['A'][0]} .. {R['windows']['A'][1]} "
         f"({R['signal_days']['A']:,} days), Rs 10 lakh", "",
         f"The plan at full size: CAGR {_p(pa['full']['cagr'])}, worst drawdown {_p(pa['full']['max_dd'])} "
         f"(peak {pa['full']['dd_peak']}, trough {pa['full']['dd_trough']}, "
         f"{'recovered ' + pa['full']['dd_recovered'] if pa['full']['dd_recovered'] else 'not recovered by the end'}). "
         f"Target: worst drawdown no deeper than -25% with CAGR at least 0.70 x {_p(pa['full']['cagr'])} = {_p(need)}.", "",
         "| book | full size: CAGR / worst DD | shrunk: f | CAGR / worst DD | CAGR kept | total gain kept | VERDICT | "
         "vs the size cut, CAGR pts [95%] | histories that meet |",
         "|---|---|---|---|---|---|---|---|---|"]
    for name in CFG["books"]:
        bk, bt = A[name], R["boot"]["A"][name]
        vs = "(this is the size cut)" if name == "PLAN" else f"{_iv(bt['vs_size_cut'])} {bt['verdict']}"
        L.append(f"| {name} | {_p(bk['full']['cagr'])} / {_p(bk['full']['max_dd'])} | {_f(bk['f'])} | "
                 f"{_p(bk['shrunk']['cagr'])} / {_p(bk['shrunk']['max_dd'])} | {_f(bk['kept_cagr'], 3)} | "
                 f"{_f(bk['kept_total'], 3)} | **{bk['verdict']}** | {vs} | {_pc(bt['share_meets'])} |")
    meets = [n for n in CFG["books"] if A[n]["verdict"] == "MEETS"]
    L += ["", f"- The pure size cut (the plan at f = {_f(pa['f'])}) keeps {_f(pa['kept_cagr'], 3)} of the CAGR: "
              "the price of -25% without any lever.",
          f"- f is the size: at f = {_f(pa['f'])} each new position gets {_f(pa['f'])} x 1/15 = "
          f"{pa['f'] / 15 * 100:.1f}% of equity instead of the plan's {100 / 15:.1f}%; the rest stays in cash.",
          "- Books that MEET: " + (", ".join(meets) if meets else "none") + ".",
          "- 'vs the size cut' = the book's shrunk CAGR minus the plan's shrunk CAGR across 2,000 resampled "
          "histories (each book re-shrunk in each); 'histories that meet' = the share of those histories in which "
          "the book keeps 70% of the plan's CAGR at -25%.", "",
          "## 2. What each lever does at full size (window A)", "",
          "| book | CAGR | worst DD | peak -> trough (recovered) | Sharpe | trades | avg trade bp | win | locked exits "
          "| costs | cash-limited | weight-0 slots |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for name in CFG["books"]:
        m = A[name]["full"]
        L.append(f"| {name} | {_p(m['cagr'])} | {_p(m['max_dd'])} | {m['dd_peak']} -> {m['dd_trough']} "
                 f"({m['dd_recovered'] or 'no'}) | {_f(m['sharpe'], 2)} | {m['trades']:,} | {m['avg_trade_bp']:+.1f} | "
                 f"{m['win_rate']:.1%} | {m['locked_exits']:,} | Rs {m['costs']:,.0f} | {m['cash_limited']:,} | "
                 f"{m['zero_weight']:,} |")
    for name in CFG["books"]:
        inf = A[name]["info"]
        if inf:
            L.append(f"\n{name}: {inf['flagged_in_top']:,} top-10 entries flagged on {inf['days_with_flags']:,} days moved back.")
        ag = A[name].get("agree")
        if ag:
            L.append(f"\n{name}: {ag['agreed']:,} of {ag['picks']:,} chosen picks also in ENS's top 3; {ag['tilted_days']:,} "
                     f"days re-sized; {ag['zero_weight']:,} weight-0 slots.")
    L += ["", f"## 3. The whole history - DESCRIPTIVE ({R['windows']['B'][0]} .. {R['windows']['B'][1]}, "
              f"{R['signal_days']['B']:,} signal days; no P(stuck) before 2022, so no TRAP)", "",
          "| book | full size: CAGR / worst DD (peak -> trough) | shrunk: f | CAGR / worst DD | CAGR kept | "
          "vs the size cut [95%] | histories that meet |", "|---|---|---|---|---|---|---|"]
    for name in CFG["books_whole_history"]:
        bk, bt = B[name], R["boot"]["B"][name]
        vs = "(the size cut)" if name == "PLAN" else f"{_iv(bt['vs_size_cut'])} {bt['verdict']}"
        L.append(f"| {name} | {_p(bk['full']['cagr'])} / {_p(bk['full']['max_dd'])} ({bk['full']['dd_peak']} -> "
                 f"{bk['full']['dd_trough']}) | {_f(bk['f'])} | {_p(bk['shrunk']['cagr'])} / {_p(bk['shrunk']['max_dd'])} | "
                 f"{_f(bk['kept_cagr'], 3)} ({bk['verdict']}, descriptive) | {vs} | {_pc(bt['share_meets'])} |")
    L += ["", "## 4. Robustness detail", "",
          "| window | book | median f* | median CAGR shrunk | median CAGR kept | histories left out (plan CAGR <= 0) | "
          "real path: f* simulator / scaled returns | CAGR kept simulator / scaled returns |",
          "|---|---|---|---|---|---|---|---|"]
    for wk in ("A", "B"):
        for name, bk in R["books"][wk].items():
            bt = R["boot"][wk][name]
            ap = bk["approx_on_path"]
            L.append(f"| {wk} | {name} | {_f(bt['median_f'])} | {_p(bt['median_cagr_shrunk'])} | {_f(bt['median_kept'], 3)} | "
                     f"{bt['excluded_plan_not_positive']:,} | {_f(bk['f'])} / {_f(ap['f'])} | {_f(bk['kept_cagr'], 3)} / "
                     f"{_f(ap['kept'], 3)} |")
    I = R["integrity"]
    e2 = I["execution_backtest"]
    L += ["", "## 5. Integrity (all must pass before any book)", "",
          f"1. Simulator copy = stage E's simulate(): PLAN whole history {I['simulator']['plan_whole_history']}; OPEN6 "
          f"{I['simulator']['open6_whole_history']}; weights all 1 at f = {CFG['check_weighted_scale']}: "
          f"{I['simulator']['weights_all_1_at_f_' + str(CFG['check_weighted_scale'])]}."]
    if not e2.get("skipped"):
        L.append(f"2. Execution backtest {meta['exec_run']}: {e2['matched']:,} of {e2['exec_trades']:,} trades reproduced "
                 f"({e2['share']:.2%}); equity identical on every common day until "
                 f"{e2['equity_first_difference'] or 'the end'}; CAGR {_p(e2['replay_cagr'], 2)} now vs "
                 f"{_p(e2['exec_cagr'], 2)} then; worst drawdown {_p(e2['replay_max_dd'], 2)} vs {_p(e2['exec_max_dd'], 2)}.")
    cv = I["forecast_coverage"]
    L += [f"3. P(stuck) forecasts for {cv['plan_picks']:.2%} of the plan's window-A picks ({cv['top10_entries']:.2%} of "
          "D's top-10 entries).", "",
          f"Sizing: {len(R['sizing']):,} simulator runs (sizing.csv). A drawdown that did not rise with f on the points "
          "tried: " + (", ".join(f"{wk}:{n}" for wk in R['books'] for n, bk in R['books'][wk].items()
                                 if not bk['monotone']) or "none") + ".", "",
          "## 6. What this does not say", "",
          "- It is not new evidence: OPEN6, TRAP and AGREE were all found on these years. The forward paper ledger decides.",
          "- The worst drawdown is one path's worst episode; read the bootstrap columns before trusting a MEETS.",
          "- The bootstrap shrinks a book by scaling its daily returns (no fixed DP charge, impact or share rounding at "
          "the smaller size); section 4 shows how close that is to the simulator on the real path.",
          "- As stage E: no survivorship correction, no trade-for-trade or surveillance restrictions, no taxes; fills at "
          "the opening auction and the closing price are assumed.", ""]
    path.write_text("\n".join(L), encoding="utf-8")


def write_outputs(R: dict, out: Path, meta: dict) -> dict:
    T = books_table(R)
    T.to_csv(out / "books.csv", index=False)
    R["sizing"].to_csv(out / "sizing.csv", index=False)
    eqs = {}
    for wk in R["books"]:
        for name, bk in R["books"][wk].items():
            if bk["res_shrunk"] is not None:
                eqs[f"{wk}_{name}"] = bk["res_shrunk"]["equity"]["equity"]
    pd.DataFrame(eqs).to_csv(out / "equity.csv")
    tr = [bk["res_shrunk"]["trades"].assign(book=name) for name, bk in R["books"]["A"].items()
          if bk["res_shrunk"] is not None and len(bk["res_shrunk"]["trades"])]
    (pd.concat(tr, ignore_index=True) if tr else pd.DataFrame()).to_csv(out / "trades.csv", index=False)
    rows = [{"window": wk, "book": name, **{k: v for k, v in bt.items() if k != "vs_size_cut"},
             "vs_size_cut_mean": bt["vs_size_cut"]["mean"], "vs_size_cut_lo": bt["vs_size_cut"]["lo"],
             "vs_size_cut_hi": bt["vs_size_cut"]["hi"]} for wk in R["boot"] for name, bt in R["boot"][wk].items()]
    pd.DataFrame(rows).to_csv(out / "bootstrap.csv", index=False)
    summ = {"tool": CODE_VERSION, **meta, "config": CFG, "windows": R["windows"], "signal_days": R["signal_days"],
            "integrity": R["integrity"], "seconds": R["seconds"],
            "books": {wk: {name: {k: v for k, v in bk.items() if k not in ("res_full", "res_shrunk")}
                           for name, bk in R["books"][wk].items()} for wk in R["books"]},
            "bootstrap": R["boot"],
            "versions": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__}}
    (out / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
    write_report(out / "report.md", R, meta)
    return summ


def _new_run_dir(base: Path) -> Tuple[str, Path]:
    day = dt.date.today().strftime("%Y%m%d")
    k = 1
    while (base / f"DR_{day}_{k:03d}").exists():
        k += 1
    rid = f"DR_{day}_{k:03d}"
    (base / rid).mkdir(parents=True)
    return rid, base / rid


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Drawdown replay of the levers in stage E's simulator (dd_replay_v1)")
    ap.add_argument("--panel", required=True, help="stage E's panel folder, e.g. %%CACHE_DAILY_ROOT%%\\panel_oc")
    ap.add_argument("--root", required=True, help="the data root, e.g. %%CACHE_DAILY_ROOT%%")
    ap.add_argument("--isin", nargs="+", default=None, help="the NSE bhavcopy file(s) the execution backtest used, if any")
    ap.add_argument("--pm-run", default=None, help="pick_meta research run PM_... (default: the latest)")
    ap.add_argument("--exec-run", default=None, help="the execution backtest EXEC_... (default: the latest stage_e_run)")
    ap.add_argument("--rerun-reason", default=None)
    a = ap.parse_args(argv)
    root = Path(a.root)
    pp = Path(a.panel) / "panel.parquet"
    ledger_pp = root / "panel" / "panel.parquet"
    if not ledger_pp.parent.is_dir():
        raise PreconditionError(f"{ledger_pp.parent} not found: --root must be the data root that holds panel\\ "
                                f"(the research ledger) and research2\\")
    decl, sha = load_declaration()
    man, sha_e = stage_e_preconditions(pp)
    exec_run, exec_dir = find_exec_run(pp, a.exec_run)
    pm_run, pm_file = find_pm_run(root, a.pm_run)
    prior = [e for e in RC.ledger_entries(ledger_pp) if e.get("kind") == "dd_replay_run"]
    if prior and not a.rerun_reason:
        raise PreconditionError(f"the drawdown replay already ran ({prior[-1].get('run_id')}); a re-run needs "
                                f"--rerun-reason \"...\" (a verified bug) and goes into the ledger")
    exec_in = read_exec(exec_dir)
    then = str(exec_in[2].get("etf_rule") or "")
    if then and ("ISIN" in then) != bool(a.isin):
        raise PreconditionError(f"{exec_run} dropped ETFs {then}; this run would drop them "
                                f"{'by ISIN' if a.isin else 'by the name rule'} - pass the same --isin file(s) as that run "
                                f"(or none), or the plan cannot be reproduced")
    prob, f_a, l_a, n_a = load_forecasts(pm_file, CFG["engine"])
    hashes = {"predictions_oos.csv": _sha(pm_file), **{f: _sha(exec_dir / f) for f in
                                                         ("equity_primary.csv", "trades_primary.csv", "stats.json")},
              "stage_e_execution.py": _sha(Path(EX.__file__)), "dd_replay.py": _sha(Path(__file__))}
    run_id, out = _new_run_dir(root / OUT_SUB)
    n = RC.ledger_append(ledger_pp, {"kind": "dd_replay_declared", "tool": CODE_VERSION, "family": FAMILY,
                                     "run_id": run_id, "declaration_sha": sha, "stage_e_declaration_sha": sha_e,
                                     "exec_run": exec_run, "pm_run": pm_run, "inputs_sha": hashes,
                                     "frozen": {k: v["run"] for k, v in man["engines"].items()},
                                     "rerun_reason": a.rerun_reason})
    print("=" * 78)
    print(f"{CODE_VERSION} | {run_id} | declaration {sha} | {EX.CODE_VERSION} | frozen D {man['engines']['D']['run']}, "
          f"ENS {man['engines']['ENS']['run']}")
    print(f"execution backtest {exec_run} | P(stuck) from {pm_run} ({n_a:,} signal days {pd.Timestamp(f_a).date()} .. "
          f"{pd.Timestamp(l_a).date()})")
    print("Rules fixed in advance: 8 books, each shrunk until its worst drawdown is -25%; MEETS if it keeps 70% of the")
    print("plan's CAGR. Same history the levers were found on - descriptive, not new evidence.")
    print("=" * 78)
    data = prepare_data(pp, root, man, a.isin)
    R = replay(data, prob, (f_a, l_a), exec_in)
    meta = {"run_id": run_id, "declaration_sha": sha, "stage_e_declaration_sha": sha_e, "exec_run": exec_run,
            "pm_run": pm_run, "inputs_sha": hashes, "etf_rule": data.get("etf_note"),
            "frozen": {k: v["run"] for k, v in man["engines"].items()}, "when": f"{dt.datetime.now():%Y-%m-%d %H:%M}",
            "rerun_reason": a.rerun_reason, "ledger_declared_entry": n}
    write_outputs(R, out, meta)
    A = R["books"]["A"]
    verdicts = {name: A[name]["verdict"] for name in CFG["books"]}
    n2 = RC.ledger_append(ledger_pp, {"kind": "dd_replay_run", "tool": CODE_VERSION, "family": FAMILY, "run_id": run_id,
                                      "declaration_sha": sha, "verdicts": verdicts,
                                      "kept_cagr": {k: A[k]["kept_cagr"] for k in CFG["books"]},
                                      "f_star": {k: A[k]["f"] for k in CFG["books"]},
                                      "plan_full": {"cagr": A["PLAN"]["full"]["cagr"], "max_dd": A["PLAN"]["full"]["max_dd"]},
                                      "boot": {k: R["boot"]["A"][k]["verdict"] for k in CFG["books"]},
                                      "rerun_reason": a.rerun_reason})
    pa = A["PLAN"]
    print()
    print(f"WINDOW A {R['windows']['A'][0]} .. {R['windows']['A'][1]}: the plan at full size CAGR {_p(pa['full']['cagr'])}, "
          f"worst drawdown {_p(pa['full']['max_dd'])}; target CAGR >= {_p(CFG['keep_cagr'] * pa['full']['cagr'])} at -25%")
    print(f"{'book':<18}{'full CAGR / DD':>18}{'f*':>8}{'shrunk CAGR / DD':>20}{'kept':>8}  {'verdict':<8}"
          f"{'vs the size cut [95%]':>36}{'meet':>7}")
    for name in CFG["books"]:
        bk, bt = A[name], R["boot"]["A"][name]
        vs = "(the size cut)" if name == "PLAN" else _iv(bt["vs_size_cut"])
        print(f"{name:<18}{_p(bk['full']['cagr']) + ' / ' + _p(bk['full']['max_dd']):>18}{_f(bk['f']):>8}"
              f"{_p(bk['shrunk']['cagr']) + ' / ' + _p(bk['shrunk']['max_dd']):>20}{_f(bk['kept_cagr']):>8}  "
              f"{bk['verdict']:<8}{vs:>36}{_pc(bt['share_meets']):>7}")
    meets = [k for k, v in verdicts.items() if v == "MEETS"]
    print(f"\n  books that MEET: {', '.join(meets) if meets else 'none'}")
    print(f"  outputs: {out}\n  research ledger: entries {n} (declared) and {n2} (dd_replay_run {run_id})")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
