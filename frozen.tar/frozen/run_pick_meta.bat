@echo off
REM run_pick_meta.bat v1 - after Run Now, before 09:00: magnitude watchlist for the latest recorded paper
REM watchlist (pick_meta publish), then the forward magnitude tracker (pick_meta score). Writes only
REM %CACHE_DAILY_ROOT%\research2\pick_meta\forward\ - never touches the paper test.
setlocal
set "BD=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
call "%BD%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :noroot
cd /d "%BD%\open_close"
set "PYTHONPATH=%BD%"
python pick_meta.py publish --root "%CACHE_DAILY_ROOT%"
if errorlevel 1 goto :failpublish
python pick_meta.py score --root "%CACHE_DAILY_ROOT%"
if errorlevel 1 goto :failscore
echo.
echo RESULT: OK - magnitude watchlist and tracker in %CACHE_DAILY_ROOT%\research2\pick_meta\forward
goto :finish
:noroot
echo RESULT: FAILED - CACHE_DAILY_ROOT is not set (env_daily.bat)
goto :finish
:failpublish
echo RESULT: FAILED at publish - read the lines above
goto :finish
:failscore
echo RESULT: FAILED at score - read the lines above
:finish
pause
endlocal
