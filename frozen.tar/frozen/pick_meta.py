#!/usr/bin/env python3
"""
pick_meta.py - a meta model over the frozen engines' daily watchlists (exits / drawdown work, Part 1).

Run from ...\\bigmove_deploy\\open_close with PYTHONPATH = ...\\bigmove_deploy:

    python pick_meta.py research  --root %CACHE_DAILY_ROOT%
    python pick_meta.py calibrate --root %CACHE_DAILY_ROOT%      (once per research run)
    python pick_meta.py publish   --root %CACHE_DAILY_ROOT% [--date YYYY-MM-DD | --all-missing] [--dry-run]
    python pick_meta.py score     --root %CACHE_DAILY_ROOT%
    run_pick_meta.bat             (double-click after Run Now: publish the latest watchlist, then score)

research
    For every pick in frozen D's and ENS's walk-forward top 10 (2020-01-16 .. 2026-09-15) it builds the
    honest 5-session trade (buy next open, sell 5th close, locked lower-band exits sold at the first
    sellable open) and 44 inputs known at the signal day's close. It then forecasts, OUT OF SAMPLE
    (2022 on; each calendar year trained only on trades finished at least 5 sessions before it):
        MFE and MAE at the 20/50/80% levels     P(profit) (direction - not a confidence score)
        edge (expected net minus the day's average of the 10)
        P(+5% touch)   P(-8% dip)   P(exit stuck at the lower band)
    Before any model is fitted it must reproduce D's frozen record (1,655 days, 4,965 trades,
    +107.4 bp) or it STOPS. Decisions are fixed in PICK_META_DECLARATION.json:
        magnitude skill   the MFE/MAE forecasts rank the real ones better than ATR alone (95%)
        pick test         best 3 of D's 10 by forecast edge vs D's own 3, paired, 95% lower bound > 0
    Writes research2\\pick_meta\\PM_YYYYMMDD_NNN\\ (report.md, summary.json, predictions.parquet,
    daily.csv, final models) and one line in panel\\research_ledger.jsonl.

calibrate (v1.3)
    The confidence check declared in PICK_META_CONFIDENCE_DECLARATION.json. From the research run's
    out-of-sample picks it builds correction tables ("when the raw model said X, how often did it happen?")
    year by year, each from earlier years only, and judges each year with them: P(+5% above entry) and
    P(+10% above entry) (the headline), P(-8% dip), P(stuck) and P(profit) -> CALIBRATED / MISCALIBRATED /
    NO SKILL, plus the 6-in-10 swing range out of time. Writes research2\\pick_meta\\confidence\\PC_YYYYMMDD_NNN\\
    (report.md, summary.json, tables.json for publish, reliability.csv, calibrated_oos.csv) and a ledger line.

publish
    Scores a recorded paper watchlist (paper\\ledger.jsonl + the same day's paper\\universe.jsonl) with
    the final models of the latest research run. Writes research2\\pick_meta\\forward\\PM_cards_YYYYMMDD
    .csv/.md, led by the MAGNITUDE WATCHLIST: the corrected chance that the best point reaches entry +5% and
    +10% (v1.3), each pick's expected swing (best minus worst point over the 5 sessions), its swing class
    1-10 and what past picks of that class did (60% range), up-room and down-risk, corrected P(-8% dip) and
    P(stuck). Marks: ! failed the check, base = no per-pick skill, (raw) = no correction tables yet.
    The classes, their histories and the correction tables come from the research run's out-of-sample
    picks (no refit).
    Append-only: a date is never overwritten (the default latest-day run skips a day already published);
    each file's SHA-256 goes into forward\\index.jsonl. A card written at or after 09:00 of the entry session
    is marked late (not forward evidence).

score
    The forward magnitude tracker: every published pick whose 5 sessions have finished is settled from the
    cache bars (actual best / worst point, swing, a 5th close locked at the lower band).
    forward\\magnitude_tracker.md shows how often the actual swing fell inside the stated 60% range, forecast
    vs actual swing, and each corrected chance said vs happened with the declared forward check - on-time
    cards only count as evidence; cards from before v1.3 are corrected afterwards from their raw numbers.

Never writes to the paper test, panel_live, the paper ledger, the panels or any frozen file.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pickle
import platform
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))           # open_close copies (research_common, panel_build) win

CODE_VERSION = "pick_meta v1.3"
FAMILY = "pick_meta_v1"
DECL_FILE = HERE / "PICK_META_DECLARATION.json"
OUT_SUB = Path("research2") / "pick_meta"
INDEX_SYMBOLS = ("NIFTY50", "INDIAVIX")

FEATURES = [
    # engine: the frozen scores of that day
    "e_rank", "e_score_z", "e_gap_next", "e_agree", "e_other_rank",
    # stock: its own bars up to the signal day
    "s_atr14", "s_rv5", "s_rv20", "s_rv60", "s_rv_ratio", "s_dnvol20", "s_range", "s_gap",
    "s_ret1", "s_ret5", "s_ret20", "s_ret60", "s_dist_hi20", "s_dist_lo20", "s_pos252",
    "s_vol_z20", "s_lturn60", "s_max_up20", "s_max_dn20", "s_frozen20", "s_lock_dn20", "s_days_since_lock",
    # own record: the stock's finished 5-session trades (exit on or before the signal day)
    "own_mfe", "own_mae", "own_r5", "own_win", "own_big", "own_deep",
    # the engine's past record with this stock (finished trades only)
    "hist_n", "hist_net",
    # market on the signal day
    "m_ret5", "m_ret20", "m_rv20", "m_dd60", "m_vix", "m_vix_chg5", "m_breadth20", "m_disp5", "m_univ_ret5",
]

CFG = {
    "engines": ["D", "ENS"],
    "primary_engine": "D",
    "top": 10,
    "trade_top": 3,
    "hold": 5,
    "lock_search_sessions": 20,
    "cost_bps": 35,
    "big_move": 0.05,
    "deep_dip": -0.08,
    "first_test_year": 2022,
    "embargo_sessions": 5,
    "min_train_rows": 1000,
    "min_history_sessions": 60,
    "personality_window": 250,
    "engine_history_k": 30,
    "quantiles": [0.2, 0.5, 0.8],
    "net_winsor": [0.01, 0.99],
    "hgb": {"max_iter": 200, "learning_rate": 0.03, "max_leaf_nodes": 7, "min_samples_leaf": 100,
            "l2_regularization": 3.0, "early_stopping": False, "random_state": 7},
    "direction_models": ["edge", "win"],
    "direction_excludes_prefix": "m_",
    "bootstrap": {"level": 0.95, "block": 10, "B": 10000, "B_pooled": 1000, "seed": 7},
    "veto_share": 0.3,
    "reference": {
        "D": {"days": 1655, "trades": 4965, "mean_net_bp": 107.4, "tolerance_bp": 1.0,
              "median_mfe_pct": 5.1, "median_mae_pct": -3.7,
              "source": "PATHS_20260930_001 plain exit +107.4 bp over 4,965 trades; "
                        "EXEC_20260930_001 1,655 signal days"},
        "ENS": {"days": 1655, "trades": 4965, "source": "SI_20261008_001: ENS traded picks 4,965"},
    },
    "features": FEATURES,
}

LABELS = ("mfe", "mae", "r5", "net", "win", "big", "deep", "trap")
EVENTS = ("win", "big", "deep", "trap")
EVENT_NAMES = {"win": "P(profit)", "big": "P(+5% touch)", "deep": "P(-8% dip)",
               "trap": "P(exit stuck at lower band)"}


class PreconditionError(RuntimeError):
    """Something needed is missing or not the shipped version. Nothing was written."""


class ReconciliationError(RuntimeError):
    """The candidate set or honest exits do not reproduce the frozen record. Nothing was modelled."""


# ----------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------
def _log(msg: str) -> None:
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _days(a) -> np.ndarray:
    """Naive dates -> datetime64[ns] at midnight. Timezone-aware input is refused (convert first)."""
    if isinstance(a, np.ndarray) and np.issubdtype(a.dtype, np.datetime64):
        x = a
    else:
        s = pd.to_datetime(pd.Series(a) if not isinstance(a, pd.Series) else a)
        if getattr(s.dt, "tz", None) is not None:
            raise PreconditionError("timezone-aware dates reached a day lookup (convert them to naive first)")
        x = s.to_numpy(dtype="datetime64[ns]")
    return x.astype("datetime64[D]").astype("datetime64[ns]")


def _bp(x, nd=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 1e4:+.{nd}f}"


def _ci_bp(d: dict, nd=1) -> str:
    if not d or not np.isfinite(d.get("mean", np.nan)):
        return "n/a"
    return f"{d['mean'] * 1e4:+.{nd}f} [{d['lo'] * 1e4:+.{nd}f}, {d['hi'] * 1e4:+.{nd}f}]"


def _ci_r(d: dict, nd=3) -> str:
    if not d or not np.isfinite(d.get("mean", np.nan)):
        return "n/a"
    return f"{d['mean']:+.{nd}f} [{d['lo']:+.{nd}f}, {d['hi']:+.{nd}f}]"


def _pct(x, nd=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:+.{nd}f}%"


def _versions() -> dict:
    import sklearn
    return {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
            "scikit-learn": sklearn.__version__}


# ----------------------------------------------------------------------
# declaration
# ----------------------------------------------------------------------
def load_declaration(path: Path = DECL_FILE) -> Tuple[dict, str]:
    path = Path(path)
    if not path.exists():
        raise PreconditionError(f"{path.name} not found next to pick_meta.py - copy it into open_close")
    raw = path.read_bytes()
    decl = json.loads(raw.decode("utf-8"))
    if decl.get("family_id") != FAMILY:
        raise PreconditionError(f"{path.name} is not the {FAMILY} declaration")
    if decl.get("config") != CFG:
        raise PreconditionError(f"{path.name} 'config' differs from pick_meta.py's own copy - a declaration "
                                f"cannot change after the fact. Restore the shipped file.")
    return decl, hashlib.sha256(raw).hexdigest()[:16]


# ----------------------------------------------------------------------
# the production rules (imported from open_close; tests pass a stand-in with the same methods)
# ----------------------------------------------------------------------
class ProductionMarket:
    """Bars, honest exits, ETF names and the frozen engines, exactly as production defines them."""

    reference = None                        # None = the declaration's frozen reference

    def __init__(self, root: Path):
        self.root = Path(root)
        try:
            import stage_e_execution as EX
            import research_common as RC
            import freeze_engines as FZ
            import stage_b_screen as SB
            from data_quality import _paths
        except ImportError as e:
            raise PreconditionError(f"cannot import a production module ({e}). Run from ...\\bigmove_deploy\\"
                                    f"open_close after: set PYTHONPATH=C:\\Users\\karanvsi\\PyCharmMiscProject\\"
                                    f"bigmove_deploy") from e
        need = ((EX, ("load_bars", "lower_locked")), (RC, ("is_etf_symbol", "load_symbol_list",
                                                           "UNIVERSE_EXCLUDE_FILE")),
                (FZ, ("verify_frozen",)), (SB, ("_naive",)))
        for mod, names in need:
            miss = [n for n in names if not hasattr(mod, n)]
            if miss:
                raise PreconditionError(f"{mod.__name__} ({mod.__file__}) lacks {miss} - not the shipped version?")
        self.EX, self.RC, self.FZ, self.SB, self._paths = EX, RC, FZ, SB, _paths
        self.origins = {m.__name__: str(Path(m.__file__).resolve()) for m in (EX, RC, FZ, SB)}
        here = HERE.resolve()
        wrong = [k for k, v in self.origins.items() if Path(v).parent != here]
        if wrong:
            raise PreconditionError(f"{wrong} imported from outside open_close ({self.origins}) - run from "
                                    f"...\\bigmove_deploy\\open_close")

    def naive(self, s: pd.Series) -> pd.Series:
        return self.SB._naive(s)

    def frozen(self) -> dict:
        return self.FZ.verify_frozen(self.root / "panel_oc" / "panel.parquet")

    def preds_file(self, man: dict, eng: str) -> Path:
        return self.root / "panel_oc" / "stage_d" / man["engines"][eng]["run"] / "preds.parquet"

    def etf_set(self, symbols) -> set:
        extra = self.RC.load_symbol_list(self.root / self.RC.UNIVERSE_EXCLUDE_FILE)
        return {s for s in symbols if self.RC.is_etf_symbol(s, extra)}

    def load_bars(self, symbols) -> dict:
        return self.EX.load_bars(self.root, list(symbols))

    def lower_locked(self, b, j: int, what: str) -> bool:
        return bool(self.EX.lower_locked(b, j, what))

    def volume(self, symbol: str, ts: np.ndarray) -> Optional[np.ndarray]:
        fp, _ = self._paths(self.root, symbol)
        try:
            v = pd.read_parquet(fp, columns=["timestamp", "volume"])
        except Exception:
            return None
        v["timestamp"] = self.SB._naive(v["timestamp"])
        v = v.drop_duplicates("timestamp").sort_values("timestamp")
        return align(v["timestamp"].to_numpy(dtype="datetime64[ns]"), v["volume"].to_numpy(float), ts)


def align(src_ts: np.ndarray, src_val: np.ndarray, ts: np.ndarray) -> np.ndarray:
    """src values at the exact timestamps ts (NaN where absent)."""
    out = np.full(len(ts), np.nan)
    if len(src_ts) == 0:
        return out
    k = np.searchsorted(src_ts, ts)
    ok = (k < len(src_ts)) & (src_ts[np.minimum(k, len(src_ts) - 1)] == ts)
    out[ok] = src_val[k[ok]]
    return out


# ----------------------------------------------------------------------
# bars per symbol
# ----------------------------------------------------------------------
@dataclass
class Sym:
    b: object                               # production Bars: ts, o, h, l, c
    d: np.ndarray                           # the day of each bar (datetime64[ns], midnight)
    vol: Optional[np.ndarray]
    arr: Optional[Dict[str, np.ndarray]] = None
    locked: Optional[np.ndarray] = None


COLLAPSED: Dict[str, List[str]] = {}       # symbol -> days that held two bars (the later bar was kept)


def _keep_last_per_day(b, d: np.ndarray):
    """Bars with two rows on one calendar day (different timestamps) -> keep the later row of each day."""
    import dataclasses
    keep = np.r_[d[1:] != d[:-1], True]
    ts = np.asarray(b.ts, dtype="datetime64[ns]")[keep]
    sub = {k: np.asarray(getattr(b, k))[keep] for k in ("o", "h", "l", "c")}
    if dataclasses.is_dataclass(b):
        extra = {}
        if hasattr(b, "vol20"):
            extra["vol20"] = np.asarray(b.vol20)[keep]
        if hasattr(b, "index"):
            extra["index"] = {t: i for i, t in enumerate(ts)}
        nb = dataclasses.replace(b, ts=ts, **sub, **extra)
    else:
        raise PreconditionError("bars object is not the production dataclass - cannot repair duplicate days")
    return nb, d[keep]


def prepare_symbols(market, symbols, with_volume=True) -> Dict[str, Sym]:
    """Bars for each symbol. A day holding two bars (two timestamps on one calendar day) keeps the later bar;
    every case is printed with both closes and listed in the summary. If it touched a traded pick enough to
    matter, the reconciliation stop catches it."""
    bars = market.load_bars(sorted(set(symbols)))
    out = {}
    for s, b in bars.items():
        d = _days(np.asarray(b.ts, dtype="datetime64[ns]"))
        if len(d) and (np.diff(d.view("i8")) < 0).any():
            raise PreconditionError(f"{s}: bars are not in time order")
        dup = np.where(d[1:] == d[:-1])[0] if len(d) else np.zeros(0, int)
        if len(dup):
            c = np.asarray(b.c, float)
            first = int(dup[0])
            COLLAPSED[s] = [str(pd.Timestamp(d[i]).date()) for i in dup]
            _log(f"WARNING {s}: {len(dup)} day(s) with two bars (first {pd.Timestamp(d[first]).date()}: closes "
                 f"{c[first]:.2f} / {c[first + 1]:.2f}) - kept the later bar of each day")
            b, d = _keep_last_per_day(b, d)
        out[s] = Sym(b=b, d=d, vol=market.volume(s, np.asarray(b.ts, dtype="datetime64[ns]")) if with_volume
                     else None)
    return out


def day_index(sy: Sym, days: np.ndarray) -> np.ndarray:
    """Index of each day in the symbol's bars, -1 where the stock has no bar that day."""
    k = np.searchsorted(sy.d, days)
    ok = (k < len(sy.d)) & (sy.d[np.minimum(k, max(len(sy.d) - 1, 0))] == days) if len(sy.d) else \
        np.zeros(len(days), bool)
    return np.where(ok, k, -1)


def locked_closes(sy: Sym, market) -> np.ndarray:
    """Close locked at a lower band, by production's rule (checked only where it is possible at all)."""
    if sy.locked is None:
        b = sy.b
        c, l = np.asarray(b.c, float), np.asarray(b.l, float)
        prev = np.r_[np.nan, c[:-1]]
        with np.errstate(invalid="ignore"):
            maybe = np.where((c <= l * (1 + 1e-9)) & (c < prev))[0]
        out = np.zeros(len(c), bool)
        for j in maybe:
            if j > 0 and market.lower_locked(b, int(j), "close"):
                out[j] = True
        sy.locked = out
    return sy.locked


# ----------------------------------------------------------------------
# labels: the honest 5-session trade
# ----------------------------------------------------------------------
def honest_trade(sy: Sym, i: int, cfg: dict, market) -> Tuple[str, dict]:
    """Signal at bar i: buy bar i+1's open, sell bar i+hold's close; a close locked at the lower band
    sells at the first later open that is not locked (searched over lock_search_sessions)."""
    b = sy.b
    n = len(b.c)
    H = cfg["hold"]
    if i < 0:
        return "no_bar", {}
    e, x = i + 1, i + H
    if x >= n:
        return "pending", {}
    entry = float(b.o[e])
    if not (entry > 0 and np.isfinite(entry)):
        return "bad_price", {}
    mfe = float(np.max(b.h[e:x + 1])) / entry - 1.0
    mae = float(np.min(b.l[e:x + 1])) / entry - 1.0
    base = {"entry_day": sy.d[e], "mfe": mfe, "mae": mae}
    if market.lower_locked(b, x, "close"):
        for k in range(x + 1, x + 1 + cfg["lock_search_sessions"]):
            if k >= n:
                return "pending", base
            if not market.lower_locked(b, k, "open"):
                return "ok", {**base, "exit_day": sy.d[k], "r5": float(b.o[k]) / entry - 1.0, "locked": True}
        return "stuck", base
    return "ok", {**base, "exit_day": sy.d[x], "r5": float(b.c[x]) / entry - 1.0, "locked": False}


# ----------------------------------------------------------------------
# inputs
# ----------------------------------------------------------------------
def feature_arrays(sy: Sym, market, cfg: dict) -> Dict[str, np.ndarray]:
    """Every stock and own-record input for every bar, each using bars up to that bar only."""
    if sy.arr is not None:
        return sy.arr
    from numpy.lib.stride_tricks import sliding_window_view as swv
    b = sy.b
    o, h, l, c = (np.asarray(x, float) for x in (b.o, b.h, b.l, b.c))
    n = len(c)
    S = pd.Series
    A: Dict[str, np.ndarray] = {}
    prev = np.r_[np.nan, c[:-1]]
    with np.errstate(divide="ignore", invalid="ignore"):
        tr = np.where(np.isnan(prev), h - l, np.maximum(h, prev) - np.minimum(l, prev))
        lr = np.log(c / prev)
        ret = c / prev - 1.0
        A["s_atr14"] = S(tr).rolling(14, min_periods=14).mean().to_numpy() / c
        A["s_rv5"] = S(lr).rolling(5, min_periods=5).std().to_numpy()
        A["s_rv20"] = S(lr).rolling(20, min_periods=20).std().to_numpy()
        A["s_rv60"] = S(lr).rolling(60, min_periods=60).std().to_numpy()
        A["s_rv_ratio"] = A["s_rv5"] / A["s_rv60"]
        dn = np.where(np.isnan(lr), np.nan, np.minimum(lr, 0.0))
        A["s_dnvol20"] = np.sqrt(S(dn ** 2).rolling(20, min_periods=20).mean().to_numpy())
        A["s_range"] = (h - l) / c
        A["s_gap"] = o / prev - 1.0
        for k in (1, 5, 20, 60):
            A[f"s_ret{k}"] = c / S(c).shift(k).to_numpy() - 1.0
        A["s_dist_hi20"] = c / S(h).rolling(20, min_periods=20).max().to_numpy() - 1.0
        A["s_dist_lo20"] = c / S(l).rolling(20, min_periods=20).min().to_numpy() - 1.0
        hi = S(h).rolling(252, min_periods=60).max().to_numpy()
        lo = S(l).rolling(252, min_periods=60).min().to_numpy()
        A["s_pos252"] = np.where(hi > lo, (c - lo) / (hi - lo), np.nan)
        if sy.vol is not None:
            v = np.asarray(sy.vol, float)
            lv = np.log(np.where(v > 0, v, np.nan))
            m = S(lv).rolling(20, min_periods=20).mean().to_numpy()
            sd = S(lv).rolling(20, min_periods=20).std().to_numpy()
            A["s_vol_z20"] = np.where(sd > 0, (lv - m) / sd, np.nan)
            A["s_lturn60"] = np.log10(S(c * v).rolling(60, min_periods=20).median().to_numpy())
        else:
            A["s_vol_z20"] = np.full(n, np.nan)
            A["s_lturn60"] = np.full(n, np.nan)
        A["s_max_up20"] = S(ret).rolling(20, min_periods=20).max().to_numpy()
        A["s_max_dn20"] = S(ret).rolling(20, min_periods=20).min().to_numpy()
        A["s_frozen20"] = S((h <= l * (1 + 1e-12)).astype(float)).rolling(20, min_periods=20).sum().to_numpy()
        lk = locked_closes(sy, market)
        A["s_lock_dn20"] = S(lk.astype(float)).rolling(20, min_periods=1).sum().to_numpy()
        last = np.maximum.accumulate(np.where(lk, np.arange(n), -1)) if n else np.zeros(0, int)
        A["s_days_since_lock"] = np.minimum(np.where(last >= 0, np.arange(n) - last, 260), 260).astype(float)

        # own record: plain 5-session virtual trade of every stock-day (entry next open, exit 5th close),
        # usable at bar i only once it has finished (exit bar j + H <= i)
        H, W, mp = cfg["hold"], cfg["personality_window"], cfg["min_history_sessions"]
        vm, va, vr = (np.full(n, np.nan) for _ in range(3))
        if n > H:
            hw, lw = swv(h[1:], H), swv(l[1:], H)
            m_ = len(hw)
            ent = o[1:1 + m_]
            vm[:m_] = hw.max(axis=1) / ent - 1.0
            va[:m_] = lw.min(axis=1) / ent - 1.0
            vr[:m_] = c[H:H + m_] / ent - 1.0
        cost = cfg["cost_bps"] / 1e4

        def roll(a):
            return S(a).rolling(W, min_periods=mp).mean().shift(H).to_numpy()

        def ind(a, cond):
            return np.where(np.isnan(a), np.nan, cond.astype(float))

        A["own_mfe"], A["own_mae"], A["own_r5"] = roll(vm), roll(va), roll(vr)
        A["own_win"] = roll(ind(vr, vr > cost))
        A["own_big"] = roll(ind(vm, vm >= cfg["big_move"]))
        A["own_deep"] = roll(ind(va, va <= cfg["deep_dip"]))
    A = {k: np.where(np.isfinite(v), v, np.nan) for k, v in A.items()}   # fresh, writable arrays
    sy.arr = A
    return A


def stock_block(C: pd.DataFrame, syms: Dict[str, Sym], market, cfg: dict) -> pd.DataFrame:
    """Stock inputs and honest-trade labels for every candidate row (aligned to C's index)."""
    if not isinstance(C.index, pd.RangeIndex) or C.index.start != 0:
        raise ValueError("stock_block needs a 0..n-1 index")
    n = len(C)
    cols = [f for f in cfg["features"] if f.startswith(("s_", "own_"))]
    F = {f: np.full(n, np.nan) for f in cols}
    L = {k: np.full(n, np.nan) for k in ("mfe", "mae", "r5")}
    locked = np.full(n, np.nan)
    status = np.array(["no_bars"] * n, dtype=object)
    entry_day = np.full(n, np.datetime64("NaT"), dtype="datetime64[ns]")
    exit_day = np.full(n, np.datetime64("NaT"), dtype="datetime64[ns]")
    days_all = C["signal_day"].to_numpy(dtype="datetime64[ns]")
    for s, g in C.groupby("symbol", sort=False):
        rows = g.index.to_numpy()
        sy = syms.get(s)
        if sy is None:
            continue
        A = feature_arrays(sy, market, cfg)
        k = day_index(sy, days_all[rows])
        ok = k >= 0
        for f in cols:
            F[f][rows[ok]] = A[f][k[ok]]
        for r, i in zip(rows, k):
            st, lab = honest_trade(sy, int(i), cfg, market)
            status[r] = st
            if "entry_day" in lab:
                entry_day[r] = lab["entry_day"]
                L["mfe"][r], L["mae"][r] = lab["mfe"], lab["mae"]
            if st == "ok":
                exit_day[r] = lab["exit_day"]
                L["r5"][r] = lab["r5"]
                locked[r] = float(lab["locked"])
    out = pd.DataFrame(F, index=C.index)
    for k, v in L.items():
        out[k] = v
    cost = cfg["cost_bps"] / 1e4
    ok = status == "ok"
    out["net"] = np.where(ok, out["r5"] - cost, np.nan)
    out["win"] = np.where(ok, (out["net"] > 0).astype(float), np.nan)
    out["big"] = np.where(ok, (out["mfe"] >= cfg["big_move"]).astype(float), np.nan)
    out["deep"] = np.where(ok, (out["mae"] <= cfg["deep_dip"]).astype(float), np.nan)
    out["trap"] = np.where(ok, locked, np.nan)
    out["status"] = status
    out["entry_day"] = entry_day
    out["exit_day"] = exit_day
    return out


def index_features(syms: Dict[str, Sym]) -> pd.DataFrame:
    """NIFTY50 and INDIAVIX inputs by day."""
    miss = [s for s in INDEX_SYMBOLS if s not in syms]
    if miss:
        raise PreconditionError(f"index series missing from the cache: {miss}")
    n50, vix = syms["NIFTY50"], syms["INDIAVIX"]
    c = np.asarray(n50.b.c, float)
    S = pd.Series
    with np.errstate(divide="ignore", invalid="ignore"):
        lr = np.log(c / np.r_[np.nan, c[:-1]])
        a = pd.DataFrame({"m_ret5": c / S(c).shift(5).to_numpy() - 1.0,
                          "m_ret20": c / S(c).shift(20).to_numpy() - 1.0,
                          "m_rv20": S(lr).rolling(20, min_periods=20).std().to_numpy(),
                          "m_dd60": c / S(c).rolling(60, min_periods=20).max().to_numpy() - 1.0},
                         index=pd.DatetimeIndex(n50.d, name="signal_day"))
        v = np.asarray(vix.b.c, float)
        bvx = pd.DataFrame({"m_vix": v, "m_vix_chg5": v / S(v).shift(5).to_numpy() - 1.0},
                           index=pd.DatetimeIndex(vix.d, name="signal_day"))
    out = a.join(bvx, how="left")
    return out.replace([np.inf, -np.inf], np.nan)


def universe_features(universe: pd.DataFrame, syms: Dict[str, Sym]) -> pd.DataFrame:
    """Breadth (share above the 20-session mean), dispersion and median of 5-session returns, by day,
    over that day's eligible universe."""
    parts = []
    for s, g in universe.groupby("symbol", sort=False):
        sy = syms.get(s)
        if sy is None:
            continue
        c = np.asarray(sy.b.c, float)
        sma = pd.Series(c).rolling(20, min_periods=20).mean().to_numpy()
        with np.errstate(divide="ignore", invalid="ignore"):
            r5 = c / pd.Series(c).shift(5).to_numpy() - 1.0
        days = g["signal_day"].to_numpy(dtype="datetime64[ns]")
        k = day_index(sy, days)
        ok = k >= 0
        kk = k[ok]
        above = np.where(np.isnan(sma[kk]), np.nan, (c[kk] > sma[kk]).astype(float))
        parts.append(pd.DataFrame({"signal_day": days[ok], "above": above, "r5": r5[kk]}))
    U = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=["signal_day", "above", "r5"])
    U["r5"] = U["r5"].replace([np.inf, -np.inf], np.nan)
    g = U.groupby("signal_day")
    return pd.DataFrame({"m_breadth20": g["above"].mean(), "m_disp5": g["r5"].std(),
                         "m_univ_ret5": g["r5"].median()})


def engine_features(tops: Dict[str, pd.DataFrame], engines: List[str]) -> Dict[str, pd.DataFrame]:
    """Rank, score shape within the day's top 10, and agreement with the other engine."""
    out = {}
    for eng in engines:
        t = tops[eng].sort_values(["signal_day", "rank"], kind="mergesort").reset_index(drop=True)
        g = t.groupby("signal_day")["score"]
        mu = g.transform("mean")
        sd = np.sqrt(np.maximum(t["score"].pow(2).groupby(t["signal_day"]).transform("mean") - mu ** 2, 0.0))
        sd = sd.where(sd > 1e-12)
        t["e_rank"] = t["rank"].astype(float)
        t["e_score_z"] = ((t["score"] - mu) / sd).fillna(0.0)
        t["e_gap_next"] = (t["score"] - g.shift(-1)) / sd
        others = [o for o in engines if o != eng]
        if others:
            o = tops[others[0]][["signal_day", "symbol", "rank"]].rename(columns={"rank": "_orank"})
            t = t.merge(o, on=["signal_day", "symbol"], how="left")
            has = t["signal_day"].isin(set(o["signal_day"]))
            t["e_agree"] = np.where(has, t["_orank"].notna().astype(float), np.nan)
            t["e_other_rank"] = np.where(has, t["_orank"].fillna(11.0), np.nan)
            t = t.drop(columns="_orank")
        else:
            t["e_agree"], t["e_other_rank"] = np.nan, np.nan
        out[eng] = t
    return out


def engine_history(C: pd.DataFrame, K: float) -> pd.DataFrame:
    """For each candidate (engine, stock, day T): how many of the engine's earlier top-10 appearances of the
    stock had finished by T (exit day <= T), and their net shrunk toward the engine's overall record:
        hist_net = (sum of their nets + K x engine mean) / (count + K)"""
    n = len(C)
    hn, hv = np.zeros(n), np.full(n, np.nan)
    for _, g in C.groupby("engine", sort=False):
        pos = g.index.to_numpy()
        res = g[g["net"].notna() & g["exit_day"].notna()]
        at = res["exit_day"].to_numpy(dtype="datetime64[ns]")
        o = np.argsort(at, kind="mergesort")
        at, asy, av = at[o], res["symbol"].to_numpy()[o], res["net"].to_numpy(float)[o]
        qo = np.argsort(g["signal_day"].to_numpy(dtype="datetime64[ns]"), kind="mergesort")
        qt = g["signal_day"].to_numpy(dtype="datetime64[ns]")[qo]
        qs = g["symbol"].to_numpy()[qo]
        pn: Dict[str, int] = {}
        ps: Dict[str, float] = {}
        tn, tsum, p = 0, 0.0, 0
        rn, rv = np.zeros(len(g)), np.full(len(g), np.nan)
        for q in range(len(g)):
            t = qt[q]
            while p < len(at) and at[p] <= t:
                s = asy[p]
                pn[s] = pn.get(s, 0) + 1
                ps[s] = ps.get(s, 0.0) + av[p]
                tn += 1
                tsum += av[p]
                p += 1
            s = qs[q]
            k = pn.get(s, 0)
            rn[q] = k
            if tn:
                rv[q] = (ps.get(s, 0.0) + K * (tsum / tn)) / (k + K)
        hn[pos[qo]] = rn
        hv[pos[qo]] = rv
    return pd.DataFrame({"hist_n": hn, "hist_net": hv}, index=C.index)


def assemble(C: pd.DataFrame, syms: Dict[str, Sym], idx: pd.DataFrame, uni: pd.DataFrame, market,
             cfg: dict) -> pd.DataFrame:
    """Candidates (engine, signal_day, symbol, rank, score, e_*) -> every input and label."""
    C = C.reset_index(drop=True)
    st = stock_block(C, syms, market, cfg)
    T = pd.concat([C, st], axis=1)
    mk = idx.join(uni, how="outer")
    mk.index = mk.index.astype("datetime64[ns]")
    T = T.merge(mk, left_on="signal_day", right_index=True, how="left")
    T = T.reset_index(drop=True)
    T = pd.concat([T, engine_history(T, cfg["engine_history_k"])], axis=1)
    miss = [f for f in cfg["features"] if f not in T.columns]
    if miss:
        raise RuntimeError(f"inputs not built: {miss}")
    return T


# ----------------------------------------------------------------------
# models
# ----------------------------------------------------------------------
def edge_target(Y: pd.DataFrame) -> np.ndarray:
    """Net minus the average net of the same engine's finished candidates that day: the part of the
    trade the day's market move does not explain (what choosing among the 10 can capture)."""
    m = Y.groupby(["engine", "signal_day"])["net"].transform("mean")
    return (Y["net"] - m).to_numpy(float)


def direction_columns(cfg: dict) -> np.ndarray:
    """Columns the direction models (edge, P(profit)) may use: inputs that differ between the day's 10 picks.
    Day-level inputs (m_*) are the same for all 10, so they cannot order them; they could only let the
    model guess the market's direction - which it memorises (seen in the synthetic tests)."""
    return np.array([i for i, f in enumerate(cfg["features"]) if not f.startswith(cfg["direction_excludes_prefix"])])


def fit_models(X: np.ndarray, Y: pd.DataFrame, cfg: dict) -> dict:
    from sklearn.ensemble import HistGradientBoostingClassifier as HGBC
    from sklearn.ensemble import HistGradientBoostingRegressor as HGBR
    hp = dict(cfg["hgb"])
    M = {}
    Xd = X[:, direction_columns(cfg)]
    for nm in ("mfe", "mae"):
        y = Y[nm].to_numpy(float)
        for q in cfg["quantiles"]:
            M[f"{nm}_q{int(round(q * 100))}"] = HGBR(loss="quantile", quantile=q, **hp).fit(X, y)
    y = edge_target(Y)
    lo, hi = np.quantile(y, cfg["net_winsor"])
    M["edge"] = HGBR(loss="squared_error", **hp).fit(Xd, np.clip(y, lo, hi))
    for nm in EVENTS:
        y = Y[nm].to_numpy(float).astype(int)
        Xm = Xd if nm in cfg["direction_models"] else X
        M[nm] = ("const", float(y.mean())) if y.min() == y.max() else HGBC(**hp).fit(Xm, y)
    return M


def predict_models(M: dict, X: np.ndarray, cfg: dict) -> pd.DataFrame:
    out = {}
    qs = [int(round(q * 100)) for q in cfg["quantiles"]]
    for nm in ("mfe", "mae"):
        Q = np.column_stack([M[f"{nm}_q{q}"].predict(X) for q in qs])
        Q.sort(axis=1)                      # quantile crossings
        for k, q in enumerate(qs):
            out[f"pred_{nm}_q{q}"] = Q[:, k]
    Xd = X[:, direction_columns(cfg)]
    out["pred_edge"] = M["edge"].predict(Xd)
    for nm in EVENTS:
        m = M[nm]
        Xm = Xd if nm in cfg["direction_models"] else X
        out[f"prob_{nm}"] = np.full(len(X), m[1]) if isinstance(m, tuple) else m.predict_proba(Xm)[:, 1]
    return pd.DataFrame(out)


PRED_COLS = ["pred_mfe_q20", "pred_mfe_q50", "pred_mfe_q80", "pred_mae_q20", "pred_mae_q50", "pred_mae_q80",
             "pred_edge", "prob_win", "prob_big", "prob_deep", "prob_trap"]


def walk_forward(T: pd.DataFrame, cal: np.ndarray, cfg: dict, verbose=True) -> Tuple[pd.DataFrame, List[dict]]:
    """One engine: expanding walk-forward by calendar year. Training rows must have finished at least
    embargo_sessions full sessions before the test year's first signal day."""
    F = cfg["features"]
    yr = pd.DatetimeIndex(T["signal_day"]).year
    out, folds = [], []
    for y in sorted(set(yr[yr >= cfg["first_test_year"]])):
        te = T[yr == y]
        start = np.datetime64(te["signal_day"].min(), "ns")
        p = int(np.searchsorted(cal, start))
        cut = cal[p - cfg["embargo_sessions"] - 1]
        tr = T[(T["status"] == "ok") & (T["exit_day"] <= cut)]
        if len(tr) < cfg["min_train_rows"]:
            raise PreconditionError(f"year {y}: only {len(tr)} finished training rows (< {cfg['min_train_rows']})")
        t0 = time.perf_counter()
        M = fit_models(tr[F].to_numpy(float), tr, cfg)
        P = predict_models(M, te[F].to_numpy(float), cfg)
        P.index = te.index
        P["fold"] = y
        out.append(P)
        last = np.datetime64(tr["exit_day"].max(), "ns")
        gap = p - int(np.searchsorted(cal, last)) - 1
        folds.append({"year": int(y), "test_first": str(pd.Timestamp(start).date()),
                      "test_last": str(pd.Timestamp(te["signal_day"].max()).date()), "test_rows": int(len(te)),
                      "train_rows": int(len(tr)), "train_last_exit": str(pd.Timestamp(last).date()),
                      "gap_sessions": int(gap)})
        if verbose:
            _log(f"  year {y}: trained on {len(tr):,} finished trades (last exit {pd.Timestamp(last).date()}, "
                 f"{gap} sessions before {pd.Timestamp(start).date()}), scored {len(te):,} "
                 f"({time.perf_counter() - t0:.0f}s)")
    return pd.concat(out).sort_index(), folds


# ----------------------------------------------------------------------
# statistics
# ----------------------------------------------------------------------
def boot_mean(x, cfg: dict, B: Optional[int] = None) -> dict:
    """Mean and its circular block-bootstrap interval; x must be in time order."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    bs = cfg["bootstrap"]
    if n < 2:
        return {"mean": float(x.mean()) if n else np.nan, "lo": np.nan, "hi": np.nan, "n": n}
    B, L, lvl = B or bs["B"], bs["block"], bs["level"]
    rng = np.random.default_rng(bs["seed"])
    nb = int(np.ceil(n / L))
    means = np.empty(B)
    for a in range(0, B, 500):
        bb = min(500, B - a)
        st = rng.integers(0, n, size=(bb, nb))
        ix = ((st[:, :, None] + np.arange(L)[None, None, :]).reshape(bb, -1)[:, :n]) % n
        means[a:a + bb] = x[ix].mean(axis=1)
    lo, hi = np.percentile(means, [100 * (1 - lvl) / 2, 100 * (1 + lvl) / 2])
    return {"mean": float(x.mean()), "lo": float(lo), "hi": float(hi), "n": int(n)}


def _rank(a: np.ndarray) -> np.ndarray:
    from scipy.stats import rankdata
    return rankdata(a)


def spearman(a, b) -> float:
    a, b = np.asarray(a, float), np.asarray(b, float)
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() < 3:
        return np.nan
    ra, rb = _rank(a[m]), _rank(b[m])
    if ra.std() == 0 or rb.std() == 0:
        return np.nan
    return float(np.corrcoef(ra, rb)[0, 1])


def auc(y, s) -> float:
    y, s = np.asarray(y, float), np.asarray(s, float)
    m = np.isfinite(y) & np.isfinite(s)
    y, s = y[m] > 0.5, s[m]
    n1 = int(y.sum())
    n0 = len(y) - n1
    if n1 == 0 or n0 == 0:
        return np.nan
    r = _rank(s)
    return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def pooled_ci(days: np.ndarray, a: np.ndarray, b: np.ndarray, metric, cfg: dict) -> dict:
    """A pooled metric (Spearman or AUC over all rows) with a day-block bootstrap interval."""
    o = np.argsort(days, kind="mergesort")
    days, a, b = days[o], np.asarray(a, float)[o], np.asarray(b, float)[o]
    est = metric(a, b)
    u, beg, cnt = np.unique(days, return_index=True, return_counts=True)
    nD = len(u)
    bs = cfg["bootstrap"]
    if nD < 10 or not np.isfinite(est):
        return {"mean": est, "lo": np.nan, "hi": np.nan, "n": int(len(a))}
    rng = np.random.default_rng(bs["seed"] + 1)
    L = bs["block"]
    nb = int(np.ceil(nD / L))
    vals = np.empty(bs["B_pooled"])
    for r in range(bs["B_pooled"]):
        st = rng.integers(0, nD, nb)
        ds = ((st[:, None] + np.arange(L)[None, :]).ravel()[:nD]) % nD
        c, s0 = cnt[ds], beg[ds]
        offs = np.repeat(s0 - np.cumsum(c) + c, c) + np.arange(c.sum())
        vals[r] = metric(a[offs], b[offs])
    lvl = bs["level"]
    lo, hi = np.nanpercentile(vals, [100 * (1 - lvl) / 2, 100 * (1 + lvl) / 2])
    return {"mean": float(est), "lo": float(lo), "hi": float(hi), "n": int(len(a))}


def daily_spearman(df: pd.DataFrame, a: str, b: str, min_n: int = 5) -> pd.Series:
    """Within-day (cross-sectional) Spearman between columns a and b, one value per day."""
    d = df[["signal_day", a, b]].dropna().copy()
    if d.empty:
        return pd.Series(dtype=float)
    g = d.groupby("signal_day")
    d["ra"] = g[a].rank()
    d["rb"] = g[b].rank()
    g = d.groupby("signal_day")
    d["xa"] = d["ra"] - g["ra"].transform("mean")
    d["xb"] = d["rb"] - g["rb"].transform("mean")
    d["xab"], d["xaa"], d["xbb"] = d["xa"] * d["xb"], d["xa"] ** 2, d["xb"] ** 2
    s = d.groupby("signal_day")[["xab", "xaa", "xbb"]].sum()
    nn = d.groupby("signal_day").size()
    with np.errstate(invalid="ignore", divide="ignore"):
        r = s["xab"] / np.sqrt(s["xaa"] * s["xbb"])
    r[(nn < min_n) | (s["xaa"] <= 0) | (s["xbb"] <= 0)] = np.nan
    return r.sort_index()


def daily_auc(df: pd.DataFrame, y: str, s: str, min_n: int = 5) -> pd.Series:
    """AUC within each day (days with both outcomes and at least min_n rows)."""
    out = {}
    for d, g in df[["signal_day", y, s]].dropna().groupby("signal_day"):
        if len(g) >= min_n and 0 < g[y].sum() < len(g):
            out[d] = auc(g[y].to_numpy(), g[s].to_numpy())
    return pd.Series(out, dtype=float).sort_index()


# ----------------------------------------------------------------------
# evaluation
# ----------------------------------------------------------------------
def select_top(E: pd.DataFrame, key: str, ascending: bool, k: int) -> pd.DataFrame:
    s = E.sort_values(["signal_day", key, "rank"], ascending=[True, ascending, True], kind="mergesort")
    return s.groupby("signal_day", sort=True).head(k)


def daily_net(sel: pd.DataFrame, weight: Optional[str] = None) -> pd.Series:
    ok = sel[sel["status"] == "ok"]
    if weight is None:
        return ok.groupby("signal_day")["net"].mean()
    w = ok[weight]
    return (ok["net"] * w).groupby(ok["signal_day"]).sum() / w.groupby(ok["signal_day"]).sum()


def paired(a: pd.Series, b: pd.Series, cfg: dict) -> Tuple[dict, pd.Series]:
    j = pd.concat([a, b], axis=1, keys=["a", "b"]).dropna().sort_index()
    d = j["a"] - j["b"]
    return boot_mean(d.to_numpy(), cfg), d


def veto_select(E: pd.DataFrame, share: float, k: int) -> pd.DataFrame:
    """Drop the day's `share` of candidates with the highest P(-8% dip) (worse D rank first on ties), then
    take the best k by D rank."""
    d = E.sort_values(["signal_day", "prob_deep", "rank"], ascending=[True, False, False], kind="mergesort").copy()
    d["_dr"] = d.groupby("signal_day").cumcount() + 1
    nday = d.groupby("signal_day")["rank"].transform("size")
    d = d[d["_dr"] > np.round(share * nday)]
    return select_top(d, "rank", True, k)


def evaluate(P: pd.DataFrame, market_daily: pd.Series, cfg: dict) -> dict:
    """One engine, out-of-sample rows only (fold set)."""
    E = P[P["fold"].notna()].copy()
    ok = E[E["status"] == "ok"]
    R: dict = {"rows": int(len(E)), "ok_rows": int(len(ok)), "days": int(E["signal_day"].nunique()),
               "first": str(pd.Timestamp(E["signal_day"].min()).date()),
               "last": str(pd.Timestamp(E["signal_day"].max()).date()),
               "status_counts": {k: int(v) for k, v in E["status"].value_counts().items()}}
    days = ok["signal_day"].to_numpy(dtype="datetime64[ns]")
    qs = [int(round(q * 100)) for q in cfg["quantiles"]]
    for nm, sgn in (("mae", -1.0), ("mfe", 1.0)):
        x = ok.assign(_atr=sgn * ok["s_atr14"])
        meta, atr = daily_spearman(x, f"pred_{nm}_q50", nm), daily_spearman(x, "_atr", nm)
        dif, _ = paired(meta, atr, cfg)
        r = {"daily": boot_mean(meta.dropna().to_numpy(), cfg), "daily_atr": boot_mean(atr.dropna().to_numpy(), cfg),
             "vs_atr": dif,
             "pooled": pooled_ci(days, ok[f"pred_{nm}_q50"].to_numpy(), ok[nm].to_numpy(), spearman, cfg),
             "pooled_atr": pooled_ci(days, x["_atr"].to_numpy(), ok[nm].to_numpy(), spearman, cfg),
             "median_real": float(ok[nm].median()), "median_pred": float(ok[f"pred_{nm}_q50"].median()),
             "coverage": {str(q): float((ok[nm] <= ok[f"pred_{nm}_q{q}"]).mean()) for q in qs},
             "coverage_by_fold": {str(int(f)): {str(q): float((g[nm] <= g[f"pred_{nm}_q{q}"]).mean()) for q in qs}
                                  for f, g in ok.groupby("fold")}}
        r["skill"] = bool(np.isfinite(r["daily"]["lo"]) and r["daily"]["lo"] > 0)
        r["beats_atr"] = bool(np.isfinite(dif["lo"]) and dif["lo"] > 0)
        R[nm] = r
    for nm in EVENTS:
        y, p = ok[nm].to_numpy(float), ok[f"prob_{nm}"].to_numpy(float)
        base = float(np.nanmean(y))
        brier = float(np.nanmean((p - y) ** 2))
        ref = float(np.nanmean((base - y) ** 2))
        a = pooled_ci(days, y, p, auc, cfg)
        R[nm] = {"auc": a, "base_rate": base, "mean_prob": float(np.nanmean(p)), "brier": brier,
                 "brier_skill": (1 - brier / ref) if ref > 0 else np.nan,
                 "skill": bool(np.isfinite(a["lo"]) and a["lo"] > 0.5)}
    q = pd.qcut(ok["prob_win"].rank(method="first"), 10, labels=False)
    R["win"]["calibration"] = [{"decile": int(d) + 1, "n": int(len(g)), "pred": float(g["prob_win"].mean()),
                                "real": float(g["win"].mean()), "net_bp": float(g["net"].mean() * 1e4)}
                               for d, g in ok.groupby(q)]
    dn = daily_spearman(ok, "pred_edge", "net")
    real_edge = edge_target(ok)
    R["edge"] = {"daily": boot_mean(dn.dropna().to_numpy(), cfg),
                 "pooled": pooled_ci(days, ok["pred_edge"].to_numpy(), real_edge, spearman, cfg)}
    dw = daily_auc(ok, "win", "prob_win")
    R["win"]["daily_auc"] = boot_mean(dw.dropna().to_numpy(), cfg)

    # ---- the pick test and the descriptive policies (selection among all 10; net over finished trades)
    k = cfg["trade_top"]
    base_sel = select_top(E, "rank", True, k)
    base = daily_net(base_sel)
    pol = {}
    E["_ra"] = E["pred_edge"] / np.maximum(E["pred_mae_q50"].abs(), 0.005)
    sels = {"META_EDGE": select_top(E, "pred_edge", False, k),
            "META_PWIN": select_top(E, "prob_win", False, k),
            "META_RISKADJ": select_top(E, "_ra", False, k),
            "VETO_DEEP": veto_select(E, cfg["veto_share"], k)}
    for nm, sel in sels.items():
        s = daily_net(sel)
        dif, d = paired(s, base, cfg)
        both = pd.concat([s, base], axis=1, keys=["p", "b"]).dropna()
        pol[nm] = {"mean": float(both["p"].mean()), "base": float(both["b"].mean()), "diff": dif,
                   "same_as_D": float(sel["rank"].le(k).mean()), "days": int(len(both)),
                   "std": float(both["p"].std()), "base_std": float(both["b"].std()),
                   "by_year": {str(y): {"pick": float(g["p"].mean()), "D": float(g["b"].mean()),
                                        "diff": float((g["p"] - g["b"]).mean()), "days": int(len(g))}
                               for y, g in both.groupby(both.index.year)}}
    bw = base_sel.assign(_w=1.0 / np.maximum(base_sel["pred_mae_q50"].abs(), 0.005))
    s = daily_net(bw, "_w")
    dif, _ = paired(s, base, cfg)
    both = pd.concat([s, base], axis=1, keys=["p", "b"]).dropna()
    pol["SIZE_PREVIEW"] = {"mean": float(both["p"].mean()), "base": float(both["b"].mean()), "diff": dif,
                           "std": float(both["p"].std()), "base_std": float(both["b"].std()), "days": int(len(both))}
    m = pol["META_EDGE"]
    R["pick_test"] = {"diff": m["diff"], "meta": m["mean"], "D": m["base"], "days": m["days"],
                      "verdict": "PASS" if (np.isfinite(m["diff"]["lo"]) and m["diff"]["lo"] > 0) else "KEEP D"}
    R["policies"] = pol
    mk = market_daily.reindex(base.index)
    R["D_top3_net"] = boot_mean(base.to_numpy(), cfg)
    R["D_top3_excess"] = boot_mean((base - mk).dropna().to_numpy(), cfg)
    ms = daily_net(sels["META_EDGE"])
    R["META_top3_excess"] = boot_mean((ms - market_daily.reindex(ms.index)).dropna().to_numpy(), cfg)
    R["market_net"] = float(mk.mean())

    # ---- day-level risk: the average forecast dip of the day's traded top 3
    t3 = base_sel.copy()
    t3["_risk"] = t3["pred_mae_q50"].abs()
    t3ok = t3[t3["status"] == "ok"]
    D = pd.DataFrame({"risk": t3.groupby("signal_day")["_risk"].mean(),
                      "real_mae": t3ok.groupby("signal_day")["mae"].mean(),
                      "real_net": t3ok.groupby("signal_day")["net"].mean()}).dropna().sort_index()
    dd = D.index.to_numpy(dtype="datetime64[ns]")
    R["day_risk"] = {"vs_dip": pooled_ci(dd, D["risk"].to_numpy(), -D["real_mae"].to_numpy(), spearman, cfg),
                     "vs_net": pooled_ci(dd, D["risk"].to_numpy(), D["real_net"].to_numpy(), spearman, cfg),
                     "quintiles": []}
    if len(D) >= 50:
        qq = pd.qcut(D["risk"].rank(method="first"), 5, labels=False)
        for qi, g in D.groupby(qq):
            R["day_risk"]["quintiles"].append({"quintile": int(qi) + 1, "days": int(len(g)),
                                               "risk": float(g["risk"].mean()), "net_bp": float(g["real_net"].mean() * 1e4),
                                               "mae": float(g["real_mae"].mean()),
                                               "bad_days": float((g["real_net"] < -0.03).mean())})
    R["_daily"] = pd.DataFrame({"D_top3_net": base, "META_top3_net": ms, "market_net": mk,
                                "day_risk": D["risk"]}).sort_index()
    return R


# ----------------------------------------------------------------------
# reconciliation with the frozen record
# ----------------------------------------------------------------------
def reconcile(T: pd.DataFrame, eng: str, ref: dict, cfg: dict) -> dict:
    t3 = T[(T["engine"] == eng) & (T["rank"] <= cfg["trade_top"])]
    ok = t3["status"] == "ok"
    R = {"days": int(t3["signal_day"].nunique()), "trades": int(len(t3)), "finished": int(ok.sum()),
         "unfinished": {k: int(v) for k, v in t3.loc[~ok, "status"].value_counts().items()},
         "mean_net_bp": float(t3.loc[ok, "net"].mean() * 1e4) if ok.any() else np.nan,
         "day_mean_net_bp": float(t3[ok].groupby("signal_day")["net"].mean().mean() * 1e4) if ok.any() else np.nan,
         "median_mfe_pct": float(t3.loc[ok, "mfe"].median() * 100) if ok.any() else np.nan,
         "median_mae_pct": float(t3.loc[ok, "mae"].median() * 100) if ok.any() else np.nan,
         "locked_share": float(t3.loc[ok, "trap"].mean()) if ok.any() else np.nan,
         "reference": ref, "warnings": []}
    fails = []
    if R["days"] != ref["days"]:
        fails.append(f"{eng}: {R['days']:,} signal days, frozen record {ref['days']:,}")
    if R["trades"] != ref["trades"]:
        fails.append(f"{eng}: {R['trades']:,} traded picks, frozen record {ref['trades']:,}")
    if "mean_net_bp" in ref:
        if not np.isfinite(R["mean_net_bp"]) or abs(R["mean_net_bp"] - ref["mean_net_bp"]) > ref["tolerance_bp"]:
            fails.append(f"{eng}: mean honest net {R['mean_net_bp']:+.2f} bp, frozen record "
                         f"{ref['mean_net_bp']:+.1f} (tolerance {ref['tolerance_bp']} bp)")
    for k in ("median_mfe_pct", "median_mae_pct"):
        if k in ref and np.isfinite(R[k]) and round(R[k], 1) != ref[k]:
            R["warnings"].append(f"{eng}: {k} {R[k]:+.2f} vs the path study's {ref[k]:+.1f} (printed to 0.1 pp)")
    R["passed"] = not fails
    R["fails"] = fails
    return R


# ----------------------------------------------------------------------
# research
# ----------------------------------------------------------------------
def _new_run_dir(base: Path, today: str) -> Path:
    base.mkdir(parents=True, exist_ok=True)
    n = 1 + sum(1 for p in base.glob(f"PM_{today}_*") if p.is_dir())
    while (base / f"PM_{today}_{n:03d}").exists():
        n += 1
    d = base / f"PM_{today}_{n:03d}"
    d.mkdir()
    return d


def _ledger_path(root: Path) -> Path:
    return Path(root) / "panel" / "research_ledger.jsonl"


def _is_rerun(root: Path, family: str = FAMILY) -> bool:
    p = _ledger_path(root)
    if not p.exists():
        return False
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            if json.loads(line).get("family") == family:
                return True
        except Exception:
            continue
    return False


def load_candidates(root: Path, market, cfg: dict, verbose=True):
    """Frozen walk-forward scores -> each engine's daily top 10 (ETFs out), the universe and market average."""
    man = market.frozen()
    ok = isinstance(man, dict) and "target" in man and all(
        e in man.get("engines", {}) and "run" in man["engines"][e] for e in cfg["engines"])
    if not ok:
        raise PreconditionError(f"the frozen-engine manifest lacks target / engines.<D|ENS>.run "
                                f"(keys: {list(man) if isinstance(man, dict) else type(man)})")
    target = man["target"]
    raw, files = {}, {}
    for eng in cfg["engines"]:
        fp = market.preds_file(man, eng)
        if not Path(fp).exists():
            raise PreconditionError(f"{eng}: walk-forward scores not found at {fp}")
        try:
            pr = pd.read_parquet(fp, columns=["timestamp", "symbol", "target", "score", "outcome"],
                                 filters=[("target", "==", target)])
        except Exception:
            pr = pd.read_parquet(fp, columns=["timestamp", "symbol", "target", "score", "outcome"])
        pr = pr[pr["target"].astype(str) == target].copy()
        if pr.empty:
            raise PreconditionError(f"{eng}: no rows for target {target} in {fp}")
        pr["signal_day"] = _days(market.naive(pr["timestamp"]).to_numpy(dtype="datetime64[ns]"))
        pr["symbol"] = pr["symbol"].astype(str)
        raw[eng] = pr[["signal_day", "symbol", "score", "outcome"]].reset_index(drop=True)
        files[eng] = {"file": str(fp), "sha256": _sha256(Path(fp)), "rows": int(len(pr)), "run": man["engines"][eng]["run"]}
        if verbose:
            _log(f"{eng}: {len(pr):,} walk-forward rows for {target}, {pr['signal_day'].nunique():,} days "
                 f"({files[eng]['run']})")
    allsyms = set().union(*[set(r["symbol"]) for r in raw.values()])
    etf = market.etf_set(sorted(allsyms))
    tops = {}
    for eng, pr in raw.items():
        p = pr[~pr["symbol"].isin(etf)].sort_values(["signal_day", "score", "symbol"], ascending=[True, False, True],
                                                    kind="mergesort")
        t = p.groupby("signal_day", sort=True).head(cfg["top"]).copy()
        t["rank"] = t.groupby("signal_day").cumcount() + 1
        tops[eng] = t[["signal_day", "symbol", "rank", "score"]].reset_index(drop=True)
    tops = engine_features(tops, cfg["engines"])
    prim = raw[cfg["primary_engine"]]
    universe = prim.loc[~prim["symbol"].isin(etf), ["signal_day", "symbol"]]
    mkt = prim[~prim["symbol"].isin(etf)].groupby("signal_day")["outcome"].mean() - cfg["cost_bps"] / 1e4
    C = pd.concat([t.assign(engine=eng) for eng, t in tops.items()], ignore_index=True)
    return man, C, universe, mkt, files, sorted(etf & allsyms)


def run_research(root: Path, market=None, verbose=True, now: Optional[dt.datetime] = None) -> dict:
    t_start = time.perf_counter()
    root = Path(root)
    decl, dsha = load_declaration()
    cfg = CFG
    market = market or ProductionMarket(root)
    if verbose:
        _log(f"{CODE_VERSION} | declaration {dsha} | Root: {root}")
    man, C, universe, mkt, files, etfs = load_candidates(root, market, cfg, verbose)
    need = set(C["symbol"]) | set(universe["symbol"]) | set(INDEX_SYMBOLS)
    if verbose:
        _log(f"loading bars for {len(need):,} series")
    syms = prepare_symbols(market, need)
    cal = np.unique(syms["NIFTY50"].d) if "NIFTY50" in syms else None
    if cal is None:
        raise PreconditionError("NIFTY50 bars missing from the cache (the trading calendar)")
    wk = pd.DatetimeIndex(cal).dayofweek
    if (wk < 5).mean() < 0.99:
        raise PreconditionError("NIFTY50 days fall on weekends - a timezone conversion shifted the dates")
    idx = index_features(syms)
    uni = universe_features(universe, syms)
    if verbose:
        _log(f"building inputs and honest trades for {len(C):,} candidates")
    T = assemble(C, syms, idx, uni, market, cfg)

    # ---- the safety stop: reproduce the frozen record before any model exists
    ref = market.reference if getattr(market, "reference", None) is not None else cfg["reference"]
    rec = {eng: reconcile(T, eng, ref[eng], cfg) for eng in cfg["engines"] if eng in ref}
    for eng, r in rec.items():
        if verbose:
            _log(f"reconcile {eng}: {r['days']:,} days, {r['trades']:,} trades, mean honest net "
                 f"{r['mean_net_bp']:+.2f} bp (frozen {r['reference'].get('mean_net_bp', 'n/a')}), median MFE "
                 f"{r['median_mfe_pct']:+.2f}%, MAE {r['median_mae_pct']:+.2f}% -> "
                 f"{'OK' if r['passed'] else 'FAIL'}")
            for w in r["warnings"]:
                _log(f"  WARNING {w}")
    bad = [f for r in rec.values() for f in r["fails"]]
    if bad:
        raise ReconciliationError("the candidates do not reproduce the frozen record - nothing was modelled:\n  "
                                  + "\n  ".join(bad))

    # ---- walk-forward per engine, then the final model
    P_all, folds, final = [], {}, {}
    for eng in cfg["engines"]:
        Te = T[T["engine"] == eng]
        if verbose:
            _log(f"{eng}: walk-forward")
        P, folds[eng] = walk_forward(Te, cal, cfg, verbose)
        P_all.append(pd.concat([Te, P], axis=1))
        tr = Te[Te["status"] == "ok"]
        final[eng] = {"models": fit_models(tr[cfg["features"]].to_numpy(float), tr, cfg),
                      "train_rows": int(len(tr)),
                      "train_last_exit": str(pd.Timestamp(tr["exit_day"].max()).date())}
    T = pd.concat(P_all).sort_values(["engine", "signal_day", "rank"]).reset_index(drop=True)
    T["meta_rank"] = T.groupby(["engine", "signal_day"])["pred_edge"].rank(ascending=False, method="first")

    if verbose:
        _log("evaluating out of sample")
    EV = {eng: evaluate(T[T["engine"] == eng], mkt, cfg) for eng in cfg["engines"]}

    # ---- outputs
    now = now or dt.datetime.now()
    out = _new_run_dir(root / OUT_SUB, now.strftime("%Y%m%d"))
    rerun = _is_rerun(root)
    keep = (["engine", "signal_day", "symbol", "rank", "score", "fold", "meta_rank", "status", "entry_day", "exit_day"]
            + PRED_COLS + list(LABELS) + cfg["features"])
    T[keep].to_parquet(out / "predictions.parquet", index=False)
    csv = T[T["fold"].notna()][["engine", "signal_day", "symbol", "rank", "meta_rank", "score"] + PRED_COLS
                               + ["status", "mfe", "mae", "net", "trap"]].copy()
    for c in ("pred_mfe_q20", "pred_mfe_q50", "pred_mfe_q80", "pred_mae_q20", "pred_mae_q50", "pred_mae_q80",
              "mfe", "mae"):
        csv[c] = (csv[c] * 100).round(2)
    for c in ("pred_edge", "net"):
        csv[c] = (csv[c] * 1e4).round(1)
    for c in ("prob_win", "prob_big", "prob_deep", "prob_trap"):
        csv[c] = (csv[c] * 100).round(1)
    csv.to_csv(out / "predictions_oos.csv", index=False)
    T[["engine", "signal_day", "symbol", "exit_day", "net", "status"]].to_parquet(out / "history.parquet", index=False)
    daily = pd.concat([EV[e]["_daily"].add_prefix(f"{e}_") for e in cfg["engines"]], axis=1)
    daily.index.name = "signal_day"
    daily.to_csv(out / "daily.csv")
    fm = out / "final_models"
    fm.mkdir()
    fj = {"code": CODE_VERSION, "declaration_sha": dsha, "features": cfg["features"], "versions": _versions(),
          "created": now.isoformat(timespec="seconds"), "engines": {}}
    for eng, f in final.items():
        p = fm / f"{eng}.pkl"
        with open(p, "wb") as fh:
            pickle.dump({"models": f["models"], "features": cfg["features"], "engine": eng}, fh, protocol=4)
        fj["engines"][eng] = {"file": p.name, "sha256": _sha256(p), "train_rows": f["train_rows"],
                              "train_last_exit": f["train_last_exit"]}
    (fm / "final_models.json").write_text(json.dumps(fj, indent=2), encoding="utf-8")

    S = {"code": CODE_VERSION, "family": FAMILY, "declaration_sha": dsha, "run": out.name, "rerun": rerun,
         "root": str(root), "created": now.isoformat(timespec="seconds"),
         "runtime_s": round(time.perf_counter() - t_start, 1), "versions": _versions(), "config": cfg,
         "frozen": {"target": man.get("target"), "engines": {e: man["engines"][e]["run"] for e in cfg["engines"]}},
         "inputs": files, "etfs_removed": etfs, "two_bar_days": COLLAPSED,
         "origins": getattr(market, "origins", {}), "reconciliation": rec, "folds": folds,
         "evaluation": {e: {k: v for k, v in EV[e].items() if not k.startswith("_")} for e in cfg["engines"]}}
    (out / "summary.json").write_text(json.dumps(S, indent=2, default=_json_default), encoding="utf-8")
    (out / "report.md").write_text(report_md(S), encoding="utf-8")
    hashes = {p.name: _sha256(p) for p in sorted(out.iterdir()) if p.is_file()}
    (out / "outputs.sha256").write_text("".join(f"{v}  {k}\n" for k, v in hashes.items()), encoding="utf-8")
    E = S["evaluation"][cfg["primary_engine"]]
    line = {"timestamp": now.isoformat(timespec="seconds"), "tool": CODE_VERSION, "family": FAMILY,
            "declaration": dsha, "run": out.name, "out": str(out), "rerun": rerun,
            "headline": {"pick_test": E["pick_test"]["verdict"],
                         "pick_diff_bp": round(E["pick_test"]["diff"]["mean"] * 1e4, 2),
                         "mae_skill": E["mae"]["skill"], "mae_beats_atr": E["mae"]["beats_atr"],
                         "mfe_skill": E["mfe"]["skill"], "mfe_beats_atr": E["mfe"]["beats_atr"],
                         "confidence_auc": round(E["win"]["auc"]["mean"], 4)}}
    lp = _ledger_path(root)
    lp.parent.mkdir(parents=True, exist_ok=True)
    with open(lp, "a", encoding="utf-8") as f:
        f.write(json.dumps(line, sort_keys=True) + "\n")
    if verbose:
        _log(f"done in {S['runtime_s']:.0f}s -> {out}")
        print(headline_text(S))
    return {"out": out, "summary": S, "table": T}


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, (pd.Timestamp, np.datetime64)):
        return str(pd.Timestamp(o))
    return str(o)


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------
def headline_text(S: dict) -> str:
    L = [f"PICK META {S['run']}{' (RERUN - not new evidence)' if S['rerun'] else ''}"]
    for eng, E in S["evaluation"].items():
        tag = "primary" if eng == S["config"]["primary_engine"] else "descriptive"
        L.append(f"  {eng} ({tag}): MAE {'SKILL' if E['mae']['skill'] else 'NO SKILL'}"
                 f"{', BEATS ATR' if E['mae']['beats_atr'] else ', not better than ATR'} | MFE "
                 f"{'SKILL' if E['mfe']['skill'] else 'NO SKILL'}"
                 f"{', BEATS ATR' if E['mfe']['beats_atr'] else ', not better than ATR'} | P(profit) AUC "
                 f"{_ci_r(E['win']['auc'])} (within day {_ci_r(E['win']['daily_auc'])}) | pick test {E['pick_test']['verdict']} "
                 f"{_ci_bp(E['pick_test']['diff'])} bp")
    return "\n".join(L)


def report_md(S: dict) -> str:
    cfg = S["config"]
    pe = cfg["primary_engine"]
    L = [f"# Pick meta model (Part 1) - {S['run']}", "",
         f"{S['code']} | declaration {S['declaration_sha']} | family {S['family']} | created {S['created']} | "
         f"runtime {S['runtime_s']:.0f} s{' | **RERUN: not new evidence**' if S['rerun'] else ''}", "",
         "Same history the engines were judged on: this describes the past, it is not new evidence. "
         "Only cards written by `publish` before the open are new evidence.", "",
         "## Verdicts (rules declared before the run)", "",
         "| engine | MAE forecast | MFE forecast | P(profit) | pick test |", "|---|---|---|---|---|"]
    for eng, E in S["evaluation"].items():
        def mag(nm):
            r = E[nm]
            return (f"{'SKILL' if r['skill'] else 'NO SKILL'}, {'BEATS ATR' if r['beats_atr'] else 'not better than ATR'}"
                    f" (daily rho {_ci_r(r['daily'])}; minus ATR {_ci_r(r['vs_atr'])})")
        tag = "" if eng == pe else " (descriptive)"
        L.append(f"| {eng}{tag} | {mag('mae')} | {mag('mfe')} | {'SKILL' if E['win']['skill'] else 'NO SKILL'}, AUC "
                 f"{_ci_r(E['win']['auc'])} | {E['pick_test']['verdict']}: {_ci_bp(E['pick_test']['diff'])} bp |")
    L += ["", "- MAE/MFE SKILL: the day's 10 forecasts rank the day's real values (mean daily Spearman, 95% lower "
          "bound > 0). BEATS ATR: better than ranking by ATR14/close alone (paired, lower bound > 0).",
          "- Pick test (primary, D only): the 3 of D's 10 with the highest forecast edge vs D's own top 3, same days, "
          "net per trade, paired; PASS needs the 95% lower bound > 0.", ""]

    L += ["## 1. Reconciliation with the frozen record (before any model)", "",
          "| engine | days | trades | finished | mean honest net bp | frozen | median MFE | median MAE | locked exits |",
          "|---|---|---|---|---|---|---|---|---|"]
    for eng, r in S["reconciliation"].items():
        ref = r["reference"]
        L.append(f"| {eng} | {r['days']:,} | {r['trades']:,} | {r['finished']:,} | {r['mean_net_bp']:+.2f} | "
                 f"{ref.get('mean_net_bp', 'n/a')} | {r['median_mfe_pct']:+.2f}% (path study "
                 f"{ref.get('median_mfe_pct', 'n/a')}) | {r['median_mae_pct']:+.2f}% (path study "
                 f"{ref.get('median_mae_pct', 'n/a')}) | {r['locked_share']:.1%} |")
        for w in r["warnings"]:
            L.append(f"- WARNING: {w}")
        if r["unfinished"]:
            L.append(f"- {eng} unfinished traded picks: {r['unfinished']}")
    L.append("")

    for eng, E in S["evaluation"].items():
        tag = "primary" if eng == pe else "descriptive"
        L += [f"## 2{'' if eng == pe else 'b'}. Forecast quality - {eng} ({tag}), out of sample {E['first']} .. "
              f"{E['last']}", "",
              f"{E['rows']:,} candidates on {E['days']:,} days; finished {E['ok_rows']:,}; status {E['status_counts']}.", "",
              "| forecast | daily rho within the 10 | ATR alone | difference | pooled rho | pooled ATR | median real | "
              "median forecast | below q20 / q50 / q80 |", "|---|---|---|---|---|---|---|---|---|"]
        for nm in ("mae", "mfe"):
            r = E[nm]
            cv = " / ".join(f"{r['coverage'][str(q)]:.0%}" for q in (20, 50, 80))
            L.append(f"| {nm.upper()} (median) | {_ci_r(r['daily'])} | {_ci_r(r['daily_atr'])} | {_ci_r(r['vs_atr'])} | "
                     f"{_ci_r(r['pooled'])} | {_ci_r(r['pooled_atr'])} | {_pct(r['median_real'])} | "
                     f"{_pct(r['median_pred'])} | {cv} |")
        L.append(f"| edge (net vs the day's 10) | {_ci_r(E['edge']['daily'])} | | | {_ci_r(E['edge']['pooled'])} | | | | |")
        L += ["", f"P(profit) within the day's 10 (mean daily AUC): {_ci_r(E['win']['daily_auc'])} - the part that can "
              "choose among the 10; the pooled AUC below also asks it to time the market.", "",
              "| event | AUC [95%] | base rate | mean forecast | Brier skill |", "|---|---|---|---|---|"]
        for nm in EVENTS:
            r = E[nm]
            L.append(f"| {EVENT_NAMES[nm]} | {_ci_r(r['auc'])} | {r['base_rate']:.1%} | {r['mean_prob']:.1%} | "
                     f"{r['brier_skill']:+.4f} |")
        L += ["", "P(profit) calibration (deciles of the forecast):", "",
              "| decile | n | forecast | real win rate | mean net bp |", "|---|---|---|---|---|"]
        for c in E["win"]["calibration"]:
            L.append(f"| {c['decile']} | {c['n']:,} | {c['pred']:.1%} | {c['real']:.1%} | {c['net_bp']:+.1f} |")
        L += ["", "Quantile coverage by fold (share of real values below the forecast; ideal 20% / 50% / 80%):", ""]
        for nm in ("mae", "mfe"):
            L.append(f"- {nm.upper()}: " + "; ".join(
                f"{f} " + "/".join(f"{v[str(q)]:.0%}" for q in (20, 50, 80)) for f, v in E[nm]["coverage_by_fold"].items()))
        L.append("")
        pt, pol = E["pick_test"], E["policies"]
        L += [f"## 3{'' if eng == pe else 'b'}. Picks - {eng} ({tag})", "",
              f"D's top 3 net per trade {_ci_bp(E['D_top3_net'])} bp; excess over buying every eligible stock "
              f"{_ci_bp(E['D_top3_excess'])} bp (market average {_bp(E['market_net'])} bp, plain exits as stage D "
              f"measured it); META_EDGE excess {_ci_bp(E['META_top3_excess'])} bp.", "",
              "| policy | net per trade bp | engine's top 3 | difference [95%] | same picks as top 3 | daily sd vs top 3 | role |",
              "|---|---|---|---|---|---|---|"]
        for nm in ("META_EDGE", "META_PWIN", "META_RISKADJ", "VETO_DEEP", "SIZE_PREVIEW"):
            p = pol[nm]
            role = ("PRIMARY - " + pt["verdict"]) if (nm == "META_EDGE" and eng == pe) else "descriptive"
            same = f"{p['same_as_D']:.0%}" if "same_as_D" in p else "-"
            L.append(f"| {nm} | {_bp(p['mean'])} | {_bp(p['base'])} | {_ci_bp(p['diff'])} | {same} | "
                     f"{p['std'] * 1e4:.0f} vs {p['base_std'] * 1e4:.0f} | {role} |")
        L += ["", "- META_EDGE: best 3 of the 10 by forecast edge (expected net minus the day's average of the 10). "
              "META_PWIN: by P(profit). META_RISKADJ: by forecast edge / "
              "|forecast MAE|. VETO_DEEP: drop the day's 30% highest P(-8% dip), then the engine's top 3. SIZE_PREVIEW: "
              "the engine's top 3 weighted by 1/|forecast MAE| (a preview of equal-risk sizing, not a portfolio).",
              "", "By year (META_EDGE vs the engine's top 3, bp per trade):", "",
              "| year | days | META_EDGE | top 3 | difference |", "|---|---|---|---|---|"]
        for y, v in pol["META_EDGE"]["by_year"].items():
            L.append(f"| {y} | {v['days']} | {_bp(v['pick'])} | {_bp(v['D'])} | {_bp(v['diff'])} |")
        dr = E["day_risk"]
        L += ["", f"## 4{'' if eng == pe else 'b'}. Day-level risk - {eng}", "",
              "The day's risk figure = average |forecast MAE| of the traded top 3. Does it rank the size of the "
              f"day's dip, and its profit? Spearman across days: vs the realised dip {_ci_r(dr['vs_dip'])}; vs the "
              f"realised net {_ci_r(dr['vs_net'])}.", "",
              "| risk quintile | days | mean risk | mean net bp | mean MAE | days below -3% |", "|---|---|---|---|---|---|"]
        for q in dr["quintiles"]:
            L.append(f"| {q['quintile']} | {q['days']} | {q['risk']:.1%} | {q['net_bp']:+.1f} | {q['mae']:+.1%} | "
                     f"{q['bad_days']:.1%} |")
        L.append("")
    L += ["## 5. Folds (walk-forward by calendar year)", "",
          "| engine | year | test days | test rows | train rows | last training exit | sessions between |",
          "|---|---|---|---|---|---|---|"]
    for eng, F in S["folds"].items():
        for f in F:
            L.append(f"| {eng} | {f['year']} | {f['test_first']} .. {f['test_last']} | {f['test_rows']:,} | "
                     f"{f['train_rows']:,} | {f['train_last_exit']} | {f['gap_sessions']} |")
    L += ["", "## 6. Provenance", "",
          f"- frozen target {S['frozen']['target']}; runs {S['frozen']['engines']}",
          "- inputs: " + "; ".join(f"{e} {v['run']} preds sha256 {v['sha256'][:16]} ({v['rows']:,} rows)"
                                   for e, v in S["inputs"].items()),
          f"- ETFs removed by the production name rule: {len(S['etfs_removed'])}",
          f"- libraries: {S['versions']}", f"- modules: {S['origins']}",
          "- outputs and their SHA-256: outputs.sha256; final models fingerprinted in final_models\\final_models.json", ""]
    return "\n".join(L)


# ----------------------------------------------------------------------
# publish: cards for recorded paper watchlists
# ----------------------------------------------------------------------
def read_ledger(root: Path) -> pd.DataFrame:
    p = Path(root) / "paper" / "ledger.jsonl"
    if not p.exists():
        raise PreconditionError(f"paper ledger not found: {p}")
    recs = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            if all(k in r for k in ("date", "engine", "rank", "symbol", "score")):
                recs.append({k: r[k] for k in ("date", "engine", "rank", "symbol", "score")})
    if not recs:
        raise PreconditionError("the paper ledger holds no watchlist records (date, engine, rank, symbol, score)")
    L = pd.DataFrame(recs)
    L["signal_day"] = _days(pd.to_datetime(L["date"]))
    L["rank"] = L["rank"].astype(int)
    L["score"] = L["score"].astype(float)
    L["symbol"] = L["symbol"].astype(str)
    return L


def read_universe(root: Path) -> Dict[np.datetime64, List[str]]:
    p = Path(root) / "paper" / "universe.jsonl"
    if not p.exists():
        raise PreconditionError(f"paper universe file not found: {p}")
    out = {}
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            out[_days(pd.to_datetime(pd.Series([r["date"]])))[0]] = [str(s) for s in r["symbols"]]
    return out


def latest_run(base: Path, run: Optional[str]) -> Path:
    if run:
        d = base / run
        if not (d / "final_models" / "final_models.json").exists():
            raise PreconditionError(f"{d} has no final models")
        return d
    runs = sorted(p for p in base.glob("PM_*") if (p / "final_models" / "final_models.json").exists())
    if not runs:
        raise PreconditionError(f"no research run with final models under {base} - run 'research' first")
    return runs[-1]


def load_final(run_dir: Path, dsha: str) -> Tuple[dict, dict]:
    J = json.loads((run_dir / "final_models" / "final_models.json").read_text(encoding="utf-8"))
    if J["declaration_sha"] != dsha:
        raise PreconditionError(f"{run_dir.name} was trained under declaration {J['declaration_sha']}, "
                                f"the current one is {dsha}")
    v = _versions()
    diff = {k: (J["versions"].get(k), v[k]) for k in ("numpy", "pandas", "scikit-learn") if J["versions"].get(k) != v[k]}
    if diff:
        raise PreconditionError(f"library versions differ from the ones the models were saved under {diff}: "
                                f"pickles are version-bound - reinstall the recorded versions")
    M = {}
    for eng, e in J["engines"].items():
        p = run_dir / "final_models" / e["file"]
        if _sha256(p) != e["sha256"]:
            raise PreconditionError(f"{p} changed since it was saved (SHA-256 mismatch) - refusing")
        with open(p, "rb") as fh:
            M[eng] = pickle.load(fh)
    return J, M


SWING_BINS = (0.05, 0.10, 0.15)             # swing size bands reported per class


def magnitude_reference(run_dir: Path, engine: str) -> dict:
    """Swing classes 1-10 = tenths of the forecast swing (median best point minus median worst point) over the
    research run's OUT-OF-SAMPLE candidates of this engine, and what the actual swing of those past picks was
    in each class. Nothing is refitted: it is a lookup table from the declared run."""
    T = pd.read_parquet(run_dir / "predictions.parquet",
                        columns=["engine", "fold", "status", "pred_mfe_q50", "pred_mae_q50", "mfe", "mae"])
    T = T[(T["engine"] == engine) & T["fold"].notna() & (T["status"] == "ok")]
    if len(T) < 500:
        raise PreconditionError(f"{run_dir.name}: only {len(T)} out-of-sample picks for {engine} - cannot build classes")
    fc = (T["pred_mfe_q50"] - T["pred_mae_q50"]).to_numpy(float)
    real = (T["mfe"] - T["mae"]).to_numpy(float)
    up, dn = T["mfe"].to_numpy(float), T["mae"].to_numpy(float)
    edges = np.quantile(fc, np.linspace(0.1, 0.9, 9))
    cls = np.searchsorted(edges, fc, side="right") + 1
    rows = []
    for k in range(1, 11):
        m = cls == k
        r = real[m]
        rows.append({"class": k, "n": int(m.sum()), "fc_median": float(np.median(fc[m])),
                     "swing_p20": float(np.percentile(r, 20)), "swing_p50": float(np.median(r)),
                     "swing_p80": float(np.percentile(r, 80)),
                     "p_lt5": float((r < SWING_BINS[0]).mean()),
                     "p_5_10": float(((r >= SWING_BINS[0]) & (r < SWING_BINS[1])).mean()),
                     "p_10_15": float(((r >= SWING_BINS[1]) & (r < SWING_BINS[2])).mean()),
                     "p_ge15": float((r >= SWING_BINS[2]).mean()),
                     "p_up5": float((up[m] >= 0.05).mean()), "p_dn8": float((dn[m] <= -0.08).mean()),
                     "up_p50": float(np.median(up[m])), "dn_p50": float(np.median(dn[m]))})
    return {"run": run_dir.name, "engine": engine, "rows": int(len(T)), "edges": [float(x) for x in edges],
            "classes": rows}


def assign_magnitude(T: pd.DataFrame, refs: Dict[str, dict]) -> pd.DataFrame:
    """Forecast swing, its class and the class history for every row (engine-specific classes)."""
    T = T.copy()
    T["swing_fc"] = T["pred_mfe_q50"] - T["pred_mae_q50"]
    cls = np.zeros(len(T), int)
    for eng, ref in refs.items():
        m = (T["engine"] == eng).to_numpy()
        cls[m] = np.searchsorted(np.asarray(ref["edges"]), T.loc[m, "swing_fc"].to_numpy(float), side="right") + 1
    T["swing_class"] = cls
    for key in ("swing_p20", "swing_p50", "swing_p80", "p_lt5", "p_5_10", "p_10_15", "p_ge15"):
        T[key] = [refs[e]["classes"][c - 1][key] for e, c in zip(T["engine"], T["swing_class"])]
    return T


# ----------------------------------------------------------------------
# confidence (v1.3): corrected chances, rules in PICK_META_CONFIDENCE_DECLARATION.json
# ----------------------------------------------------------------------
CONF_FAMILY = "pick_meta_conf_v1"
CONF_DECL_FILE = HERE / "PICK_META_CONFIDENCE_DECLARATION.json"
CONF_SUB = OUT_SUB / "confidence"
CONF_CFG = {
    "events": ["up5", "up10", "dip8", "stuck", "profit"],
    "headline": ["up5", "up10"],
    "levels": {"up5": 0.05, "up10": 0.10, "dip8": -0.08},
    "raw": {"up5": "prob_big", "up10": "implied_mfe", "dip8": "prob_deep", "stuck": "prob_trap", "profit": "prob_win"},
    "implied_tail_factor": 0.4,
    "cap": {"up10": "up5"},
    "display_raw": ["up5"],
    "first_test_year": 2023,
    "embargo_sessions": 5,
    "min_bucket": 200,
    "max_buckets": 20,
    "bands_pp": [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
    "bands_pp_stuck": [0, 1, 2, 5, 10, 20, 100],
    "rules": {"default": {"avg_gap_pp": 3.0, "level_pp": 2.0, "tail_pp": 10.0, "tail_min_picks": 200},
              "stuck": {"avg_gap_pp": 1.0, "level_pp": 1.0, "tail_clear_pp": 1.0, "tail_min_picks": 200}},
    "range": {"target": 0.60, "lo": 0.55, "hi": 0.65},
    "bootstrap": {"level": 0.95, "block": 10, "B": 1000, "seed": 7},
    "primary_engine": "D",
    "forward": {"min_days": 20, "level_pp": 2.0, "band_pp": 5.0, "bands_pp": [0, 30, 60, 100], "band_min_picks": 100,
                "checkpoint_last_signal_day": "2027-03-31"},
}
CONF_LABELS = {"up5": "P(+5% above entry)", "up10": "P(+10% above entry)", "dip8": "P(-8% dip)",
               "stuck": "P(stuck at the lower band)", "profit": "P(profit after 35 bp)"}
CONF_SHORT = {"up5": "P(+5%)", "up10": "P(+10%)", "dip8": "P(-8%)", "stuck": "P(stuck)", "profit": "P(profit)"}


def load_conf_declaration(path: Path = CONF_DECL_FILE) -> Tuple[dict, str]:
    path = Path(path)
    if not path.exists():
        raise PreconditionError(f"{path.name} not found next to pick_meta.py - copy it into open_close")
    raw = path.read_bytes()
    decl = json.loads(raw.decode("utf-8"))
    if decl.get("family_id") != CONF_FAMILY:
        raise PreconditionError(f"{path.name} is not the {CONF_FAMILY} declaration")
    if decl.get("config") != CONF_CFG:
        raise PreconditionError(f"{path.name} 'config' differs from pick_meta.py's own copy - a declaration cannot "
                                f"change after the fact. Restore the shipped file.")
    return decl, hashlib.sha256(raw).hexdigest()[:16]


def _read_hashes(path: Path) -> Dict[str, str]:
    out = {}
    if Path(path).exists():
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                out[parts[1].strip()] = parts[0]
    return out


def implied_up(x: float, q20, q50, q80, factor: float = 0.4) -> np.ndarray:
    """The chance that the best point reaches x, implied by the MFE forecast's 20/50/80% levels: straight lines
    between the levels; above the 80% level the chance keeps falling by `factor` per (q80 - q50), as it fell
    from 50% to 20%; below the 20% level the mirror image. Exact for an exponential distribution's tail."""
    q20, q50, q80 = (np.asarray(a, float) for a in (q20, q50, q80))
    lo_s = np.maximum(q50 - q20, 1e-6)
    hi_s = np.maximum(q80 - q50, 1e-6)
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        p = np.where(x >= q80, 0.2 * factor ** ((x - q80) / hi_s),
                     np.where(x >= q50, 0.5 - 0.3 * (x - q50) / hi_s,
                              np.where(x >= q20, 0.8 - 0.3 * (x - q20) / lo_s,
                                       1.0 - 0.2 * factor ** ((q20 - x) / lo_s))))
    ok = np.isfinite(q20) & np.isfinite(q50) & np.isfinite(q80)
    return np.where(ok, np.clip(p, 0.0, 1.0), np.nan)


def conf_raw(T: pd.DataFrame, ccfg: dict = CONF_CFG) -> pd.DataFrame:
    """The raw (uncorrected) chance of each event, as fractions."""
    R = pd.DataFrame(index=T.index)
    R["up5"] = T["prob_big"].astype(float)
    R["up10"] = implied_up(ccfg["levels"]["up10"], T["pred_mfe_q20"], T["pred_mfe_q50"], T["pred_mfe_q80"],
                           ccfg["implied_tail_factor"])
    R["dip8"] = T["prob_deep"].astype(float)
    R["stuck"] = T["prob_trap"].astype(float)
    R["profit"] = T["prob_win"].astype(float)
    return R[ccfg["events"]]


def conf_outcomes(T: pd.DataFrame, ccfg: dict = CONF_CFG) -> pd.DataFrame:
    """1 / 0 per event for finished trades (status ok), NaN otherwise."""
    ok = (T["status"] == "ok").to_numpy()
    lv = ccfg["levels"]
    O = pd.DataFrame(index=T.index)
    O["up5"] = np.where(ok, (T["mfe"] >= lv["up5"]).astype(float), np.nan)
    O["up10"] = np.where(ok, (T["mfe"] >= lv["up10"]).astype(float), np.nan)
    O["dip8"] = np.where(ok, (T["mae"] <= lv["dip8"]).astype(float), np.nan)
    O["stuck"] = np.where(ok, T["trap"].astype(float), np.nan)
    O["profit"] = np.where(ok, T["win"].astype(float), np.nan)
    return O[ccfg["events"]]


def pava(y, w) -> np.ndarray:
    """Weighted pool-adjacent-violators: the closest sequence that never falls."""
    vals, wts, cnt = [], [], []
    for yi, wi in zip(np.asarray(y, float), np.asarray(w, float)):
        vals.append(float(yi)); wts.append(float(wi)); cnt.append(1)
        while len(vals) > 1 and vals[-2] > vals[-1]:
            v2, w2, c2 = vals.pop(), wts.pop(), cnt.pop()
            v1, w1, c1 = vals.pop(), wts.pop(), cnt.pop()
            vals.append((v1 * w1 + v2 * w2) / (w1 + w2)); wts.append(w1 + w2); cnt.append(c1 + c2)
    return np.repeat(np.asarray(vals, float), cnt)


def fit_table(s, y, min_bucket: int, max_buckets: int) -> dict:
    """A correction table: equal-count buckets of the raw score (>= min_bucket rows, <= max_buckets), each
    bucket's event rate, pooled so the rate never falls as the raw score rises. Buckets whose centres tie are
    merged first."""
    s, y = np.asarray(s, float), np.asarray(y, float)
    m = np.isfinite(s) & np.isfinite(y)
    s, y = s[m], y[m]
    n = len(s)
    if n == 0:
        raise PreconditionError("a correction table needs at least one finished row")
    o = np.argsort(s, kind="mergesort")
    s, y = s[o], y[o]
    k = int(max(1, min(max_buckets, n // min_bucket)))
    b = (np.arange(n) * k) // n
    cnt = np.bincount(b, minlength=k).astype(float)
    xs = np.bincount(b, weights=s, minlength=k) / cnt
    ys = np.bincount(b, weights=y, minlength=k) / cnt
    ux, inv = np.unique(xs, return_inverse=True)
    cw = np.bincount(inv, weights=cnt)
    cy = np.bincount(inv, weights=ys * cnt) / cw
    return {"x": [float(v) for v in ux], "y": [float(v) for v in pava(cy, cw)], "w": [int(v) for v in cw],
            "n": int(n), "base_rate": float(y.mean())}


def apply_table(tab: dict, s) -> np.ndarray:
    s = np.asarray(s, float)
    x, y = np.asarray(tab["x"], float), np.asarray(tab["y"], float)
    out = np.interp(s, x, y) if len(x) > 1 else np.full(s.shape, y[0])
    return np.where(np.isfinite(s), out, np.nan)


def conf_cap(C: pd.DataFrame, ccfg: dict = CONF_CFG) -> pd.DataFrame:
    C = C.copy()
    for a, b in ccfg["cap"].items():
        if a in C and b in C:
            C[a] = np.where(C[a].notna() & C[b].notna(), np.minimum(C[a], C[b]), C[a])
    return C


def session_calendar(T: pd.DataFrame) -> np.ndarray:
    parts = [pd.to_datetime(T[c]).dropna().to_numpy(dtype="datetime64[ns]") for c in ("signal_day", "entry_day", "exit_day")
             if c in T]
    return np.unique(_days(np.concatenate(parts)))


def conf_walk_forward(Te: pd.DataFrame, cal: np.ndarray, ccfg: dict = CONF_CFG):
    """One engine: corrected chances for the test years, each year from a table of earlier out-of-sample rows
    whose trade exited at least embargo_sessions sessions before the year's first signal day."""
    R, O = conf_raw(Te, ccfg), conf_outcomes(Te, ccfg)
    yr = pd.DatetimeIndex(Te["signal_day"]).year.to_numpy()
    oos = Te["fold"].notna().to_numpy()
    okm = (Te["status"] == "ok").to_numpy()
    ex = pd.to_datetime(Te["exit_day"]).to_numpy(dtype="datetime64[ns]")
    C = pd.DataFrame(np.nan, index=Te.index, columns=ccfg["events"])
    B = pd.DataFrame(np.nan, index=Te.index, columns=ccfg["events"])
    folds = []
    for y in sorted(set(yr[oos & (yr >= ccfg["first_test_year"])])):
        te = oos & (yr == y)
        start = np.datetime64(pd.Timestamp(Te.loc[te, "signal_day"].min()), "ns")
        p = int(np.searchsorted(cal, start))
        if p - ccfg["embargo_sessions"] - 1 < 0:
            raise PreconditionError(f"year {y}: the calendar does not reach {ccfg['embargo_sessions'] + 1} sessions back")
        cut = cal[p - ccfg["embargo_sessions"] - 1]
        with np.errstate(invalid="ignore"):
            win = oos & okm & (ex <= cut)
        if win.sum() < ccfg["min_bucket"]:
            raise PreconditionError(f"year {y}: only {int(win.sum())} earlier out-of-sample rows for the table")
        last = ex[win].max()
        folds.append({"year": int(y), "test_rows": int(te.sum()), "table_rows": int(win.sum()),
                      "table_last_exit": str(pd.Timestamp(last).date()),
                      "sessions_between": int(p - int(np.searchsorted(cal, last)) - 1)})
        for ev in ccfg["events"]:
            tab = fit_table(R.loc[win, ev], O.loc[win, ev], ccfg["min_bucket"], ccfg["max_buckets"])
            C.loc[te, ev] = apply_table(tab, R.loc[te, ev].to_numpy())
            B.loc[te, ev] = tab["base_rate"]
    return conf_cap(C, ccfg), B, folds


def _boot_counts(nD: int, ccfg: dict, offset: int) -> np.ndarray:
    """B x nD: how many times each day is drawn in each circular-block resample (blocks of consecutive days)."""
    bs = ccfg["bootstrap"]
    rng = np.random.default_rng(bs["seed"] + offset)
    L, B = bs["block"], bs["B"]
    nb = int(np.ceil(nD / L))
    st = rng.integers(0, nD, size=(B, nb))
    ix = ((st[:, :, None] + np.arange(L)[None, None, :]).reshape(B, -1)[:, :nD]) % nD
    flat = (ix + (np.arange(B) * nD)[:, None]).ravel()
    return np.bincount(flat, minlength=B * nD).reshape(B, nD).astype(float)


def reliability(days, p, y, bands_pp, ccfg: dict = CONF_CFG, offset: int = 11, with_ci: bool = True,
                tail_min: int = 200) -> dict:
    """Said vs happened by fixed bands of the stated chance, with day-block intervals."""
    days = np.asarray(days, dtype="datetime64[ns]")
    p, y = np.asarray(p, float), np.asarray(y, float)
    m = np.isfinite(p) & np.isfinite(y)
    days, p, y = days[m], p[m], y[m]
    if len(p) == 0:
        return {"n": 0, "days": 0, "bands": [], "said": np.nan, "happened": np.nan, "level": np.nan, "level_lo": np.nan,
                "level_hi": np.nan, "avg_gap": np.nan, "tail": None}
    edges = np.asarray(bands_pp, float) / 100.0
    nbd = len(edges) - 1
    b = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, nbd - 1)
    u, di = np.unique(days, return_inverse=True)
    nD = len(u)
    idx = di * nbd + b
    n = np.bincount(idx, minlength=nD * nbd).reshape(nD, nbd).astype(float)
    ys = np.bincount(idx, weights=y, minlength=nD * nbd).reshape(nD, nbd)
    ps = np.bincount(idx, weights=p, minlength=nD * nbd).reshape(nD, nbd)
    N, Y, P = n.sum(0), ys.sum(0), ps.sum(0)
    lvl = ccfg["bootstrap"]["level"]
    q = [100 * (1 - lvl) / 2, 100 * (1 + lvl) / 2]
    ci = with_ci and nD >= 10
    if ci:
        Cb = _boot_counts(nD, ccfg, offset)
        Nb, Yb, Pb = Cb @ n, Cb @ ys, Cb @ ps
        with np.errstate(invalid="ignore", divide="ignore"):
            hb = Yb / Nb
            gb = (Yb - Pb) / Nb
            lb = (Yb.sum(1) - Pb.sum(1)) / Nb.sum(1)
            ab = Yb.sum(1) / Nb.sum(1)
    rows = []
    for k in range(nbd):
        if N[k] == 0:
            continue
        r = {"lo_pp": float(bands_pp[k]), "hi_pp": float(bands_pp[k + 1]), "n": int(N[k]), "said": float(P[k] / N[k]),
             "happened": float(Y[k] / N[k]), "gap": float((Y[k] - P[k]) / N[k])}
        if ci:
            with np.errstate(invalid="ignore"):
                hl, hh = np.nanpercentile(hb[:, k], q) if np.isfinite(hb[:, k]).any() else (np.nan, np.nan)
                gl, gh = np.nanpercentile(gb[:, k], q) if np.isfinite(gb[:, k]).any() else (np.nan, np.nan)
            r.update({"happened_lo": float(hl), "happened_hi": float(hh), "gap_lo": float(gl), "gap_hi": float(gh)})
        rows.append(r)
    tot = N.sum()
    big = [r for r in rows if r["n"] >= tail_min]

    def clear(r):                           # how far the band is off at least, with 95% confidence (0 = not clearly)
        lo, hi = r.get("gap_lo", np.nan), r.get("gap_hi", np.nan)
        if not (np.isfinite(lo) and np.isfinite(hi)):
            return np.nan
        return float(lo) if lo > 0 else (float(-hi) if hi < 0 else 0.0)
    out = {"n": int(tot), "days": int(nD), "bands": rows, "said": float(P.sum() / tot), "happened": float(Y.sum() / tot),
           "level": float((Y.sum() - P.sum()) / tot),
           "avg_gap": float(sum(r["n"] * abs(r["gap"]) for r in rows) / tot),
           "tail": max(abs(r["gap"]) for r in big) if big else None,
           "tail_clear": (max(clear(r) for r in big) if big and ci else None)}
    if ci:
        lo, hi = np.nanpercentile(lb, q)
        out["level_lo"], out["level_hi"] = float(lo), float(hi)
        lo, hi = np.nanpercentile(ab, q)
        out["happened_lo"], out["happened_hi"] = float(lo), float(hi)
    else:
        out["level_lo"] = out["level_hi"] = out["happened_lo"] = out["happened_hi"] = np.nan
    return out


def brier_skill(days, p, y, base, ccfg: dict = CONF_CFG, offset: int = 13) -> dict:
    """1 - Brier(p) / Brier(base rate), with a day-block interval."""
    days = np.asarray(days, dtype="datetime64[ns]")
    p, y, base = np.asarray(p, float), np.asarray(y, float), np.broadcast_to(np.asarray(base, float), np.shape(p))
    m = np.isfinite(p) & np.isfinite(y) & np.isfinite(base)
    days, p, y, base = days[m], p[m], y[m], base[m]
    if len(p) == 0:
        return {"skill": np.nan, "lo": np.nan, "hi": np.nan}
    u, di = np.unique(days, return_inverse=True)
    se = np.bincount(di, weights=(p - y) ** 2)
    sr = np.bincount(di, weights=(base - y) ** 2)
    if sr.sum() <= 0:
        return {"skill": np.nan, "lo": np.nan, "hi": np.nan}
    est = 1.0 - se.sum() / sr.sum()
    if len(u) < 10:
        return {"skill": float(est), "lo": np.nan, "hi": np.nan}
    Cb = _boot_counts(len(u), ccfg, offset)
    with np.errstate(invalid="ignore", divide="ignore"):
        bs = 1.0 - (Cb @ se) / (Cb @ sr)
    lvl = ccfg["bootstrap"]["level"]
    lo, hi = np.nanpercentile(bs, [100 * (1 - lvl) / 2, 100 * (1 + lvl) / 2])
    return {"skill": float(est), "lo": float(lo), "hi": float(hi)}


def _rules(ev: str, ccfg: dict = CONF_CFG) -> dict:
    return ccfg["rules"]["stuck" if ev == "stuck" else "default"]


def _bands(ev: str, ccfg: dict = CONF_CFG) -> list:
    return ccfg["bands_pp_stuck"] if ev == "stuck" else ccfg["bands_pp"]


def conf_verdict(rel: dict, sk: dict, rules: dict) -> str:
    if not (np.isfinite(sk.get("lo", np.nan)) and sk["lo"] > 0):
        return "NO SKILL"
    tail_ok = True
    if "tail_pp" in rules:                  # the largest gap of a band with 200+ picks
        tail_ok = rel["tail"] is None or rel["tail"] * 100 <= rules["tail_pp"]
    if "tail_clear_pp" in rules:            # no band of 200+ picks clearly (95%) off by more than this
        tc = rel.get("tail_clear")
        tail_ok = tail_ok and (tc is None or not np.isfinite(tc) or tc * 100 <= rules["tail_clear_pp"])
    if rel["avg_gap"] * 100 <= rules["avg_gap_pp"] and abs(rel["level"]) * 100 <= rules["level_pp"] and tail_ok:
        return "CALIBRATED"
    return "MISCALIBRATED"


def range_walk_forward(Te: pd.DataFrame, cal: np.ndarray, ccfg: dict = CONF_CFG) -> dict:
    """The 6-in-10 swing range out of time: classes and class ranges from earlier out-of-sample rows only."""
    fc = (Te["pred_mfe_q50"] - Te["pred_mae_q50"]).to_numpy(float)
    real = (Te["mfe"] - Te["mae"]).to_numpy(float)
    yr = pd.DatetimeIndex(Te["signal_day"]).year.to_numpy()
    oos = Te["fold"].notna().to_numpy()
    okm = (Te["status"] == "ok").to_numpy()
    ex = pd.to_datetime(Te["exit_day"]).to_numpy(dtype="datetime64[ns]")
    sd = Te["signal_day"].to_numpy(dtype="datetime64[ns]")
    inside_all, day_all, by_year = [], [], {}
    for y in sorted(set(yr[oos & (yr >= ccfg["first_test_year"])])):
        te = oos & (yr == y)
        start = np.datetime64(pd.Timestamp(Te.loc[te, "signal_day"].min()), "ns")
        p = int(np.searchsorted(cal, start))
        cut = cal[p - ccfg["embargo_sessions"] - 1]
        with np.errstate(invalid="ignore"):
            win = oos & okm & (ex <= cut)
        edges = np.quantile(fc[win], np.linspace(0.1, 0.9, 9))
        cw = np.searchsorted(edges, fc[win], side="right") + 1
        lo = np.array([np.percentile(real[win][cw == k], 20) if (cw == k).any() else np.nan for k in range(1, 11)])
        hi = np.array([np.percentile(real[win][cw == k], 80) if (cw == k).any() else np.nan for k in range(1, 11)])
        t = te & okm
        ct = np.searchsorted(edges, fc[t], side="right") + 1
        ins = ((real[t] >= lo[ct - 1]) & (real[t] <= hi[ct - 1])).astype(float)
        by_year[str(int(y))] = {"picks": int(t.sum()), "inside": float(ins.mean()) if len(ins) else np.nan}
        inside_all.append(ins)
        day_all.append(sd[t])
    ins = np.concatenate(inside_all) if inside_all else np.zeros(0)
    dd = np.concatenate(day_all) if day_all else np.zeros(0, dtype="datetime64[ns]")
    rel = reliability(dd, np.full(len(ins), ccfg["range"]["target"]), ins, [0, 100], ccfg, offset=17)
    cov = rel["happened"]
    ok = ccfg["range"]["lo"] <= cov <= ccfg["range"]["hi"] if np.isfinite(cov) else False
    return {"inside": cov, "inside_lo": rel["bands"][0].get("happened_lo", np.nan) if rel["bands"] else np.nan,
            "inside_hi": rel["bands"][0].get("happened_hi", np.nan) if rel["bands"] else np.nan, "picks": int(len(ins)),
            "by_year": by_year, "verdict": "CALIBRATED" if ok else "MISCALIBRATED"}


def calibrate_table(T: pd.DataFrame, cal: np.ndarray, ccfg: dict = CONF_CFG, verbose: bool = False) -> dict:
    """Everything the calibrate step decides, from a predictions table (pure: no files)."""
    out = {"engines": {}, "rows": {}}
    for eng in [e for e in CFG["engines"] if (T["engine"] == e).any()]:
        Te = T[T["engine"] == eng]
        C, Bse, folds = conf_walk_forward(Te, cal, ccfg)
        R, O = conf_raw(Te, ccfg), conf_outcomes(Te, ccfg)
        yr = pd.DatetimeIndex(Te["signal_day"]).year.to_numpy()
        test = (Te["fold"].notna().to_numpy() & (yr >= ccfg["first_test_year"]) & (Te["status"] == "ok").to_numpy())
        days = Te["signal_day"].to_numpy(dtype="datetime64[ns]")
        E = {"folds": folds, "events": {}}
        for k, ev in enumerate(ccfg["events"]):
            rl = _rules(ev, ccfg)
            bands = _bands(ev, ccfg)
            p, y, bse = C[ev].to_numpy(float), O[ev].to_numpy(float), Bse[ev].to_numpy(float)
            rc = reliability(days[test], p[test], y[test], bands, ccfg, offset=11 + k, tail_min=rl["tail_min_picks"])
            sk = brier_skill(days[test], p[test], y[test], bse[test], ccfg, offset=31 + k)
            rr = reliability(days[test], R[ev].to_numpy(float)[test], y[test], bands, ccfg, offset=51 + k,
                             tail_min=rl["tail_min_picks"])
            skr = brier_skill(days[test], R[ev].to_numpy(float)[test], y[test], bse[test], ccfg, offset=71 + k)
            t3 = test & (Te["rank"] <= CFG["trade_top"]).to_numpy()
            r3 = reliability(days[t3], p[t3], y[t3], bands, ccfg, offset=91 + k, tail_min=rl["tail_min_picks"])
            by = {}
            for yy in sorted(set(yr[test])):
                mm = test & (yr == yy)
                ry = reliability(days[mm], p[mm], y[mm], bands, ccfg, with_ci=False, tail_min=rl["tail_min_picks"])
                by[str(int(yy))] = {"n": ry["n"], "said": ry["said"], "happened": ry["happened"], "avg_gap": ry["avg_gap"]}
            E["events"][ev] = {"corrected": rc, "skill": sk, "raw": rr, "raw_skill": skr, "top3": r3, "by_year": by,
                               "verdict": conf_verdict(rc, sk, rl), "raw_verdict": conf_verdict(rr, skr, rl)}
        E["range"] = range_walk_forward(Te, cal, ccfg)
        allm = Te["fold"].notna().to_numpy() & (Te["status"] == "ok").to_numpy()
        E["tables"] = {ev: {**fit_table(R.loc[allm, ev], O.loc[allm, ev], ccfg["min_bucket"], ccfg["max_buckets"]),
                            "verdict": E["events"][ev]["verdict"], "raw_verdict": E["events"][ev]["raw_verdict"],
                            "shown": "raw" if ev in ccfg["display_raw"] else "corrected", "raw": ccfg["raw"][ev]}
                       for ev in ccfg["events"]}
        out["engines"][eng] = E
        rows = Te[["engine", "signal_day", "symbol", "rank", "fold", "status"]].copy()
        rows["test"] = test
        for ev in ccfg["events"]:
            rows[f"raw_{ev}_pct"] = (R[ev] * 100).round(3)
            rows[f"{ev}_pct"] = (C[ev] * 100).round(3)
            rows[f"happened_{ev}"] = O[ev]
        out["rows"][eng] = rows
        if verbose:
            _log(f"{eng}: " + " | ".join(f"{CONF_SHORT[ev]} {E['events'][ev]['verdict']}" for ev in ccfg["events"])
                 + f" | range {E['range']['inside']:.1%} inside")
    return out


def _new_dir(base: Path, prefix: str, today: str) -> Path:
    base.mkdir(parents=True, exist_ok=True)
    n = 1 + sum(1 for p in base.glob(f"{prefix}_{today}_*") if p.is_dir())
    while (base / f"{prefix}_{today}_{n:03d}").exists():
        n += 1
    d = base / f"{prefix}_{today}_{n:03d}"
    d.mkdir()
    return d


def run_calibrate(root: Path, run: Optional[str] = None, verbose: bool = True,
                  now: Optional[dt.datetime] = None) -> dict:
    """The declared confidence check on a research run's out-of-sample picks, and the tables publish uses."""
    t0 = time.perf_counter()
    root = Path(root)
    decl, csha = load_conf_declaration()
    _, dsha = load_declaration()
    ccfg = CONF_CFG
    base = root / OUT_SUB
    rdir = latest_run(base, run)
    J = json.loads((rdir / "final_models" / "final_models.json").read_text(encoding="utf-8"))
    if J["declaration_sha"] != dsha:
        raise PreconditionError(f"{rdir.name} was trained under declaration {J['declaration_sha']}, the current one is "
                                f"{dsha} - publish would refuse its models, so no tables are built for it")
    pf = rdir / "predictions.parquet"
    if not pf.exists():
        raise PreconditionError(f"{pf} not found")
    want = _read_hashes(rdir / "outputs.sha256").get("predictions.parquet")
    psha = _sha256(pf)
    if want != psha:
        raise PreconditionError(f"{pf} does not match the research run's outputs.sha256 - refusing")
    if verbose:
        _log(f"{CODE_VERSION} | confidence declaration {csha} | research run {rdir.name} | Root: {root}")
    cols = ["engine", "signal_day", "symbol", "rank", "fold", "status", "entry_day", "exit_day", "pred_mfe_q20",
            "pred_mfe_q50", "pred_mfe_q80", "pred_mae_q50", "prob_big", "prob_deep", "prob_trap", "prob_win",
            "mfe", "mae", "win", "trap"]
    T = pd.read_parquet(pf, columns=cols)
    T["signal_day"] = _days(T["signal_day"])
    for c in ("entry_day", "exit_day"):
        T[c] = pd.to_datetime(T[c]).astype("datetime64[ns]")
    T = T.sort_values(["engine", "signal_day", "rank"], kind="mergesort").reset_index(drop=True)
    cal = session_calendar(T)
    res = calibrate_table(T, cal, ccfg, verbose=verbose)
    now = now or dt.datetime.now()
    out = _new_dir(root / CONF_SUB, "PC", now.strftime("%Y%m%d"))
    rerun = _is_rerun(root, CONF_FAMILY)
    tables = {"code": CODE_VERSION, "family": CONF_FAMILY, "declaration_sha": csha, "pick_meta_declaration_sha": dsha,
              "source_run": rdir.name, "source_predictions_sha256": psha, "created": now.isoformat(timespec="seconds"),
              "engines": {e: v["tables"] for e, v in res["engines"].items()},
              "range": {e: v["range"]["verdict"] for e, v in res["engines"].items()}}
    (out / "tables.json").write_text(json.dumps(tables, indent=2, default=_json_default), encoding="utf-8")
    rows = pd.concat(res["rows"].values(), ignore_index=True)
    rows["signal_day"] = pd.to_datetime(rows["signal_day"]).dt.date.astype(str)
    rows.to_csv(out / "calibrated_oos.csv", index=False)
    long = []
    for eng, E in res["engines"].items():
        for ev, R in E["events"].items():
            for kind in ("corrected", "raw", "top3"):
                for b in R[kind]["bands"]:
                    long.append({"engine": eng, "event": ev, "kind": kind, **b})
    pd.DataFrame(long).to_csv(out / "reliability.csv", index=False)
    S = {"code": CODE_VERSION, "family": CONF_FAMILY, "declaration_sha": csha, "run": out.name, "rerun": rerun,
         "source_run": rdir.name, "source_predictions_sha256": psha, "root": str(root),
         "created": now.isoformat(timespec="seconds"), "runtime_s": round(time.perf_counter() - t0, 1),
         "versions": _versions(), "config": ccfg, "calendar_sessions": int(len(cal)),
         "rows": {e: int(len(r)) for e, r in res["rows"].items()},
         "evaluation": {e: {k: v for k, v in E.items() if k != "tables"} for e, E in res["engines"].items()}}
    (out / "summary.json").write_text(json.dumps(S, indent=2, default=_json_default), encoding="utf-8")
    (out / "report.md").write_text(conf_report_md(S, tables), encoding="utf-8")
    hashes = {p.name: _sha256(p) for p in sorted(out.iterdir()) if p.is_file()}
    (out / "outputs.sha256").write_text("".join(f"{v}  {k}\n" for k, v in hashes.items()), encoding="utf-8")
    pe = ccfg["primary_engine"]
    line = {"timestamp": now.isoformat(timespec="seconds"), "tool": CODE_VERSION, "family": CONF_FAMILY,
            "declaration": csha, "run": out.name, "source_run": rdir.name, "out": str(out), "rerun": rerun,
            "headline": {ev: res["engines"][pe]["events"][ev]["verdict"] for ev in ccfg["events"]}
            | {"range": res["engines"][pe]["range"]["verdict"]}
            | {f"{ev}_shown_model_own": res["engines"][pe]["events"][ev]["raw_verdict"] for ev in ccfg["display_raw"]}}
    lp = _ledger_path(root)
    lp.parent.mkdir(parents=True, exist_ok=True)
    with open(lp, "a", encoding="utf-8") as f:
        f.write(json.dumps(line, sort_keys=True) + "\n")
    if verbose:
        _log(f"done in {S['runtime_s']:.0f}s -> {out}")
        print(conf_headline_text(S))
    return {"out": out, "summary": S, "tables": tables, "result": res}


def _pp(x, nd=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:.{nd}f}"


def _spp(x, nd=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 100:+.{nd}f}"


def _tail_text(ev: str, c: dict) -> str:
    if "tail_clear_pp" in _rules(ev):
        t = c.get("tail_clear")
        return f"clearly off by {_pp(t, 1) if t is not None else 'n/a'}"
    return f"tail {_pp(c['tail'], 1) if c['tail'] is not None else 'n/a'}"


def conf_headline_text(S: dict) -> str:
    L = [f"CONFIDENCE CHECK {S['run']} on {S['source_run']}{' (RERUN - not new evidence)' if S['rerun'] else ''} "
         f"(test years {S['config']['first_test_year']}+, rules fixed before the run)"]
    for eng, E in S["evaluation"].items():
        tag = "primary" if eng == S["config"]["primary_engine"] else "descriptive"
        parts = []
        for ev, R in E["events"].items():
            c = R["corrected"]
            parts.append(f"{CONF_SHORT[ev]} {R['verdict']} (avg gap {_pp(c['avg_gap'], 2)}, level {_spp(c['level'], 2)}, "
                         f"{_tail_text(ev, c)} pts)")
        L.append(f"  {eng} ({tag}): " + " | ".join(parts))
        for ev in S["config"].get("display_raw", []):
            R = E["events"][ev]
            L.append(f"  {eng} card shows the model's own {CONF_SHORT[ev]} (amendment b): {R['raw_verdict']} (avg gap "
                     f"{_pp(R['raw']['avg_gap'], 2)}, level {_spp(R['raw']['level'], 2)}, {_tail_text(ev, R['raw'])} pts)")
        L.append(f"  {eng} 6-in-10 swing range: {E['range']['inside']:.1%} inside -> {E['range']['verdict']}")
    return "\n".join(L)


def conf_report_md(S: dict, tables: dict) -> str:
    cfg = S["config"]
    pe = cfg["primary_engine"]
    L = [f"# Confidence check - {S['run']} (on research run {S['source_run']})", "",
         f"{S['code']} | declaration {S['declaration_sha']} | family {S['family']} | created {S['created']} | runtime "
         f"{S['runtime_s']:.0f} s{' | **RERUN: not new evidence**' if S['rerun'] else ''}", "",
         "Out of sample, year by year: each year's correction table was built only from earlier years' picks "
         f"(trades that exited at least {cfg['embargo_sessions']} sessions before the year began), then judged on that "
         "year. It describes the past; only on-time forward cards are new evidence.", "",
         "## Verdicts (rules declared before the run)", "",
         "| engine | number | verdict | average gap | level | tail | Brier skill [95%] | uncorrected: average gap / verdict |",
         "|---|---|---|---|---|---|---|---|"]
    for eng, E in S["evaluation"].items():
        for ev, R in E["events"].items():
            c, r, sk = R["corrected"], R["raw"], R["skill"]
            L.append(f"| {eng}{'' if eng == pe else ' (descriptive)'} | {CONF_LABELS[ev]}{' (headline)' if ev in cfg['headline'] else ''} | "
                     f"**{R['verdict']}** | {_pp(c['avg_gap'], 2)} | {_spp(c['level'], 2)} | "
                     f"{_tail_text(ev, c)} | {sk['skill']:+.4f} [{sk['lo']:+.4f}, {sk['hi']:+.4f}] | "
                     f"{_pp(r['avg_gap'], 2)} / {R['raw_verdict']}"
                     f"{' - **the card shows this one (amendment b)**' if ev in cfg.get('display_raw', []) else ''} |")
        L.append(f"| {eng} | 6-in-10 swing range | **{E['range']['verdict']}** | inside {E['range']['inside']:.1%} "
                 f"[{E['range']['inside_lo']:.1%}, {E['range']['inside_hi']:.1%}] of {E['range']['picks']:,} (target 60%, "
                 f"55-65%) | | | | |")
    L += ["", "- Points = percentage points. Average gap = pick-weighted mean |happened - said| over the bands; level = "
          "happened - said over all picks; tail = largest |gap| in a band of 200+ picks.",
          "- CALIBRATED: average gap <= 3.0, |level| <= 2.0, tail <= 10.0. P(stuck), a rare event: average gap <= 1.0, "
          "|level| <= 1.0 and no band of 200+ picks clearly off by more than 1.0 (its 95% gap interval entirely beyond "
          "+/-1.0). NO SKILL: the Brier skill's 95% lower bound <= 0 (no better than quoting the past base rate) - the "
          "card shows the base rate.", ""]
    for eng, E in S["evaluation"].items():
        tag = "primary" if eng == pe else "descriptive"
        L += [f"## {eng} ({tag}) - said vs happened, corrected, test years pooled", ""]
        for ev, R in E["events"].items():
            c = R["corrected"]
            L += [f"### {CONF_LABELS[ev]} - {R['verdict']}", "",
                  f"{c['n']:,} picks on {c['days']:,} days; said {_pp(c['said'])}%, happened {_pp(c['happened'])}% "
                  f"(level {_spp(c['level'], 2)} [{_spp(c['level_lo'], 2)}, {_spp(c['level_hi'], 2)}] pts).", "",
                  "| band | picks | said | happened [95%] | gap [95%] |", "|---|---|---|---|---|"]
            for b in c["bands"]:
                L.append(f"| {b['lo_pp']:g}-{b['hi_pp']:g}% | {b['n']:,} | {_pp(b['said'])}% | {_pp(b['happened'])}% "
                         f"[{_pp(b.get('happened_lo'))}, {_pp(b.get('happened_hi'))}] | {_spp(b['gap'])} "
                         f"[{_spp(b.get('gap_lo'))}, {_spp(b.get('gap_hi'))}] |")
            L += ["", "By year: " + "; ".join(f"{y} said {_pp(v['said'])}% happened {_pp(v['happened'])}% (gap avg "
                                               f"{_pp(v['avg_gap'])})" for y, v in R["by_year"].items()), "",
                  f"Uncorrected (the v1.2 number) on the same picks: said {_pp(R['raw']['said'])}%, happened "
                  f"{_pp(R['raw']['happened'])}%, average gap {_pp(R['raw']['avg_gap'], 2)}, level {_spp(R['raw']['level'], 2)}, "
                  f"{_tail_text(ev, R['raw'])} -> {R['raw_verdict']}.",
                  f"Ranks 1-3 only (descriptive): {R['top3']['n']:,} picks, said {_pp(R['top3']['said'])}%, happened "
                  f"{_pp(R['top3']['happened'])}%, average gap {_pp(R['top3']['avg_gap'], 2)}.", ""]
        L += ["### 6-in-10 swing range (out of time)", "",
              "; ".join(f"{y}: {v['inside']:.1%} of {v['picks']:,}" for y, v in E["range"]["by_year"].items()), ""]
    L += ["## Correction tables used by publish (all out-of-sample picks)", ""]
    for eng, tb in tables["engines"].items():
        for ev, t in tb.items():
            pts = ", ".join(f"{x * 100:.1f}->{y * 100:.1f}" for x, y in zip(t["x"], t["y"]))
            L.append(f"- {eng} {CONF_SHORT[ev]} ({t['raw']}; {t['n']:,} picks, base rate {t['base_rate']:.1%}; "
                     f"{t['verdict']}): raw% -> corrected% {pts}")
    L += ["", "## Folds", "", "| engine | year | test rows | table rows | table's last exit | sessions between |",
          "|---|---|---|---|---|---|"]
    for eng, E in S["evaluation"].items():
        for f in E["folds"]:
            L.append(f"| {eng} | {f['year']} | {f['test_rows']:,} | {f['table_rows']:,} | {f['table_last_exit']} | "
                     f"{f['sessions_between']} |")
    L += ["", "## Provenance", "", f"- research run {S['source_run']}; predictions.parquet sha256 "
          f"{S['source_predictions_sha256'][:16]} (matches its outputs.sha256)", f"- rows {S['rows']}; calendar "
          f"{S['calendar_sessions']:,} sessions", f"- libraries: {S['versions']}", "- outputs and their SHA-256: outputs.sha256", ""]
    return "\n".join(L)


def find_conf(base: Path, source_run: str, csha: str) -> Optional[Path]:
    """The latest calibrate run for these models under the current confidence declaration."""
    d = Path(base) / "confidence"
    if not d.exists():
        return None
    good = []
    for p in sorted(d.glob("PC_*")):
        f = p / "tables.json"
        if not f.exists():
            continue
        try:
            J = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        if J.get("source_run") == source_run and J.get("declaration_sha") == csha:
            good.append(p)
    return good[-1] if good else None


def load_conf_tables(cdir: Path) -> dict:
    f = Path(cdir) / "tables.json"
    if _read_hashes(Path(cdir) / "outputs.sha256").get("tables.json") != _sha256(f):
        raise PreconditionError(f"{f} changed since calibrate wrote it (SHA-256 mismatch) - refusing")
    return json.loads(f.read_text(encoding="utf-8"))


def shown_verdict(t: dict, ev: str, ccfg: dict = CONF_CFG) -> str:
    """The verdict of the number a card shows: the model's own for display_raw events (amendment b), else the
    corrected one."""
    return t.get("raw_verdict", t["verdict"]) if ev in ccfg["display_raw"] else t["verdict"]


def conf_correct(raw: pd.DataFrame, engines: pd.Series, tables: dict, ccfg: dict = CONF_CFG,
                 shown: bool = True) -> pd.DataFrame:
    """The chances a card shows (shown=True): display_raw events keep the model's own number (amendment b), the
    others come from the final tables; a NO SKILL number becomes the base rate; then the +10% <= +5% cap.
    shown=False: every number from its table (the corrected variant, kept for the tracker)."""
    C = pd.DataFrame(np.nan, index=raw.index, columns=ccfg["events"])
    eng = engines.to_numpy()
    for e, tb in tables["engines"].items():
        m = eng == e
        if not m.any():
            continue
        for ev in ccfg["events"]:
            t = tb[ev]
            r = raw.loc[m, ev].to_numpy(float)
            if shown and ev in ccfg["display_raw"]:
                C.loc[m, ev] = t["base_rate"] if shown_verdict(t, ev, ccfg) == "NO SKILL" else r
            else:
                C.loc[m, ev] = t["base_rate"] if t["verdict"] == "NO SKILL" else apply_table(t, r)
    return conf_cap(C, ccfg)


def run_publish(root: Path, market=None, date: Optional[str] = None, all_missing: bool = False,
                dry_run: bool = False, run: Optional[str] = None, now: Optional[dt.datetime] = None,
                verbose: bool = True) -> dict:
    root = Path(root)
    decl, dsha = load_declaration()
    cfg = CFG
    market = market or ProductionMarket(root)
    base = root / OUT_SUB
    rdir = latest_run(base, run)
    J, M = load_final(rdir, dsha)
    conf = conf_for(base, rdir.name, verbose)
    fwd = base / "forward"
    L = read_ledger(root)
    U = read_universe(root)
    days = sorted(L["signal_day"].unique())
    if date:
        want = [_days(pd.to_datetime(pd.Series([date])))[0]]
        if want[0] not in set(days):
            raise PreconditionError(f"no watchlist recorded for {date} in the paper ledger")
    elif all_missing:
        want = [d for d in days if not (fwd / f"PM_cards_{pd.Timestamp(d):%Y%m%d}.csv").exists()]
    else:
        want = [days[-1]]
        if (fwd / f"PM_cards_{pd.Timestamp(want[0]):%Y%m%d}.csv").exists() and not dry_run:
            if verbose:
                _log(f"cards for {pd.Timestamp(want[0]).date()} are already published - nothing to do "
                     f"(published cards are never overwritten)")
            return {"written": [], "cards": None, "skipped": str(pd.Timestamp(want[0]).date())}
    if not want:
        if verbose:
            _log("every recorded watchlist already has cards - nothing to do")
        return {"written": [], "cards": None}
    if not dry_run:
        clash = [d for d in want if (fwd / f"PM_cards_{pd.Timestamp(d):%Y%m%d}.csv").exists()]
        if clash:
            raise PreconditionError(f"cards already exist for {[str(pd.Timestamp(d).date()) for d in clash]} - "
                                    f"published cards are never overwritten")
    for d in want:
        if d not in U:
            raise PreconditionError(f"paper\\universe.jsonl has no universe for {pd.Timestamp(d).date()}")
    hist = pd.read_parquet(rdir / "history.parquet")
    hist["signal_day"] = _days(hist["signal_day"])
    hist["exit_day"] = pd.to_datetime(hist["exit_day"]).astype("datetime64[ns]")
    hist = hist[hist["signal_day"] < min(want)]
    paper = L[L["signal_day"] <= max(want)]
    need = set(paper["symbol"]) | set(INDEX_SYMBOLS) | {s for d in want for s in U[d]}
    syms = prepare_symbols(market, need)
    idx = index_features(syms)
    uni = universe_features(pd.DataFrame([(d, s) for d in want for s in U[d]], columns=["signal_day", "symbol"]), syms)
    # the paper picks themselves: candidates (with engine inputs) and finished trades for the engine record
    tops = {eng: paper[paper["engine"] == eng][["signal_day", "symbol", "rank", "score"]] for eng in cfg["engines"]}
    for eng, t in tops.items():
        if not set(want) <= set(t["signal_day"]):
            raise PreconditionError(f"engine {eng} has no recorded watchlist for some requested days")
    tops = engine_features(tops, cfg["engines"])
    C = pd.concat([t.assign(engine=eng) for eng, t in tops.items()], ignore_index=True)
    T = assemble(C, syms, idx, uni, market, cfg)
    # engine record at each day: the research history plus the paper picks finished by then
    Hh = pd.concat([hist.assign(_src="research"),
                    T[["engine", "signal_day", "symbol", "exit_day", "net", "status"]].assign(_src="paper")],
                   ignore_index=True)
    eh = engine_history(Hh, cfg["engine_history_k"])
    paper_rows = Hh.index[Hh["_src"] == "paper"]
    T[["hist_n", "hist_net"]] = eh.loc[paper_rows].to_numpy()
    T = T[T["signal_day"].isin(want)].reset_index(drop=True)
    miss = T[T["s_atr14"].isna() & T["status"].isin(["no_bar", "no_bars"])]
    if len(miss):
        raise PreconditionError(f"the cache has no bar on the signal day for {sorted(set(miss['symbol']))} - "
                                f"run the nightly cache first")
    parts = []
    for eng in cfg["engines"]:
        g = T[T["engine"] == eng]
        P = predict_models(M[eng]["models"], g[cfg["features"]].to_numpy(float), cfg)
        P.index = g.index
        parts.append(pd.concat([g, P], axis=1))
    T = pd.concat(parts).sort_values(["signal_day", "engine", "rank"]).reset_index(drop=True)
    T["meta_rank"] = T.groupby(["signal_day", "engine"])["pred_edge"].rank(ascending=False, method="first").astype(int)
    t3 = T[T["rank"] <= cfg["trade_top"]].assign(_r=lambda x: x["pred_mae_q50"].abs())
    T = T.merge(t3.groupby(["signal_day", "engine"])["_r"].mean().rename("day_risk").reset_index(),
                on=["signal_day", "engine"], how="left")
    refs = {eng: magnitude_reference(rdir, eng) for eng in cfg["engines"]}
    T = assign_magnitude(T, refs)
    raw = conf_raw(T)
    nan = pd.DataFrame(np.nan, index=T.index, columns=CONF_CFG["events"])
    corr = conf_correct(raw, T["engine"], conf["tables"]) if conf["tables"] is not None else nan
    alt = conf_correct(raw, T["engine"], conf["tables"], shown=False) if conf["tables"] is not None else nan
    marks = conf["marks"]
    now = now or dt.datetime.now()
    cal = syms["NIFTY50"].d
    written = []
    if not dry_run:
        fwd.mkdir(parents=True, exist_ok=True)
        rf = fwd / f"magnitude_classes_{rdir.name}.json"
        if not rf.exists():
            rf.write_text(json.dumps(refs, indent=2), encoding="utf-8")
    for d in want:
        g = T[T["signal_day"] == d].copy()
        tag = pd.Timestamp(d).strftime("%Y%m%d")
        later = cal[cal > d]                # the entry session: the next NIFTY session, else the next weekday
        entry = pd.Timestamp(later[0]) if len(later) else pd.Timestamp(d) + pd.offsets.BDay(1)
        late = pd.Timestamp(now) >= entry + pd.Timedelta(hours=9)
        rw, cr, al = raw.loc[g.index], corr.loc[g.index], alt.loc[g.index]
        card = pd.DataFrame({
            "signal_day": pd.Timestamp(d).date().isoformat(), "engine": g["engine"], "rank": g["rank"],
            "symbol": g["symbol"], "score": g["score"].round(6), "meta_rank": g["meta_rank"],
            "up5_pct": (cr["up5"] * 100).round(1), "up10_pct": (cr["up10"] * 100).round(1),
            "dip8_pct": (cr["dip8"] * 100).round(1), "stuck_pct": (cr["stuck"] * 100).round(2),
            "profit_pct": (cr["profit"] * 100).round(1),
            "mfe_q20_pct": (g["pred_mfe_q20"] * 100).round(2), "mfe_q50_pct": (g["pred_mfe_q50"] * 100).round(2),
            "mfe_q80_pct": (g["pred_mfe_q80"] * 100).round(2), "mae_q20_pct": (g["pred_mae_q20"] * 100).round(2),
            "mae_q50_pct": (g["pred_mae_q50"] * 100).round(2), "mae_q80_pct": (g["pred_mae_q80"] * 100).round(2),
            "edge_bp": (g["pred_edge"] * 1e4).round(1), "day_risk_pct": (g["day_risk"] * 100).round(2),
            "atr14_pct": (g["s_atr14"] * 100).round(2), "own_mfe_pct": (g["own_mfe"] * 100).round(2),
            "own_mae_pct": (g["own_mae"] * 100).round(2), "hist_n": g["hist_n"].astype(int),
            "swing_fc_pct": (g["swing_fc"] * 100).round(2), "swing_class": g["swing_class"].astype(int),
            "swing_p20_pct": (g["swing_p20"] * 100).round(2), "swing_p50_pct": (g["swing_p50"] * 100).round(2),
            "swing_p80_pct": (g["swing_p80"] * 100).round(2),
            "raw_up5_pct": (rw["up5"] * 100).round(3), "raw_up10_pct": (rw["up10"] * 100).round(3),
            "raw_dip8_pct": (rw["dip8"] * 100).round(3), "raw_stuck_pct": (rw["stuck"] * 100).round(3),
            "raw_profit_pct": (rw["profit"] * 100).round(3),
            **{f"{ev}_corrected_pct": (al[ev] * 100).round(3) for ev in CONF_CFG["display_raw"]},
            "conf_run": conf["run"] or "",
            "conf_marks": g["engine"].map(lambda e: "|".join(f"{ev}={marks.get(e, {}).get(ev, 'UNCORRECTED')}"
                                                              for ev in CONF_CFG["events"])),
            "recorded_at": now.isoformat(timespec="seconds"), "late": late, "models_run": rdir.name,
            "code": CODE_VERSION, "declaration": dsha})
        if dry_run:
            if verbose:
                _log(f"dry run {pd.Timestamp(d).date()}: {len(card)} cards (nothing written)")
            written.append({"date": str(pd.Timestamp(d).date()), "file": None, "cards": card})
            continue
        fp = fwd / f"PM_cards_{tag}.csv"
        card.to_csv(fp, index=False)
        (fwd / f"PM_cards_{tag}.md").write_text(cards_md(card, pd.Timestamp(d), late, rdir.name, dsha, conf),
                                                encoding="utf-8")
        with open(fwd / "index.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps({"date": str(pd.Timestamp(d).date()), "file": fp.name, "sha256": _sha256(fp),
                                "recorded_at": now.isoformat(timespec="seconds"), "late": bool(late),
                                "models_run": rdir.name, "declaration": dsha, "code": CODE_VERSION,
                                "conf_run": conf["run"] or "", "conf_declaration": conf["csha"] or ""},
                               sort_keys=True) + "\n")
        written.append({"date": str(pd.Timestamp(d).date()), "file": str(fp), "cards": card})
        if verbose:
            _log(f"cards {pd.Timestamp(d).date()}: {len(card)} picks -> {fp}{' (LATE - not forward evidence)' if late else ''}")
    if verbose and written and len(want) == 1:
        print(magnitude_console(written[-1]["cards"], conf))
    return {"written": written, "table": T}


def conf_for(base: Path, source_run: str, verbose: bool = True) -> dict:
    """The correction tables publish uses for these models, or none (then the cards say UNCORRECTED).
    A table file that changed since calibrate wrote it is refused."""
    out = {"run": None, "csha": None, "tables": None, "summary": None, "marks": {}, "note": ""}
    try:
        _, out["csha"] = load_conf_declaration()
    except PreconditionError as e:
        out["note"] = str(e)
    if out["csha"]:
        cdir = find_conf(base, source_run, out["csha"])
        if cdir is None:
            out["note"] = (f"no calibrate run for {source_run} under this declaration - run: python pick_meta.py "
                           f"calibrate --root <root>")
        else:
            out["tables"] = load_conf_tables(cdir)
            sf = cdir / "summary.json"
            if _read_hashes(cdir / "outputs.sha256").get("summary.json") != _sha256(sf):
                raise PreconditionError(f"{sf} changed since calibrate wrote it (SHA-256 mismatch) - refusing")
            out["summary"] = json.loads(sf.read_text(encoding="utf-8"))
            out["run"] = cdir.name
            out["marks"] = {e: {ev: shown_verdict(t, ev) for ev, t in tb.items()} for e, tb in out["tables"]["engines"].items()}
    if out["tables"] is None and verbose:
        _log(f"WARNING confidence NOT CORRECTED ({out['note']}). The cards show the raw numbers, marked (raw).")
    return out


def _cell(v, mark: str, nd: int = 0) -> str:
    if v is None or not np.isfinite(v):
        return "n/a"
    s = f"{v:.{nd}f}%"
    return s + {"MISCALIBRATED": " !", "NO SKILL": " base", "UNCORRECTED": " (raw)"}.get(mark, "")


def _row_marks(r) -> Dict[str, str]:
    return dict(x.split("=", 1) for x in str(r.get("conf_marks", "")).split("|") if "=" in x)


def _shown(r, ev: str) -> float:
    """The number a card shows: corrected when there is a table, else the raw one."""
    v = r.get(f"{ev}_pct", np.nan)
    if v is None or not np.isfinite(v):
        v = r.get(f"raw_{ev}_pct", np.nan)
    return v


def conf_line(conf: dict) -> str:
    if conf.get("summary") is None:
        return (f"Confidence: NOT CORRECTED - {conf.get('note', '')}. The numbers below are the models' raw chances, "
                f"marked (raw).")
    S = conf["summary"]
    pe = S["config"]["primary_engine"]
    E = S["evaluation"][pe]
    parts = []
    for ev, R in E["events"].items():
        if ev == "profit":
            continue
        if ev in CONF_CFG["display_raw"]:
            parts.append(f"{CONF_SHORT[ev]} model's own {R['raw_verdict']} (average gap {_pp(R['raw']['avg_gap'], 2)} pts; "
                         f"the corrected one {R['verdict']}, {_pp(R['corrected']['avg_gap'], 2)})")
        else:
            parts.append(f"{CONF_SHORT[ev]} {R['verdict']} (average gap {_pp(R['corrected']['avg_gap'], 2)} pts)")
    parts.append(f"6-in-10 range {E['range']['inside']:.1%} inside ({E['range']['verdict']})")
    return (f"Confidence check {S['run']} ({pe}, out of sample {S['config']['first_test_year']}+, year by year, rules "
            f"fixed before the run): " + " | ".join(parts))


def magnitude_console(card: pd.DataFrame, conf: Optional[dict] = None) -> str:
    conf = conf or {}
    L = [f"\nMAGNITUDE WATCHLIST for the open after {card['signal_day'].iloc[0]}",
         "  P(+5%) / P(+10%) = chance the best point of the 5 sessions reaches entry +5% / +10% (buy at the next open)",
         f"  {conf_line(conf)}",
         "  class 1 calmest .. 10 wildest; swing = best minus worst point; ! = failed the check, base = no per-pick skill"]
    for eng, g in card.groupby("engine", sort=False):
        L.append(f"  {eng}:  rank symbol          P(+5%)    P(+10%)  class  expected swing (6 in 10)   up-room  "
                 f"down-risk  P(-8%)    P(stuck)")
        for _, r in g.iterrows():
            mk = _row_marks(r)
            L.append(f"        {'*' if r['rank'] <= 3 else ' '}{r['rank']:>3} {r['symbol']:<14} "
                     f"{_cell(_shown(r, 'up5'), mk.get('up5', '')):>9} {_cell(_shown(r, 'up10'), mk.get('up10', '')):>9}  "
                     f"{r['swing_class']:>3}   {r['swing_p50_pct']:5.1f}% ({r['swing_p20_pct']:4.1f}-{r['swing_p80_pct']:4.1f}%)"
                     f"      {r['mfe_q50_pct']:+5.1f}%  {r['mae_q50_pct']:+6.1f}%  "
                     f"{_cell(_shown(r, 'dip8'), mk.get('dip8', '')):>9} {_cell(_shown(r, 'stuck'), mk.get('stuck', ''), 1):>9}")
    L.append("  * = ranks 1-3 (the paper test buys the first 3 not locked at the upper band at the open)")
    return "\n".join(L)


def cards_md(card: pd.DataFrame, d: pd.Timestamp, late: bool, run: str, dsha: str, conf: Optional[dict] = None) -> str:
    conf = conf or {}
    L = [f"# Meta cards for the open after {d.date()}", "",
         f"{CODE_VERSION} | models {run} | declaration {dsha} | confidence {conf.get('run') or 'NOT CORRECTED'}"
         f"{' (' + conf['csha'] + ')' if conf.get('csha') else ''} | recorded {card['recorded_at'].iloc[0]}"
         f"{' | LATE - not forward evidence' if late else ''}", "",
         "Descriptive. These cards never change the paper test's picks.", "",
         "## Magnitude watchlist", "",
         "**P(+5%) / P(+10%) above entry** = the chance the best point of the 5 sessions (buying at the next open) "
         "reaches the entry price +5% / +10%. Checked out of sample, year by year: when the card says 60%, about 60 in "
         "100 past picks given 60% got there. P(+5%) is the model's own number (it passed the check; its corrected "
         "version did not - amendment b); P(+10%), P(-8%) and P(stuck) are corrected. Class 1 = calmest tenth "
         "of past forecasts, 10 = wildest; expected swing and its 6-in-10 range = what past picks of the class did. "
         "Up-room / down-risk = median forecast best / worst point. Size, not direction.", "",
         conf_line(conf), "", "Marks: ! = failed the check (shown, not trusted); base = no per-pick skill, the past base "
         "rate is shown; (raw) = not corrected.", ""]
    for eng, g in card.groupby("engine", sort=False):
        L += [f"### {eng}", "", "| rank | symbol | P(+5%) | P(+10%) | class | expected swing | 6 in 10 past | up-room | "
              "down-risk | P(-8% dip) | P(stuck) |", "|---|---|---|---|---|---|---|---|---|---|---|"]
        for _, r in g.iterrows():
            mk = _row_marks(r)
            L.append(f"| {'**' + str(r['rank']) + '**' if r['rank'] <= 3 else r['rank']} | {r['symbol']} | "
                     f"{_cell(_shown(r, 'up5'), mk.get('up5', ''))} | {_cell(_shown(r, 'up10'), mk.get('up10', ''))} | "
                     f"{r['swing_class']} | {r['swing_p50_pct']:.1f}% | {r['swing_p20_pct']:.1f}-{r['swing_p80_pct']:.1f}% | "
                     f"{r['mfe_q50_pct']:+.1f}% | {r['mae_q50_pct']:+.1f}% | {_cell(_shown(r, 'dip8'), mk.get('dip8', ''))} | "
                     f"{_cell(_shown(r, 'stuck'), mk.get('stuck', ''), 1)} |")
        L.append("")
    L += ["Bold ranks = 1-3 (the paper test buys the first 3 not locked at the upper band at the open).", "",
          "## Full cards", "", "MFE/MAE = best/worst point over the 5 sessions (20/50/80% levels). P(profit) = chance the "
          "honest trade beats its 35 bp cost - direction, the weakest number (AUC 0.529 out of sample), never a reason "
          "to pick. Raw = the models' own chances before correction (kept for audit).", ""]
    for eng, g in card.groupby("engine", sort=False):
        L += [f"## {eng}", "", "| rank | symbol | meta rank | MFE 20/50/80 | MAE 20/50/80 | P(profit) | edge vs the 10 | "
              "raw P(+5%) / P(+10%) / P(-8%) / P(stuck) |", "|---|---|---|---|---|---|---|---|"]
        for _, r in g.iterrows():
            mk = _row_marks(r)
            L.append(f"| {r['rank']} | {r['symbol']} | {r['meta_rank']} | {r['mfe_q20_pct']:+.1f} / {r['mfe_q50_pct']:+.1f} / "
                     f"{r['mfe_q80_pct']:+.1f}% | {r['mae_q20_pct']:+.1f} / {r['mae_q50_pct']:+.1f} / "
                     f"{r['mae_q80_pct']:+.1f}% | {_cell(_shown(r, 'profit'), mk.get('profit', ''))} | {r['edge_bp']:+.0f} bp | "
                     f"{r['raw_up5_pct']:.0f}% / {r['raw_up10_pct']:.0f}% / {r['raw_dip8_pct']:.0f}% / {r['raw_stuck_pct']:.1f}% |")
        L += ["", f"Day risk (average |MAE forecast| of ranks 1-3): {g['day_risk_pct'].iloc[0]:.2f}%", ""]
    return "\n".join(L)


# ----------------------------------------------------------------------
# score: the forward magnitude tracker
# ----------------------------------------------------------------------
def card_confidence(C: pd.DataFrame, base: Path) -> Tuple[pd.DataFrame, Dict[str, dict]]:
    """Raw and corrected chances for every published card. v1.3 cards carry what they showed ('shown'); older
    cards are corrected afterwards from their raw numbers with the final tables of their models' run - the
    tables use data up to that run's last finished trade only, so this adds no hindsight."""
    C = C.copy()
    legacy = {"raw_up5_pct": "p_plus5_pct", "raw_dip8_pct": "p_dip8_pct", "raw_stuck_pct": "p_stuck_pct",
              "raw_profit_pct": "confidence_pct"}
    for new, old in legacy.items():
        if new not in C:
            C[new] = np.nan
        if old in C:
            C[new] = C[new].fillna(C[old])
    if "raw_up10_pct" not in C:
        C["raw_up10_pct"] = np.nan
    imp = implied_up(CONF_CFG["levels"]["up10"], C["mfe_q20_pct"] / 100, C["mfe_q50_pct"] / 100, C["mfe_q80_pct"] / 100,
                     CONF_CFG["implied_tail_factor"]) * 100
    C["raw_up10_pct"] = C["raw_up10_pct"].fillna(pd.Series(imp, index=C.index))
    for ev in CONF_CFG["events"]:
        if f"{ev}_pct" not in C:
            C[f"{ev}_pct"] = np.nan
    for ev in CONF_CFG["display_raw"]:
        if f"{ev}_corrected_pct" not in C:
            C[f"{ev}_corrected_pct"] = np.nan
    for c in ("conf_run", "conf_marks"):
        C[c] = C[c].fillna("").astype(str) if c in C else ""
    shown = (C["conf_run"] != "") & C["up5_pct"].notna()
    C["conf_source"] = np.where(shown, "shown", "none")
    try:
        _, csha = load_conf_declaration()
    except PreconditionError:
        csha = None
    bases: Dict[str, dict] = {}
    for run, g in C.groupby("models_run"):
        cdir = find_conf(base, run, csha) if csha else None
        if cdir is None:
            continue
        tables = load_conf_tables(cdir)
        bases[run] = {e: {ev: t["base_rate"] for ev, t in tb.items()} for e, tb in tables["engines"].items()}
        m = g.index[~shown.loc[g.index].to_numpy()]
        if len(m):
            raw = pd.DataFrame({ev: C.loc[m, f"raw_{ev}_pct"].astype(float) / 100 for ev in CONF_CFG["events"]})
            cc = conf_correct(raw, C.loc[m, "engine"], tables)
            for ev in CONF_CFG["events"]:
                C.loc[m, f"{ev}_pct"] = (cc[ev] * 100).round(3)
            C.loc[m, "conf_source"] = "corrected afterwards"
            mk = {e: "|".join(f"{ev}={shown_verdict(t, ev)}" for ev, t in tb.items()) for e, tb in tables["engines"].items()}
            C.loc[m, "conf_marks"] = C.loc[m, "engine"].map(lambda e: mk.get(e, ""))
        a = g.index[C.loc[g.index, [f"{ev}_corrected_pct" for ev in CONF_CFG["display_raw"]]].isna().any(axis=1).to_numpy()]
        if len(a) and CONF_CFG["display_raw"]:
            raw = pd.DataFrame({ev: C.loc[a, f"raw_{ev}_pct"].astype(float) / 100 for ev in CONF_CFG["events"]})
            cc = conf_correct(raw, C.loc[a, "engine"], tables, shown=False)
            for ev in CONF_CFG["display_raw"]:
                C.loc[a, f"{ev}_corrected_pct"] = (cc[ev] * 100).round(3)
    return C, bases


def run_score(root: Path, market=None, verbose: bool = True) -> dict:
    """Settle every published pick whose 5 sessions have finished: actual best / worst point, swing and whether the
    5th close was locked at the lower band, from the cache bars (buy at the next session's open). Rewrites
    forward\\magnitude_results.csv and forward\\magnitude_tracker.md from the card files (the cards are the
    evidence; these are derived)."""
    root = Path(root)
    base = root / OUT_SUB
    fwd = base / "forward"
    files = sorted(fwd.glob("PM_cards_*.csv"))
    if not files:
        raise PreconditionError(f"no published cards under {fwd} - run publish first")
    C = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    C["signal_day"] = _days(pd.to_datetime(C["signal_day"]))
    if "swing_fc_pct" not in C:
        C["swing_fc_pct"] = np.nan
    C["swing_fc_pct"] = C["swing_fc_pct"].fillna(C["mfe_q50_pct"] - C["mae_q50_pct"])
    C, bases = card_confidence(C, base)
    market = market or ProductionMarket(root)
    syms = prepare_symbols(market, set(C["symbol"]), with_volume=False)
    H = CFG["hold"]
    st, up, dn, lk = [], [], [], []
    for sym, day in zip(C["symbol"], C["signal_day"].to_numpy(dtype="datetime64[ns]")):
        sy = syms.get(sym)
        i = int(day_index(sy, np.array([day]))[0]) if sy is not None else -1
        if i < 0:
            st.append("no_bar"); up.append(np.nan); dn.append(np.nan); lk.append(np.nan)
            continue
        b = sy.b
        if i + H >= len(b.c):
            st.append("pending"); up.append(np.nan); dn.append(np.nan); lk.append(np.nan)
            continue
        e = float(b.o[i + 1])
        st.append("settled")
        up.append((float(np.max(b.h[i + 1:i + H + 1])) / e - 1) * 100)
        dn.append((float(np.min(b.l[i + 1:i + H + 1])) / e - 1) * 100)
        lk.append(float(market.lower_locked(b, i + H, "close")))
    C["status"] = st
    C["real_mfe_pct"], C["real_mae_pct"] = np.round(up, 3), np.round(dn, 3)
    C["real_swing_pct"] = (C["real_mfe_pct"] - C["real_mae_pct"]).round(3)
    has = C["swing_p20_pct"].notna() if "swing_p20_pct" in C else pd.Series(False, index=C.index)
    C["inside_range"] = np.where(has & (C["status"] == "settled"),
                                 ((C["real_swing_pct"] >= C.get("swing_p20_pct")) &
                                  (C["real_swing_pct"] <= C.get("swing_p80_pct"))).astype(float), np.nan)
    sett = C["status"] == "settled"
    lv = CONF_CFG["levels"]
    C["touched_up5"] = np.where(sett, (C["real_mfe_pct"] >= lv["up5"] * 100).astype(float), np.nan)
    C["touched_up10"] = np.where(sett, (C["real_mfe_pct"] >= lv["up10"] * 100).astype(float), np.nan)
    C["touched_dn8"] = np.where(sett, (C["real_mae_pct"] <= lv["dip8"] * 100).astype(float), np.nan)
    C["locked_close5"] = np.where(sett, lk, np.nan)
    out = C.copy()
    out["signal_day"] = pd.to_datetime(out["signal_day"]).dt.date.astype(str)
    out.to_csv(fwd / "magnitude_results.csv", index=False)
    md = tracker_md(C, bases)
    (fwd / "magnitude_tracker.md").write_text(md, encoding="utf-8")
    if verbose:
        n_s = int(sett.sum())
        ot = C[sett & (~C["late"].astype(bool))]
        _log(f"score: {n_s:,} picks settled, {int((C['status'] == 'pending').sum()):,} pending; on-time (evidence) "
             f"{len(ot):,} picks on {ot['signal_day'].nunique()} days -> {fwd / 'magnitude_tracker.md'}")
        if len(ot):
            ins = ot["inside_range"].dropna()
            print(f"  on-time: actual swing inside the stated 60% range {ins.mean():.0%} of {len(ins)} (target 60%); "
                  f"forecast vs actual swing Spearman {spearman(ot['swing_fc_pct'], ot['real_swing_pct']):+.3f}")
            for ev, col in (("up5", "touched_up5"), ("up10", "touched_up10")):
                g = ot[ot[f"{ev}_pct"].notna()]
                if len(g):
                    print(f"  on-time {CONF_LABELS[ev]}: said {g[f'{ev}_pct'].mean():.1f}% on average, happened "
                          f"{g[col].mean():.1%} of {len(g)} picks")
    return {"results": C, "md": md}


OUTCOME_COL = {"up5": "touched_up5", "up10": "touched_up10", "dip8": "touched_dn8", "stuck": "locked_close5"}


def _overlap(lo, hi, t) -> bool:
    return bool(np.isfinite(lo) and np.isfinite(hi) and lo <= t and hi >= -t)


def forward_check(S: pd.DataFrame, ev: str, base_rate: Optional[float], ccfg: dict = CONF_CFG) -> dict:
    """The declared forward check for one event on settled picks (corrected chances vs what happened)."""
    fw = ccfg["forward"]
    g = S[S[f"{ev}_pct"].notna() & S[OUTCOME_COL[ev]].notna()]
    days = g["signal_day"].to_numpy(dtype="datetime64[ns]")
    p, y = g[f"{ev}_pct"].to_numpy(float) / 100, g[OUTCOME_COL[ev]].to_numpy(float)
    nd = int(len(np.unique(days)))
    ci = nd >= fw["min_days"]
    rel = reliability(days, p, y, fw["bands_pp"] if ev != "stuck" else ccfg["bands_pp_stuck"], ccfg, offset=101,
                      with_ci=ci, tail_min=fw["band_min_picks"])
    sk = (brier_skill(days, p, y, base_rate, ccfg, offset=103) if (ci and base_rate is not None)
          else {"skill": np.nan, "lo": np.nan, "hi": np.nan})
    out = {"n": rel["n"], "days": nd, "rel": rel, "skill": sk, "intervals": ci}
    if ci and rel["n"]:
        lvl_ok = _overlap(rel["level_lo"] * 100, rel["level_hi"] * 100, fw["level_pp"])
        bands = [b for b in rel["bands"] if b["n"] >= fw["band_min_picks"]]
        band_ok = all(_overlap(b.get("gap_lo", np.nan) * 100, b.get("gap_hi", np.nan) * 100, fw["band_pp"]) for b in bands)
        sk_ok = bool(np.isfinite(sk["lo"]) and sk["lo"] > 0)
        fails = [k for k, ok in (("overall level", lvl_ok), ("a band", band_ok), ("skill", sk_ok)) if not ok]
        out.update({"level_ok": lvl_ok, "band_ok": band_ok, "skill_ok": sk_ok,
                    "verdict": "HOLDS" if not fails else "FAILS (" + ", ".join(fails) + ")"})
    else:
        out["verdict"] = f"too early ({nd} settled days; intervals from {fw['min_days']})"
    return out


def _tracker_block(G: pd.DataFrame, title: str, bases: Optional[Dict[str, dict]] = None, check: bool = False) -> List[str]:
    S = G[G["status"] == "settled"]
    L = [f"### {title}", ""]
    if S.empty:
        return L + ["No settled picks yet.", ""]
    ins = S["inside_range"].dropna()
    nd = S["signal_day"].nunique()
    rho = spearman(S["swing_fc_pct"], S["real_swing_pct"])
    ci = ""
    if nd >= 20:
        cfg = {**CFG, "bootstrap": {**CFG["bootstrap"], "B_pooled": 1000}}
        r = pooled_ci(S["signal_day"].to_numpy(dtype="datetime64[ns]"), S["swing_fc_pct"].to_numpy(float),
                      S["real_swing_pct"].to_numpy(float), spearman, cfg)
        ci = f" [{r['lo']:+.3f}, {r['hi']:+.3f}]"
    else:
        ci = f" (interval once there are 20 days; now {nd})"
    L += [f"- settled picks {len(S):,} on {nd} days; pending {int((G['status'] == 'pending').sum())}",
          f"- actual swing inside the stated 60% range: **{ins.mean():.0%}** of {len(ins)} (target 60%)" if len(ins)
          else "- inside-range: these cards predate the magnitude columns",
          f"- forecast vs actual swing (Spearman): **{rho:+.3f}**{ci} - research history +0.35 to +0.38 on the traded picks",
          f"- median swing: forecast {S['swing_fc_pct'].median():.1f}%, actual {S['real_swing_pct'].median():.1f}%", ""]
    eng = str(G["engine"].iloc[0])
    src = ", ".join(f"{k} {v}" for k, v in S["conf_source"].value_counts().items())
    L += [f"Confidence, said vs happened (corrected numbers; {src}):", "",
          "| number | picks | days | said (mean) | happened [95%] | gap [95%] | Brier skill vs base rate [95%] |",
          "|---|---|---|---|---|---|---|"]
    checks = {}

    def base_of(ev):
        runs = S["models_run"].unique()
        if bases and len(runs) == 1 and runs[0] in bases:
            return bases[runs[0]].get(eng, {}).get(ev)
        return None
    for ev in ("up5", "up10", "dip8", "stuck"):
        br = base_of(ev)
        fc = forward_check(S, ev, br)
        checks[ev] = fc
        r = fc["rel"]
        if not r["n"]:
            L.append(f"| {CONF_LABELS[ev]} | 0 | | | | | |")
            continue
        hap = f"{_pp(r['happened'])}%"
        gap = _spp(r["level"])
        if fc["intervals"]:
            hap += f" [{_pp(r['happened_lo'])}, {_pp(r['happened_hi'])}]"
            gap += f" [{_spp(r['level_lo'])}, {_spp(r['level_hi'])}]"
        sk = fc["skill"]
        skt = (f"{sk['skill']:+.3f} [{sk['lo']:+.3f}, {sk['hi']:+.3f}]" if np.isfinite(sk["skill"])
               else f"from {CONF_CFG['forward']['min_days']} days")
        L.append(f"| {CONF_LABELS[ev]}{' (model own, shown)' if ev in CONF_CFG['display_raw'] else ''} | {r['n']:,} | "
                 f"{r['days']} | {_pp(r['said'])}% | {hap} | {gap} | {skt} |")
    for ev in CONF_CFG["display_raw"]:
        if f"{ev}_corrected_pct" not in S or not S[f"{ev}_corrected_pct"].notna().any():
            continue
        fc = forward_check(S.assign(**{f"{ev}_pct": S[f"{ev}_corrected_pct"]}), ev, base_of(ev))
        r = fc["rel"]
        if r["n"]:
            hap = f"{_pp(r['happened'])}%" + (f" [{_pp(r['happened_lo'])}, {_pp(r['happened_hi'])}]" if fc["intervals"] else "")
            gap = _spp(r["level"]) + (f" [{_spp(r['level_lo'])}, {_spp(r['level_hi'])}]" if fc["intervals"] else "")
            sk = fc["skill"]
            skt = (f"{sk['skill']:+.3f} [{sk['lo']:+.3f}, {sk['hi']:+.3f}]" if np.isfinite(sk["skill"])
                   else f"from {CONF_CFG['forward']['min_days']} days")
            L.append(f"| {CONF_LABELS[ev]} (corrected, not shown - descriptive) | {r['n']:,} | {r['days']} | "
                     f"{_pp(r['said'])}% | {hap} | {gap} | {skt} |")
    L.append("")
    if check:
        cut = np.datetime64(CONF_CFG["forward"]["checkpoint_last_signal_day"], "ns")
        sd = S["signal_day"].to_numpy(dtype="datetime64[ns]")
        at = bool((sd > cut).any())         # a later card has settled: every card up to the checkpoint is in
        Sv = S[sd <= cut] if at else S
        L += [f"Forward check (declared before the forward period; judged at the month-6 checkpoint on cards through "
              f"{CONF_CFG['forward']['checkpoint_last_signal_day']}): "
              + (f"AT CHECKPOINT ({Sv['signal_day'].nunique()} days)" if at else "PROVISIONAL")
              + " - holds if the overall gap's interval overlaps +/-2 points, each band of 100+ picks overlaps +/-5 points "
              "and the Brier skill's lower bound is above 0.", ""]
        for ev in CONF_CFG["headline"]:
            fc = forward_check(Sv, ev, base_of(ev)) if at else checks[ev]
            L += [f"**{CONF_LABELS[ev]}: {fc['verdict']}**", "", "| stated band | picks | said | happened [95%] | gap [95%] |",
                  "|---|---|---|---|---|"]
            for b in fc["rel"]["bands"]:
                L.append(f"| {b['lo_pp']:g}-{b['hi_pp']:g}% | {b['n']:,} | {_pp(b['said'])}% | {_pp(b['happened'])}%"
                         + (f" [{_pp(b.get('happened_lo'))}, {_pp(b.get('happened_hi'))}]" if fc["intervals"] else "")
                         + f" | {_spp(b['gap'])}" + (f" [{_spp(b.get('gap_lo'))}, {_spp(b.get('gap_hi'))}]" if fc["intervals"] else "")
                         + " |")
            L.append("")
    if "swing_class" in S and S["swing_class"].notna().any():
        grp = pd.cut(S["swing_class"], [0, 3, 7, 10], labels=["calm (1-3)", "middle (4-7)", "wild (8-10)"])
        L += ["| classes | picks | median forecast swing | median actual swing | inside range | touched +5% | touched +10% | "
              "touched -8% |", "|---|---|---|---|---|---|---|---|"]
        for k, g in S.groupby(grp, observed=True):
            L.append(f"| {k} | {len(g)} | {g['swing_fc_pct'].median():.1f}% | {g['real_swing_pct'].median():.1f}% | "
                     f"{g['inside_range'].mean():.0%} | {g['touched_up5'].mean():.0%} | {g['touched_up10'].mean():.0%} | "
                     f"{g['touched_dn8'].mean():.0%} |")
        L.append("")
    return L


def tracker_md(C: pd.DataFrame, bases: Optional[Dict[str, dict]] = None) -> str:
    L = [f"# Forward magnitude tracker", "",
         f"{CODE_VERSION} | rebuilt {dt.datetime.now():%Y-%m-%d %H:%M} from {C['signal_day'].nunique()} published days", "",
         "Each published pick is checked once its 5 sessions finish: actual best point, worst point and swing "
         "(buy at the next open), and whether the 5th close was locked at the lower band. Only cards written before "
         "09:00 of the entry session count as evidence; late (backfilled) cards are shown separately. Cards from "
         "before v1.3 are corrected afterwards from their raw numbers (tables built from data before the forward "
         "period). A few weeks is noise: judge with an interval.", ""]
    late = C["late"].astype(bool)
    for label, G in (("ON-TIME cards (forward evidence)", C[~late]), ("LATE cards (backfill - not evidence)", C[late])):
        L += [f"## {label}", ""]
        for eng, g in G.groupby("engine", sort=False):
            prim = eng == CFG["primary_engine"]
            L += _tracker_block(g, f"{eng} - all 10", bases, check=prim and not g["late"].astype(bool).any())
            if prim:
                L += _tracker_block(g[g["rank"] <= CFG["trade_top"]], f"{eng} - ranks 1-3", bases)
    return "\n".join(L)


# ----------------------------------------------------------------------
# command line
# ----------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--version", action="version", version=CODE_VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("research", help="walk-forward meta model on the frozen engines' history")
    r.add_argument("--root", required=True, help="the data root, e.g. %%CACHE_DAILY_ROOT%%")
    p = sub.add_parser("publish", help="cards for recorded paper watchlists")
    p.add_argument("--root", required=True)
    p.add_argument("--date", default=None, help="signal day YYYY-MM-DD (default: the latest recorded)")
    p.add_argument("--all-missing", action="store_true", help="every recorded day that has no cards yet")
    p.add_argument("--run", default=None, help="research run folder PM_... (default: the latest)")
    p.add_argument("--dry-run", action="store_true")
    sc = sub.add_parser("score", help="forward magnitude tracker: settle published cards")
    sc.add_argument("--root", required=True)
    cb = sub.add_parser("calibrate", help="the declared confidence check and the correction tables publish uses")
    cb.add_argument("--root", required=True)
    cb.add_argument("--run", default=None, help="research run folder PM_... (default: the latest)")
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.exists():
        print(f"Root does not exist: {root}")
        return 2
    print(f"{CODE_VERSION} | Root: {root}")
    try:
        if a.cmd == "research":
            run_research(root)
        elif a.cmd == "publish":
            run_publish(root, date=a.date, all_missing=a.all_missing, dry_run=a.dry_run, run=a.run)
        elif a.cmd == "calibrate":
            run_calibrate(root, run=a.run)
        else:
            run_score(root)
    except PreconditionError as e:
        print(f"STOPPED: {e}")
        return 2
    except ReconciliationError as e:
        print(f"STOPPED (reconciliation): {e}")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
