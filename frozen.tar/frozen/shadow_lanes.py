#!/usr/bin/env python3
"""
shadow_lanes.py - the forward test of the drawdown levers: does selling at the 6th open (and the trap swap on top
of it) hold on days nobody has seen? Computed beside the paper test from its own records; it never changes them.

Run from ...\\bigmove_deploy\\open_close with PYTHONPATH = ...\\bigmove_deploy (as stage_e_execution):

    python shadow_lanes.py track --root %CACHE_DAILY_ROOT%                  (any time: a dated snapshot)
    python shadow_lanes.py judge --root %CACHE_DAILY_ROOT% --checkpoint 6   (once, when month 6 has settled)

THE RULES ARE IN SHADOW_LANES_DECLARATION.json (fixed 19 Oct 2026 before any lane was computed; amendment (a)
the same night, before any run on the paper test's data)
  Lanes on the paper test's D watchlists from 30 Sep 2026, in stage E's simulator (dd_replay's verified copy),
  Rs 10 lakh, stage E's PRIMARY mechanics:
    PLAN        sell at the 5th close (the reference)
    OPEN6       sell at the 6th session's open
    OPEN6+TRAP  top-10 picks with an ON-TIME P(stuck) >= 10% move behind the others, then OPEN6
  each at full size and at its replay size (DR_20261018_001: 0.698 / 0.727 / 0.785).
  At month 6 (signal days through 2027-03-31) and month 12 (through 2027-09-30):
    J1  the 6th open minus the 5th close on every PLAN trade, 95% interval over blocks of 10 signal days:
        CONFIRMED / CONTRADICTED / NOT YET
    J2  each trap swap: the pick bought instead minus the flagged pick (6th-open exits); under 30 swaps:
        NOT ENOUGH EVENTS
    J3  the lanes' equity, drawdown and daily differences (descriptive)
  Before a checkpoint every number is a running number, not a verdict.

INPUTS: the paper ledger's D watchlists (a watchlist recorded after 09:00 of its entry session - the paper test's
late rule - buys nothing: it could not have been traded at that open); pick_meta's on-time cards; the daily cache
through stage E's loader; the liquidity figure from panel_live (the live panel Run Now extends every night -
panel_oc is frozen at 22 Sep 2026 and holds no forward day).

SAFETY STOPS: each lane at full size must equal stage E's own simulate() exactly; a card listed as on time must
have the SHA-256 recorded when it was published; 99% of the top-10 entries need the panel's liquidity figure; a
checkpoint is not judged while a forward day holds two bars in the cache (a snapshot warns).

OUTPUT: <root>\\research2\\shadow_lanes\\SL_YYYYMMDD_NNN\\ (track) and SLJ_M6_YYYYMMDD_NNN\\ (judge): report.md,
summary.json, lanes_daily.csv, trades.csv, open6_pairs.csv, trap_swaps.csv, outputs.sha256. Ledger lines
shadow_lanes_declared (first run) / shadow_lanes_track / shadow_lanes_judged in panel\\research_ledger.jsonl.
Never writes to the paper test, pick_meta's folders, the panels, stage E's folders or any frozen file.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import research_common as RC        # noqa: E402  (this folder's copy wins, as in stage E)
import stage_e_execution as EX      # noqa: E402  (simulator, exits, loaders - read only)
import dd_replay as DR              # noqa: E402  (the verified simulator copy and the levers - read only)

CODE_VERSION = "shadow_lanes v1"
FAMILY = "shadow_lanes_v1"
DECL_FILE = HERE / "SHADOW_LANES_DECLARATION.json"
OUT_SUB = Path("research2") / "shadow_lanes"
CARDS_SUB = Path("research2") / "pick_meta" / "forward"
LIVE_PANEL = Path("panel_live") / "panel.parquet"
CFG = {
    "engine": "D",
    "lanes": ["PLAN", "OPEN6", "OPEN6+TRAP"],
    "replay_run": "DR_20261018_001",
    "replay_sizes": {"PLAN": 0.6984375, "OPEN6": 0.7265625, "OPEN6+TRAP": 0.78515625},
    "forward_start": "2026-09-30",
    "late_cutoff": "09:00",
    "checkpoints": {"6": "2027-03-31", "12": "2027-09-30"},
    "trap_line_pct": 10.0,
    "trap_top": 10,
    "trap_round_dp": 1,
    "picks_per_day": 3,
    "min_swaps": 30,
    "cagr_min_sessions": 60,
    "boot_B": 2000,
    "boot_block": 10,
    "boot_seed": 7,
    "min_interval_groups": 20,
    "min_liquidity_coverage": 0.99,
    "reference_open6_bp": {"mean": 51.5, "lo": 43.3, "hi": 60.1, "source": "Soul study SI_20261008_001"},
    "stage_e_version": "stage_e_execution v1.2",
    "stage_e_declaration": "5ba73cc0687eb482",
    "dd_replay_version": "dd_replay v1",
    "dd_replay_declaration": "f81e86cf7f4deefa",
}
SIZES = ("full", "replay")


class PreconditionError(RuntimeError):
    """Something needed is missing, not the shipped version, or not ready (a checkpoint not settled)."""


class IntegrityError(RuntimeError):
    """An input or the simulator copy does not check out. Nothing is judged."""


def _log(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _D(x) -> np.datetime64:
    return np.datetime64(pd.Timestamp(x).normalize().to_datetime64(), "D")


def load_declaration(path: Path = DECL_FILE) -> Tuple[dict, str]:
    p = Path(path)
    if not p.exists():
        raise PreconditionError(f"{p.name} not found next to {Path(__file__).name}")
    raw = p.read_bytes()
    decl = json.loads(raw.decode("utf-8"))
    want, got = json.loads(json.dumps(CFG)), decl.get("config", {})
    if decl.get("family_id") != FAMILY or got != want:
        diff = sorted(k for k in set(want) | set(got) if want.get(k) != got.get(k))
        raise PreconditionError(f"settings differ from {p.name} on {diff or ['family_id']}; the declaration is fixed")
    return decl, hashlib.sha256(raw).hexdigest()[:16]


def check_modules(cfg: dict = CFG) -> dict:
    """stage E and dd_replay must be the shipped versions, imported from this folder, with the declared rules."""
    origins = {m.__name__: str(Path(m.__file__).resolve()) for m in (EX, DR, RC)}
    wrong = [k for k, v in origins.items() if Path(v).parent != HERE.resolve()]
    if wrong:
        raise PreconditionError(f"{wrong} imported from outside open_close ({origins}) - run from ...\\bigmove_deploy\\open_close")
    if EX.CODE_VERSION != cfg["stage_e_version"] or DR.CODE_VERSION != cfg["dd_replay_version"]:
        raise PreconditionError(f"need {cfg['stage_e_version']} and {cfg['dd_replay_version']}, found {EX.CODE_VERSION} "
                                f"and {DR.CODE_VERSION}")
    try:
        _, esha = EX.load_declaration()
        _, dsha = DR.load_declaration()
    except SystemExit as e:
        raise PreconditionError(str(e)) from None
    if esha != cfg["stage_e_declaration"] or dsha != cfg["dd_replay_declaration"]:
        raise PreconditionError(f"declarations: stage E {esha} (need {cfg['stage_e_declaration']}), dd_replay {dsha} "
                                f"(need {cfg['dd_replay_declaration']})")
    rules = {"trap_line_pct": cfg["trap_line_pct"], "trap_top": cfg["trap_top"], "open6_session": 6,
             "lock_search_sessions": 20}
    bad = [k for k, v in rules.items() if DR.CFG.get(k) != v]
    sc = EX.primary_scenario()
    if bad or (sc.n, sc.hold, sc.capital, sc.costs, sc.liquidity_cap, sc.duplicates, sc.depth, sc.stop) != \
            (cfg["picks_per_day"], 5, 1_000_000.0, "zerodha_base", 0.02, True, 20, None):
        raise PreconditionError(f"the replay's rules or stage E's PRIMARY scenario are not the declared ones ({bad})")
    return origins


# ----------------------------------------------------------------------
# inputs: the paper test's watchlists, pick_meta's on-time cards, bars, liquidity
# ----------------------------------------------------------------------
def _recorded(v) -> Optional[pd.Timestamp]:
    """A ledger record's recording time as a naive IST timestamp (None if absent or unreadable)."""
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return None
    try:
        t = pd.Timestamp(v)
    except (ValueError, TypeError):
        return None
    if t is pd.NaT:
        return None
    return t.tz_convert("Asia/Kolkata").tz_localize(None) if t.tzinfo is not None else t


def read_watchlists(root: Path, cfg: dict = CFG) -> Tuple[Dict[np.datetime64, List[str]], dict]:
    """D's recorded watchlists from the paper ledger, by day, in rank order. A day recorded twice keeps its first
    record of each rank (the one made on the evening itself); conflicts are reported. info['recorded_at'] = each
    day's recording time (the latest of its kept records; None if any of them has none)."""
    p = Path(root) / "paper" / "ledger.jsonl"
    if not p.exists():
        raise PreconditionError(f"paper ledger not found: {p}")
    rows, unreadable = [], 0
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            unreadable += 1
            continue
        if isinstance(r, dict) and all(k in r for k in ("date", "engine", "rank", "symbol", "score")) \
                and str(r["engine"]) == cfg["engine"]:
            rows.append((str(r["date"])[:10], int(r["rank"]), str(r["symbol"]).strip(), _recorded(r.get("recorded_at"))))
    if not rows:
        raise PreconditionError(f"{p} holds no watchlist records of engine {cfg['engine']}")
    L = pd.DataFrame(rows, columns=["date", "rank", "symbol", "recorded_at"])
    L["day"] = pd.to_datetime(L["date"]).values.astype("datetime64[D]")
    L = L[L["day"] >= np.datetime64(cfg["forward_start"], "D")]
    if L.empty:
        raise PreconditionError(f"no {cfg['engine']} watchlist on or after {cfg['forward_start']} in {p}")
    first = L.drop_duplicates(["day", "rank"], keep="first")
    conflicts = sorted({str(pd.Timestamp(d).date()) for (d, r), g in L.groupby(["day", "rank"])
                        if g["symbol"].nunique() > 1})
    out, rec = {}, {}
    for d, g in first.sort_values(["day", "rank"]).groupby("day", sort=True):
        seen, wl = set(), []
        for s in g["symbol"]:
            if s not in seen:
                seen.add(s)
                wl.append(s)
        k = np.datetime64(d, "D")
        out[k] = wl
        ra = list(g["recorded_at"])
        rec[k] = None if any(pd.isna(x) for x in ra) else pd.Timestamp(max(ra))     # None becomes NaT in a frame
    return out, {"days": len(out), "first": str(min(out)), "last": str(max(out)), "unreadable_lines": unreadable,
                 "days_recorded_twice_with_different_picks": conflicts, "recorded_at": rec}


def read_cards(root: Path, cfg: dict = CFG) -> Tuple[Dict[Tuple[np.datetime64, str], float], dict]:
    """P(stuck) of D's picks from the cards pick_meta published ON TIME (index.jsonl late = false), each file
    checked against the SHA-256 recorded at publication. Late or missing cards flag nothing."""
    base = Path(root) / CARDS_SUB
    idx = base / "index.jsonl"
    prob: Dict[Tuple[np.datetime64, str], float] = {}
    info = {"index_found": idx.exists(), "on_time_days": [], "late_days": []}
    if not idx.exists():
        return prob, info
    seen = set()
    for line in idx.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        d = str(r.get("date", ""))[:10]
        if not d or d in seen:
            continue
        seen.add(d)
        if bool(r.get("late", True)):
            info["late_days"].append(d)
            continue
        fp = base / str(r.get("file", ""))
        if not fp.exists():
            raise IntegrityError(f"card {fp.name}, listed as published on time in index.jsonl, is missing")
        if _sha256(fp) != r.get("sha256"):
            raise IntegrityError(f"card {fp.name} is not the file published on {d} (SHA-256 differs from index.jsonl) "
                                 f"- refusing")
        C = pd.read_csv(fp)
        C = C[C["engine"].astype(str) == cfg["engine"]]
        for s, v in zip(C["symbol"].astype(str), pd.to_numeric(C["raw_stuck_pct"], errors="coerce")):
            if np.isfinite(v):
                prob[(np.datetime64(d, "D"), s.strip())] = round(float(v), cfg["trap_round_dp"])
        info["on_time_days"].append(d)
    return prob, info


def load_adv(panel: Path, pairs: set, naive) -> Dict[Tuple[np.datetime64, str], float]:
    """panel_oc's X_turnover_med for the (day, symbol) pairs asked for."""
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(panel)
    try:                                                  # closed explicitly: Windows keeps an open file locked
        if "X_turnover_med" not in pf.schema_arrow.names:
            raise PreconditionError(f"{panel} has no X_turnover_med column (stage E's liquidity cap)")
        syms = {s for _, s in pairs}
        out = {}
        for rb in pf.iter_batches(batch_size=250_000, columns=["timestamp", "symbol", "X_turnover_med"]):
            df = rb.to_pandas()
            s = df["symbol"].astype(str)
            m = s.isin(syms).to_numpy()
            if not m.any():
                continue
            sub = df.loc[m]
            days = naive(sub["timestamp"]).to_numpy(dtype="datetime64[ns]").astype("datetime64[D]")
            for d_, s_, v_ in zip(days, s[m].to_numpy(),
                                  pd.to_numeric(sub["X_turnover_med"], errors="coerce").to_numpy(float)):
                if (d_, s_) in pairs:
                    out[(d_, s_)] = float(v_)
        return out
    finally:
        if hasattr(pf, "close"):
            pf.close()


class ProductionMarket:
    """Bars through stage E's own loader, ETFs by the replay's name rule."""

    def __init__(self, root: Path):
        self.root = Path(root)

    def load_bars(self, symbols) -> dict:
        return EX.load_bars(self.root, list(symbols))

    def etf_set(self, symbols) -> set:
        extra = RC.load_symbol_list(self.root / RC.UNIVERSE_EXCLUDE_FILE)
        return {s for s in symbols if RC.is_etf_symbol(s, extra)}

    def naive(self, s: pd.Series) -> pd.Series:
        return EX.SB._naive(s)


def prepare(root: Path, market, cfg: dict = CFG, say=lambda m: None) -> dict:
    root = Path(root)
    W, winfo = read_watchlists(root, cfg)
    syms = sorted({s for v in W.values() for s in v})
    etf = market.etf_set(syms)
    if etf:
        W = {d: [s for s in v if s not in etf] for d, v in W.items()}
    say(f"watchlists: {len(W):,} days {winfo['first']} .. {winfo['last']} ({len(syms):,} stocks; ETFs out: {len(etf)})")
    bars = market.load_bars(sorted(set(syms) - etf) + ["NIFTY50"])
    if "NIFTY50" not in bars:
        raise PreconditionError("NIFTY50 bars missing from the cache (the trading calendar)")
    first = min(W)
    allts = np.unique(np.concatenate([np.asarray(b.ts, dtype="datetime64[ns]") for b in bars.values()]))
    cal = allts[allts >= np.datetime64(first, "ns")]
    cal_days = cal.astype("datetime64[D]")
    two_ts = sorted({str(d) for d, c in zip(*np.unique(cal_days, return_counts=True)) if c > 1})
    day_ts: Dict[np.datetime64, np.datetime64] = {}
    for d_, t_ in zip(cal_days, cal):
        day_ts.setdefault(d_, t_)
    lists, no_session = {}, []
    for d, v in sorted(W.items()):
        t = day_ts.get(d)
        if t is None:
            no_session.append(str(d))
            continue
        lists[t] = v
    # the paper test's late rule: recorded after 09:00 of the entry session -> it could not be traded at that open
    pos = {t: i for i, t in enumerate(cal)}
    cut_h = pd.Timedelta(f"{cfg['late_cutoff']}:00")
    late, not_yet = [], []
    for t in sorted(lists):
        i = pos[t]
        d = np.datetime64(t, "D")
        if i + 1 >= len(cal):
            not_yet.append(str(d))
            continue
        cut = pd.Timestamp(cal[i + 1]).normalize() + cut_h
        rec = winfo["recorded_at"].get(d)
        if rec is None or rec > cut:
            late.append(f"{d} (recorded {rec:%Y-%m-%d %H:%M})" if rec is not None else f"{d} (no recording time)")
            del lists[t]
    rec_days = set(W)
    gaps = [str(d) for d in sorted(day_ts) if np.datetime64(cfg["forward_start"], "D") <= d <= max(W) and d not in rec_days]
    pairs = {(np.datetime64(t, "D"), s) for t, v in lists.items() for s in v[:cfg["trap_top"]]}
    panel = root / LIVE_PANEL
    if not panel.exists():
        raise PreconditionError(f"{panel} not found - the live panel Run Now extends every night holds stage E's "
                                f"liquidity figure X_turnover_med for the forward days (panel_oc is frozen at 22 Sep)")
    advD = load_adv(panel, pairs, market.naive)
    adv = {(day_ts[d], s): v for (d, s), v in advD.items()}
    have = sum(1 for p_ in pairs if np.isfinite(advD.get(p_, float("nan"))) and advD.get(p_, 0) > 0)
    cov = have / len(pairs) if pairs else 1.0
    if cov < cfg["min_liquidity_coverage"]:
        miss = sorted(f"{d} {s}" for d, s in pairs if not (advD.get((d, s), 0) > 0))[:8]
        raise PreconditionError(f"panel_live has the liquidity figure for {cov:.2%} of the top-10 entries (need "
                                f"{cfg['min_liquidity_coverage']:.0%}); e.g. {miss} - run Run Now first")
    prob, cinfo = read_cards(root, cfg)
    if late:
        say(f"late watchlists (recorded after {cfg['late_cutoff']} of the entry session; no buys): {', '.join(late)}")
    say(f"cards: {len(cinfo['on_time_days'])} on time, {len(cinfo['late_days'])} late (late ones flag nothing); "
        f"liquidity figure for {cov:.2%} of top-10 entries; calendar {len(cal):,} sessions to "
        f"{pd.Timestamp(cal[-1]).date()}")
    return {"lists": lists, "bars": bars, "adv": adv, "cal": cal, "prob": prob, "sc": EX.primary_scenario(),
            "info": {"watchlists": {k: v for k, v in winfo.items() if k != "recorded_at"},
                     "late_watchlists": late, "awaiting_entry_session": not_yet,
                     "etfs_removed": sorted(etf), "signal_days_without_session": no_session,
                     "sessions_without_watchlist": gaps, "days_with_two_bars": two_ts, "liquidity_coverage": cov,
                     "cards": cinfo, "last_session": str(pd.Timestamp(cal[-1]).date())}}


# ----------------------------------------------------------------------
# lanes
# ----------------------------------------------------------------------
def lane_setup(name: str, lists: Dict, prob: Dict, cfg: dict = CFG):
    info = {}
    if "TRAP" in name:
        lists, info = DR.trap_lists(lists, prob, line=cfg["trap_line_pct"], top=cfg["trap_top"])
    planner = DR.open6_planner if "OPEN6" in name else None
    return lists, planner, info


def window_lists(lists: Dict, end: Optional[str]) -> Dict:
    if end is None:
        return dict(lists)
    e = np.datetime64(end, "D")
    return {t: v for t, v in lists.items() if np.datetime64(t, "D") <= e}


def run_lanes(data: dict, end: Optional[str] = None, cfg: dict = CFG) -> dict:
    """Every lane at full size and at its replay size; at full size each must equal stage E's own simulate()."""
    lw = window_lists(data["lists"], end)
    out, integ = {}, {}
    for name in cfg["lanes"]:
        lists, planner, info = lane_setup(name, lw, data["prob"], cfg)
        full = DR.simulate_x(data["sc"], lists, data["bars"], data["adv"], data["cal"], keep_trades=True,
                             exit_planner=planner, scale=1.0)
        ref = EX.simulate(data["sc"], lists, data["bars"], data["adv"], data["cal"], keep_trades=True,
                          exit_planner=planner)
        ok, why = DR.same_run(full, ref)
        integ[name] = why
        if not ok:
            raise IntegrityError(f"lane {name}: the simulator copy differs from stage E's simulate() - {why}")
        f = cfg["replay_sizes"][name]
        rep = DR.simulate_x(data["sc"], lists, data["bars"], data["adv"], data["cal"], keep_trades=True,
                            exit_planner=planner, scale=f)
        out[name] = {"full": full, "replay": rep, "f": f, "lists": lists, "info": info}
    return {"lanes": out, "integrity": integ, "lists": lw}


def _settled(n: int, planned: int, x: int, kind: str, flags: dict, search: int) -> bool:
    if flags.get("data_end"):
        return False
    if flags.get("locked_exit"):
        return kind == "open" or x == planned + search
    return True


def both_exits(b, e: int, hold: int = 5, search: int = 20) -> dict:
    """The plan's exit (5th close) and the 6th-open exit of a position bought at bar e's open, and whether each
    is final in the data."""
    n = len(b.c)
    x5, k5, r5, f5 = EX.plan_exit(b, e, hold, None)
    x6, k6, r6, f6 = DR.open6_exit(b, e)
    return {"x5": int(x5), "kind5": k5, "raw5": float(r5), "locked5": bool(f5["locked_exit"]),
            "ok5": _settled(n, e + hold - 1, x5, k5, f5, search),
            "x6": int(x6), "kind6": k6, "raw6": float(r6), "locked6": bool(f6["locked_exit"]),
            "ok6": _settled(n, e + 5, x6, k6, f6, search)}


def open6_pairs(plan_full: dict, data: dict) -> pd.DataFrame:
    """J1 rows: every PLAN trade at full size (closed ones; an open PLAN position cannot be settled)."""
    t = plan_full["trades"]
    rows = []
    for r in t.itertuples():
        b = data["bars"][r.symbol]
        e = b.index.get(pd.Timestamp(r.entry_day).to_datetime64())
        if e is None:
            continue
        x = both_exits(b, int(e))
        o = float(b.o[e])
        rows.append({"signal_day": pd.Timestamp(r.signal_day), "symbol": r.symbol, "rank": int(r.rank),
                     "entry_day": pd.Timestamp(r.entry_day), "entry_open": o,
                     "exit5_day": pd.Timestamp(b.ts[x["x5"]]), "exit5_kind": x["kind5"], "exit5_raw": x["raw5"],
                     "exit6_day": pd.Timestamp(b.ts[x["x6"]]), "exit6_kind": x["kind6"], "exit6_raw": x["raw6"],
                     "locked5": x["locked5"], "locked6": x["locked6"],
                     "ret5_bp": (x["raw5"] / o - 1) * 1e4, "ret6_bp": (x["raw6"] / o - 1) * 1e4,
                     "diff_bp": (x["raw6"] - x["raw5"]) / o * 1e4, "settled": bool(x["ok5"] and x["ok6"])})
    cols = ["signal_day", "symbol", "rank", "entry_day", "entry_open", "exit5_day", "exit5_kind", "exit5_raw",
            "exit6_day", "exit6_kind", "exit6_raw", "locked5", "locked6", "ret5_bp", "ret6_bp", "diff_bp", "settled"]
    return pd.DataFrame(rows, columns=cols)


def first_buyable(wl: List[str], t, entry, data: dict, k: int) -> List[str]:
    """The first k picks the simulator can buy at the entry open: a bar that session, an open above 0, a
    liquidity cap above 0 (cash and share rounding aside)."""
    sc = data["sc"]
    out = []
    for s in wl[:sc.depth]:
        b = data["bars"].get(s)
        e = b.index.get(entry) if b is not None else None
        if e is None or not (b.o[e] > 0):
            continue
        a = data["adv"].get((t, s), float("nan"))
        if sc.liquidity_cap is not None and not (np.isfinite(a) and sc.liquidity_cap * a > 0):
            continue
        out.append(s)
        if len(out) >= k:
            break
    return out


def trap_swaps(base_lists: Dict, trap_lists_: Dict, data: dict, cfg: dict = CFG) -> Tuple[pd.DataFrame, dict]:
    """J2 rows: each flagged pick the trap rule took out of the 3 bought, against the pick bought instead."""
    cal = data["cal"]
    pos = {t: i for i, t in enumerate(cal)}
    rows, flagged_top10, flagged_days = [], 0, 0
    for t in sorted(base_lists):
        L, T_ = base_lists[t], trap_lists_.get(t, base_lists[t])
        d = np.datetime64(t, "D")
        nf = sum(1 for s in L[:cfg["trap_top"]] if data["prob"].get((d, s), float("nan")) >= cfg["trap_line_pct"])
        flagged_top10 += nf
        flagged_days += int(nf > 0)
        if L == T_:
            continue
        i = pos.get(t)
        if i is None or i + 1 >= len(cal):
            continue
        entry = cal[i + 1]
        k = cfg["picks_per_day"]
        S0, S1 = first_buyable(L, t, entry, data, k), first_buyable(T_, t, entry, data, k)
        out_ = [s for s in S0 if s not in S1]
        in_ = [s for s in S1 if s not in S0]
        for so, si in zip(out_, in_):
            rec = {"signal_day": pd.Timestamp(t), "entry_day": pd.Timestamp(entry), "flagged": so, "instead": si,
                   "p_stuck_flagged": data["prob"].get((d, so), float("nan")),
                   "p_stuck_instead": data["prob"].get((d, si), float("nan"))}
            ok = True
            for tag, s in (("flagged", so), ("instead", si)):
                b = data["bars"][s]
                e = int(b.index[entry])
                x = both_exits(b, e)
                rec[f"{tag}_ret6_bp"] = (x["raw6"] / float(b.o[e]) - 1) * 1e4
                rec[f"{tag}_locked"] = x["locked6"]
                rec[f"{tag}_exit_day"] = pd.Timestamp(b.ts[x["x6"]])
                ok = ok and x["ok6"]
            rec["diff_bp"] = rec["instead_ret6_bp"] - rec["flagged_ret6_bp"]
            rec["settled"] = bool(ok)
            rows.append(rec)
    cols = ["signal_day", "entry_day", "flagged", "instead", "p_stuck_flagged", "p_stuck_instead", "flagged_ret6_bp",
            "flagged_locked", "flagged_exit_day", "instead_ret6_bp", "instead_locked", "instead_exit_day", "diff_bp",
            "settled"]
    return pd.DataFrame(rows, columns=cols), {"flagged_top10_entries": int(flagged_top10),
                                               "days_with_flags": int(flagged_days)}


# ----------------------------------------------------------------------
# statistics
# ----------------------------------------------------------------------
def block_mean(groups: np.ndarray, x: np.ndarray, B: int, block: int, seed: int, min_groups: int) -> dict:
    """Mean of x with a 95% interval from circular blocks of `block` consecutive groups (signal days or
    sessions), resampled B times. Fewer than `min_groups` groups: no interval (NaN). With circular blocks, a
    sample of no more groups than one block resamples to itself, so its 'interval' would be the mean alone."""
    x = np.asarray(x, float)
    ok = np.isfinite(x)
    x, groups = x[ok], np.asarray(groups)[ok]
    out = {"n": int(len(x)), "groups": 0, "mean": float(x.mean()) if len(x) else float("nan"),
           "lo": float("nan"), "hi": float("nan")}
    if len(x) == 0:
        return out
    ug, inv = np.unique(groups, return_inverse=True)
    n = len(ug)
    out["groups"] = int(n)
    if n < max(2, min_groups):
        return out
    s = np.bincount(inv, weights=x, minlength=n)
    c = np.bincount(inv, minlength=n).astype(float)
    rng = np.random.default_rng(seed)
    nb = int(math.ceil(n / block))
    st = rng.integers(0, n, size=(B, nb))
    idx = ((st[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(B, -1)[:, :n]
    m = s[idx].sum(axis=1) / c[idx].sum(axis=1)
    out["lo"], out["hi"] = float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))
    return out


def verdict(r: dict, min_n: Optional[int] = None) -> str:
    if min_n is not None and r["n"] < min_n:
        return "NOT ENOUGH EVENTS"
    if not np.isfinite(r["lo"]):
        return "NOT YET"
    if r["lo"] > 0:
        return "CONFIRMED"
    if r["hi"] < 0:
        return "CONTRADICTED"
    return "NOT YET"


def trade_final(trades: pd.DataFrame, data: dict, lane: str) -> np.ndarray:
    """Which of a lane's trades really closed. Stage E sells at the last close (a) a position whose exit lies
    beyond the data (data_end) and (b) one still locked at the lower band when the data cuts its 20-session
    search short; both are still open in the market."""
    if not len(trades):
        return np.zeros(0, bool)
    o6 = "OPEN6" in lane
    k = DR.CFG["open6_session"] if o6 else data["sc"].hold
    search = DR.CFG["lock_search_sessions"] if o6 else 20          # stage E's plan_exit searches 20 sessions
    out = []
    for r in trades.itertuples():
        b = data["bars"][r.symbol]
        e = b.index.get(pd.Timestamp(r.entry_day).to_datetime64())
        x = b.index.get(pd.Timestamp(r.exit_day).to_datetime64())
        if e is None or x is None:
            out.append(not bool(r.data_end))
            continue
        out.append(_settled(len(b.c), int(e) + k - 1, int(x), str(r.exit_kind),
                            {"data_end": bool(r.data_end), "locked_exit": bool(r.locked_exit)}, search))
    return np.asarray(out, bool)


def _trim(res: dict, until) -> dict:
    """The lane up to `until` (the sessions after the last exit of the window's positions hold no position)."""
    out = dict(res)
    out["equity"] = res["equity"][res["equity"].index <= until]
    return out


def lane_measures(res: dict, final: np.ndarray, cfg: dict = CFG) -> dict:
    """dd_replay's measures; the trade figures over the trades that really closed (trade_final). A position
    still open counts as sold at the last close in the return and drawdown (stage E's end-of-data rule)."""
    m = DR.measure(res)
    sessions = int(len(res["equity"]))
    m["sessions"] = sessions
    if sessions < cfg["cagr_min_sessions"]:
        m["cagr"] = float("nan")
    t = res["trades"]
    done = t[final] if len(t) else t
    m["open_at_end"] = int((~final).sum()) + int(res["open_at_end"])
    m["trades"] = int(len(done))
    m["avg_trade_bp"] = float(done["ret"].mean() * 1e4) if len(done) else float("nan")
    m["win_rate"] = float((done["ret"] > 0).mean()) if len(done) else float("nan")
    m["locked_exits"] = int(done["locked_exit"].astype(bool).sum()) if len(done) else 0
    return m


def daily_diffs(lanes: dict, cfg: dict = CFG) -> dict:
    r = {n: lanes[n]["full"]["equity"]["equity"].pct_change() for n in cfg["lanes"]}
    out = {}
    for a, b in (("OPEN6", "PLAN"), ("OPEN6+TRAP", "OPEN6")):
        d = (r[a] - r[b]).dropna()
        out[f"{a} - {b}"] = block_mean(np.arange(len(d)), d.to_numpy() * 1e4, cfg["boot_B"], cfg["boot_block"],
                                       cfg["boot_seed"], cfg["min_interval_groups"])
    return out


# ----------------------------------------------------------------------
# the study: a snapshot (track) or a checkpoint (judge)
# ----------------------------------------------------------------------
def evaluate(data: dict, end: Optional[str] = None, cfg: dict = CFG) -> dict:
    R = run_lanes(data, end, cfg)
    L = R["lanes"]
    pairs = open6_pairs(L["PLAN"]["full"], data)
    sw, tinfo = trap_swaps(R["lists"], L["OPEN6+TRAP"]["lists"], data, cfg)
    ps, ss = pairs[pairs["settled"].astype(bool)], sw[sw["settled"].astype(bool)]
    j1 = block_mean(ps["signal_day"].to_numpy(dtype="datetime64[ns]"), ps["diff_bp"].to_numpy(float), cfg["boot_B"],
                    cfg["boot_block"], cfg["boot_seed"], cfg["min_interval_groups"])
    j1["verdict"] = verdict(j1)
    j1["share_6th_open_better"] = float((ps["diff_bp"] > 0).mean()) if len(ps) else float("nan")
    ref = cfg["reference_open6_bp"]
    j1["backtest_inside"] = (bool(j1["lo"] <= ref["mean"] <= j1["hi"]) if np.isfinite(j1["lo"]) else None)
    j1["unsettled"] = int((~pairs["settled"]).sum())
    j1["mean_ret5_bp"] = float(ps["ret5_bp"].mean()) if len(ps) else float("nan")
    j1["mean_ret6_bp"] = float(ps["ret6_bp"].mean()) if len(ps) else float("nan")
    j2 = block_mean(ss["signal_day"].to_numpy(dtype="datetime64[ns]"), ss["diff_bp"].to_numpy(float), cfg["boot_B"],
                    cfg["boot_block"], cfg["boot_seed"], cfg["min_interval_groups"])
    j2["verdict"] = verdict(j2, cfg["min_swaps"])
    j2.update(tinfo)
    j2["swaps_all"] = int(len(sw))
    j2["unsettled"] = int((~sw["settled"]).sum())
    j2["flagged_locked"] = int(ss["flagged_locked"].sum()) if len(ss) else 0
    j2["instead_locked"] = int(ss["instead_locked"].sum()) if len(ss) else 0
    # the lanes to the last exit of the window's positions (at a checkpoint the later sessions hold nothing)
    exits = [pd.Timestamp(L[n][sz]["trades"]["exit_day"].max()) for n in cfg["lanes"] for sz in SIZES
             if len(L[n][sz]["trades"])]
    cal = data["cal"]
    in_win = cal if end is None else cal[cal.astype("datetime64[D]") <= np.datetime64(end, "D")]
    until = max(exits + [pd.Timestamp(in_win[-1] if len(in_win) else cal[0])])
    LT = {n: {**L[n], **{sz: _trim(L[n][sz], until) for sz in SIZES}} for n in cfg["lanes"]}
    meas = {n: {sz: lane_measures(LT[n][sz], trade_final(LT[n][sz]["trades"], data, n), cfg) for sz in SIZES}
            for n in cfg["lanes"]}
    for n in cfg["lanes"]:
        meas[n]["f"] = L[n]["f"]
    return {"lanes": LT, "measures": meas, "integrity": R["integrity"], "pairs": pairs, "swaps": sw, "J1": j1,
            "J2": j2, "J3": daily_diffs(LT, cfg), "window_end": end, "lanes_until": str(until.date()),
            "signal_days": int(len(R["lists"])),
            "last_watchlist": str(max(np.datetime64(t, "D") for t in R["lists"])) if R["lists"] else None,
            "open_positions": {n: {sz: meas[n][sz]["open_at_end"] for sz in SIZES} for n in cfg["lanes"]}}


def settlement(data: dict, E: dict, checkpoint: str, cfg: dict = CFG) -> List[str]:
    """What is still missing before a checkpoint can be judged (empty = ready)."""
    end = np.datetime64(cfg["checkpoints"][checkpoint], "D")
    cal_days = data["cal"].astype("datetime64[D]")
    miss = []
    upto = cal_days[cal_days <= end]
    if not (cal_days > end).any():
        miss.append(f"the cache has no session after {end} yet")
    last_rec = max(np.datetime64(t, "D") for t in data["lists"])
    if len(upto) and last_rec < upto[-1]:
        miss.append(f"the paper ledger's last D watchlist is {last_rec}; the window needs the one of {upto[-1]}")
    open_ = {f"{n} {sz}": v for n, d in E["open_positions"].items() for sz, v in d.items() if v}
    if open_:
        miss.append(f"positions still open: {open_}")
    if E["J1"]["unsettled"] or E["J2"]["unsettled"]:
        miss.append(f"exits not final yet: {E['J1']['unsettled']} plan trades, {E['J2']['unsettled']} swaps")
    return miss


def _new_dir(base: Path, prefix: str, now: dt.datetime) -> Path:
    k = 1
    while (base / f"{prefix}_{now:%Y%m%d}_{k:03d}").exists():
        k += 1
    p = base / f"{prefix}_{now:%Y%m%d}_{k:03d}"
    p.mkdir(parents=True)
    return p


def _ledger(root: Path) -> Path:
    return Path(root) / "panel" / "panel.parquet"


def declared_before(root: Path, dsha: str) -> bool:
    E = RC.ledger_entries(_ledger(root))
    first = next((e for e in E if e.get("kind") == "shadow_lanes_declared"), None)
    if first is not None and first.get("declaration_sha") != dsha:
        raise PreconditionError(f"SHADOW_LANES_DECLARATION.json ({dsha}) is not the one first used "
                                f"({first.get('declaration_sha')}, {first.get('at', '')[:16]}) - the declaration is fixed")
    return first is not None


def write_outputs(out: Path, E: dict, S: dict, data: dict, cfg: dict = CFG) -> None:
    rows = []
    for n in cfg["lanes"]:
        for sz in SIZES:
            eq = E["lanes"][n][sz]["equity"].reset_index()
            eq.insert(1, "lane", n)
            eq.insert(2, "size", sz)
            rows.append(eq)
    pd.concat(rows, ignore_index=True).to_csv(out / "lanes_daily.csv", index=False)
    tr = []
    for n in cfg["lanes"]:
        for sz in SIZES:
            t = E["lanes"][n][sz]["trades"]
            if len(t):
                tr.append(t.assign(lane=n, size=sz, closed=trade_final(t, data, n)))
    (pd.concat(tr, ignore_index=True) if tr else pd.DataFrame(columns=["lane", "size"])).to_csv(out / "trades.csv",
                                                                                               index=False)
    E["pairs"].to_csv(out / "open6_pairs.csv", index=False)
    E["swaps"].to_csv(out / "trap_swaps.csv", index=False)
    (out / "summary.json").write_text(json.dumps(S, indent=2, default=_json), encoding="utf-8")
    (out / "report.md").write_text(report_md(S, cfg), encoding="utf-8")
    lines = [f"{_sha256(p)}  {p.name}" for p in sorted(out.iterdir()) if p.is_file() and p.name != "outputs.sha256"]
    (out / "outputs.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _json(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, (pd.Timestamp, np.datetime64, dt.date)):
        return str(pd.Timestamp(o).date())
    return str(o)


def summary(E: dict, data: dict, kind: str, run_id: str, dsha: str, now: dt.datetime, checkpoint: Optional[str],
            origins: dict, cfg: dict = CFG) -> dict:
    clean = lambda d: {k: (None if isinstance(v, float) and not np.isfinite(v) else v) for k, v in d.items()}
    return {"tool": CODE_VERSION, "family": FAMILY, "kind": kind, "run_id": run_id, "declaration_sha": dsha,
            "when": f"{now:%Y-%m-%d %H:%M}", "checkpoint": checkpoint,
            "window": {"from": cfg["forward_start"], "to": E["last_watchlist"], "end": E["window_end"],
                       "data_to": data["info"]["last_session"], "lanes_until": E["lanes_until"],
                       "signal_days": E["signal_days"]},
            "inputs": data["info"], "integrity": {"simulator_vs_stage_e": E["integrity"]},
            "lanes": {n: {"f": E["measures"][n]["f"], **{sz: clean(E["measures"][n][sz]) for sz in SIZES}}
                      for n in cfg["lanes"]},
            "J1": clean(E["J1"]), "J2": clean(E["J2"]), "J3": {k: clean(v) for k, v in E["J3"].items()},
            "open_positions": E["open_positions"], "config": cfg, "origins": origins,
            "versions": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__}}


def _p(x, d=1, sign=True) -> str:
    if x is None or not np.isfinite(x):
        return "n/a"
    return f"{x * 100:+.{d}f}%" if sign else f"{x * 100:.{d}f}%"


def _num(x, d=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x:+.{d}f}"


def _has_iv(r: dict) -> bool:
    return r.get("lo") is not None and bool(np.isfinite(r["lo"]))


def _bp(r: dict, d=1, unit="signal days") -> str:
    m, lo, hi = (r.get(k) for k in ("mean", "lo", "hi"))
    if m is None or not np.isfinite(m):
        return "n/a"
    if lo is None or not np.isfinite(lo):
        return (f"{m:+.{d}f} bp (no interval yet: {r.get('groups', 0)} {unit}, an interval needs "
                f"{CFG['min_interval_groups']})")
    return f"{m:+.{d}f} bp [{lo:+.{d}f}, {hi:+.{d}f}]"


def report_md(S: dict, cfg: dict = CFG) -> str:
    judged = S["kind"] == "judge"
    tag = (f"**CHECKPOINT month {S['checkpoint']} - verdicts as declared**" if judged else
           "**RUNNING - not a verdict.** Verdicts come only at the checkpoints (month 6: signal days through "
           f"{cfg['checkpoints']['6']}; month 12: through {cfg['checkpoints']['12']}).")
    I = S["inputs"]
    W = S["window"]
    L = [f"# Shadow lanes - {S['run_id']}", "",
         f"{CODE_VERSION} | declaration {S['declaration_sha']} | stage E {cfg['stage_e_version']} | {cfg['dd_replay_version']} "
         f"| replay sizes from {cfg['replay_run']} | {S['when']}", "", tag, "",
         "Forward evidence: the paper test's own D watchlists, recorded each evening since 30 Sep 2026. The lanes are "
         "computed beside the paper test in stage E's simulator; nothing in production changes.", "",
         f"## 1. Lanes - signal days {W['from']} .. {W['to']} ({W['signal_days']:,} with a watchlist; bars to "
         f"{W['data_to']}), Rs 10 lakh", "",
         "| lane | size | return | CAGR | worst drawdown (peak -> trough) | trades closed | still open | avg closed "
         "trade | win | locked exits | costs |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    for n in cfg["lanes"]:
        for sz in SIZES:
            m = S["lanes"][n][sz]
            f = 1.0 if sz == "full" else S["lanes"][n]["f"]
            dd = f"{_p(m['max_dd'])} ({m['dd_peak']} -> {m['dd_trough']})" if m.get("dd_peak") else _p(m["max_dd"])
            avg = "n/a" if m["avg_trade_bp"] is None else f"{m['avg_trade_bp']:+.1f} bp"
            L.append(f"| {n} | {f:.3f} | {_p(m['total_return'])} | {_p(m['cagr'])} | {dd} | {m['trades']:,} | "
                     f"{m['open_at_end']} | {avg} | {_p(m['win_rate'], 1, False)} | {m['locked_exits']} | "
                     f"Rs {m['costs']:,.0f} |")
    L += ["", f"Sessions to {W['lanes_until']}. CAGR is shown from {cfg['cagr_min_sessions']} sessions on (annualising a "
              "few weeks says nothing). Size = the share of the plan's 1/15 of equity each new position gets. A position "
              "still open counts as sold at the last close in the return and drawdown (stage E's end-of-data rule); the "
              "trade figures cover closed trades only.", ""]
    j1 = S["J1"]
    ref = cfg["reference_open6_bp"]
    L += ["## 2. J1 - sell at the 6th open instead of the 5th close, trade by trade", "",
          f"- PLAN trades with both exits final: {j1['n']:,} on {j1['groups']:,} signal days (not final yet: "
          f"{j1['unsettled']}).",
          f"- 6th open minus 5th close: **{_bp(j1)}**"
          + (" (95% interval, blocks of 10 signal days)" if _has_iv(j1) else "") + " -> "
          f"**{j1['verdict'] if judged else 'running: ' + j1['verdict']}**",
          f"- Average trade from the entry open: 5th close {_num(j1['mean_ret5_bp'])} bp, 6th open "
          f"{_num(j1['mean_ret6_bp'])} bp; the 6th open was better on {_p(j1['share_6th_open_better'], 1, False)} of "
          f"trades.",
          f"- Backtest: {ref['mean']:+.1f} bp [{ref['lo']:+.1f}, {ref['hi']:+.1f}] ({ref['source']}) - "
          + ("no forward interval yet." if j1["backtest_inside"] is None else
             f"{'inside' if j1['backtest_inside'] else 'not inside'} the forward interval."), ""]
    j2 = S["J2"]
    L += ["## 3. J2 - the trap swap (on-time P(stuck) >= 10%)", "",
          f"- Top-10 entries flagged: {j2['flagged_top10_entries']:,} on {j2['days_with_flags']:,} days; swaps among the "
          f"3 bought: {j2['swaps_all']:,} ({j2['n']:,} final, {j2['unsettled']} not yet).",
          f"- The pick bought instead minus the flagged pick (6th-open exits): **{_bp(j2)}** -> "
          f"**{j2['verdict'] if judged else 'running: ' + j2['verdict']}** (fewer than {cfg['min_swaps']} swaps = NOT "
          f"ENOUGH EVENTS).",
          f"- Locked exits: {j2['flagged_locked']} of the flagged picks, {j2['instead_locked']} of the picks bought "
          f"instead.", ""]
    L += ["## 4. J3 - daily return differences at full size (descriptive)", ""]
    for k, v in S["J3"].items():
        if v.get("mean") is None or not np.isfinite(v["mean"]):
            L.append(f"- {k}: n/a")
        elif _has_iv(v):
            L.append(f"- {k}: {v['mean']:+.2f} bp a session [{v['lo']:+.2f}, {v['hi']:+.2f}] over {v['n']:,} sessions "
                     f"(blocks of 10 sessions)")
        else:
            L.append(f"- {k}: {v['mean']:+.2f} bp a session over {v['n']:,} sessions (no interval before "
                     f"{cfg['min_interval_groups']})")
    cards = I["cards"]
    L += ["", "## 5. Inputs and integrity", "",
          f"- Watchlists: {I['watchlists']['days']:,} days {I['watchlists']['first']} .. {I['watchlists']['last']}; "
          f"sessions without a recorded watchlist: {', '.join(I['sessions_without_watchlist']) or 'none'}; "
          f"days recorded twice with different picks: {', '.join(I['watchlists']['days_recorded_twice_with_different_picks']) or 'none'}.",
          f"- Late watchlists (recorded after {cfg['late_cutoff']} of the entry session - the paper test's late rule; no "
          f"buys in any lane): {', '.join(I['late_watchlists']) or 'none'}.",
          f"- Cards: on time {len(cards['on_time_days'])} (from {cards['on_time_days'][0] if cards['on_time_days'] else 'n/a'}), "
          f"late {len(cards['late_days'])} - late cards flag nothing.",
          f"- Liquidity figure for {I['liquidity_coverage']:.2%} of top-10 entries; ETFs removed: "
          f"{', '.join(I['etfs_removed']) or 'none'}; days with two bars: {', '.join(I['days_with_two_bars']) or 'none'}.",
          "- Simulator copy against stage E's simulate() at full size: " +
          "; ".join(f"{n} {v}" for n, v in S["integrity"]["simulator_vs_stage_e"].items()) + ".", "",
          "## 6. What this does not say", "",
          "- A running number is not a verdict: deciding on a good or bad week is what the checkpoints exist to prevent.",
          "- Six months is short: J1 can confirm an effect near the backtest's size; J2 will likely need month 12.",
          "- Stage E's fills (opening auction, closing price, impact model) for every lane, not the paper test's own; "
          "whether Zerodha lets the opening-auction sale pay for that morning's buys is not modelled.", ""]
    if judged:
        L += ["## Verdicts", "", f"- J1 (6th-open exit): **{j1['verdict']}**", f"- J2 (trap swap): **{j2['verdict']}**",
              "", f"Adoption rule (declared): {json.loads(DECL_FILE.read_text(encoding='utf-8'))['adoption']}", ""]
    return "\n".join(L)


def console(S: dict, out: Path, cfg: dict = CFG) -> str:
    j1, j2 = S["J1"], S["J2"]
    head = f"CHECKPOINT month {S['checkpoint']}" if S["kind"] == "judge" else "RUNNING - not a verdict"
    L = ["=" * 78, f"{CODE_VERSION} | {S['run_id']} | {head}",
         f"signal days {S['window']['from']} .. {S['window']['to']} ({S['window']['signal_days']} with a watchlist; "
         f"bars to {S['window']['data_to']})"]
    for n in cfg["lanes"]:
        m, r = S["lanes"][n]["full"], S["lanes"][n]["replay"]
        L.append(f"  {n:<11} full {_p(m['total_return']):>8} (worst {_p(m['max_dd'])})   size {S['lanes'][n]['f']:.3f} "
                 f"{_p(r['total_return']):>8} (worst {_p(r['max_dd'])})   closed {m['trades']}, open {m['open_at_end']}")
    run_ = "" if S["kind"] == "judge" else "running: "
    L.append(f"  J1 6th open - 5th close: {_bp(j1)} on {j1['n']} trades -> {run_}{j1['verdict']}")
    L.append(f"  J2 trap swap: {_bp(j2)} on {j2['n']} swaps -> {run_}{j2['verdict']}")
    if S["inputs"]["days_with_two_bars"]:
        L.append(f"  WARNING days holding two bars (counted as two sessions): {', '.join(S['inputs']['days_with_two_bars'])}")
    if S["inputs"]["late_watchlists"]:
        L.append(f"  late watchlists (no buys): {', '.join(S['inputs']['late_watchlists'])}")
    L.append(f"  outputs: {out}")
    L.append("=" * 78)
    return "\n".join(L)


def run(root: Path, kind: str = "track", checkpoint: Optional[str] = None, market=None, verbose: bool = True,
        rerun_reason: Optional[str] = None, now: Optional[dt.datetime] = None, cfg: dict = CFG) -> dict:
    root = Path(root)
    say = _log if verbose else (lambda m: None)
    _, dsha = load_declaration()
    origins = check_modules(cfg)
    if not (root / "panel").is_dir():
        raise PreconditionError(f"{root / 'panel'} not found: --root must be the data root (it holds panel\\ and "
                                f"research2\\)")
    seen_decl = declared_before(root, dsha)
    if kind == "judge":
        if checkpoint not in cfg["checkpoints"]:
            raise PreconditionError(f"checkpoint must be one of {sorted(cfg['checkpoints'])}")
        done = [e for e in RC.ledger_entries(_ledger(root)) if e.get("kind") == "shadow_lanes_judged"
                and str(e.get("checkpoint")) == checkpoint]
        if done and not rerun_reason:
            raise PreconditionError(f"month {checkpoint} was already judged ({done[-1].get('run_id')}); a second "
                                    f"judging needs --rerun-reason \"...\" (a verified bug only)")
    market = market or ProductionMarket(root)
    say(f"{CODE_VERSION} | declaration {dsha} | {kind}{' month ' + checkpoint if checkpoint else ''}")
    data = prepare(root, market, cfg, say)
    end = cfg["checkpoints"][checkpoint] if kind == "judge" else None
    two = data["info"]["days_with_two_bars"]
    if two:
        if kind == "judge":
            raise PreconditionError(f"days holding two bars ({', '.join(two)}): the simulator's calendar counts each as "
                                    f"two sessions - fix the duplicate bars in the cache first")
        say(f"WARNING days holding two bars ({', '.join(two)}): the calendar counts each as two sessions")
    say("running the lanes (full size and replay size; each checked against stage E's simulate)")
    E = evaluate(data, end, cfg)
    if kind == "judge":
        miss = settlement(data, E, checkpoint, cfg)
        if miss:
            raise PreconditionError(f"month {checkpoint} cannot be judged yet: " + "; ".join(miss))
    now = now or dt.datetime.now()
    base = root / OUT_SUB
    prefix = "SL" if kind == "track" else f"SLJ_M{checkpoint}"
    out = _new_dir(base, prefix, now)
    if not seen_decl:
        RC.ledger_append(_ledger(root), {"kind": "shadow_lanes_declared", "tool": CODE_VERSION, "family": FAMILY,
                                         "declaration_sha": dsha, "run_id": out.name})
    S = summary(E, data, kind, out.name, dsha, now, checkpoint, origins, cfg)
    S["rerun_reason"] = rerun_reason
    write_outputs(out, E, S, data, cfg)
    rec = {"kind": "shadow_lanes_track" if kind == "track" else "shadow_lanes_judged", "tool": CODE_VERSION,
           "family": FAMILY, "run_id": out.name, "declaration_sha": dsha, "checkpoint": checkpoint,
           "signal_days": E["signal_days"], "J1": {k: S["J1"][k] for k in ("n", "mean", "lo", "hi", "verdict")},
           "J2": {k: S["J2"][k] for k in ("n", "mean", "lo", "hi", "verdict")}, "rerun_reason": rerun_reason}
    RC.ledger_append(_ledger(root), rec)
    if verbose:
        print(console(S, out, cfg))
    return {"out": out, "summary": S, "eval": E, "data": data}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="forward shadow lanes: the 6th-open exit and the trap swap")
    ap.add_argument("--version", action="version", version=CODE_VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("track", help="a dated snapshot of the lanes (running numbers)")
    t.add_argument("--root", required=True, help="the data root, e.g. %%CACHE_DAILY_ROOT%%")
    j = sub.add_parser("judge", help="the declared verdicts at a checkpoint (once, when settled)")
    j.add_argument("--root", required=True)
    j.add_argument("--checkpoint", required=True, choices=sorted(CFG["checkpoints"]))
    j.add_argument("--rerun-reason", default=None)
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.exists():
        print(f"Root does not exist: {root}")
        return 2
    try:
        if a.cmd == "track":
            run(root, "track")
        else:
            run(root, "judge", checkpoint=a.checkpoint, rerun_reason=a.rerun_reason)
    except PreconditionError as e:
        print(f"STOPPED: {e}")
        return 2
    except IntegrityError as e:
        print(f"STOPPED (integrity): {e}")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
