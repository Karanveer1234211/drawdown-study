#!/usr/bin/env python3
"""
engine_models.py - Stage B's state representations in plain numpy (no scikit-learn needed), each fitted on a fold's
training window only.

  Prep       robust scaling (median, IQR), clip at +-5, blanks -> 0, then PCA keeping 90% of the variance (2..8 parts)
  kmeans     k-means++ / Lloyd; hard states
  GMM        Gaussian mixture with diagonal covariances (EM, k-means start); soft state probabilities
  HMM        Gaussian hidden Markov model over each session's decision points (Baum-Welch on training sequences);
             state probabilities are FILTERED - the forward pass only, so a decision sees observations up to itself
  grid12     the interpretable human-made grid (the simple baseline)
  knn        nearest training analogues of the same stock
  ari / psi  stability measures
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

LOG2PI = np.log(2 * np.pi)


class Prep:
    def __init__(self, clip: float = 5.0, var_share: float = 0.9, pmin: int = 2, pmax: int = 8):
        self.clip, self.var_share, self.pmin, self.pmax = clip, var_share, pmin, pmax

    def fit(self, X: np.ndarray) -> "Prep":
        X = np.asarray(X, float)
        self.med = np.nanmedian(X, 0)
        q75, q25 = np.nanpercentile(X, 75, 0), np.nanpercentile(X, 25, 0)
        sc = (q75 - q25) / 1.349
        sd = np.nanstd(X, 0)
        sc = np.where(sc > 1e-12, sc, np.where(sd > 1e-12, sd, 1.0))
        self.med = np.where(np.isfinite(self.med), self.med, 0.0)
        self.scale = np.where(np.isfinite(sc), sc, 1.0)
        Z = self.z(X)
        self.mean = Z.mean(0)
        _, s, Vt = np.linalg.svd(Z - self.mean, full_matrices=False)
        v = s ** 2
        share = np.cumsum(v) / v.sum() if v.sum() > 0 else np.ones(len(v))
        p = int(np.clip(np.searchsorted(share, self.var_share) + 1, self.pmin, min(self.pmax, len(v))))
        self.comp, self.explained = Vt[:p], float(share[p - 1])
        return self

    def z(self, X: np.ndarray) -> np.ndarray:
        Z = (np.asarray(X, float) - self.med) / self.scale
        return np.nan_to_num(np.clip(Z, -self.clip, self.clip), nan=0.0)

    def transform(self, X: np.ndarray) -> np.ndarray:
        return (self.z(X) - self.mean) @ self.comp.T


def sqdist(Y: np.ndarray, C: np.ndarray) -> np.ndarray:
    return np.maximum((Y ** 2).sum(1)[:, None] - 2 * Y @ C.T + (C ** 2).sum(1)[None, :], 0.0)


def kmeans(Y: np.ndarray, K: int, rng, n_init: int = 3, iters: int = 100, sample: int = 40000) -> np.ndarray:
    """Cluster centres (k-means++ start on a sample, Lloyd on all rows); the best of n_init by inertia."""
    N = len(Y)
    best, best_in = None, np.inf
    for _ in range(n_init):
        S = Y[rng.choice(N, size=min(N, sample), replace=False)]
        C = [S[rng.integers(len(S))]]
        for _ in range(1, K):
            d = sqdist(S, np.array(C)).min(1)
            C.append(S[rng.choice(len(S), p=d / d.sum())] if d.sum() > 0 else S[rng.integers(len(S))])
        C = np.array(C)
        lab = None
        for _ in range(iters):
            new = sqdist(Y, C).argmin(1)
            if lab is not None and np.array_equal(new, lab):
                break
            lab = new
            for k in range(K):
                m = lab == k
                C[k] = Y[m].mean(0) if m.any() else Y[rng.integers(N)]
        inertia = sqdist(Y, C).min(1).sum()
        if inertia < best_in:
            best, best_in = C.copy(), inertia
    return best


def _softmax(L: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    m = L.max(1, keepdims=True)
    e = np.exp(L - m)
    s = e.sum(1, keepdims=True)
    return e / s, (m + np.log(s))[:, 0]


class KMeans:
    kind = "kmeans"

    def fit(self, Y, K, rng, n_init=3, iters=100):
        self.C = kmeans(Y, K, rng, n_init, iters)
        self.K = K
        return self

    def proba(self, Y):
        lab = sqdist(Y, self.C).argmin(1)
        P = np.zeros((len(Y), self.K))
        P[np.arange(len(Y)), lab] = 1.0
        return P

    def novelty_score(self, Y):
        """Higher = less like the training data: squared distance to the nearest centre."""
        return sqdist(Y, self.C).min(1)


class GMM:
    kind = "gmm"

    def _logjoint(self, Y):
        iv = 1.0 / self.var
        q = (Y ** 2) @ iv.T - 2 * Y @ (self.mu * iv).T + (self.mu ** 2 * iv).sum(1)[None, :]
        return np.log(self.w)[None, :] - 0.5 * (q + np.log(self.var).sum(1)[None, :] + Y.shape[1] * LOG2PI)

    def fit(self, Y, K, rng, n_init=3, iters=100, max_iter=150, tol=1e-4, var_floor=1e-3):
        N, p = Y.shape
        C = kmeans(Y, K, rng, n_init, iters)
        lab = sqdist(Y, C).argmin(1)
        self.mu = C.copy()
        self.var = np.array([Y[lab == k].var(0) if (lab == k).sum() > 1 else Y.var(0) for k in range(K)]) + var_floor
        self.w = np.bincount(lab, minlength=K) / N + 1e-6
        self.w /= self.w.sum()
        prev = -np.inf
        for it in range(max_iter):
            R, ll = _softmax(self._logjoint(Y))
            ll = ll.mean()
            Nk = R.sum(0) + 1e-10
            self.w = Nk / N
            self.mu = (R.T @ Y) / Nk[:, None]
            self.var = np.maximum((R.T @ (Y ** 2)) / Nk[:, None] - self.mu ** 2, var_floor)
            if ll - prev < tol:
                break
            prev = ll
        self.K, self.iters, self.ll = K, it + 1, float(ll)
        return self

    def proba(self, Y):
        return _softmax(self._logjoint(Y))[0]

    def loglik(self, Y):
        return _softmax(self._logjoint(Y))[1]

    def novelty_score(self, Y):
        return -self.loglik(Y)


class HMM:
    """Diagonal-Gaussian HMM over sequences Y (S, T, p) with an observed mask M (S, T): a missing step only propagates
    the state. fit = Baum-Welch (scaled); filter = forward pass only (each step sees observations up to itself)."""
    kind = "hmm"

    def _logB(self, Y, M):
        S, T, p = Y.shape
        L = self.g._logjoint(Y.reshape(-1, p)).reshape(S, T, self.K) - np.log(self.g.w)[None, None, :]
        return np.where(M[:, :, None], L, 0.0)

    def _forward(self, B):
        S, T, K = B.shape
        a = np.empty((S, T, K))
        c = np.empty((S, T))
        x = self.pi[None, :] * B[:, 0]
        c[:, 0] = x.sum(1)
        a[:, 0] = x / c[:, 0:1]
        for t in range(1, T):
            x = (a[:, t - 1] @ self.A) * B[:, t]
            c[:, t] = x.sum(1)
            a[:, t] = x / c[:, t:t + 1]
        return a, c

    def _scaled_B(self, Y, M):
        L = self._logB(Y, M)
        m = L.max(2, keepdims=True)
        return np.exp(L - m), m[:, :, 0]

    def fit(self, Y, M, K, rng, n_init=3, iters=100, max_iter=60, tol=1e-4, var_floor=1e-3):
        S, T, p = Y.shape
        obs = Y[M]
        self.K = K
        self.g = GMM().fit(obs, K, rng, n_init, iters, max_iter=30, var_floor=var_floor)
        self.pi = self.g.w.copy()
        self.A = np.full((K, K), 0.3 / K) + np.eye(K) * 0.7
        prev = -np.inf
        for it in range(max_iter):
            B, m = self._scaled_B(Y, M)
            a, c = self._forward(B)
            ll = (np.log(c).sum() + (m * M).sum()) / max(M.sum(), 1)
            b = np.ones((S, T, K))
            for t in range(T - 2, -1, -1):
                b[:, t] = ((B[:, t + 1] * b[:, t + 1]) @ self.A.T) / c[:, t + 1:t + 2]
            gam = a * b
            gam /= gam.sum(2, keepdims=True)
            xi = np.zeros((K, K))
            for t in range(T - 1):
                xi += self.A * (a[:, t].T @ (B[:, t + 1] * b[:, t + 1] / c[:, t + 1:t + 2]))
            self.pi = np.maximum(gam[:, 0].mean(0), 1e-8)
            self.pi /= self.pi.sum()
            self.A = np.maximum(xi / xi.sum(1, keepdims=True), 1e-8)
            self.A /= self.A.sum(1, keepdims=True)
            G = gam[M]
            Nk = G.sum(0) + 1e-10
            self.g.mu = (G.T @ obs) / Nk[:, None]
            self.g.var = np.maximum((G.T @ obs ** 2) / Nk[:, None] - self.g.mu ** 2, var_floor)
            self.g.w = Nk / Nk.sum()
            if ll - prev < tol:
                break
            prev = ll
        self.iters, self.ll = it + 1, float(ll)
        return self

    def filter(self, Y, M):
        B, _ = self._scaled_B(Y, M)
        return self._forward(B)[0]

    def novelty_score(self, Yflat):
        return -self.g.loglik(Yflat)


def grid12(i_ret: np.ndarray, i_vwap: np.ndarray, i_rv: np.ndarray, thr: float) -> np.ndarray:
    """The human-made grid: move since the open (down / flat / up at +-thr ATR) x side of VWAP x intraday volatility above
    or below its usual level (blank = not above)."""
    a = np.where(i_ret < -thr, 0, np.where(i_ret > thr, 2, 1))
    b = (np.nan_to_num(i_vwap) > 0).astype(int)
    c = (np.nan_to_num(i_rv) > 0).astype(int)
    lab = a * 4 + b * 2 + c
    P = np.zeros((len(lab), 12))
    P[np.arange(len(lab)), lab] = 1.0
    return P


def knn_predict(Ytr: np.ndarray, Dtr: np.ndarray, Yte: np.ndarray, k: int, lam: float, chunk: int = 2000) -> np.ndarray:
    """Mean outcome deviation of the k nearest training rows (per target, ignoring blanks), shrunk by n / (n + lam)."""
    out = np.full((len(Yte), Dtr.shape[1]), np.nan)
    if len(Ytr) == 0:
        return out
    k = min(k, len(Ytr))
    fin = np.isfinite(Dtr)
    D0 = np.where(fin, Dtr, 0.0)
    for s in range(0, len(Yte), chunk):
        d = sqdist(Yte[s:s + chunk], Ytr)
        nn = np.argpartition(d, k - 1, axis=1)[:, :k]
        n = fin[nn].sum(1)
        sm = D0[nn].sum(1)
        out[s:s + chunk] = sm / (n + lam)
    return out


def ari(a: np.ndarray, b: np.ndarray) -> float:
    """Adjusted Rand index of two labelings (1 = identical partitions, about 0 = chance)."""
    a, b = np.asarray(a), np.asarray(b)
    if len(a) < 2:
        return np.nan
    _, ai = np.unique(a, return_inverse=True)
    _, bi = np.unique(b, return_inverse=True)
    M = np.zeros((ai.max() + 1, bi.max() + 1))
    np.add.at(M, (ai, bi), 1)
    c2 = lambda x: x * (x - 1) / 2.0
    sij, sa, sb = c2(M).sum(), c2(M.sum(1)).sum(), c2(M.sum(0)).sum()
    exp = sa * sb / c2(len(a))
    mx = 0.5 * (sa + sb)
    return float((sij - exp) / (mx - exp)) if mx != exp else 1.0


def psi(p: np.ndarray, q: np.ndarray, floor: float = 1e-4) -> float:
    """Population stability index between two share vectors."""
    p = np.maximum(np.asarray(p, float), floor)
    q = np.maximum(np.asarray(q, float), floor)
    p, q = p / p.sum(), q / q.sum()
    return float(((p - q) * np.log(p / q)).sum())
