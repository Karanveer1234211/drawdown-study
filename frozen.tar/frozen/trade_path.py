#!/usr/bin/env python3
"""
trade_path.py - a day-by-day keep-or-exit check during D's 5-session trades (drawdown part 2, and
direction after entry).

Run from ...\\bigmove_deploy\\open_close with PYTHONPATH = ...\\bigmove_deploy:

    python trade_path.py research --root %CACHE_DAILY_ROOT% [--run PM_YYYYMMDD_NNN]

What it asks
    D buys at day 1's open and plans to sell at day 5's close. On the evenings after day 1, 2, 3 and 4,
    should an open trade be kept, or sold at the next open? It learns, out of sample, the ADVANTAGE OF
    HOLDING = (net if held to the plan) - (net if sold at the next open) from the trade's path so far
    (move since entry, best and worst point, the day's move, gap, close position, range, a close locked at
    the lower band, volume, NIFTY's move) plus the 44 pre-entry inputs of pick_meta.
    That advantage is the remaining direction of the trade: whether the price goes on to do better than
    tomorrow's open. (The chance the whole trade ends in profit rises after day 1 for any stock - part of
    the result is already in - so it is not reported as skill.)

What it decides (rules fixed in TRADE_PATH_DECLARATION.json before any real run)
    CHECK rule: on each evening, sell at the next open when the forecast advantage of holding is below 0.
    exit rule         HELPS / HARMS / NO CLEAR EFFECT: CHECK minus HOLD net per trade, D's ranks 1-3,
                      95% interval over trading days
    Karan's target    MEETS / MISSES: worst drawdown at most 0.525 of the plan's (-47.6% -> -25%) while
                      keeping at least 70% of its P&L (a realised-P&L proxy; the execution simulator decides)
    direction         per evening: SKILL / NO SKILL and CALIBRATED / MISCALIBRATED for the chance that
                      holding beats selling at the next open

Safety stop: before any model, it must reproduce the research run's honest net of every one of D's traded
picks exactly from the bars. Writes research2\\trade_path\\TP_YYYYMMDD_NNN\\ and one ledger line.
Never writes to the paper test, the paper ledger, the panels or any frozen file.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pickle
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import pick_meta as PM                      # noqa: E402  (bars, honest exits, statistics, the research run)

CODE_VERSION = "trade_path v1"
FAMILY = "trade_path_v1"
DECL_FILE = HERE / "TRADE_PATH_DECLARATION.json"
OUT_SUB = Path("research2") / "trade_path"
PreconditionError = PM.PreconditionError
ReconciliationError = PM.ReconciliationError

PATH_FEATURES = ["p_day", "p_ret", "p_best", "p_worst", "p_last", "p_gap", "p_clv", "p_range", "p_lock",
                 "p_ret_atr", "p_worst_atr", "p_vol", "p_mkt", "p_mkt_last", "p_rel"]
FEATURES = PM.FEATURES + PATH_FEATURES

CFG = {
    "engine": "D",
    "train_ranks": 10,
    "eval_ranks": 3,
    "checks": [1, 2, 3, 4],
    "hold": 5,
    "lock_search_sessions": 20,
    "cost_bps": 35,
    "first_test_year": 2022,
    "embargo_sessions": 5,
    "min_train_rows": 2000,
    "hgb": {"max_iter": 200, "learning_rate": 0.03, "max_leaf_nodes": 7, "min_samples_leaf": 100,
            "l2_regularization": 3.0, "early_stopping": False, "random_state": 7},
    "adv_winsor": [0.01, 0.99],
    "exit_threshold_bp": 0.0,
    "slots": 15,
    "bootstrap": {"level": 0.95, "block": 10, "B": 10000, "B_pooled": 1000, "seed": 7},
    "target": {"dd_ratio_max": 0.525, "pnl_ratio_min": 0.70},
    "direction_bands_pp": [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
    "direction_rules": {"avg_gap_pp": 3.0, "level_pp": 2.0, "tail_pp": 10.0, "tail_min_picks": 200},
}


def _log(msg: str) -> None:
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def load_declaration(path: Path = DECL_FILE) -> Tuple[dict, str]:
    path = Path(path)
    if not path.exists():
        raise PreconditionError(f"{path.name} not found next to trade_path.py - copy it into open_close")
    raw = path.read_bytes()
    decl = json.loads(raw.decode("utf-8"))
    if decl.get("family_id") != FAMILY:
        raise PreconditionError(f"{path.name} is not the {FAMILY} declaration")
    if decl.get("config") != CFG:
        raise PreconditionError(f"{path.name} 'config' differs from trade_path.py's own copy - a declaration cannot "
                                f"change after the fact. Restore the shipped file.")
    return decl, hashlib.sha256(raw).hexdigest()[:16]


# ----------------------------------------------------------------------
# the source: the pick_meta research run (candidates, pre-entry inputs, honest outcomes)
# ----------------------------------------------------------------------
def load_source(root: Path, run: Optional[str], cfg: dict = CFG) -> Tuple[Path, pd.DataFrame, str]:
    base = Path(root) / PM.OUT_SUB
    rdir = PM.latest_run(base, run)
    _, dsha = PM.load_declaration()
    J = json.loads((rdir / "final_models" / "final_models.json").read_text(encoding="utf-8"))
    if J.get("declaration_sha") != dsha:
        raise PreconditionError(f"{rdir.name} was made under pick_meta declaration {J.get('declaration_sha')}, the "
                                f"current one is {dsha}")
    pf = rdir / "predictions.parquet"
    if not pf.exists():
        raise PreconditionError(f"{pf} not found")
    psha = PM._sha256(pf)
    if PM._read_hashes(rdir / "outputs.sha256").get("predictions.parquet") != psha:
        raise PreconditionError(f"{pf} does not match the research run's outputs.sha256 - refusing")
    cols = ["engine", "signal_day", "symbol", "rank", "fold", "status", "net", "prob_win"] + PM.FEATURES
    T = pd.read_parquet(pf, columns=cols)
    T = T[(T["engine"] == cfg["engine"]) & (T["rank"] <= cfg["train_ranks"])].copy()
    if T.empty:
        raise PreconditionError(f"{rdir.name} holds no {cfg['engine']} candidates")
    T["signal_day"] = PM._days(T["signal_day"])
    T["symbol"] = T["symbol"].astype(str)
    T = T.sort_values(["signal_day", "rank"], kind="mergesort").reset_index(drop=True)
    return rdir, T, psha


# ----------------------------------------------------------------------
# paths: the state on each evening and what keeping vs selling at the next open did
# ----------------------------------------------------------------------
def _sell_open(sy, m: int, n: int, search: int, market) -> int:
    """First bar from m whose open is not locked at the lower band: the next open, then up to `search` more
    sessions; -1 if none. Production's lock rule, called exactly as pick_meta's honest exit calls it."""
    b = sy.b
    for q in range(m, min(m + search + 1, n)):
        if not market.lower_locked(b, q, "open"):
            return q
    return -1


def build_paths(T: pd.DataFrame, syms: Dict[str, "PM.Sym"], market, cfg: dict = CFG) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """One row per candidate (the honest planned trade) and one row per candidate and evening k (state + labels)."""
    H, S, cost = cfg["hold"], cfg["lock_search_sessions"], cfg["cost_bps"] / 1e4
    n50 = syms.get("NIFTY50")
    if n50 is None:
        raise PreconditionError("NIFTY50 bars missing from the cache")
    c50 = np.asarray(n50.b.c, float)
    nT = len(T)
    tr = {"status": np.array(["no_bar"] * nT, dtype=object), "net_hold": np.full(nT, np.nan),
          "hold_exit_day": np.full(nT, np.datetime64("NaT"), dtype="datetime64[ns]"),
          "last_day": np.full(nT, np.datetime64("NaT"), dtype="datetime64[ns]")}
    rows: List[dict] = []
    days_all = T["signal_day"].to_numpy(dtype="datetime64[ns]")
    for sym, g in T.groupby("symbol", sort=False):
        sy = syms.get(sym)
        if sy is None:
            continue
        b = sy.b
        o, h, l, c = (np.asarray(x, float) for x in (b.o, b.h, b.l, b.c))
        n = len(c)
        lk = PM.locked_closes(sy, market)
        vol = np.asarray(sy.vol, float) if sy.vol is not None else None
        pos = g.index.to_numpy()
        ii = PM.day_index(sy, days_all[pos])
        for r, i in zip(pos, ii):
            st, lab = PM.honest_trade(sy, int(i), cfg, market)
            tr["status"][r] = st
            if st != "ok":
                continue
            e = int(i) + 1
            E = o[e]
            net_hold = lab["r5"] - cost
            tr["net_hold"][r] = net_hold
            tr["hold_exit_day"][r] = lab["exit_day"]
            last = np.datetime64(lab["exit_day"], "ns")
            atr = T.at[r, "s_atr14"]
            pre_vol = np.nanmean(vol[max(0, e - 20):e]) if vol is not None and e > 0 else np.nan
            ni = int(PM.day_index(n50, np.array([sy.d[int(i)]]))[0])
            for k in cfg["checks"]:
                j = e + k - 1
                if j + 1 >= n:
                    break
                with np.errstate(divide="ignore", invalid="ignore"):
                    ret = c[j] / E - 1.0
                    best = float(np.max(h[e:j + 1])) / E - 1.0
                    worst = float(np.min(l[e:j + 1])) / E - 1.0
                    rg = h[j] - l[j]
                    nj = int(PM.day_index(n50, np.array([sy.d[j]]))[0])
                    mkt = c50[nj] / c50[ni] - 1.0 if (nj >= 0 and ni >= 0) else np.nan
                    mkt_last = c50[nj] / c50[nj - 1] - 1.0 if nj >= 1 else np.nan
                    pv = np.log(vol[j] / pre_vol) if (vol is not None and vol[j] > 0 and pre_vol > 0) else np.nan
                    f = {"p_day": float(k), "p_ret": ret, "p_best": best, "p_worst": worst,
                         "p_last": c[j] / c[j - 1] - 1.0, "p_gap": o[j] / c[j - 1] - 1.0,
                         "p_clv": (c[j] - l[j]) / rg if rg > 0 else 0.5, "p_range": rg / c[j - 1],
                         "p_lock": float(lk[j]),
                         "p_ret_atr": ret / atr if (atr and atr > 0) else np.nan,
                         "p_worst_atr": worst / atr if (atr and atr > 0) else np.nan,
                         "p_vol": pv, "p_mkt": mkt, "p_mkt_last": mkt_last, "p_rel": ret - mkt}
                m = _sell_open(sy, j + 1, n, S, market)
                if m < 0:
                    net_exit, ex_day = np.nan, np.datetime64("NaT")
                else:
                    net_exit = o[m] / E - 1.0 - cost
                    ex_day = np.datetime64(sy.d[m], "ns")
                    last = max(last, ex_day)
                adv = net_hold - net_exit if np.isfinite(net_exit) else np.nan
                rows.append({"row": r, "k": k, "check_day": np.datetime64(sy.d[j], "ns"), **f, "net_exit": net_exit,
                             "exit_day": ex_day, "adv": adv, "hold_wins": float(adv > 0) if np.isfinite(adv) else np.nan})
            tr["last_day"][r] = last
    trades = T[["signal_day", "symbol", "rank", "fold", "s_atr14", "prob_win"]].copy()
    for k_, v in tr.items():
        trades[k_] = v
    C = pd.DataFrame(rows)
    if C.empty:
        raise PreconditionError("no finished trade had a path to check")
    C = C.merge(T[["signal_day", "symbol", "rank"] + PM.FEATURES], left_on="row", right_index=True, how="left")
    C["last_day"] = trades.loc[C["row"].to_numpy(), "last_day"].to_numpy()
    C["net_hold"] = trades.loc[C["row"].to_numpy(), "net_hold"].to_numpy()
    for col in ("check_day", "exit_day", "last_day"):
        C[col] = pd.to_datetime(C[col]).astype("datetime64[ns]")
    return trades, C.sort_values(["signal_day", "rank", "k"], kind="mergesort").reset_index(drop=True)


def reconcile(trades: pd.DataFrame, T: pd.DataFrame, cfg: dict = CFG) -> dict:
    """The traded picks' honest net, recomputed from the bars, must equal the research run's exactly."""
    ev = trades.index[trades["rank"] <= cfg["eval_ranks"]]
    ok_new = (trades.loc[ev, "status"] == "ok").to_numpy()
    ok_ref = (T.loc[ev, "status"] == "ok").to_numpy()
    fails = []
    if (ok_new != ok_ref).any():
        fails.append(f"{int((ok_new != ok_ref).sum())} traded picks finish differently from the research run")
    both = ev[ok_new & ok_ref]
    diff = (trades.loc[both, "net_hold"] - T.loc[both, "net"]).abs()
    mx = float(diff.max()) if len(diff) else 0.0
    if not mx <= 1e-9:
        fails.append(f"honest net differs from the research run by up to {mx * 1e4:.6f} bp")
    return {"trades": int(len(ev)), "finished": int(ok_new.sum()),
            "mean_net_bp": float(trades.loc[ev[ok_new], "net_hold"].mean() * 1e4) if ok_new.any() else np.nan,
            "research_mean_net_bp": float(T.loc[ev[ok_ref], "net"].mean() * 1e4) if ok_ref.any() else np.nan,
            "max_abs_diff_bp": mx * 1e4, "passed": not fails, "fails": fails}


# ----------------------------------------------------------------------
# models
# ----------------------------------------------------------------------
def fit_models(tr: pd.DataFrame, cfg: dict = CFG) -> dict:
    from sklearn.ensemble import HistGradientBoostingClassifier as HGBC
    from sklearn.ensemble import HistGradientBoostingRegressor as HGBR
    X = tr[FEATURES].to_numpy(float)
    y = tr["adv"].to_numpy(float)
    lo, hi = np.quantile(y, cfg["adv_winsor"])
    reg = HGBR(loss="squared_error", **cfg["hgb"]).fit(X, np.clip(y, lo, hi))
    yb = tr["hold_wins"].to_numpy(float).astype(int)
    clf = ("const", float(yb.mean())) if yb.min() == yb.max() else HGBC(**cfg["hgb"]).fit(X, yb)
    return {"reg": reg, "clf": clf, "base_rate": float(yb.mean()), "winsor": [float(lo), float(hi)]}


def predict_models(M: dict, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    adv = M["reg"].predict(X)
    clf = M["clf"]
    p = np.full(len(X), clf[1]) if isinstance(clf, tuple) else clf.predict_proba(X)[:, 1]
    return adv, p


def walk_forward(C: pd.DataFrame, cal: np.ndarray, cfg: dict = CFG, verbose: bool = True):
    """Expanding walk-forward by calendar year of the signal day. A year's models train only on trades whose
    last needed price came at least embargo_sessions sessions before the year's first signal day."""
    yr = pd.DatetimeIndex(C["signal_day"]).year.to_numpy()
    out = pd.DataFrame(np.nan, index=C.index, columns=["pred_adv", "prob_hold", "base_rate", "fold"])
    folds = []
    for y in sorted(set(yr[yr >= cfg["first_test_year"]])):
        te = yr == y
        start = np.datetime64(pd.Timestamp(C.loc[te, "signal_day"].min()), "ns")
        p = int(np.searchsorted(cal, start))
        if p - cfg["embargo_sessions"] - 1 < 0:
            raise PreconditionError(f"year {y}: the calendar does not reach back {cfg['embargo_sessions'] + 1} sessions")
        cut = cal[p - cfg["embargo_sessions"] - 1]
        with np.errstate(invalid="ignore"):
            trm = (C["last_day"].to_numpy(dtype="datetime64[ns]") <= cut) & C["adv"].notna().to_numpy()
        if trm.sum() < cfg["min_train_rows"]:
            raise PreconditionError(f"year {y}: only {int(trm.sum())} finished training rows (< {cfg['min_train_rows']})")
        t0 = time.perf_counter()
        M = fit_models(C[trm], cfg)
        adv, prob = predict_models(M, C.loc[te, FEATURES].to_numpy(float))
        out.loc[te, "pred_adv"] = adv
        out.loc[te, "prob_hold"] = prob
        out.loc[te, "base_rate"] = M["base_rate"]
        out.loc[te, "fold"] = float(y)
        last = C.loc[trm, "last_day"].max()
        gap = p - int(np.searchsorted(cal, np.datetime64(last, "ns"))) - 1
        folds.append({"year": int(y), "test_rows": int(te.sum()), "train_rows": int(trm.sum()),
                      "train_last_day": str(pd.Timestamp(last).date()), "gap_sessions": int(gap)})
        if verbose:
            _log(f"  year {y}: trained on {int(trm.sum()):,} evening checks (last price {pd.Timestamp(last).date()}, "
                 f"{gap} sessions before {pd.Timestamp(start).date()}), scored {int(te.sum()):,} "
                 f"({time.perf_counter() - t0:.0f}s)")
    return out, folds


# ----------------------------------------------------------------------
# the rule and its evaluation
# ----------------------------------------------------------------------
def apply_rule(C: pd.DataFrame, trades: pd.DataFrame, cfg: dict = CFG) -> pd.DataFrame:
    """CHECK: on each evening in order, sell at the next open when the forecast advantage of holding < threshold."""
    thr = cfg["exit_threshold_bp"] / 1e4
    R = trades[["signal_day", "symbol", "rank", "status", "net_hold", "hold_exit_day"]].copy()
    R["exit_k"] = 0
    R["net_check"] = R["net_hold"]
    R["check_exit_day"] = R["hold_exit_day"]
    R["scored"] = False
    done = np.zeros(len(R), bool)
    pos = {rid: q for q, rid in enumerate(R.index)}
    for k in cfg["checks"]:
        G = C[(C["k"] == k) & C["pred_adv"].notna()]
        for rid, pa, ne, ed in zip(G["row"].to_numpy(), G["pred_adv"].to_numpy(), G["net_exit"].to_numpy(),
                                   G["exit_day"].to_numpy(dtype="datetime64[ns]")):
            q = pos[rid]
            R.iat[q, R.columns.get_loc("scored")] = True
            if done[q]:
                continue
            if pa < thr and np.isfinite(ne):
                done[q] = True
                R.iat[q, R.columns.get_loc("exit_k")] = k
                R.iat[q, R.columns.get_loc("net_check")] = ne
                R.iat[q, R.columns.get_loc("check_exit_day")] = ed
    return R


def boot_ratio(sums: np.ndarray, cnts: np.ndarray, cfg: dict = CFG) -> Tuple[float, float]:
    """95% interval of sum(S) / sum(n) under circular blocks of days (time order)."""
    bs = cfg["bootstrap"]
    nD = len(sums)
    if nD < 10:
        return np.nan, np.nan
    rng = np.random.default_rng(bs["seed"])
    L, B = bs["block"], bs["B"]
    nb = int(np.ceil(nD / L))
    out = np.empty(B)
    for a in range(0, B, 500):
        bb = min(500, B - a)
        st = rng.integers(0, nD, size=(bb, nb))
        ix = ((st[:, :, None] + np.arange(L)[None, None, :]).reshape(bb, -1)[:, :nD]) % nD
        out[a:a + bb] = sums[ix].sum(1) / cnts[ix].sum(1)
    lvl = bs["level"]
    lo, hi = np.percentile(out, [100 * (1 - lvl) / 2, 100 * (1 + lvl) / 2])
    return float(lo), float(hi)


def per_trade_ci(R: pd.DataFrame, col: str, cfg: dict = CFG) -> dict:
    g = R.groupby("signal_day")[col].agg(["sum", "count"]).sort_index()
    lo, hi = boot_ratio(g["sum"].to_numpy(float), g["count"].to_numpy(float), cfg)
    return {"mean": float(R[col].mean()), "lo": lo, "hi": hi, "n": int(len(R))}


def drawdown(pnl: np.ndarray) -> float:
    """Worst fall from a running peak, as a share of that peak. Equity starts at 1 (the starting capital), so a
    fall from the very first day counts."""
    eq = np.r_[1.0, 1.0 + np.cumsum(np.asarray(pnl, float))]
    peak = np.maximum.accumulate(eq)
    return float(np.max((peak - eq) / peak))


def portfolio(R: pd.DataFrame, cal: np.ndarray, cfg: dict = CFG) -> dict:
    """Realised P&L by exit date, every trade 1/slots of capital, no compounding. Ratios CHECK / HOLD with
    intervals from the same circular-block resamples of the calendar for both (a resample in which HOLD made no
    money, or had no drawdown, has no ratio and is left out of that interval; the count kept is reported).
    If HOLD lost money over the whole period, 'keep 70% of the P&L' means nothing: the P&L condition becomes
    CHECK's P&L >= HOLD's and the ratio is not shown (amendment (a) of the declaration)."""
    slot = 1.0 / cfg["slots"]
    d0 = np.datetime64(R["signal_day"].min(), "ns")
    d1 = max(np.datetime64(R["hold_exit_day"].max(), "ns"), np.datetime64(R["check_exit_day"].max(), "ns"))
    days = cal[(cal >= d0) & (cal <= d1)]
    idx = pd.DatetimeIndex(days)

    def series(day_col, net_col):
        # an exit on a day that is not a NIFTY session is booked on the next session (never dropped)
        at = np.searchsorted(days, pd.to_datetime(R[day_col]).to_numpy(dtype="datetime64[ns]"), side="left")
        at = np.minimum(at, len(days) - 1)
        return np.bincount(at, weights=R[net_col].to_numpy(float) * slot, minlength=len(days))
    hold, check = series("hold_exit_day", "net_hold"), series("check_exit_day", "net_check")
    out = {"days": int(len(days)), "hold_pnl": float(hold.sum()), "check_pnl": float(check.sum()),
           "hold_dd": drawdown(hold), "check_dd": drawdown(check)}
    out["pnl_rule"] = "ratio" if out["hold_pnl"] > 0 else "not worse"
    out["pnl_ratio"] = out["check_pnl"] / out["hold_pnl"] if out["hold_pnl"] > 0 else np.nan
    out["dd_ratio"] = out["check_dd"] / out["hold_dd"] if out["hold_dd"] > 0 else np.nan
    bs = cfg["bootstrap"]
    rng = np.random.default_rng(bs["seed"] + 3)
    nD, L = len(days), bs["block"]
    nb = int(np.ceil(nD / L))
    pr, dr = [], []
    for _ in range(bs["B_pooled"]):
        st = rng.integers(0, nD, nb)
        ix = ((st[:, None] + np.arange(L)[None, :]).ravel()[:nD]) % nD
        h_, c_ = hold[ix], check[ix]
        hp, hd = h_.sum(), drawdown(h_)
        if hp > 0:
            pr.append(c_.sum() / hp)
        if hd > 0:
            dr.append(drawdown(c_) / hd)
    lvl = bs["level"]
    q = [100 * (1 - lvl) / 2, 100 * (1 + lvl) / 2]
    out["pnl_ratio_ci"] = [float(x) for x in np.percentile(pr, q)] if (pr and out["hold_pnl"] > 0) else [np.nan, np.nan]
    out["dd_ratio_ci"] = [float(x) for x in np.percentile(dr, q)] if dr else [np.nan, np.nan]
    out["resamples_kept"] = {"pnl": len(pr) if out["hold_pnl"] > 0 else 0, "dd": len(dr), "of": int(bs["B_pooled"])}
    t = cfg["target"]
    # "keep at least 70% of the return" needs a positive return to keep; if the plan lost money, CHECK must not lose more
    pnl_ok = (out["pnl_ratio"] >= t["pnl_ratio_min"]) if out["pnl_rule"] == "ratio" else (out["check_pnl"] >= out["hold_pnl"])
    out["meets"] = bool(np.isfinite(out["dd_ratio"]) and out["dd_ratio"] <= t["dd_ratio_max"] and pnl_ok)
    out["_daily"] = pd.DataFrame({"hold": hold, "check": check}, index=idx)
    return out


def evaluate(C: pd.DataFrame, trades: pd.DataFrame, cal: np.ndarray, cfg: dict = CFG) -> dict:
    R = apply_rule(C, trades, cfg)
    E = R[(R["rank"] <= cfg["eval_ranks"]) & (R["status"] == "ok") & R["scored"]].copy()
    if E.empty:
        raise PreconditionError("no traded pick has out-of-sample checks")
    E["diff"] = E["net_check"] - E["net_hold"]
    paired = per_trade_ci(E, "diff", cfg)
    v = "HELPS" if paired["lo"] > 0 else ("HARMS" if paired["hi"] < 0 else "NO CLEAR EFFECT")
    ex = E[E["exit_k"] > 0]
    worst = max(1, int(round(0.05 * len(E))))
    ev = {"trades": int(len(E)), "days": int(E["signal_day"].nunique()),
          "first": str(pd.Timestamp(E["signal_day"].min()).date()), "last": str(pd.Timestamp(E["signal_day"].max()).date()),
          "hold": per_trade_ci(E, "net_hold", cfg), "check": per_trade_ci(E, "net_check", cfg), "paired": paired,
          "verdict": v,
          "sold_share": float((E["exit_k"] > 0).mean()),
          "sold_by_k": {str(k): int((E["exit_k"] == k).sum()) for k in cfg["checks"]},
          "sold_would_have": float(ex["net_hold"].mean()) if len(ex) else np.nan,
          "sold_got": float(ex["net_check"].mean()) if len(ex) else np.nan,
          "sold_would_have_profited": float((ex["net_hold"] > 0).mean()) if len(ex) else np.nan,
          "sold_better_to_hold": float((ex["net_hold"] > ex["net_check"]).mean()) if len(ex) else np.nan,
          "worst5_hold": float(np.sort(E["net_hold"].to_numpy())[:worst].mean()),
          "worst5_check": float(np.sort(E["net_check"].to_numpy())[:worst].mean()),
          "min_hold": float(E["net_hold"].min()), "min_check": float(E["net_check"].min()),
          "win_hold": float((E["net_hold"] > 0).mean()), "win_check": float((E["net_check"] > 0).mean()),
          "by_year": {str(y): {"trades": int(len(g)), "hold": float(g["net_hold"].mean()), "check": float(g["net_check"].mean()),
                               "sold": float((g["exit_k"] > 0).mean())}
                      for y, g in E.groupby(pd.DatetimeIndex(E["signal_day"]).year)}}
    pf = portfolio(E, cal, cfg)
    ev["portfolio"] = {k: v for k, v in pf.items() if not k.startswith("_")}
    ev["_daily"] = pf["_daily"]
    ev["_trades"] = E
    # direction after entry: the chance that holding beats selling at the next open, D's top 10
    bcfg = {"bootstrap": {**cfg["bootstrap"], "B": cfg["bootstrap"]["B_pooled"]}}
    D10 = C[C["prob_hold"].notna() & C["hold_wins"].notna()]
    dirn = {}
    for k in cfg["checks"]:
        g = D10[D10["k"] == k]
        if g.empty:
            continue
        days = g["signal_day"].to_numpy(dtype="datetime64[ns]")
        p, y, base = g["prob_hold"].to_numpy(float), g["hold_wins"].to_numpy(float), g["base_rate"].to_numpy(float)
        a = PM.pooled_ci(days, y, p, PM.auc, cfg)
        sk = PM.brier_skill(days, p, y, base, bcfg, offset=41 + k)
        rel = PM.reliability(days, p, y, cfg["direction_bands_pp"], bcfg, offset=61 + k,
                             tail_min=cfg["direction_rules"]["tail_min_picks"])
        dirn[str(k)] = {"rows": int(len(g)), "auc": a, "skill": sk, "rel": rel,
                        "verdict": PM.conf_verdict(rel, sk, cfg["direction_rules"]),
                        "hold_wins_rate": float(y.mean())}
    pre = trades[(trades["status"] == "ok") & trades["prob_win"].notna() & trades.index.isin(D10["row"].unique())]
    if len(pre):
        dd = pre["signal_day"].to_numpy(dtype="datetime64[ns]")
        dirn["entry"] = {"rows": int(len(pre)), "auc": PM.pooled_ci(dd, (pre["net_hold"] > 0).to_numpy(float),
                                                                    pre["prob_win"].to_numpy(float), PM.auc, cfg)}
    ev["direction"] = dirn
    return ev


# ----------------------------------------------------------------------
# research
# ----------------------------------------------------------------------
def run_research(root: Path, market=None, run: Optional[str] = None, verbose: bool = True,
                 now: Optional[dt.datetime] = None) -> dict:
    t_start = time.perf_counter()
    root = Path(root)
    decl, dsha = load_declaration()
    cfg = CFG
    market = market or PM.ProductionMarket(root)
    rdir, T, psha = load_source(root, run, cfg)
    if verbose:
        _log(f"{CODE_VERSION} | declaration {dsha} | research run {rdir.name} | Root: {root}")
        _log(f"{cfg['engine']}: {len(T):,} candidates (top {cfg['train_ranks']}), {T['signal_day'].nunique():,} days; "
             f"loading bars")
    syms = PM.prepare_symbols(market, set(T["symbol"]) | {"NIFTY50"})
    if "NIFTY50" not in syms:
        raise PreconditionError("NIFTY50 bars missing from the cache (the trading calendar)")
    cal = np.unique(syms["NIFTY50"].d)
    if verbose:
        _log("building trade paths and the sell-at-next-open alternatives")
    trades, C = build_paths(T, syms, market, cfg)
    rec = reconcile(trades, T, cfg)
    if verbose:
        _log(f"reconcile {cfg['engine']}: {rec['trades']:,} traded picks, {rec['finished']:,} finished, mean honest net "
             f"{rec['mean_net_bp']:+.2f} bp (research run {rec['research_mean_net_bp']:+.2f}), largest difference "
             f"{rec['max_abs_diff_bp']:.6f} bp -> {'OK' if rec['passed'] else 'FAIL'}")
    if not rec["passed"]:
        raise ReconciliationError("the paths do not reproduce the research run - nothing was modelled:\n  "
                                  + "\n  ".join(rec["fails"]))
    if verbose:
        _log(f"walk-forward on {len(C):,} evening checks")
    P, folds = walk_forward(C, cal, cfg, verbose)
    C = pd.concat([C, P], axis=1)
    EV = evaluate(C, trades, cal, cfg)
    # final models for later forward use (all finished checks)
    trm = C["adv"].notna()
    final = fit_models(C[trm], cfg)

    now = now or dt.datetime.now()
    out = PM._new_dir(root / OUT_SUB, "TP", now.strftime("%Y%m%d"))
    rerun = PM._is_rerun(root, FAMILY)
    keep = ["signal_day", "symbol", "rank", "k", "check_day"] + PATH_FEATURES + [
        "net_hold", "net_exit", "exit_day", "adv", "hold_wins", "pred_adv", "prob_hold", "base_rate", "fold"]
    C[keep].to_parquet(out / "checks.parquet", index=False)
    TR = EV["_trades"].copy()
    TR["signal_day"] = pd.to_datetime(TR["signal_day"]).dt.date.astype(str)
    for c_ in ("net_hold", "net_check", "diff"):
        TR[c_] = (TR[c_] * 1e4).round(1)
    TR.to_csv(out / "trades_oos.csv", index=False)
    EV["_daily"].rename_axis("day").to_csv(out / "daily_pnl.csv")
    fm = out / "final_models"
    fm.mkdir()
    with open(fm / "models.pkl", "wb") as fh:
        pickle.dump({"models": final, "features": FEATURES, "engine": cfg["engine"]}, fh, protocol=4)
    (fm / "final_models.json").write_text(json.dumps(
        {"code": CODE_VERSION, "declaration_sha": dsha, "features": FEATURES, "versions": PM._versions(),
         "created": now.isoformat(timespec="seconds"), "file": "models.pkl", "sha256": PM._sha256(fm / "models.pkl"),
         "train_rows": int(trm.sum()), "source_run": rdir.name}, indent=2), encoding="utf-8")
    S = {"code": CODE_VERSION, "family": FAMILY, "declaration_sha": dsha, "run": out.name, "rerun": rerun,
         "source_run": rdir.name, "source_predictions_sha256": psha, "root": str(root),
         "created": now.isoformat(timespec="seconds"), "runtime_s": round(time.perf_counter() - t_start, 1),
         "versions": PM._versions(), "config": cfg, "origins": getattr(market, "origins", {}),
         "two_bar_days": PM.COLLAPSED, "reconciliation": rec, "folds": folds, "checks_rows": int(len(C)),
         "evaluation": {k: v for k, v in EV.items() if not k.startswith("_")}}
    (out / "summary.json").write_text(json.dumps(S, indent=2, default=PM._json_default), encoding="utf-8")
    (out / "report.md").write_text(report_md(S), encoding="utf-8")
    hashes = {p.name: PM._sha256(p) for p in sorted(out.iterdir()) if p.is_file()}
    (out / "outputs.sha256").write_text("".join(f"{v}  {k}\n" for k, v in hashes.items()), encoding="utf-8")
    E = S["evaluation"]
    line = {"timestamp": now.isoformat(timespec="seconds"), "tool": CODE_VERSION, "family": FAMILY, "declaration": dsha,
            "run": out.name, "source_run": rdir.name, "out": str(out), "rerun": rerun,
            "headline": {"exit_rule": E["verdict"], "paired_bp": round(E["paired"]["mean"] * 1e4, 2),
                         "target": "MEETS" if E["portfolio"]["meets"] else "MISSES",
                         "dd_ratio": _num(E["portfolio"]["dd_ratio"]), "pnl_ratio": _num(E["portfolio"]["pnl_ratio"]),
                         "hold_dd": _num(E["portfolio"]["hold_dd"]), "check_dd": _num(E["portfolio"]["check_dd"]),
                         "direction": {k: v["verdict"] for k, v in E["direction"].items() if k != "entry"}}}
    lp = PM._ledger_path(root)
    lp.parent.mkdir(parents=True, exist_ok=True)
    with open(lp, "a", encoding="utf-8") as f:
        f.write(json.dumps(line, sort_keys=True) + "\n")
    if verbose:
        _log(f"done in {S['runtime_s']:.0f}s -> {out}")
        print(headline_text(S))
    return {"out": out, "summary": S, "checks": C, "trades": trades, "eval": EV}


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------
def _num(x, nd=4):
    return None if x is None or not np.isfinite(x) else round(float(x), nd)


def _pnl_text(pf: dict, cfg: dict) -> str:
    if pf["pnl_rule"] == "ratio":
        return (f"P&L {_r(pf['pnl_ratio'], 3)} x [{_r(pf['pnl_ratio_ci'][0], 3)}, {_r(pf['pnl_ratio_ci'][1], 3)}] "
                f"(needs >= {cfg['target']['pnl_ratio_min']})")
    return (f"P&L: the plan LOST money ({pf['hold_pnl']:+.1%} of capital), CHECK {pf['check_pnl']:+.1%} (needs CHECK >= "
            f"the plan; a share of a loss means nothing)")


def _bp(x, nd=1) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x * 1e4:+.{nd}f}"


def _ci_bp(d: dict, nd=1) -> str:
    return f"{_bp(d['mean'], nd)} [{_bp(d['lo'], nd)}, {_bp(d['hi'], nd)}]"


def _r(x, nd=3) -> str:
    return "n/a" if x is None or not np.isfinite(x) else f"{x:.{nd}f}"


def headline_text(S: dict) -> str:
    E = S["evaluation"]
    pf = E["portfolio"]
    L = [f"TRADE PATH {S['run']} on {S['source_run']}{' (RERUN - not new evidence)' if S['rerun'] else ''} "
         f"(out of sample {E['first']} .. {E['last']}, rules fixed before the run)",
         f"  exit rule: {E['verdict']} - CHECK minus HOLD {_ci_bp(E['paired'])} bp per traded pick "
         f"({E['trades']:,} picks; {E['sold_share']:.1%} sold early)",
         f"  Karan's target: {'MEETS' if pf['meets'] else 'MISSES'} - worst drawdown (proxy) {-pf['hold_dd']:.1%} -> "
         f"{-pf['check_dd']:.1%} = {_r(pf['dd_ratio'], 3)} x the plan's [{_r(pf['dd_ratio_ci'][0], 3)}, "
         f"{_r(pf['dd_ratio_ci'][1], 3)}] (needs <= {S['config']['target']['dd_ratio_max']}), " + _pnl_text(pf, S["config"])]
    parts = []
    for k, d in E["direction"].items():
        if k == "entry":
            continue
        parts.append(f"after day {k}: {d['verdict']} (AUC {_r(d['auc']['mean'])} [{_r(d['auc']['lo'])}, {_r(d['auc']['hi'])}])")
    L.append("  direction (holding beats selling at the next open): " + " | ".join(parts))
    if "entry" in E["direction"]:
        a = E["direction"]["entry"]["auc"]
        L.append(f"  for comparison, P(profit) at entry on the same trades: AUC {_r(a['mean'])} [{_r(a['lo'])}, {_r(a['hi'])}]")
    return "\n".join(L)


def report_md(S: dict) -> str:
    cfg = S["config"]
    E = S["evaluation"]
    pf = E["portfolio"]
    rec = S["reconciliation"]
    L = [f"# Trade path check - {S['run']} (on research run {S['source_run']})", "",
         f"{S['code']} | declaration {S['declaration_sha']} | family {S['family']} | created {S['created']} | runtime "
         f"{S['runtime_s']:.0f} s{' | **RERUN: not new evidence**' if S['rerun'] else ''}", "",
         "Out of sample, year by year (each year's models never saw it). It describes the past; only forward paper "
         "trades are new evidence. Nothing here changes the frozen system or the paper test.", "",
         "## Verdicts (rules declared before the run)", "",
         f"- **Exit rule: {E['verdict']}.** Sell at the next open when the forecast advantage of holding is below "
         f"{cfg['exit_threshold_bp']:g} bp, checked on the evenings after days {', '.join(map(str, cfg['checks']))}. "
         f"CHECK minus HOLD, D's ranks 1-{cfg['eval_ranks']}: {_ci_bp(E['paired'])} bp per trade ({E['trades']:,} trades, "
         f"{E['days']:,} days, {E['first']} .. {E['last']}).",
         f"- **Karan's target: {'MEETS' if pf['meets'] else 'MISSES'}.** Worst drawdown (proxy) {-pf['hold_dd']:.1%} -> "
         f"{-pf['check_dd']:.1%} = {_r(pf['dd_ratio'], 3)} x the plan's [{_r(pf['dd_ratio_ci'][0], 3)}, "
         f"{_r(pf['dd_ratio_ci'][1], 3)}] - needs <= {cfg['target']['dd_ratio_max']} (-47.6% -> -25%); "
         + _pnl_text(pf, cfg) + f". Realised-P&L proxy (every trade 1/{cfg['slots']} of capital, no compounding, "
         f"booked on its exit day): a screen; the execution simulator decides. The verdict uses the actual values; the "
         f"intervals come from reshuffled {cfg['bootstrap']['block']}-session blocks, which break up long drawdowns, so "
         f"they are rough and need not contain the actual value.",
         "- **Direction after entry** (the chance that holding beats selling at the next open): "
         + "; ".join(f"after day {k}: **{d['verdict']}**" for k, d in E["direction"].items() if k != "entry"), "",
         "## 1. Reconciliation (before any model)", "",
         f"{rec['trades']:,} traded picks, {rec['finished']:,} finished; mean honest net recomputed from the bars "
         f"{rec['mean_net_bp']:+.2f} bp vs the research run {rec['research_mean_net_bp']:+.2f} bp; largest difference "
         f"{rec['max_abs_diff_bp']:.6f} bp -> {'OK' if rec['passed'] else 'FAIL'}.", "",
         "## 2. Keep or sell - D's traded picks", "",
         "| | HOLD (the plan) | CHECK (the rule) |", "|---|---|---|",
         f"| net per trade [95%] | {_ci_bp(E['hold'])} bp | {_ci_bp(E['check'])} bp |",
         f"| win rate | {E['win_hold']:.1%} | {E['win_check']:.1%} |",
         f"| average of the worst 5% | {_bp(E['worst5_hold'])} bp | {_bp(E['worst5_check'])} bp |",
         f"| worst trade | {_bp(E['min_hold'])} bp | {_bp(E['min_check'])} bp |",
         f"| P&L (1/{cfg['slots']} each) | {pf['hold_pnl']:+.1%} | {pf['check_pnl']:+.1%} |",
         f"| worst drawdown (proxy) | {pf['hold_dd']:.1%} | {pf['check_dd']:.1%} |", "",
         f"Sold early: {E['sold_share']:.1%} of trades (after day " + ", ".join(
             f"{k}: {n:,}" for k, n in E["sold_by_k"].items()) + "). The sold trades would have made "
         f"{_bp(E['sold_would_have'])} bp if held and got {_bp(E['sold_got'])} bp; {_r(E['sold_would_have_profited'] * 100, 1)}% "
         f"of them would have ended in profit, and for {_r(E['sold_better_to_hold'] * 100, 1)}% holding would have been "
         f"better.", "", "By year:", "", "| year | trades | HOLD bp | CHECK bp | sold early |", "|---|---|---|---|---|"]
    for y, v in E["by_year"].items():
        L.append(f"| {y} | {v['trades']:,} | {_bp(v['hold'])} | {_bp(v['check'])} | {v['sold']:.1%} |")
    L += ["", "## 3. Direction after entry - D's top 10", "",
          "The chance that holding to the plan beats selling at the next open, judged against what happened. "
          "(The chance that the whole trade ends in profit is not reported as skill: after day 1 part of the result "
          "is already in, for any stock.)", "",
          "| evening | checks | holding won | AUC [95%] | Brier skill [95%] | average gap | level | tail | verdict |",
          "|---|---|---|---|---|---|---|---|---|"]
    for k, d in E["direction"].items():
        if k == "entry":
            continue
        rl, sk, a = d["rel"], d["skill"], d["auc"]
        L.append(f"| after day {k} | {d['rows']:,} | {d['hold_wins_rate']:.1%} | {_r(a['mean'])} [{_r(a['lo'])}, {_r(a['hi'])}] | "
                 f"{sk['skill']:+.4f} [{sk['lo']:+.4f}, {sk['hi']:+.4f}] | {_r(rl['avg_gap'] * 100, 2)} | "
                 f"{rl['level'] * 100:+.2f} | {_r((rl['tail'] or 0) * 100, 1)} | **{d['verdict']}** |")
    if "entry" in E["direction"]:
        a = E["direction"]["entry"]["auc"]
        L += ["", f"For comparison: pick_meta's P(profit) at entry on the same trades, AUC {_r(a['mean'])} "
              f"[{_r(a['lo'])}, {_r(a['hi'])}] ({E['direction']['entry']['rows']:,} trades)."]
    L += ["", "## 4. Folds", "", "| year | test checks | training checks | last training price | sessions between |",
          "|---|---|---|---|---|"]
    for f in S["folds"]:
        L.append(f"| {f['year']} | {f['test_rows']:,} | {f['train_rows']:,} | {f['train_last_day']} | {f['gap_sessions']} |")
    L += ["", "## 5. Provenance", "", f"- research run {S['source_run']}; predictions.parquet sha256 "
          f"{S['source_predictions_sha256'][:16]} (matches its outputs.sha256); {S['checks_rows']:,} evening checks",
          f"- libraries: {S['versions']}", f"- modules: {S['origins']}",
          f"- days with two bars (later bar kept): {len(S['two_bar_days'])} symbols",
          "- outputs and their SHA-256: outputs.sha256; final models fingerprinted in final_models\\final_models.json", ""]
    return "\n".join(L)


# ----------------------------------------------------------------------
# command line
# ----------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--version", action="version", version=CODE_VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("research", help="walk-forward keep-or-exit check on D's history")
    r.add_argument("--root", required=True, help="the data root, e.g. %%CACHE_DAILY_ROOT%%")
    r.add_argument("--run", default=None, help="pick_meta research run folder PM_... (default: the latest)")
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.exists():
        print(f"Root does not exist: {root}")
        return 2
    print(f"{CODE_VERSION} | Root: {root}")
    try:
        run_research(root, run=a.run)
    except PreconditionError as e:
        print(f"STOPPED: {e}")
        return 2
    except ReconciliationError as e:
        print(f"STOPPED (reconciliation): {e}")
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
