# MANIFEST rows - pick_meta v1.3 (17 Oct 2026)

| file (under bigmove_deploy\open_close) | version / fingerprint | what it does | status |
|---|---|---|---|
| pick_meta.py | v1.3 (2b5732c7d0cb3e3a) | meta model over frozen D / ENS watchlists: research, calibrate (new), publish, score | replaces v1.2 |
| PICK_META_CONFIDENCE_DECLARATION.json | 126197433e5f1b4f (family pick_meta_conf_v1) | rules for the confidence numbers: events, method, pass rules, forward check; amendment (a) before any real run, post-hoc display amendment (b) (model's own P(+5%)), rule false-alarm rates | NEW |
| PICK_META_DECLARATION.json | 4cc59d6318005ae0 (family pick_meta_v1) | rules of the research run PM_20261017_001 | unchanged - do not touch |
| run_pick_meta.bat | v1 (CRLF, 9c81765115d7ad99) | nightly after Run Now, before 09:00: publish then score | unchanged |
| tests\test_pick_meta.py | v1.3 (b78b924a6e569892) | suite; must end VERIFIED (pick_meta v1.3) | replaces v1.2 |
| tests\conf_world.py | v1 (45e6f85849269e69) | synthetic predictions tables with known true chances (used by the suite) | NEW |
| tests\conf_rates.py | v1 (d8cc4b307c286b9a) | optional (~6 min): reproduces the declaration's rule false-alarm numbers | NEW |
| tests\pick_meta_world.py | unchanged (4fce62c5dceb8979) | synthetic market worlds | unchanged |

Outputs (under %CACHE_DAILY_ROOT%\research2\pick_meta\): confidence\PC_YYYYMMDD_NNN\ (report.md, summary.json, tables.json, reliability.csv, calibrated_oos.csv, outputs.sha256); forward\PM_cards_YYYYMMDD.csv/.md (v1.3 columns: up5_pct = model's own P(+5%), up10_pct / dip8_pct / stuck_pct / profit_pct corrected; up5_corrected_pct; raw_* kept; conf_run, conf_marks); forward\magnitude_results.csv, magnitude_tracker.md. Ledger: one line per calibrate run (family pick_meta_conf_v1).
