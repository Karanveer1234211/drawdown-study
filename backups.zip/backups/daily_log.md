# Daily log - newest first

paper_pipeline v1.6 | every session since the first watchlist, rebuilt nightly

Running: D: 9 on-time settled days, mean net -70.3 bp per trade | ENS: 9 on-time settled days, mean net -154.6 bp per trade

## 2026-10-23 (Fri)
- D bought at the open: FINCABLES (rank 1) Rs 1,150.00, INDOSTAR (rank 2) Rs 170.60, FUSION (rank 3) Rs 140.05
- ENS bought at the open: INDORAMA (rank 1) Rs 75.50, FINCABLES (rank 2) Rs 1,150.00, INDOSTAR (rank 3) Rs 170.60
- D sold UNIPARTS (bought 2026-10-16): -509 bp net (MFE +3.83%, MAE -6.71%)
- D sold DIVGIITTS (bought 2026-10-16): -329 bp net (MFE +7.98%, MAE -5.38%)
- D sold SMCGLOBAL (bought 2026-10-16): -1251 bp net (MFE +5.34%, MAE -14.02%)
- ENS sold DIVGIITTS (bought 2026-10-16): -329 bp net (MFE +7.98%, MAE -5.38%)
- ENS sold UNIPARTS (bought 2026-10-16): -509 bp net (MFE +3.83%, MAE -6.71%)
- ENS sold XPROINDIA (bought 2026-10-16): -230 bp net (MFE +5.84%, MAE -2.66%)
- holding at the close: D XPROINDIA -1.23%, D SANGHVIMOV -6.77%, D SUNDROP -1.47%, ENS AVALON -7.08%, ENS APARINDS -10.84%, ENS SANGHVIMOV -6.77%, D SHILPAMED +2.43%, D KRN -7.81%, D KPEL -13.79%, ENS GENESYS -13.82%, ENS GENCON -9.71%, ENS TALBROAUTO -1.32%, D SBCL -3.04%, D EMIL -4.75%, D SHILPAMED +6.00%, ENS SBCL -3.04%, ENS SHILPAMED +6.00%, ENS EMIL -4.75%, D FINCABLES -5.65%, D INDOSTAR -4.40%, D FUSION -0.57%, ENS INDORAMA -1.19%, ENS FINCABLES -5.65%, ENS INDOSTAR -4.40%
- watchlist recorded for the next open: D INDORAMA, KPEL, INDOSTAR | ENS MANINDS, KPEL, FINCABLES

## 2026-10-22 (Thu)
- D bought at the open: SBCL (rank 1) Rs 933.40, EMIL (rank 2) Rs 161.00, SHILPAMED (rank 3) Rs 826.30
- ENS bought at the open: SBCL (rank 1) Rs 933.40, SHILPAMED (rank 2) Rs 826.30, EMIL (rank 3) Rs 161.00
- D sold XPROINDIA (bought 2026-10-15): +40 bp net (MFE +4.19%, MAE -4.19%)
- D sold DIVGIITTS (bought 2026-10-15): -457 bp net (MFE +4.09%, MAE -7.47%)
- D sold SANGHVIMOV (bought 2026-10-15): -1134 bp net (MFE +1.11%, MAE -12.52%)
- ENS sold DIVGIITTS (bought 2026-10-15): -457 bp net (MFE +4.09%, MAE -7.47%)
- ENS sold CUPID (bought 2026-10-15): -1020 bp net (MFE +0.97%, MAE -10.99%)
- ENS sold SBC (bought 2026-10-15): -329 bp net (MFE +3.67%, MAE -3.12%)
- holding at the close: D UNIPARTS -0.83%, D DIVGIITTS -0.64%, D SMCGLOBAL -7.72%, ENS DIVGIITTS -0.64%, ENS UNIPARTS -0.83%, ENS XPROINDIA +2.35%, D XPROINDIA +3.10%, D SANGHVIMOV -3.97%, D SUNDROP +1.88%, ENS AVALON -0.62%, ENS APARINDS -8.27%, ENS SANGHVIMOV -3.97%, D SHILPAMED +0.67%, D KRN -2.96%, D KPEL -8.77%, ENS GENESYS -10.17%, ENS GENCON -10.29%, ENS TALBROAUTO -2.41%, D SBCL +0.03%, D EMIL -0.86%, D SHILPAMED +4.18%, ENS SBCL +0.03%, ENS SHILPAMED +4.18%, ENS EMIL -0.86%
- watchlist recorded for the next open: D FINCABLES, INDOSTAR, FUSION | ENS INDORAMA, FINCABLES, INDOSTAR

## 2026-10-21 (Wed)
- D bought at the open: SHILPAMED (rank 1) Rs 855.10, KRN (rank 2) Rs 1,104.35, KPEL (rank 3) Rs 188.62
- ENS bought at the open: GENESYS (rank 1) Rs 225.10, GENCON (rank 2) Rs 28.85, TALBROAUTO (rank 3) Rs 356.70
- D sold XPROINDIA (bought 2026-10-14): +46 bp net (MFE +2.95%, MAE -5.33%)
- D sold ELECTHERM (bought 2026-10-14): -543 bp net (MFE +8.67%, MAE -7.25%)
- D sold DIVGIITTS (bought 2026-10-14): -886 bp net (MFE +1.17%, MAE -9.27%)
- ENS sold CUPID (bought 2026-10-14): -385 bp net (MFE +3.09%, MAE -8.81%)
- ENS sold DIVGIITTS (bought 2026-10-14): -886 bp net (MFE +1.17%, MAE -9.27%)
- ENS sold XPROINDIA (bought 2026-10-14): +46 bp net (MFE +2.95%, MAE -5.33%)
- holding at the close: D XPROINDIA +2.02%, D DIVGIITTS -5.87%, D SANGHVIMOV -8.22%, ENS DIVGIITTS -5.87%, ENS CUPID -4.01%, ENS SBC -1.66%, D UNIPARTS -1.78%, D DIVGIITTS -2.35%, D SMCGLOBAL -6.10%, ENS DIVGIITTS -2.35%, ENS UNIPARTS -1.78%, ENS XPROINDIA +3.65%, D XPROINDIA +4.41%, D SANGHVIMOV -0.99%, D SUNDROP +0.50%, ENS AVALON +0.03%, ENS APARINDS -5.72%, ENS SANGHVIMOV -0.99%, D SHILPAMED -1.16%, D KRN -4.65%, D KPEL -5.09%, ENS GENESYS -7.46%, ENS GENCON -8.15%, ENS TALBROAUTO -3.57%
- watchlist recorded for the next open: D SBCL, EMIL, SHILPAMED | ENS SBCL, SHILPAMED, EMIL

## 2026-10-19 (Mon)
- D bought at the open: XPROINDIA (rank 1) Rs 980.10, SANGHVIMOV (rank 2) Rs 342.15, SUNDROP (rank 3) Rs 614.00
- ENS bought at the open: AVALON (rank 1) Rs 1,996.40, APARINDS (rank 2) Rs 16,040.00, SANGHVIMOV (rank 3) Rs 342.15
- D sold ELECTHERM (bought 2026-10-13): -371 bp net (MFE +9.45%, MAE -4.74%)
- D sold ABREL (bought 2026-10-13): +780 bp net (MFE +11.65%, MAE -0.20%)
- D sold RAMKY (bought 2026-10-13): -56 bp net (MFE +6.94%, MAE -1.21%)
- ENS sold SUVEN (bought 2026-10-13): +38 bp net (MFE +8.00%, MAE -3.98%)
- ENS sold CUPID (bought 2026-10-13): -741 bp net (MFE +0.59%, MAE -7.78%)
- ENS sold GLOBAL (bought 2026-10-13): -235 bp net (MFE +1.21%, MAE -3.57%)
- holding at the close: D XPROINDIA -1.98%, D ELECTHERM -4.06%, D DIVGIITTS -4.61%, ENS CUPID -4.76%, ENS DIVGIITTS -4.61%, ENS XPROINDIA -1.98%, D XPROINDIA -0.80%, D DIVGIITTS -1.86%, D SANGHVIMOV -5.92%, ENS DIVGIITTS -1.86%, ENS CUPID -5.27%, ENS SBC +0.78%, D UNIPARTS -0.76%, D DIVGIITTS +1.81%, D SMCGLOBAL -2.56%, ENS DIVGIITTS +1.81%, ENS UNIPARTS -0.76%, ENS XPROINDIA +0.78%, D XPROINDIA +1.52%, D SANGHVIMOV +1.49%, D SUNDROP -0.20%, ENS AVALON +1.21%, ENS APARINDS -1.89%, ENS SANGHVIMOV +1.49%
- watchlist recorded for the next open: D SHILPAMED, KRN, KPEL | ENS GENESYS, GENCON, TALBROAUTO

## 2026-10-16 (Fri)
- D bought at the open: UNIPARTS (rank 1) Rs 720.10, DIVGIITTS (rank 2) Rs 927.30, SMCGLOBAL (rank 3) Rs 110.49
- ENS bought at the open: DIVGIITTS (rank 1) Rs 927.30, UNIPARTS (rank 2) Rs 720.10, XPROINDIA (rank 3) Rs 987.30
- D sold SUVEN (bought 2026-10-12): +655 bp net (MFE +9.53%, MAE -2.62%)
- D sold PFOCUS (bought 2026-10-12): +1079 bp net (MFE +16.18%, MAE +0.00%)
- D sold ABREL (bought 2026-10-12): +844 bp net (MFE +10.13%, MAE -1.78%)
- ENS sold PFOCUS (bought 2026-10-12): +1079 bp net (MFE +16.18%, MAE +0.00%)
- ENS sold SUVEN (bought 2026-10-12): +655 bp net (MFE +9.53%, MAE -2.62%)
- ENS sold ELECTHERM (bought 2026-10-12): -139 bp net (MFE +6.45%, MAE -3.63%)
- holding at the close: D ELECTHERM +1.75%, D ABREL +10.29%, D RAMKY +2.22%, ENS SUVEN +5.42%, ENS CUPID -2.25%, ENS GLOBAL -1.01%, D XPROINDIA -3.70%, D ELECTHERM +1.02%, D DIVGIITTS -0.23%, ENS CUPID +0.17%, ENS DIVGIITTS -0.23%, ENS XPROINDIA -3.70%, D XPROINDIA -2.54%, D DIVGIITTS +2.64%, D SANGHVIMOV -6.54%, ENS DIVGIITTS +2.64%, ENS CUPID -0.37%, ENS SBC -1.05%, D UNIPARTS +2.13%, D DIVGIITTS +6.48%, D SMCGLOBAL -0.34%, ENS DIVGIITTS +6.48%, ENS UNIPARTS +2.13%, ENS XPROINDIA -0.99%
- watchlist recorded for the next open: D XPROINDIA, SANGHVIMOV, SUNDROP | ENS AVALON, APARINDS, SANGHVIMOV

## 2026-10-15 (Thu)
- D bought at the open: XPROINDIA (rank 1) Rs 1,003.00, DIVGIITTS (rank 2) Rs 962.00, SANGHVIMOV (rank 3) Rs 369.10
- ENS bought at the open: DIVGIITTS (rank 1) Rs 962.00, CUPID (rank 2) Rs 355.00, SBC (rank 3) Rs 64.00
- D sold OMAXE (bought 2026-10-09): +950 bp net (MFE +11.17%, MAE -0.96%)
- D sold ZEEL (bought 2026-10-09): +560 bp net (MFE +9.43%, MAE -0.79%)
- D sold SUVEN (bought 2026-10-09): +358 bp net (MFE +7.65%, MAE -4.29%)
- ENS sold CUPID (bought 2026-10-09): -206 bp net (MFE +2.87%, MAE -7.71%)
- ENS sold OMAXE (bought 2026-10-09): +950 bp net (MFE +11.17%, MAE -0.96%)
- ENS sold SUVEN (bought 2026-10-09): +358 bp net (MFE +7.65%, MAE -4.29%)
- holding at the close: D SUVEN +5.74%, D PFOCUS +6.44%, D ABREL +7.97%, ENS PFOCUS +6.44%, ENS SUVEN +5.74%, ENS ELECTHERM -2.39%, D ELECTHERM +0.37%, D ABREL +9.46%, D RAMKY +2.45%, ENS SUVEN +4.27%, ENS CUPID -2.58%, ENS GLOBAL +0.24%, D XPROINDIA -3.23%, D ELECTHERM -0.35%, D DIVGIITTS -6.33%, ENS CUPID -0.17%, ENS DIVGIITTS -6.33%, ENS XPROINDIA -3.23%, D XPROINDIA -2.06%, D DIVGIITTS -3.63%, D SANGHVIMOV -5.05%, ENS DIVGIITTS -3.63%, ENS CUPID -0.70%, ENS SBC +0.33%
- watchlist recorded for the next open: D UNIPARTS, DIVGIITTS, SMCGLOBAL | ENS DIVGIITTS, UNIPARTS, XPROINDIA

## 2026-10-14 (Wed)
- D bought at the open: XPROINDIA (rank 1) Rs 1,015.10, ELECTHERM (rank 2) Rs 690.00, DIVGIITTS (rank 3) Rs 989.70
- ENS bought at the open: CUPID (rank 1) Rs 353.10, DIVGIITTS (rank 2) Rs 989.70, XPROINDIA (rank 3) Rs 1,015.10
- holding at the close: D OMAXE +6.57%, D ZEEL +7.44%, D SUVEN -1.19%, ENS CUPID -1.13%, ENS OMAXE +6.57%, ENS SUVEN -1.19%, D SUVEN +0.53%, D PFOCUS +8.47%, D ABREL +4.88%, ENS PFOCUS +8.47%, ENS SUVEN +0.53%, ENS ELECTHERM +0.66%, D ELECTHERM +3.50%, D ABREL +6.32%, D RAMKY +4.93%, ENS SUVEN -0.87%, ENS CUPID -2.00%, ENS GLOBAL +0.03%, D XPROINDIA -0.98%, D ELECTHERM +2.76%, D DIVGIITTS -2.98%, ENS CUPID +0.42%, ENS DIVGIITTS -2.98%, ENS XPROINDIA -0.98%
- watchlist recorded for the next open: D XPROINDIA, DIVGIITTS, SANGHVIMOV | ENS DIVGIITTS, CUPID, SBC

## 2026-10-13 (Tue)
- D bought at the open: ELECTHERM (rank 1) Rs 685.05, ABREL (rank 2) Rs 1,015.70, RAMKY (rank 3) Rs 263.80
- ENS bought at the open: SUVEN (rank 1) Rs 287.95, CUPID (rank 2) Rs 361.85, GLOBAL (rank 3) Rs 144.15
- D sold ABREL (bought 2026-10-07): -170 bp net (MFE +0.84%, MAE -7.27%)
- D sold BHARATRAS (bought 2026-10-07): -194 bp net (MFE +0.27%, MAE -4.71%)
- D sold PRICOLLTD (bought 2026-10-07): -208 bp net (MFE +0.88%, MAE -6.57%)
- ENS sold PRICOLLTD (bought 2026-10-07): -208 bp net (MFE +0.88%, MAE -6.57%)
- ENS sold ABREL (bought 2026-10-07): -170 bp net (MFE +0.84%, MAE -7.27%)
- ENS sold SJS (bought 2026-10-07): +458 bp net (MFE +5.50%, MAE -3.10%)
- holding at the close: D OMAXE +1.91%, D ZEEL +7.92%, D SUVEN -1.78%, ENS CUPID -1.55%, ENS OMAXE +1.91%, ENS SUVEN -1.78%, D SUVEN -0.07%, D PFOCUS +6.96%, D ABREL +3.55%, ENS PFOCUS +6.96%, ENS SUVEN -0.07%, ENS ELECTHERM -2.04%, D ELECTHERM +0.72%, D ABREL +4.98%, D RAMKY +2.01%, ENS SUVEN -1.46%, ENS CUPID -2.42%, ENS GLOBAL -0.82%
- watchlist recorded for the next open: D XPROINDIA, ELECTHERM, DIVGIITTS | ENS CUPID, DIVGIITTS, XPROINDIA

## 2026-10-12 (Mon)
- D bought at the open: SUVEN (rank 1) Rs 283.95, PFOCUS (rank 2) Rs 260.80, ABREL (rank 3) Rs 1,029.70
- ENS bought at the open: PFOCUS (rank 1) Rs 260.80, SUVEN (rank 2) Rs 283.95, ELECTHERM (rank 3) Rs 704.40
- holding at the close: D ABREL -6.07%, D BHARATRAS -3.45%, D PRICOLLTD -2.06%, ENS PRICOLLTD -2.06%, ENS ABREL -6.07%, ENS SJS +3.89%, D OMAXE +0.89%, D ZEEL +7.69%, D SUVEN -0.97%, ENS CUPID +0.88%, ENS OMAXE +0.89%, ENS SUVEN -0.97%, D SUVEN +0.76%, D PFOCUS +8.15%, D ABREL -1.40%, ENS PFOCUS +8.15%, ENS SUVEN +0.76%, ENS ELECTHERM -2.58%
- watchlist recorded for the next open: D ELECTHERM, ABREL, RAMKY | ENS SUVEN, CUPID, GLOBAL

## 2026-10-09 (Fri)
- D bought at the open: OMAXE (rank 1) Rs 98.95, ZEEL (rank 2) Rs 68.70, SUVEN (rank 3) Rs 288.90
- ENS bought at the open: CUPID (rank 1) Rs 358.65, OMAXE (rank 2) Rs 98.95, SUVEN (rank 3) Rs 288.90
- D sold POLICYBZR (bought 2026-10-05): +240 bp net (MFE +6.36%, MAE -4.04%)
- D sold ELECTHERM (bought 2026-10-05): -586 bp net (MFE +5.98%, MAE -7.54%)
- D sold NACLIND (bought 2026-10-05): -135 bp net (MFE +5.36%, MAE -1.85%)
- ENS sold POLICYBZR (bought 2026-10-05): +240 bp net (MFE +6.36%, MAE -4.04%)
- ENS sold IFCI (bought 2026-10-05): +247 bp net (MFE +6.56%, MAE -3.36%)
- ENS sold ELECTHERM (bought 2026-10-05): -586 bp net (MFE +5.98%, MAE -7.54%)
- holding at the close: D ABREL -5.42%, D BHARATRAS -4.04%, D PRICOLLTD -1.49%, ENS PRICOLLTD -1.49%, ENS ABREL -5.42%, ENS SJS +0.78%, D OMAXE +1.25%, D ZEEL +1.85%, D SUVEN -2.13%, ENS CUPID +2.08%, ENS OMAXE +1.25%, ENS SUVEN -2.13%
- watchlist recorded for the next open: D SUVEN, PFOCUS, ABREL | ENS PFOCUS, SUVEN, ELECTHERM

## 2026-10-08 (Thu)
- D sold SALASAR (bought 2026-10-01): -10 bp net (MFE +6.37%, MAE -1.96%)
- D sold RAMKY (bought 2026-10-01): -347 bp net (MFE +3.57%, MAE -5.03%)
- D sold SHANTIGEAR (bought 2026-10-01): -263 bp net (MFE +6.82%, MAE -2.32%)
- ENS sold RAMKY (bought 2026-10-01): -347 bp net (MFE +3.57%, MAE -5.03%)
- ENS sold SHANTIGEAR (bought 2026-10-01): -263 bp net (MFE +6.82%, MAE -2.32%)
- ENS sold ELECTHERM (bought 2026-10-01): -1204 bp net (MFE +0.07%, MAE -12.69%)
- holding at the close: D POLICYBZR +1.13%, D ELECTHERM -6.48%, D NACLIND -1.00%, ENS POLICYBZR +1.13%, ENS IFCI +1.42%, ENS ELECTHERM -6.48%, D ABREL -5.82%, D BHARATRAS -3.83%, D PRICOLLTD -4.54%, ENS PRICOLLTD -4.54%, ENS ABREL -5.82%, ENS SJS +0.05%
- watchlist recorded for the next open: D OMAXE, ZEEL, SUVEN | ENS CUPID, OMAXE, SUVEN

## 2026-10-07 (Wed)
- D bought at the open: ABREL (rank 1) Rs 1,080.90, BHARATRAS (rank 2) Rs 1,005.30, PRICOLLTD (rank 3) Rs 681.00
- ENS bought at the open: PRICOLLTD (rank 1) Rs 681.00, ABREL (rank 2) Rs 1,080.90, SJS (rank 3) Rs 1,979.30
- holding at the close: D SALASAR +2.21%, D RAMKY +1.15%, D SHANTIGEAR +2.82%, ENS RAMKY +1.15%, ENS SHANTIGEAR +2.82%, ENS ELECTHERM -6.63%, D POLICYBZR +5.59%, D ELECTHERM -1.11%, D NACLIND +1.68%, ENS POLICYBZR +5.59%, ENS IFCI -2.24%, ENS ELECTHERM -1.11%, D ABREL -2.91%, D BHARATRAS -2.00%, D PRICOLLTD -2.90%, ENS PRICOLLTD -2.90%, ENS ABREL -2.91%, ENS SJS +0.17%

## 2026-10-06 (Tue)
- holding at the close: D SALASAR +3.43%, D RAMKY +2.93%, D SHANTIGEAR +5.67%, ENS RAMKY +2.93%, ENS SHANTIGEAR +5.67%, ENS ELECTHERM -5.04%, D POLICYBZR +5.08%, D ELECTHERM +0.57%, D NACLIND +4.77%, ENS POLICYBZR +5.08%, ENS IFCI +0.02%, ENS ELECTHERM +0.57%
- watchlist recorded for the next open: D ABREL, BHARATRAS, PRICOLLTD | ENS PRICOLLTD, ABREL, SJS

## 2026-10-05 (Mon)
- D bought at the open: POLICYBZR (rank 1) Rs 984.90, ELECTHERM (rank 2) Rs 731.10, NACLIND (rank 3) Rs 130.41
- ENS bought at the open: POLICYBZR (rank 1) Rs 984.90, IFCI (rank 2) Rs 65.50, ELECTHERM (rank 3) Rs 731.10
- holding at the close: D SALASAR -0.98%, D RAMKY +0.88%, D SHANTIGEAR +3.82%, ENS RAMKY +0.88%, ENS SHANTIGEAR +3.82%, ENS ELECTHERM -9.28%, D POLICYBZR -0.88%, D ELECTHERM -3.93%, D NACLIND -0.09%, ENS POLICYBZR -0.88%, ENS IFCI -1.86%, ENS ELECTHERM -3.93%

## 2026-10-01 (Thu)
- D bought at the open: SALASAR (rank 1) Rs 4.08, RAMKY (rank 2) Rs 278.50, SHANTIGEAR (rank 3) Rs 570.00
- ENS bought at the open: RAMKY (rank 1) Rs 278.50, SHANTIGEAR (rank 2) Rs 570.00, ELECTHERM (rank 3) Rs 774.25
- holding at the close: D SALASAR +1.23%, D RAMKY -1.40%, D SHANTIGEAR +0.64%, ENS RAMKY -1.40%, ENS SHANTIGEAR +0.64%, ENS ELECTHERM -3.96%
- watchlist recorded for the next open: D POLICYBZR, ELECTHERM, NACLIND | ENS POLICYBZR, IFCI, ELECTHERM

## 2026-09-30 (Wed)
- watchlist recorded for the next open: D SALASAR, RAMKY, SHANTIGEAR | ENS RAMKY, SHANTIGEAR, ELECTHERM
