# Paper test - running report

paper_pipeline v1.6 | first watchlist 2026-09-30 | report 2026-10-23

## D (primary - judged at month 6)

- first_day: 2026-09-30
- month6_on: 2027-03-30
- days: 9
- status: too early

## ENS (challenger - descriptive until month 12)

- first_day: 2026-09-30
- month6_on: 2027-03-30
- days: 9
- status: too early

Sessions since day 1 with NO recorded watchlist: 2 - 2026-10-05, 2026-10-07

Month-6 rule for D (declared before day 1): CONFIRMED if mean net per trade > 0 and mean excess > 0; FAILED if the 95% upper bound of the mean net < 0; otherwise INCONCLUSIVE and the test runs to month 12.
