# MANIFEST rows - trade_path v1 + test_pick_meta v1.3.1 (18 Oct 2026)

| file (under bigmove_deploy\open_close) | version / fingerprint | what it does | status |
|---|---|---|---|
| trade_path.py | v1 (be535f23c3d920fb) | day-by-day keep-or-exit check during D's 5-session trades (drawdown part 2) and direction after entry: `research` command, walk-forward 2022+, writes research2\trade_path\TP_YYYYMMDD_NNN\ | NEW |
| TRADE_PATH_DECLARATION.json | 297a32b6b6c36fe9 (family trade_path_v1) | rules fixed before any real run: CHECK sells at the next open when the forecast advantage of holding is below 0 bp; verdicts; Karan's target (drawdown <= 0.525 x, P&L >= 0.70 x); amendment (a); behaviour on synthetic worlds | NEW |
| tests\test_trade_path.py | v1 (3a5ed21901fa5bc8) | suite, 66 checks; must end VERIFIED (trade_path v1) | NEW |
| tests\path_world.py | v1 (393d590382ef1d59) | synthetic worlds where the truth is known: planted / absent / reverse after-drop drift (used by the suite) | NEW |
| tests\path_rates.py | v1 (285a5dc41eeb5c23) | optional (~25 min): verdict rates over many synthetic worlds | NEW |
| tests\test_pick_meta.py | v1.3.1 (63db5eda054b3654) | pick_meta suite; a missing run_pick_meta.bat is now a FAIL line instead of a crash; must end VERIFIED (pick_meta v1.3) | replaces v1.3 |
| pick_meta.py, PICK_META_*_DECLARATION.json, run_pick_meta.bat, tests\pick_meta_world.py, tests\conf_*.py | unchanged | trade_path reads pick_meta's research run and uses its bar and lock helpers | unchanged - do not touch |

Outputs of `trade_path.py research` (under %CACHE_DAILY_ROOT%\research2\trade_path\TP_YYYYMMDD_NNN\): report.md, summary.json, checks.parquet (every evening check with its forecasts), trades_oos.csv (judged trades, HOLD vs CHECK), daily_pnl.csv (the drawdown proxy), final_models\models.pkl + final_models.json, outputs.sha256. Ledger: one line per run in panel\research_ledger.jsonl (family trade_path_v1; a second run is stamped RERUN). Never writes to the paper test, the paper ledger, the panels or any frozen file.

Verified 18 Oct: VERIFIED (trade_path v1), 66 checks, 0 failures, and VERIFIED (pick_meta v1.3) with test v1.3.1, 150 checks, 0 failures - on pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2 (Karan's) and pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1.
