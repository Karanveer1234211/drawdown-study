from pathlib import Path
import json
import pandas as pd
import streamlit as st
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.dataset as ds

st.set_page_config(page_title="Panel Reader & Exporter", layout="wide")
st.title("Panel Reader & Exporter — Local File Mode")
st.write("Reads a Parquet file directly from this computer. The source file is read-only and is never modified.")

default_path = r"C:\QuantData\cache_daily\panel_live\panel.parquet"
path_text = st.text_input("Full path to panel.parquet", value=default_path)
batch_rows = st.number_input("Rows to export for preview", min_value=1, max_value=100000, value=500, step=100)

if st.button("Inspect panel", type="primary"):
    path = Path(path_text.strip().strip('"'))
    if not path.exists():
        st.error(f"File not found: {path}")
        st.stop()
    try:
        pf = pq.ParquetFile(path)
        st.session_state["panel_path"] = str(path)
        st.session_state["panel_columns"] = pf.schema_arrow.names
        st.session_state["panel_schema"] = str(pf.schema_arrow)
        st.session_state["panel_meta"] = {
            "row_groups": pf.metadata.num_row_groups,
            "rows": pf.metadata.num_rows,
            "columns": len(pf.schema_arrow.names),
            "size_bytes": path.stat().st_size,
        }
        st.success("Parquet metadata read successfully. No full-table load was performed.")
    except Exception as e:
        st.error(f"Could not inspect Parquet file: {e}")
        st.stop()

if "panel_meta" in st.session_state and st.session_state.get("panel_path") == path_text.strip().strip('"'):
    meta = st.session_state["panel_meta"]
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Rows", f'{meta["rows"]:,}')
    c2.metric("Columns", meta["columns"])
    c3.metric("Row groups", meta["row_groups"])
    c4.metric("File size", f'{meta["size_bytes"]/1024**3:.2f} GB')

    schema_text = st.session_state["panel_schema"]
    st.subheader("Schema")
    st.code(schema_text, language="text")
    st.download_button("Download schema report", schema_text, file_name="panel_schema.txt", mime="text/plain")

    path = Path(st.session_state["panel_path"])
    pf = pq.ParquetFile(path)
    columns = st.session_state["panel_columns"]

    st.subheader("Export first N rows")
    if st.button(f"Prepare first {int(batch_rows):,} rows"):
        try:
            frames = []
            remaining = int(batch_rows)
            for batch in pf.iter_batches(batch_size=min(65536, remaining), use_threads=True):
                take = min(remaining, batch.num_rows)
                frames.append(batch.slice(0, take).to_pandas())
                remaining -= take
                if remaining <= 0:
                    break
            preview = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=columns)
            st.session_state["preview_csv"] = preview.to_csv(index=False).encode("utf-8-sig")
            st.session_state["preview_rows"] = len(preview)
            st.dataframe(preview.head(100), use_container_width=True)
            st.caption(f"Prepared {len(preview):,} rows; showing up to 100 rows on screen.")
        except Exception as e:
            st.error(f"Could not read first rows: {e}")
    if "preview_csv" in st.session_state:
        st.download_button("Download first rows as CSV", st.session_state["preview_csv"],
                           file_name="panel_first_rows.csv", mime="text/csv")

    st.subheader("Export all rows for one stock")
    symbol_col = st.selectbox("Select symbol/ticker column", options=columns,
                              index=next((i for i,c in enumerate(columns) if c.lower() in
                                          ["symbol","ticker","stock","tradingsymbol","security"]), 0))
    stock_value = st.text_input("Exact stock value (as it appears in that column)")
    out_format = st.selectbox("Output format", ["CSV", "Parquet"])
    if st.button("Export selected stock"):
        if not stock_value.strip():
            st.warning("Enter an exact stock value first.")
        else:
            try:
                dataset = ds.dataset(str(path), format="parquet")
                filt = ds.field(symbol_col) == stock_value.strip()
                out_path = path.parent / f"panel_stock_{stock_value.strip().replace('/', '_').replace('\\\\','_')}.{ 'csv' if out_format == 'CSV' else 'parquet'}"
                scanner = dataset.scanner(filter=filt, batch_size=65536, use_threads=True)
                count = 0
                if out_format == "CSV":
                    with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
                        first = True
                        for batch in scanner.to_batches():
                            frame = batch.to_pandas()
                            frame.to_csv(f, index=False, header=first)
                            first = False
                            count += len(frame)
                    if count == 0:
                        out_path.unlink(missing_ok=True)
                        st.warning("No rows matched that exact stock value.")
                    else:
                        st.success(f"Exported {count:,} rows to: {out_path}")
                        st.code(str(out_path))
                else:
                    table = scanner.to_table()
                    count = table.num_rows
                    if count == 0:
                        st.warning("No rows matched that exact stock value.")
                    else:
                        pq.write_table(table, out_path, compression="zstd")
                        st.success(f"Exported {count:,} rows to: {out_path}")
                        st.code(str(out_path))
            except Exception as e:
                st.error(f"Stock export failed: {e}")

st.info("For the first review, export the schema report and first 500 rows. The stock export scans the Parquet dataset and may take time depending on row-group layout.")
