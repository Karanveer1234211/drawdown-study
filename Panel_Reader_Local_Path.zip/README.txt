# Panel Reader — Local Path Mode

This version reads the panel directly from its path on your Windows computer. It does not upload the full Parquet file through the browser and does not modify the original.

## Run
1. Extract this ZIP.
2. Open the extracted folder in PyCharm.
3. In PyCharm Terminal, run:
   `python -m pip install -r requirements.txt`
4. Run:
   `python -m streamlit run app.py`
5. Open the Local URL Streamlit prints, usually `http://localhost:8501`.
6. The path is prefilled as:
   `C:\QuantData\cache_daily\panel_live\panel.parquet`
7. Click **Inspect panel**, download the schema report, and prepare/download the first 500 rows.
8. Optionally export all rows for one stock by choosing the correct symbol column and entering the exact symbol value.

Exports are written beside the source file. The original panel is read-only from this app.
