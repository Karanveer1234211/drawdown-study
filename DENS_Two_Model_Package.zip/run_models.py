from __future__ import annotations
import argparse, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import pyarrow.dataset as ds
import joblib
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, brier_score_loss, accuracy_score, mean_absolute_error, r2_score
from scipy.stats import spearmanr

BLOCK = {
 "timestamp","symbol","index","Unnamed: 0","signal_day","rank","status","net_hold",
 "hold_exit_day","exit_k","net_check","check_exit_day","scored","diff",
}
def nday(s): return pd.to_datetime(s, errors="coerce").dt.normalize()
def numeric(s): return pd.to_numeric(s, errors="coerce")
def allowed_feature(c, cfg):
    if c in BLOCK or c.startswith("label_"): return False
    if c in {cfg["date_column_panel"], cfg["symbol_column_panel"]}: return False
    low = c.lower()
    if any(t in low for t in ("exit_day","entry_price","exit_price","future","forward","target","outcome")): return False
    return True
def regime_feature(c):
    # Strict input whitelist requested by user: Nifty/index, sector, India VIX, USD/INR, cross-sectional.
    u = c.upper()
    return u.startswith(("NIFTY", "INDIAVIX", "USDINR", "X_"))
def cls_pipe():
    return Pipeline([
      ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
      ("scale", StandardScaler()),
      ("model", LogisticRegression(max_iter=1500, class_weight="balanced", C=0.5))
    ])
def reg_pipe():
    return Pipeline([
      ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
      ("scale", StandardScaler()),
      ("model", Ridge(alpha=10.0))
    ])
def numeric_cols(df, cols):
    return [c for c in cols if c in df.columns and (pd.api.types.is_numeric_dtype(df[c]) or pd.api.types.is_bool_dtype(df[c]))]
def prepare(cfg):
    panel_path = Path(cfg["panel_path"]); trades_path = Path(cfg["trades_path"])
    if not panel_path.exists(): raise FileNotFoundError(f"Panel not found: {panel_path}")
    if not trades_path.exists(): raise FileNotFoundError(f"Trades file not found: {trades_path}")
    trades = pd.read_csv(trades_path)
    req = {cfg["date_column_trades"], cfg["symbol_column_trades"], cfg["net_trade_pnl_column"]}
    missing = req - set(trades.columns)
    if missing: raise ValueError(f"Trades file missing required columns: {sorted(missing)}")
    trades["_signal_day"] = nday(trades[cfg["date_column_trades"]])
    trades["_symbol"] = trades[cfg["symbol_column_trades"]].astype(str).str.strip()
    trades["_net_pnl"] = numeric(trades[cfg["net_trade_pnl_column"]])
    trades["y_trade_direction"] = np.where(trades["_net_pnl"].notna(), (trades["_net_pnl"] > 0).astype(float), np.nan)
    trades["y_trade_strength"] = trades["_net_pnl"]
    exit_col = cfg.get("hold_exit_date_column")
    trades["_exit_day"] = nday(trades[exit_col]) if exit_col in trades.columns else pd.NaT
    lo, hi = trades["_signal_day"].min(), trades["_signal_day"].max()
    if pd.isna(lo) or pd.isna(hi): raise ValueError("No valid signal dates in trades file.")
    dataset = ds.dataset(str(panel_path), format="parquet")
    schema = dataset.schema.names
    for c in (cfg["date_column_panel"], cfg["symbol_column_panel"], cfg["forward_return_label"]):
        if c not in schema: raise ValueError(f"Panel missing required column: {c}")
    candidates = [c for c in schema if allowed_feature(c, cfg)]
    labels = [c for c in [cfg["forward_return_label"], cfg.get("mfe_label"), cfg.get("mae_label")] if c in schema]
    symbols = trades["_symbol"].dropna().unique().tolist()
    filt = ((ds.field(cfg["date_column_panel"]) >= np.datetime64(lo.to_datetime64())) &
            (ds.field(cfg["date_column_panel"]) < np.datetime64((hi + pd.Timedelta(days=1)).to_datetime64())) &
            ds.field(cfg["symbol_column_panel"]).isin(symbols))
    table = dataset.to_table(columns=list(dict.fromkeys([cfg["date_column_panel"], cfg["symbol_column_panel"]] + candidates + labels)), filter=filt)
    panel = table.to_pandas()
    panel["_signal_day"] = nday(panel[cfg["date_column_panel"]])
    panel["_symbol"] = panel[cfg["symbol_column_panel"]].astype(str).str.strip()
    for c in labels: panel[c] = numeric(panel[c])
    panel["y_price_direction"] = np.where(panel[cfg["forward_return_label"]].notna(), (panel[cfg["forward_return_label"]] > 0).astype(float), np.nan)
    dup = int(panel.duplicated(["_signal_day","_symbol"], keep=False).sum())
    if dup: raise ValueError(f"Panel has {dup} rows involved in duplicate (timestamp,symbol) keys; resolve before modeling.")
    feats = numeric_cols(panel, candidates)
    keep = ["_signal_day","_symbol","y_price_direction"] + feats + labels
    keep = list(dict.fromkeys(keep))
    panel = panel[keep]
    merged = trades.merge(panel, on=["_signal_day","_symbol"], how="left", validate="many_to_one", indicator=True)
    unmatched = merged[merged["_merge"] != "both"].copy()
    out = Path(cfg["output_dir"]); out.mkdir(parents=True, exist_ok=True)
    original_cols = [c for c in [cfg["date_column_trades"],cfg["symbol_column_trades"],"rank","status","_signal_day","_symbol"] if c in unmatched]
    unmatched[original_cols].to_csv(out/"unmatched_trades.csv", index=False)
    rank_col = cfg.get("ens_rank_column")
    baseline = [rank_col] if rank_col in merged.columns else []
    baseline += [c for c in cfg.get("ens_score_columns",[]) if c in merged.columns and c not in baseline]
    baseline = numeric_cols(merged, baseline)
    panel_features = [c for c in feats if c not in regime_feature(c)]
    regime_features = [c for c in feats if regime_feature(c)]
    audit = {
      "trades_rows": int(len(trades)), "unique_trade_symbols": int(trades["_symbol"].nunique()),
      "panel_rows_for_picked_symbols_and_dates": int(len(panel)),
      "matched_trade_rows": int((merged["_merge"]=="both").sum()),
      "unmatched_trade_rows": int((merged["_merge"]!="both").sum()),
      "match_rate": float((merged["_merge"]=="both").mean()),
      "duplicate_panel_keys": dup, "numeric_panel_feature_count": int(len(feats)),
      "model1_stock_feature_count": int(len(panel_features)),
      "model2_regime_feature_count": int(len(regime_features)),
      "model2_regime_feature_names": regime_features,
      "model1_baseline_columns": baseline,
      "signal_start": str(lo.date()), "signal_end": str(hi.date()),
      "target_note": "label_fwd_ret_5d is a 5-day forward price target and is not assumed to equal the production six-day trade outcome.",
      "baseline_note": "If baseline columns only contain rank, this is a rank-only benchmark, not a complete reproduction of D/ENS scoring.",
      "sample_note": "Every train/test trade row comes from the supplied D/ENS trades file. The Parquet panel is used only to enrich those picks."
    }
    merged.drop(columns=["_merge"], inplace=True)
    return merged, baseline, panel_features, regime_features, audit
def classify_fold(tr, te, features, target, name, fold):
    tr=tr.dropna(subset=[target]); te=te.dropna(subset=[target])
    tr=tr[tr[target].isin([0.,1.])]; te=te[te[target].isin([0.,1.])]
    usable=[c for c in features if c in tr.columns and tr[c].notna().any()]
    if len(tr)<50 or tr[target].nunique()<2 or len(te)<10 or not usable: return None,None,None
    pipe=cls_pipe()
    pipe.fit(tr[usable].replace([np.inf,-np.inf],np.nan), tr[target].astype(int))
    prob=pipe.predict_proba(te[usable].replace([np.inf,-np.inf],np.nan))[:,1]; pred=(prob>=.5).astype(int)
    auc=roc_auc_score(te[target].astype(int),prob) if te[target].nunique()==2 else np.nan
    metrics={"model_family":name,"task":target,"fold":fold,"train_rows":len(tr),"test_rows":len(te),
      "train_start":str(tr["_signal_day"].min().date()),"train_end":str(tr["_signal_day"].max().date()),
      "test_start":str(te["_signal_day"].min().date()),"test_end":str(te["_signal_day"].max().date()),
      "positive_rate":float(te[target].mean()),"accuracy":accuracy_score(te[target].astype(int),pred),
      "balanced_accuracy":balanced_accuracy_score(te[target].astype(int),pred),"roc_auc":auc,
      "brier":brier_score_loss(te[target].astype(int),prob),"features_used":len(usable)}
    p=te[["_signal_day","_symbol",target,"_net_pnl","_exit_day"]].copy()
    p["model_family"]=name;p["task"]=target;p["fold"]=fold;p["prob_positive"]=prob;p["predicted_class"]=pred
    return metrics,p,{"model":pipe,"features":usable}
def regression_fold(tr, te, features, target, name, fold):
    tr=tr.dropna(subset=[target]); te=te.dropna(subset=[target])
    usable=[c for c in features if c in tr.columns and tr[c].notna().any()]
    if len(tr)<50 or len(te)<10 or len(usable)<1: return None,None,None
    pipe=reg_pipe()
    pipe.fit(tr[usable].replace([np.inf,-np.inf],np.nan), numeric(tr[target]))
    pred=pipe.predict(te[usable].replace([np.inf,-np.inf],np.nan))
    actual=numeric(te[target]).to_numpy()
    try: rho=spearmanr(actual,pred,nan_policy="omit").statistic
    except Exception: rho=np.nan
    metrics={"model_family":name,"task":target,"fold":fold,"train_rows":len(tr),"test_rows":len(te),
      "train_start":str(tr["_signal_day"].min().date()),"train_end":str(tr["_signal_day"].max().date()),
      "test_start":str(te["_signal_day"].min().date()),"test_end":str(te["_signal_day"].max().date()),
      "mae":mean_absolute_error(actual,pred),"r2":r2_score(actual,pred) if len(np.unique(actual))>1 else np.nan,
      "spearman":rho,"features_used":len(usable)}
    p=te[["_signal_day","_symbol",target,"_net_pnl","_exit_day"]].copy()
    p["model_family"]=name;p["task"]=target;p["fold"]=fold;p["predicted_value"]=pred
    return metrics,p,{"model":pipe,"features":usable}
def main(cfg):
    merged, baseline, stock_feats, regime_feats, audit=prepare(cfg)
    out=Path(cfg["output_dir"]); out.mkdir(parents=True,exist_ok=True)
    all_feat=stock_feats
    # Only two top-level model families. Model 1 contains an internal baseline-vs-incremental ablation.
    family_specs = {
      "MODEL_1_DIRECTION_STRENGTH": {
        "baseline": baseline,
        "incremental": list(dict.fromkeys(baseline + all_feat[:int(cfg.get("max_features",500))]))
      },
      "MODEL_2_MARKET_REGIME": {
        "regime_only": regime_feats[:int(cfg.get("max_features",500))]
      }
    }
    # Classification and regression targets are separate outputs within each family.
    tasks = [
      ("classification","y_price_direction"),
      ("regression",cfg["forward_return_label"]),
      ("regression",cfg.get("mfe_label","label_mfe_5d")),
      ("regression",cfg.get("mae_label","label_mae_5d")),
      ("classification","y_trade_direction"),
      ("regression","y_trade_strength")
    ]
    available_tasks=[]
    for kind,target in tasks:
      if target in merged.columns and merged[target].notna().any(): available_tasks.append((kind,target))
    dates=np.array(sorted(merged["_signal_day"].dropna().unique()))
    min_train=int(cfg.get("min_train_days",504)); fold_days=int(cfg.get("test_fold_days",126)); purge=int(cfg.get("purge_days",10))
    summaries=[]; pred_parts=[]; saved={}
    for start in range(min_train,len(dates),fold_days):
      test_dates=dates[start:start+fold_days]
      if not len(test_dates): continue
      first_test=pd.Timestamp(test_dates[0])
      # Calendar purge for all tasks. Completed trade outcomes additionally require exit before test start.
      train=merged[merged["_signal_day"] < first_test-pd.Timedelta(days=purge)].copy()
      test=merged[merged["_signal_day"].isin(test_dates)].copy()
      # Do not train on outcome records that exit on/after first test day.
      for kind,target in available_tasks:
        train_task=train.copy()
        if target in ("y_trade_direction","y_trade_strength") and "_exit_day" in train_task:
          train_task=train_task[train_task["_exit_day"].notna() & (train_task["_exit_day"] < first_test)]
        # Price-forward label observations are purged by 10 calendar days as a conservative first guard.
        for family_name, variants in family_specs.items():
          for variant, feats in variants.items():
            feats=[c for c in feats if c in merged.columns and (pd.api.types.is_numeric_dtype(merged[c]) or pd.api.types.is_bool_dtype(merged[c]))]
            if not feats: continue
            if kind=="classification":
              metrics,pred,obj=classify_fold(train_task,test,feats,target,f"{family_name}:{variant}",int(np.searchsorted(dates,test_dates[0])))
            else:
              metrics,pred,obj=regression_fold(train_task,test,feats,target,f"{family_name}:{variant}",int(np.searchsorted(dates,test_dates[0])))
            if metrics:
              metrics["family_variant"]=variant
              summaries.append(metrics)
              pred_parts.append(pred)
              saved[(family_name,variant,target,kind)]=obj
    with open(out/"join_audit.json","w",encoding="utf-8") as f: json.dump(audit,f,indent=2)
    pd.DataFrame(summaries).to_csv(out/"model_summary.csv",index=False)
    if pred_parts: pd.concat(pred_parts,ignore_index=True).to_csv(out/"walk_forward_predictions.csv",index=False)
    pd.DataFrame([{"feature":c,"group":"market_regime" if regime_feature(c) else "stock_feature"} for c in stock_feats+regime_feats]).drop_duplicates("feature").to_csv(out/"feature_groups.csv",index=False)
    for (fam,var,target,kind),obj in saved.items():
      joblib.dump(obj,out/f"{fam.lower()}_{var}_{target}_{kind}.joblib")
    print(json.dumps(audit,indent=2))
    print(f"\nOutputs saved to: {out.resolve()}")
    print("Exactly two top-level model families were evaluated:")
    print("  1) MODEL_1_DIRECTION_STRENGTH (includes baseline vs incremental feature comparison)")
    print("  2) MODEL_2_MARKET_REGIME (only Nifty/sector/VIX/USDINR and X_ cross-sectional features)")
    print("Research only. D/ENS unchanged. Verify score columns, label timing and six-day outcome semantics.")
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--config",default="config.json");args=parser.parse_args()
    with open(args.config,encoding="utf-8") as f: main(json.load(f))
