# D/ENS Two-Model Research Package

This package contains exactly TWO top-level model families. Both use **only the existing D/ENS trade rows** from the configured trades CSV. The full Parquet panel is queried only to look up features for those symbol/date picks. It does not add unselected stocks and does not change D/ENS.

## Model 1 — Direction & Strength on D/ENS picks
Predicts separate outcomes:
- Forward price direction: `label_fwd_ret_5d > 0`
- Forward return magnitude: regression on `label_fwd_ret_5d`
- Favourable excursion: regression on `label_mfe_5d`
- Adverse excursion: regression on `label_mae_5d`
- Actual D/ENS trade profitability: `net_hold > 0`
- Actual trade P&L magnitude: regression on `net_hold`

Within Model 1 only, the script compares a baseline using available D/ENS rank/score metadata with an incremental feature set adding stock-level panel features. If the trade file only has `rank`, baseline is rank-only and is not a full reproduction of production D/ENS. Add real D/ENS score fields to `ens_score_columns` if present.

## Model 2 — Market Regime
Uses only feature columns beginning `NIFTY`, `INDIAVIX`, `USDINR`, or `X_`. That means Nifty/index/sector context, VIX, USDINR and cross-sectional ranks/z-scores/relative metrics. Stock-specific technical indicators are excluded. Review `feature_groups.csv` and `join_audit.json` to validate this whitelist.

## Install and run on Windows (PyCharm terminal)
```bash
python -m pip install -r requirements.txt
python run_models.py --config config.json
```

The default paths reflect the user's screenshot:
- `C:\QuantData\cache_daily\panel_live\panel.parquet`
- `C:\QuantData\cache_daily\research2\trade_path\TP_20261018_001\trades_oos.csv`

Verify the trades path actually exists. Edit `config.json` if needed.

## Outputs
- `model_summary.csv` - chronological fold metrics for two model families and their separate targets.
- `walk_forward_predictions.csv` - predictions and realized outcomes.
- `join_audit.json` - match coverage, feature counts, model 2 whitelist and baseline fields.
- `unmatched_trades.csv` - D/ENS trades with no panel row match.
- `feature_groups.csv` - feature classification audit.
- Saved model artifacts for the most recent scored folds.

## Validation caveats
- `label_fwd_ret_5d` is a 5-day forward label, not automatically equivalent to the existing six-day production trade exit.
- `net_hold` is assumed to already include the costs embedded in that file; no additional costs are subtracted. It is P&L magnitude, not a percent return unless the notional is known/normalized.
- `purge_days=10` calendar days is only a first safety guard. Verify exact label horizon and holding-period overlap before trusting metrics.
- If the true D/ENS ranking depends on score fields that are not in the trade CSV, then the baseline must be enriched with those original, timestamp-valid scores to make the incremental comparison fair.
- These are research models, not production-approved. D/ENS rules and production decisions remain unchanged.
