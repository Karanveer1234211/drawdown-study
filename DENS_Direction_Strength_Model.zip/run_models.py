from __future__ import annotations
import argparse, json, os
from pathlib import Path
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import pyarrow.dataset as ds
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, brier_score_loss, accuracy_score
import joblib

NON_FEATURE_EXACT = {
    "timestamp", "symbol", "index", "Unnamed: 0",
    "signal_day", "rank", "status", "net_hold", "hold_exit_day", "exit_k",
    "net_check", "check_exit_day", "scored", "diff",
}
NON_FEATURE_PREFIXES = ("label_",)
BAD_FEATURE_TOKENS = ("exit_day", "entry_price", "exit_price", "future", "forward", "target", "outcome")

def parse_day(series):
    return pd.to_datetime(series, errors="coerce").dt.normalize()

def select_feature_columns(schema_names, cfg):
    cols = []
    for c in schema_names:
        if c in NON_FEATURE_EXACT or c.startswith(NON_FEATURE_PREFIXES):
            continue
        if c in {cfg["date_column_panel"], cfg["symbol_column_panel"]}:
            continue
        low = c.lower()
        if any(tok in low for tok in BAD_FEATURE_TOKENS):
            continue
        cols.append(c)
    return cols

def load_joined(cfg):
    panel_path = Path(cfg["panel_path"])
    trades_path = Path(cfg["trades_path"])
    if not panel_path.exists():
        raise FileNotFoundError(f"Panel not found: {panel_path}")
    if not trades_path.exists():
        raise FileNotFoundError(f"Trades file not found: {trades_path}")

    trades = pd.read_csv(trades_path)
    needed = {cfg["date_column_trades"], cfg["symbol_column_trades"], cfg["net_trade_pnl_column"]}
    missing = needed - set(trades.columns)
    if missing:
        raise ValueError(f"Trades file missing required columns: {sorted(missing)}")
    trades["_signal_day"] = parse_day(trades[cfg["date_column_trades"]])
    trades["_symbol"] = trades[cfg["symbol_column_trades"]].astype(str).str.strip()
    trades["_net_pnl"] = pd.to_numeric(trades[cfg["net_trade_pnl_column"]], errors="coerce")
    trades["_trade_profitable"] = (trades["_net_pnl"] > 0).astype("float")
    trades.loc[trades["_net_pnl"].isna(), "_trade_profitable"] = np.nan
    if cfg.get("hold_exit_date_column") in trades.columns:
        trades["_exit_day"] = parse_day(trades[cfg["hold_exit_date_column"]])
    else:
        trades["_exit_day"] = pd.NaT

    dataset = ds.dataset(str(panel_path), format="parquet")
    schema_names = dataset.schema.names
    required_panel = [cfg["date_column_panel"], cfg["symbol_column_panel"], cfg["price_direction_label"]]
    missing_panel = set(required_panel) - set(schema_names)
    if missing_panel:
        raise ValueError(f"Panel missing required columns: {sorted(missing_panel)}")
    feature_cols = select_feature_columns(schema_names, cfg)
    # Exclude obvious object/string fields except keys; feature types are checked after loading.
    columns = list(dict.fromkeys(required_panel + feature_cols))
    # Filter on D/ENS pick date range and stock symbols first. This limits scan scope.
    min_day, max_day = trades["_signal_day"].min(), trades["_signal_day"].max()
    symbols = sorted(trades["_symbol"].dropna().unique().tolist())
    if pd.isna(min_day) or pd.isna(max_day):
        raise ValueError("No valid trade signal dates.")
    date_field = ds.field(cfg["date_column_panel"])
    symbol_field = ds.field(cfg["symbol_column_panel"])
    # Inclusive date filter; normalize timestamps in pandas after read.
    filt = (date_field >= np.datetime64(min_day.to_datetime64())) & (date_field <= np.datetime64(max_day.to_datetime64() + np.timedelta64(1, "D") - np.timedelta64(1, "ns")))
    filt = filt & symbol_field.isin(symbols)
    table = dataset.to_table(columns=columns, filter=filt)
    panel = table.to_pandas()
    panel["_signal_day"] = parse_day(panel[cfg["date_column_panel"]])
    panel["_symbol"] = panel[cfg["symbol_column_panel"]].astype(str).str.strip()
    panel[cfg["price_direction_label"]] = pd.to_numeric(panel[cfg["price_direction_label"]], errors="coerce")
    # The direction label is an outcome only. The row's price direction is known only after the forward horizon.
    panel["_price_direction"] = np.where(panel[cfg["price_direction_label"]].notna(),
                                          (panel[cfg["price_direction_label"]] > 0).astype(float), np.nan)
    # Keep one panel record per symbol/date only if unique; fail loudly otherwise.
    dup = int(panel.duplicated(["_signal_day", "_symbol"], keep=False).sum())
    if dup:
        raise ValueError(f"Panel has {dup} rows participating in duplicate (date,symbol) keys; resolve before modeling.")
    # Retain only numeric/bool feature columns.
    numeric_features = [c for c in feature_cols if c in panel.columns and
                        (pd.api.types.is_numeric_dtype(panel[c]) or pd.api.types.is_bool_dtype(panel[c]))]
    panel = panel[["_signal_day", "_symbol", "_price_direction"] + numeric_features]
    merged = trades.merge(panel, on=["_signal_day", "_symbol"], how="left", validate="many_to_one", indicator=True)
    audit = {
        "trades_rows": int(len(trades)),
        "unique_trade_symbols": int(len(symbols)),
        "panel_rows_scanned": int(len(panel)),
        "matched_trade_rows": int((merged["_merge"] == "both").sum()),
        "unmatched_trade_rows": int((merged["_merge"] != "both").sum()),
        "match_rate": float((merged["_merge"] == "both").mean()) if len(merged) else 0.0,
        "numeric_predictor_count": int(len(numeric_features)),
        "duplicate_panel_keys": dup,
        "signal_start": str(min_day.date()),
        "signal_end": str(max_day.date()),
        "price_target": cfg["price_direction_label"],
        "trade_target": cfg["net_trade_pnl_column"],
        "warning": "Forward price target is separate from net trade profitability target; verify timing and label semantics before interpreting metrics."
    }
    merged.drop(columns=["_merge"], inplace=True)
    return merged, numeric_features, audit

def make_model():
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
        ("scale", StandardScaler()),
        ("model", LogisticRegression(max_iter=1500, class_weight="balanced", C=0.5))
    ])

def score_fold(train, test, features, target, fold_num):
    train = train.dropna(subset=[target]).copy()
    test = test.dropna(subset=[target]).copy()
    # Require numeric target labels in {0,1}.
    train = train[train[target].isin([0.0, 1.0])]
    test = test[test[target].isin([0.0, 1.0])]
    if len(train) < 50 or train[target].nunique() < 2 or len(test) < 10:
        return None, None, None
    X_train = train[features].replace([np.inf, -np.inf], np.nan)
    X_test = test[features].replace([np.inf, -np.inf], np.nan)
    # Drop all-empty predictors in this fold to avoid imputer failure.
    usable = [c for c in features if X_train[c].notna().any()]
    if not usable:
        return None, None, None
    model = make_model()
    model.fit(X_train[usable], train[target].astype(int))
    prob = model.predict_proba(X_test[usable])[:, 1]
    pred = (prob >= 0.5).astype(int)
    try: auc = roc_auc_score(test[target].astype(int), prob) if test[target].nunique() == 2 else np.nan
    except Exception: auc = np.nan
    metrics = {
        "target": target, "fold": fold_num, "train_rows": len(train), "test_rows": len(test),
        "train_start": str(train["_signal_day"].min().date()), "train_end": str(train["_signal_day"].max().date()),
        "test_start": str(test["_signal_day"].min().date()), "test_end": str(test["_signal_day"].max().date()),
        "positive_rate_test": float(test[target].mean()), "accuracy": float(accuracy_score(test[target].astype(int), pred)),
        "balanced_accuracy": float(balanced_accuracy_score(test[target].astype(int), pred)),
        "roc_auc": float(auc) if pd.notna(auc) else np.nan,
        "brier": float(brier_score_loss(test[target].astype(int), prob)),
        "features_used": len(usable)
    }
    preds = test[["_signal_day", "_symbol", "_net_pnl", "_exit_day", target]].copy()
    preds["target"] = target
    preds["fold"] = fold_num
    preds["prob_positive"] = prob
    preds["pred_positive_0p5"] = pred
    return metrics, preds, model

def run(cfg):
    merged, features, audit = load_joined(cfg)
    # Set numeric direction and profitability targets separately.
    merged["target_price_direction"] = merged["_price_direction"]
    merged["target_trade_profitability"] = merged["_trade_profitable"]
    # Model features are numeric panel fields only. Never include outcomes or trade metadata.
    banned = {"_price_direction", "_trade_profitable", "_net_pnl", "_exit_day", "_signal_day", "_symbol"}
    features = [c for c in features if c not in banned]
    # Avoid absurdly wide first run; retain stable numeric columns up to configured cap.
    features = features[:int(cfg.get("max_features", 500))]
    dates = np.array(sorted(merged["_signal_day"].dropna().unique()))
    if len(dates) == 0:
        raise ValueError("No joined signal dates.")
    min_train = int(cfg.get("min_train_days", 504))
    test_len = int(cfg.get("test_fold_days", 126))
    purge_days = int(cfg.get("purge_days", 8))
    rows_metrics, rows_preds = [], []
    target_map = {
        "price_direction": "target_price_direction",
        "net_trade_profitability": "target_trade_profitability"
    }
    for target_name, target_col in target_map.items():
        fold = 0
        test_start_idx = min_train
        while test_start_idx < len(dates):
            test_dates = dates[test_start_idx:test_start_idx+test_len]
            if len(test_dates) == 0: break
            first_test = pd.Timestamp(test_dates[0])
            cutoff = first_test - pd.Timedelta(days=purge_days)
            train = merged[merged["_signal_day"] < cutoff].copy()
            test = merged[merged["_signal_day"].isin(test_dates)].copy()
            fold += 1
            metrics, preds, model = score_fold(train, test, features, target_col, fold)
            if metrics:
                metrics["model_target"] = target_name
                rows_metrics.append(metrics)
                preds["model_target"] = target_name
                rows_preds.append(preds)
                # Save last fold model as a research artifact only.
                out = Path(cfg["output_dir"])
                out.mkdir(parents=True, exist_ok=True)
                joblib.dump({"model": model, "features": features, "target": target_name},
                            out / f"latest_{target_name}_model.joblib")
            test_start_idx += test_len
    out = Path(cfg["output_dir"])
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "join_audit.json", "w", encoding="utf-8") as f:
        json.dump(audit, f, indent=2)
    pd.DataFrame(rows_metrics).to_csv(out / "model_summary.csv", index=False)
    if rows_preds:
        pd.concat(rows_preds, ignore_index=True).to_csv(out / "walk_forward_predictions.csv", index=False)
    print(json.dumps(audit, indent=2))
    print(f"\nWrote research outputs to: {out.resolve()}")
    print(f"Feature candidates before fold-specific missingness: {len(features)}")
    if audit["match_rate"] < 0.99:
        print("WARNING: Join match rate below 99%. Inspect unmatched dates/symbols before trusting model metrics.")
    print("Research-only: do not use these models in production until targets/timing and walk-forward results are reviewed.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.json")
    args = ap.parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        config = json.load(f)
    run(config)
