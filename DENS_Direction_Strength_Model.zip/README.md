# D/ENS Direction + Strength Research Models

Purpose: research-only models on **existing D/ENS picks**. D/ENS selection, ranks, entry/exit rules, and production behavior are not changed.

## Two separate target families

1. **Forward price direction**: uses `label_fwd_ret_5d` from the feature panel, with a binary direction target `label_fwd_ret_5d > 0`. This is a 5-day forward label, NOT assumed to equal the production six-day trade.
2. **Actual D/ENS trade profitability**: uses `net_hold > 0` from `trades_oos.csv`. The `net_hold` column is treated as already net of the costs embedded in the supplied file; this code does not subtract costs again. `net_hold` is P&L, not a percentage return unless trade notional is known.

The first version trains two classifiers. It does not claim a validated edge. Run only after confirming that `label_fwd_ret_5d` is aligned to the signal timestamp and that `net_hold` is the intended production six-day exit outcome.

## Files expected

- `panel.parquet`: the full feature panel
- `trades_oos.csv`: existing OOS trade outcomes with columns such as `signal_day`, `symbol`, `net_hold`, `hold_exit_day`
- Set paths in `config.json`.

The code reads only selected columns from Parquet and filters to dates/symbols appearing in D/ENS picks. It does not write to or modify the source panel/trades file.

## Run

```bash
python -m pip install -r requirements.txt
python run_models.py --config config.json
```

It writes a timestamped research output folder with:
- `join_audit.json`
- `walk_forward_predictions.csv`
- `model_summary.csv`
- fitted models for the latest fold (research artifact only)

## Method controls

- Only D/ENS picks are included in the profitability target.
- All `label_` columns are excluded from predictors.
- `timestamp`, `symbol`, trade outcomes, rank, and post-entry fields are not predictors.
- Chronological expanding-window folds, with a purge/embargo in calendar days between training and test.
- Two targets are reported separately. Never conflate 5-day forward price direction with six-day net trade profitability.
- The script reports fold-level sample counts and basic classification metrics. It does not perform portfolio drawdown reconstruction, cost sensitivity, probability calibration, or hyperparameter discovery yet.
- Treat the results as preliminary until the signal timestamp, entry convention, label definitions, missingness, and sample overlap are independently validated.
